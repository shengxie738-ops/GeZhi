"""向量存储抽象基类。"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class VectorRecord:
    """向量记录。"""

    id: str = field(description="向量 ID")
    vector: List[float] = field(description="向量数据")
    payload: Dict[str, Any] = field(default_factory=dict, description="附带元数据")


@dataclass
class SearchResult:
    """检索结果。"""

    id: str = field(description="向量 ID")
    score: float = field(description="相似度得分")
    payload: Dict[str, Any] = field(default_factory=dict, description="附带元数据")


class BaseVectorStore(ABC):
    """向量存储抽象基类。"""

    @abstractmethod
    async def create_collection(self, dimension: int) -> None:
        """创建向量集合（如果不存在）。

        Args:
            dimension: 向量维度。
        """
        ...

    @abstractmethod
    async def upsert_vectors(self, records: List[VectorRecord]) -> int:
        """批量写入/更新向量。

        Args:
            records: 向量记录列表。

        Returns:
            成功写入的记录数。
        """
        ...

    @abstractmethod
    async def search(
        self,
        vector: List[float],
        top_k: int = 10,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[SearchResult]:
        """向量检索。

        Args:
            vector: 查询向量。
            top_k: 返回结果数量。
            filters: 过滤条件。

        Returns:
            检索结果列表。
        """
        ...

    @abstractmethod
    async def delete_by_document(self, document_id: str) -> int:
        """按文档 ID 删除向量。

        Args:
            document_id: 文档 ID。

        Returns:
            删除的记录数。
        """
        ...

    @abstractmethod
    async def delete_by_course(self, course_id: str) -> int:
        """按课程 ID 删除向量。

        Args:
            course_id: 课程 ID。

        Returns:
            删除的记录数。
        """
        ...

    @abstractmethod
    async def update_payload(self, point_id: str, payload: Dict[str, Any]) -> bool:
        """更新向量的 payload。

        Args:
            point_id: 向量 ID。
            payload: 要更新的字段。

        Returns:
            是否更新成功。
        """
        ...
