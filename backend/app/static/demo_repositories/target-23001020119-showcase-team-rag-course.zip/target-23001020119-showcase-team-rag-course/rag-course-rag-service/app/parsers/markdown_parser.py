"""Markdown 文档解析器。"""

from __future__ import annotations

import logging
from typing import List

from app.parsers.base import BaseParser, ParsedPage

logger = logging.getLogger(__name__)


class MarkdownParser(BaseParser):
    """将 Markdown 文件按一级标题 (#) 分页。"""

    def parse(self, file_bytes: bytes, file_name: str = "") -> List[ParsedPage]:
        """解析 Markdown 文件。

        Args:
            file_bytes: Markdown 文件的原始二进制内容。
            file_name: 文件名。

        Returns:
            ``ParsedPage`` 列表，每个一级标题章节为一页。
        """
        content = file_bytes.decode("utf-8", errors="replace")
        pages = self._split_by_heading(content)

        logger.info("Markdown 解析完成: %s, 共 %d 页", file_name, len(pages))
        return pages

    @staticmethod
    def _split_by_heading(content: str) -> List[ParsedPage]:
        """按一级标题 (#) 拆分 Markdown 内容。"""
        pages: List[ParsedPage] = []
        current_parts: List[str] = []
        page_number = 1

        for line in content.splitlines():
            if line.startswith("# ") and current_parts:
                combined = "\n".join(current_parts)
                cleaned = combined.strip()
                if cleaned:
                    pages.append(ParsedPage(page_number=page_number, text=cleaned))
                page_number += 1
                current_parts = []
            current_parts.append(line)

        # 处理最后一个章节
        if current_parts:
            combined = "\n".join(current_parts)
            cleaned = combined.strip()
            if cleaned:
                pages.append(ParsedPage(page_number=page_number, text=cleaned))

        return pages if pages else [ParsedPage(page_number=1, text=content.strip())]
