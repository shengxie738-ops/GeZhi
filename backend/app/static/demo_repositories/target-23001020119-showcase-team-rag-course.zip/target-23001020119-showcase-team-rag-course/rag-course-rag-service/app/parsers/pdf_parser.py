"""PDF 文档解析器 — 基于 PyMuPDF 提取文本并保留页码信息。"""

from __future__ import annotations

import io
import logging
from typing import List

from app.parsers.base import BaseParser, ParsedPage

logger = logging.getLogger(__name__)


class PDFParser(BaseParser):
    """使用 PyMuPDF (fitz) 解析 PDF 文档。"""

    def parse(self, file_bytes: bytes, file_name: str = "") -> List[ParsedPage]:
        """逐页提取 PDF 文本。

        Args:
            file_bytes: PDF 文件的原始二进制内容。
            file_name: 文件名（用于日志）。

        Returns:
            ``ParsedPage`` 列表，每条包含 ``page_number`` 和 ``text``。
        """
        try:
            import fitz  # PyMuPDF
        except ImportError:
            logger.error("PyMuPDF (fitz) 未安装，无法解析 PDF 文件")
            raise

        pages: List[ParsedPage] = []
        doc = fitz.open(stream=io.BytesIO(file_bytes), filetype="pdf")

        try:
            for page_idx in range(len(doc)):
                page = doc.load_page(page_idx)
                text = page.get_text("text")
                cleaned = self._clean_page_text(text)
                if cleaned:
                    pages.append(
                        ParsedPage(page_number=page_idx + 1, text=cleaned)
                    )
            logger.info("PDF 解析完成: %s, 共 %d 页", file_name, len(pages))
        finally:
            doc.close()

        return pages
