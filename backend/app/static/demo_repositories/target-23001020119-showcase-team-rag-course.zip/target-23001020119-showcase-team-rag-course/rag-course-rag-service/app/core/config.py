"""应用配置 — 基于 Pydantic BaseSettings，从环境变量 / .env 加载。"""

from __future__ import annotations

from typing import List

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """全局配置项，与 .env 文件一一对应。"""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ===== Application =====
    app_env: str = "development"
    app_debug: bool = True
    app_port: int = 8000
    cors_origins: List[str] = ["*"]

    # ===== Mock Mode =====
    mock_mode: bool = True

    # ===== Qdrant =====
    qdrant_url: str = "http://localhost:6333"
    qdrant_api_key: str = ""
    qdrant_collection: str = "rag_course_chunks"

    # ===== MySQL =====
    mysql_host: str = "localhost"
    mysql_port: int = 3306
    mysql_user: str = "root"
    mysql_password: str = "password"
    mysql_database: str = "rag_course"

    # ===== Redis =====
    redis_host: str = "localhost"
    redis_port: int = 6379
    redis_db: int = 0
    redis_password: str = ""

    # ===== Embedding =====
    embedding_provider: str = "local"  # local | openai | qwen
    embedding_model: str = "shibing624/text2vec-base-chinese"
    embedding_dimension: int = 768

    # ===== Chat / LLM =====
    chat_provider: str = "openai"  # openai | mock
    chat_model: str = "gpt-4o"
    model_api_key: str = ""
    model_base_url: str = "https://api.openai.com/v1"

    # ===== Security =====
    rag_internal_token: str = "dev-internal-token-change-in-production"

    # ===== BM25 =====
    bm25_k1: float = 1.5
    bm25_b: float = 0.75

    # ===== Retrieval =====
    vector_search_top_k: int = 20
    bm25_search_top_k: int = 20
    hybrid_top_k: int = 10
    rerank_top_n: int = 5
    keyword_weight: float = 0.3
    vector_weight: float = 0.7
    verified_qa_weight: float = 0.2
    min_relevance_score: float = 0.3

    # ===== Chunking =====
    chunk_size: int = 512
    chunk_overlap: int = 128


settings = Settings()
