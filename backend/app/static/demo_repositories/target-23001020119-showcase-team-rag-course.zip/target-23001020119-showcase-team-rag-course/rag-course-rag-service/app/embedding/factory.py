"""Embedding Provider 工厂。"""

from __future__ import annotations

import logging

from app.core.config import settings
from app.embedding.base import BaseEmbeddingProvider

logger = logging.getLogger(__name__)


class EmbeddingFactory:
    """根据配置选择 Embedding Provider。"""

    @staticmethod
    def create() -> BaseEmbeddingProvider:
        """创建 Embedding Provider 实例。

        Returns:
            根据 ``settings.embedding_provider`` 返回对应实例。

        Raises:
            ValueError: 不支持的 provider 类型。
        """
        provider = settings.embedding_provider.lower()

        if provider == "local":
            from app.embedding.local_provider import LocalEmbeddingProvider

            return LocalEmbeddingProvider()
        elif provider == "openai":
            from app.embedding.openai_provider import OpenAIEmbeddingProvider

            return OpenAIEmbeddingProvider()
        elif provider == "qwen":
            from app.embedding.qwen_provider import QwenEmbeddingProvider

            return QwenEmbeddingProvider()
        else:
            raise ValueError(f"不支持的 Embedding Provider: {provider}")
