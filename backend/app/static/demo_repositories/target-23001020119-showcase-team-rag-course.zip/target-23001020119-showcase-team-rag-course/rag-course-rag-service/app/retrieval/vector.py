"""向量检索器。"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple

from app.core.config import settings
from app.vectorstore.base import BaseVectorStore

logger = logging.getLogger(__name__)


class VectorRetriever:
    """基于向量相似度的检索器。"""

    def __init__(self, vector_store: BaseVectorStore):
        self.vector_store = vector_store

    async def search(
        self,
        query_vector: List[float],
        top_k: int | None = None,
        course_id: str | None = None,
        chapter_id: str | None = None,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[Tuple[str, float, Dict[str, Any]]]:
        """向量相似度检索。

        Args:
            query_vector: 查询向量。
            top_k: 返回结果数量。
            course_id: 课程 ID 过滤。
            chapter_id: 章节 ID 过滤（可选）。
            filters: 额外过滤条件。

        Returns:
            ``(chunk_id, score, payload)`` 列表。
        """
        top_k = top_k or settings.vector_search_top_k

        # 构建过滤条件
        search_filters = filters or {}
        if course_id:
            search_filters["course_id"] = course_id
        if chapter_id:
            search_filters["chapter_id"] = chapter_id

        results = await self.vector_store.search(
            vector=query_vector,
            top_k=top_k,
            filters=search_filters if search_filters else None,
        )

        return [
            (r.id, r.score, r.payload)
            for r in results
        ]
