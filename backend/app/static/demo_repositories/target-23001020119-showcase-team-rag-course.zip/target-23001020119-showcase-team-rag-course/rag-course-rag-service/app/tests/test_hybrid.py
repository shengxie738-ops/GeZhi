"""混合检索器测试。"""

from __future__ import annotations

import pytest

from app.retrieval.hybrid import HybridRetriever, HybridResult
from app.retrieval.reranker import Reranker


class TestHybridRetriever:
    """混合检索融合测试。"""

    def setup_method(self):
        self.retriever = HybridRetriever()

    def test_combine_empty(self):
        """测试空结果合并。"""
        results = self.retriever.combine([], [])
        assert results == []

    def test_combine_vector_only(self):
        """测试仅向量结果。"""
        vector_results = [
            {"chunk_id": "v1", "score": 0.9, "payload": {"teacher_verified": False}},
            {"chunk_id": "v2", "score": 0.7, "payload": {"teacher_verified": False}},
        ]
        results = self.retriever.combine(vector_results, [])
        assert len(results) == 2
        assert results[0].chunk_id == "v1"

    def test_combine_bm25_only(self):
        """测试仅 BM25 结果。"""
        bm25_results = [
            {"chunk_id": "b1", "score": 5.0, "payload": {}},
            {"chunk_id": "b2", "score": 3.0, "payload": {}},
        ]
        results = self.retriever.combine([], bm25_results)
        assert len(results) == 2

    def test_combine_dedup(self):
        """测试重复结果去重和分数叠加。"""
        vector_results = [
            {"chunk_id": "v1", "score": 0.9, "payload": {}},
            {"chunk_id": "v2", "score": 0.5, "payload": {}},
        ]
        bm25_results = [
            {"chunk_id": "v1", "score": 5.0, "payload": {}},
            {"chunk_id": "b1", "score": 3.0, "payload": {}},
        ]
        results = self.retriever.combine(vector_results, bm25_results, top_k=10)
        ids = [r.chunk_id for r in results]
        # v1 出现在两个结果中，应该只出现一次
        assert ids.count("v1") == 1

    def test_combine_verified_bonus(self):
        """测试教师审核通过的加分。"""
        vector_results = [
            {"chunk_id": "v1", "score": 0.5, "payload": {"teacher_verified": True}},
            {"chunk_id": "v2", "score": 0.5, "payload": {"teacher_verified": False}},
        ]
        results = self.retriever.combine(vector_results, [])
        # v1 有 verified 加分，应该排在 v2 前面
        assert results[0].chunk_id == "v1"

    def test_combine_top_k(self):
        """测试 top_k 截断。"""
        vector_results = [
            {"chunk_id": f"v{i}", "score": 1.0 - i * 0.1, "payload": {}}
            for i in range(10)
        ]
        results = self.retriever.combine(vector_results, [], top_k=3)
        assert len(results) == 3


class TestReranker:
    """重排序器测试。"""

    def setup_method(self):
        self.reranker = Reranker(top_n=3, min_score=0.3)

    def test_rerank_basic(self):
        """测试基本重排序。"""
        results = [
            {"chunk_id": "c1", "score": 0.5},
            {"chunk_id": "c2", "score": 0.9},
            {"chunk_id": "c3", "score": 0.1},
            {"chunk_id": "c4", "score": 0.7},
        ]
        reranked = self.reranker.rerank(results)
        assert len(reranked) == 3
        # 按分数降序
        assert reranked[0]["chunk_id"] == "c2"
        assert reranked[1]["chunk_id"] == "c4"
        assert reranked[2]["chunk_id"] == "c1"
        # c3 分数低于 min_score 被过滤
        assert all(r["chunk_id"] != "c3" for r in reranked)

    def test_rerank_empty(self):
        """测试空结果。"""
        reranked = self.reranker.rerank([])
        assert reranked == []
