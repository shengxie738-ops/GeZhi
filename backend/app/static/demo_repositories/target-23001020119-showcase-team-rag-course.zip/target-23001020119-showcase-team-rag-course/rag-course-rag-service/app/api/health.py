"""健康检查端点。"""

from __future__ import annotations

import time
from typing import Any, Dict

from fastapi import APIRouter

from app.core.config import settings

router = APIRouter()

_start_time: float = time.time()


@router.get("/health")
async def health_check() -> Dict[str, Any]:
    """健康检查端点。

    返回服务状态、运行时间和配置摘要。
    """
    # TODO: 检查 Qdrant、MySQL、Redis 连接状态
    return {
        "status": "healthy",
        "service": "rag-course-service",
        "version": "0.1.0",
        "mock_mode": settings.mock_mode,
        "uptime_seconds": round(time.time() - _start_time, 2),
        "checks": {
            "qdrant": "skipped" if settings.mock_mode else "not_implemented",
            "mysql": "skipped" if settings.mock_mode else "not_implemented",
            "redis": "skipped" if settings.mock_mode else "not_implemented",
        },
    }
