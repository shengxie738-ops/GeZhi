"""切分器工厂。"""

from __future__ import annotations

import logging
from typing import Literal

from app.chunking.base import BaseChunker
from app.chunking.overlap_chunker import OverlapChunker
from app.chunking.semantic_chunker import SemanticChunker

logger = logging.getLogger(__name__)


class ChunkerFactory:
    """根据配置返回对应的切分器实例。"""

    @staticmethod
    def get_chunker(
        method: Literal["overlap", "semantic"] = "overlap",
    ) -> BaseChunker:
        """获取切分器。

        Args:
            method: 切分方法 — ``overlap``（重叠窗口）或 ``semantic``（语义切分）。

        Returns:
            对应的 ``BaseChunker`` 实例。
        """
        if method == "semantic":
            return SemanticChunker()
        return OverlapChunker()
