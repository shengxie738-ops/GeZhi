"""BM25 关键词检索器。"""

from __future__ import annotations

import logging
from typing import Dict, List, Tuple

import jieba
from rank_bm25 import BM25Okapi

from app.core.config import settings

logger = logging.getLogger(__name__)


class BM25Retriever:
    """基于 BM25 的中文关键词检索器。

    使用 jieba 进行中文分词，支持增量索引。
    """

    def __init__(self, k1: float | None = None, b: float | None = None):
        self.k1 = k1 or settings.bm25_k1
        self.b = b or settings.bm25_b
        self._bm25: BM25Okapi | None = None
        self._corpus_ids: List[str] = []
        self._corpus_tokens: List[List[str]] = []

    def index_corpus(self, chunk_ids: List[str], texts: List[str]) -> None:
        """索引文档语料。

        Args:
            chunk_ids: 知识块 ID 列表。
            texts: 对应的文本列表。
        """
        self._corpus_ids = list(chunk_ids)
        self._corpus_tokens = [self._tokenize(text) for text in texts]
        self._bm25 = BM25Okapi(
            self._corpus_tokens,
            k1=self.k1,
            b=self.b,
        )
        logger.info("BM25 索引完成: %d 个文档", len(self._corpus_ids))

    def search(
        self,
        query: str,
        top_k: int | None = None,
    ) -> List[Tuple[str, float]]:
        """关键词检索。

        Args:
            query: 查询文本。
            top_k: 返回结果数量。

        Returns:
            ``(chunk_id, score)`` 列表，按得分降序排列。
        """
        if self._bm25 is None or not self._corpus_ids:
            return []

        top_k = top_k or settings.bm25_search_top_k
        query_tokens = self._tokenize(query)
        scores = self._bm25.get_scores(query_tokens)

        # 合并 (id, score) 并排序
        scored = list(zip(self._corpus_ids, scores))
        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[:top_k]

    def clear(self) -> None:
        """清空索引。"""
        self._bm25 = None
        self._corpus_ids = []
        self._corpus_tokens = []

    @staticmethod
    def _tokenize(text: str) -> List[str]:
        """使用 jieba 分词。"""
        return list(jieba.cut_for_search(text))
