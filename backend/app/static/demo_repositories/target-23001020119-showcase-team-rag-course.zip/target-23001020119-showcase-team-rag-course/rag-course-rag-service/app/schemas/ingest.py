"""文档入库（Ingest）请求 / 响应模型。"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field

from app.schemas.common import FileUploadInfo


class IngestStatus(str, Enum):
    """入库任务状态。"""

    PENDING = "pending"
    PARSING = "parsing"
    CHUNKING = "chunking"
    EMBEDDING = "embedding"
    INDEXING = "indexing"
    COMPLETED = "completed"
    FAILED = "failed"


class IngestDocument(BaseModel):
    """单个入库文档。"""

    document_id: str = Field(description="文档 ID（由上游系统分配）")
    course_id: str = Field(description="课程 ID")
    chapter_id: Optional[str] = Field(default=None, description="章节 ID")
    title: Optional[str] = Field(default=None, description="文档标题")
    source_type: str = Field(default="document", description="来源类型：document | qa_pair | note")
    file_info: FileUploadInfo = Field(description="文件信息")
    teacher_verified: bool = Field(default=False, description="是否教师审核通过")


class IngestRequest(BaseModel):
    """入库请求体。"""

    documents: List[IngestDocument] = Field(
        description="待入库文档列表，支持批量"
    )


class IngestResult(BaseModel):
    """单个文档入库结果。"""

    document_id: str
    status: IngestStatus
    chunk_count: int = Field(default=0, description="生成的知识块数量")
    vector_count: int = Field(default=0, description="写入向量库的数量")
    error_message: Optional[str] = Field(default=None, description="失败时的错误信息")
    started_at: Optional[datetime] = Field(default=None)
    completed_at: Optional[datetime] = Field(default=None)


class IngestResponse(BaseModel):
    """入库响应体。"""

    batch_id: str = Field(description="批次 ID")
    total: int = Field(description="文档总数")
    accepted: int = Field(description="接受入库的数量")
    results: List[IngestResult] = Field(default_factory=list)
