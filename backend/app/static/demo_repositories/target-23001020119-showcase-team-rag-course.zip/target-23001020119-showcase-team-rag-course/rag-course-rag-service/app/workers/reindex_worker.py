"""重建索引工作流 — 重新切分、向量化并更新向量存储。"""

from __future__ import annotations

import logging
import uuid
from typing import Any, Dict, List, Optional

from app.chunking.factory import ChunkerFactory
from app.core.config import settings
from app.db.base import BaseDBClient
from app.embedding.base import BaseEmbeddingProvider
from app.parsers.text_cleaner import TextCleaner
from app.vectorstore.base import BaseVectorStore, VectorRecord

logger = logging.getLogger(__name__)


class ReindexWorker:
    """重建索引工作流。

    用于当切分策略或 Embedding 模型变更后，对已有文档重新索引。
    """

    def __init__(
        self,
        vector_store: BaseVectorStore,
        embedding_provider: BaseEmbeddingProvider,
        db_client: BaseDBClient,
    ):
        self.vector_store = vector_store
        self.embedding_provider = embedding_provider
        self.db_client = db_client
        self.cleaner = TextCleaner()

    async def reindex_course(self, course_id: str) -> Dict[str, Any]:
        """重建某门课程的全部索引。

        Args:
            course_id: 课程 ID。

        Returns:
            重建结果统计。
        """
        logger.info("开始重建课程索引: %s", course_id)

        # 1. 获取该课程下所有知识块
        chunks = await self.db_client.get_chunks_by_course(course_id)
        if not chunks:
            logger.info("课程 %s 无知识块，跳过重建", course_id)
            return {"course_id": course_id, "total": 0, "reindexed": 0}

        # 2. 删除原有向量
        await self.vector_store.delete_by_course(course_id)

        # 3. 重新向量化
        texts = [c.get("text", "") for c in chunks]
        embeddings = await self.embedding_provider.embed_texts(texts)

        # 4. 写入新向量
        records: List[VectorRecord] = []
        for chunk, embedding in zip(chunks, embeddings):
            chunk_id = chunk.get("vector_id") or str(uuid.uuid4())
            payload = {
                "course_id": chunk.get("course_id", course_id),
                "chapter_id": chunk.get("chapter_id", ""),
                "document_id": chunk.get("document_id", ""),
                "chunk_id": chunk_id,
                "source_type": chunk.get("source_type", "document"),
                "title": chunk.get("title", ""),
                "page_start": chunk.get("page_start", 0),
                "page_end": chunk.get("page_end", 0),
                "title_path": chunk.get("title_path", ""),
                "enabled": chunk.get("enabled", True),
                "teacher_verified": chunk.get("teacher_verified", False),
                "text_preview": chunk.get("text", "")[:200],
            }
            records.append(VectorRecord(id=chunk_id, vector=embedding, payload=payload))

        vector_count = await self.vector_store.upsert_vectors(records)

        result = {
            "course_id": course_id,
            "total": len(chunks),
            "reindexed": vector_count,
        }
        logger.info("课程索引重建完成: %s", result)
        return result

    async def reindex_document(self, document_id: str) -> Dict[str, Any]:
        """重建某个文档的索引。

        Args:
            document_id: 文档 ID。

        Returns:
            重建结果统计。
        """
        logger.info("开始重建文档索引: %s", document_id)

        # 删除原有向量
        await self.vector_store.delete_by_document(document_id)

        # 获取该文档的知识块
        chunks = await self.db_client.get_chunks_by_document(document_id)
        if not chunks:
            return {"document_id": document_id, "total": 0, "reindexed": 0}

        texts = [c.get("text", "") for c in chunks]
        embeddings = await self.embedding_provider.embed_texts(texts)

        records: List[VectorRecord] = []
        for chunk, embedding in zip(chunks, embeddings):
            chunk_id = chunk.get("vector_id") or str(uuid.uuid4())
            payload = {
                "course_id": chunk.get("course_id", ""),
                "chapter_id": chunk.get("chapter_id", ""),
                "document_id": chunk.get("document_id", document_id),
                "chunk_id": chunk_id,
                "source_type": chunk.get("source_type", "document"),
                "title": chunk.get("title", ""),
                "page_start": chunk.get("page_start", 0),
                "page_end": chunk.get("page_end", 0),
                "title_path": chunk.get("title_path", ""),
                "enabled": chunk.get("enabled", True),
                "teacher_verified": chunk.get("teacher_verified", False),
                "text_preview": chunk.get("text", "")[:200],
            }
            records.append(VectorRecord(id=chunk_id, vector=embedding, payload=payload))

        vector_count = await self.vector_store.upsert_vectors(records)

        result = {
            "document_id": document_id,
            "total": len(chunks),
            "reindexed": vector_count,
        }
        logger.info("文档索引重建完成: %s", result)
        return result
