"""引用构建器 — 从检索结果构建引用列表。"""

from __future__ import annotations

import logging
from typing import Any, Dict, List

from app.schemas.generate import Citation

logger = logging.getLogger(__name__)


class CitationBuilder:
    """从检索结果构建引用列表。"""

    @staticmethod
    def build_citations(
        retrieved_chunks: List[Dict[str, Any]],
    ) -> List[Citation]:
        """构建引用列表。

        Args:
            retrieved_chunks: 检索到的知识块信息列表。

        Returns:
            ``Citation`` 列表，每条带唯一编号。
        """
        citations: List[Citation] = []

        for i, chunk in enumerate(retrieved_chunks, 1):
            # 取文本的前 200 字符作为引用原文片段
            full_text = chunk.get("text", "")
            source_text = full_text[:200] + ("..." if len(full_text) > 200 else "")

            citation = Citation(
                citation_id=f"[{i}]",
                chunk_id=chunk.get("chunk_id", ""),
                document_id=chunk.get("document_id", ""),
                title=chunk.get("title", "未知来源"),
                source_text=source_text,
                page_start=chunk.get("page_start"),
                page_end=chunk.get("page_end"),
                score=chunk.get("score", 0.0),
            )
            citations.append(citation)

        logger.debug("构建 %d 条引用", len(citations))
        return citations

    @staticmethod
    def format_citation_source(citation: Citation) -> str:
        """格式化单条引用来源文本。

        Args:
            citation: 引用信息。

        Returns:
            格式化的引用字符串。
        """
        pages = ""
        if citation.page_start and citation.page_end:
            if citation.page_start == citation.page_end:
                pages = f" 第{citation.page_start}页"
            else:
                pages = f" 第{citation.page_start}-{citation.page_end}页"

        title = citation.title or "未知来源"
        return f"{citation.citation_id} 《{title}》{pages}"
