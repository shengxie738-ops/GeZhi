"""Prompt 构建器 — 构建系统提示词和用户提问 prompt。"""

from __future__ import annotations

from typing import Any, Dict, List, Optional


class PromptBuilder:
    """Prompt 构建工具。"""

    SYSTEM_PROMPT_TEMPLATE = """你是一个人工智能技术基础课程（RAG 教学系统）的智能助教。
你的职责是基于提供的课程资料，准确、专业地回答学生的问题。

## 回答规则

1. **基于证据回答**：你的回答必须基于下方提供的参考资料。如果参考资料中没有足够的信息来回答问题，请明确告知学生"当前资料中未找到相关内容"。
2. **引用标注**：在回答中引用资料时，使用 [1]、[2] 等编号标注来源。
3. **准确客观**：不要编造资料中没有的信息。
4. **语言风格**：使用清晰、简洁的中文，适合大学生理解。
5. **格式要求**：使用 Markdown 格式组织回答，包括适当的标题、列表和加粗。
6. **学术严谨**：对于技术概念，给出准确的定义和解释。

## 回答格式

- 先给出直接回答
- 再提供详细解释（如有需要）
- 最后列出引用来源

## 引用来源格式

在回答末尾列出所有引用的来源：
[1] 《文档标题》第X页
[2] 《文档标题》第X-Y页
"""

    USER_PROMPT_TEMPLATE = """## 参考资料

{context}

---

## 学生提问

{query}
"""

    EVIDENCE_INSUFFICIENT_TEMPLATE = """根据当前课程资料库中的内容，未能找到与您的问题直接相关的资料。

建议：
1. 尝试换一种方式描述您的问题
2. 查阅课程教材的相关章节
3. 向任课教师提问

> 当前检索到的参考资料不足以支撑对该问题的回答。"""

    @classmethod
    def build_system_prompt(cls) -> str:
        """构建系统提示词。"""
        return cls.SYSTEM_PROMPT_TEMPLATE

    @classmethod
    def build_user_prompt(
        cls,
        query: str,
        context_chunks: List[Dict[str, Any]],
    ) -> str:
        """构建用户提问 prompt。

        Args:
            query: 用户问题。
            context_chunks: 检索到的上下文知识块列表。

        Returns:
            格式化的用户 prompt。
        """
        context_parts: List[str] = []
        for i, chunk in enumerate(context_chunks, 1):
            title = chunk.get("title", "未知来源")
            page_start = chunk.get("page_start", "?")
            page_end = chunk.get("page_end", "?")
            text = chunk.get("text", "")
            source_type = chunk.get("source_type", "document")

            context_parts.append(
                f"**[{i}]** 《{title}》 第{page_start}-{page_end}页 "
                f"[{source_type}]\n\n{text}"
            )

        context = "\n\n---\n\n".join(context_parts) if context_parts else "（无可用参考资料）"

        return cls.USER_PROMPT_TEMPLATE.format(
            context=context,
            query=query,
        )

    @classmethod
    def build_evidence_insufficient_response(cls) -> str:
        """构建证据不足时的默认回答。"""
        return cls.EVIDENCE_INSUFFICIENT_TEMPLATE
