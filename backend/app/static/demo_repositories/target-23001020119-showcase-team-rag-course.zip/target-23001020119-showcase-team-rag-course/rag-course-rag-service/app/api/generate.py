"""生成回答 API 端点。"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, List

from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse

from app.core.config import settings
from app.core.security import verify_internal_token
from app.db.mock_client import MockDBClient
from app.db.mysql_client import MySQLClient
from app.embedding.base import BaseEmbeddingProvider
from app.embedding.factory import EmbeddingFactory
from app.generation.answer_generator import AnswerGenerator
from app.generation.citation_builder import CitationBuilder
from app.retrieval.hybrid import HybridRetriever
from app.retrieval.reranker import Reranker
from app.retrieval.vector import VectorRetriever
from app.schemas.common import ApiResponse
from app.schemas.generate import (
    AnswerStatus,
    GenerateRequest,
    GenerateResponse,
)
from app.vectorstore.base import BaseVectorStore
from app.vectorstore.mock_store import MockVectorStore
from app.vectorstore.qdrant_store import QdrantVectorStore

logger = logging.getLogger(__name__)
router = APIRouter()


def _get_vector_store() -> BaseVectorStore:
    if settings.mock_mode:
        return MockVectorStore()
    return QdrantVectorStore()


def _get_db_client():
    if settings.mock_mode:
        return MockDBClient()
    return MySQLClient()


def _get_embedding_provider() -> BaseEmbeddingProvider:
    if settings.mock_mode:
        from app.embedding.local_provider import LocalEmbeddingProvider
        return LocalEmbeddingProvider()
    return EmbeddingFactory.create()


async def _retrieve_context(
    query: str,
    course_id: str,
    top_k: int,
    embedding_provider: BaseEmbeddingProvider,
    vector_store: BaseVectorStore,
) -> List[Dict[str, Any]]:
    """检索上下文知识块。"""
    query_vector = await embedding_provider.embed_text(query)

    vector_retriever = VectorRetriever(vector_store=vector_store)
    vector_results = await vector_retriever.search(
        query_vector=query_vector,
        top_k=top_k,
        course_id=course_id,
    )

    # 简单返回向量检索结果作为上下文
    context: List[Dict[str, Any]] = []
    for r in vector_results:
        payload = r.payload
        context.append({
            "chunk_id": r.id,
            "text": payload.get("text_preview", ""),
            "document_id": payload.get("document_id", ""),
            "title": payload.get("title", ""),
            "page_start": payload.get("page_start", 0),
            "page_end": payload.get("page_end", 0),
            "source_type": payload.get("source_type", "document"),
            "score": r.score,
        })
    return context


@router.post("/generate", response_model=ApiResponse[GenerateResponse])
async def generate_answer(
    request: GenerateRequest,
    _token: None = Depends(verify_internal_token),
) -> ApiResponse[GenerateResponse]:
    """生成回答端点。

    检索上下文 → 构建 Prompt → 调用 LLM → 返回带引用的回答。
    """
    logger.info(
        "收到生成请求: query=%s, course_id=%s, stream=%s",
        request.query,
        request.course_id,
        request.stream,
    )

    vector_store = _get_vector_store()
    embedding_provider = _get_embedding_provider()
    db_client = _get_db_client()

    # 检索上下文
    context_chunks = await _retrieve_context(
        query=request.query,
        course_id=request.course_id,
        top_k=request.top_k,
        embedding_provider=embedding_provider,
        vector_store=vector_store,
    )

    # 流式模式
    if request.stream:
        generator = AnswerGenerator()

        async def event_stream():
            async for chunk in generator.stream_generate(
                query=request.query,
                context_chunks=context_chunks,
                conversation_history=request.conversation_history,
            ):
                yield chunk

        return StreamingResponse(event_stream(), media_type="text/event-stream")

    # 非流式模式
    generator = AnswerGenerator()
    gen_result = await generator.generate(
        query=request.query,
        context_chunks=context_chunks,
        conversation_history=request.conversation_history,
    )

    # 构建引用
    citation_builder = CitationBuilder()
    citations = citation_builder.build_citations(context_chunks)

    # 保存聊天记录（异步，不阻塞响应）
    try:
        message_id = await db_client.save_chat_message(
            course_id=request.course_id,
            query=request.query,
            answer=gen_result.get("answer", ""),
            model_used=gen_result.get("model_used"),
        )
        for citation in citations:
            await db_client.save_citation(
                message_id=message_id,
                chunk_id=citation.chunk_id,
                citation_text=citation.source_text,
                score=citation.score,
            )
    except Exception:
        logger.exception("保存聊天记录失败")

    # 判断答案状态
    status = AnswerStatus.SUCCESS
    if gen_result.get("status") == "error":
        status = AnswerStatus.ERROR
    elif not context_chunks:
        status = AnswerStatus.EVIDENCE_INSUFFICIENT

    response_data = GenerateResponse(
        query=request.query,
        answer=gen_result.get("answer", ""),
        status=status,
        citations=citations,
        model_used=gen_result.get("model_used"),
        token_usage=gen_result.get("token_usage"),
    )

    return ApiResponse(data=response_data)
