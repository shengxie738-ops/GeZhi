"""pytest fixtures — 为测试提供通用的 Mock 实例。"""

from __future__ import annotations

import os
from typing import Generator

import pytest

# 确保使用 Mock 模式
os.environ["MOCK_MODE"] = "true"
os.environ["APP_DEBUG"] = "true"


@pytest.fixture
def sample_pdf_bytes() -> bytes:
    """返回一个最小化的 PDF 文件字节内容（仅用于测试解析逻辑）。"""
    # 构造一个极简 PDF（实际测试中可能需要更完整的 PDF）
    return (
        b"%PDF-1.4\n"
        b"1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n"
        b"2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n"
        b"3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] "
        b"/Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>\nendobj\n"
        b"4 0 obj\n<< /Length 44 >>\nstream\nBT /F1 12 Tf 100 700 Td (Hello) Tj ET\nendstream\nendobj\n"
        b"5 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n"
        b"xref\n0 6\n"
        b"0000000000 65535 f \n"
        b"0000000009 00000 n \n"
        b"0000000058 00000 n \n"
        b"0000000115 00000 n \n"
        b"0000000266 00000 n \n"
        b"0000000360 00000 n \n"
        b"trailer\n<< /Size 6 /Root 1 0 R >>\n"
        b"startxref\n439\n%%EOF\n"
    )


@pytest.fixture
def sample_text_content() -> str:
    """返回一段示例中文文本。"""
    return (
        "第一章 人工智能概述\n\n"
        "人工智能（Artificial Intelligence，AI）是计算机科学的一个分支，"
        "致力于研究和开发能够模拟人类智能行为的理论、方法和技术。\n\n"
        "1.1 什么是人工智能\n\n"
        "人工智能是指由人制造出来的系统所表现出来的智能。"
        "通过人工智能的研究，可以将人类的智能扩展到机器上。\n\n"
        "第二章 机器学习基础\n\n"
        "机器学习是人工智能的核心技术之一。"
        "它使计算机系统能够从数据中自动学习和改进，而无需显式编程。\n"
    )


@pytest.fixture
def sample_chunks_data() -> list:
    """返回一组示例知识块数据。"""
    return [
        {
            "chunk_id": "chunk-1",
            "document_id": "doc-1",
            "course_id": "course-1",
            "chapter_id": "ch-1",
            "title": "人工智能概述",
            "text": "人工智能是计算机科学的一个分支，致力于研究和开发能够模拟人类智能行为的理论。",
            "page_start": 1,
            "page_end": 1,
            "score": 0.95,
            "source_type": "document",
            "teacher_verified": True,
        },
        {
            "chunk_id": "chunk-2",
            "document_id": "doc-1",
            "course_id": "course-1",
            "chapter_id": "ch-2",
            "title": "机器学习基础",
            "text": "机器学习是人工智能的核心技术之一，使计算机系统能够从数据中自动学习。",
            "page_start": 2,
            "page_end": 2,
            "score": 0.82,
            "source_type": "document",
            "teacher_verified": False,
        },
    ]


@pytest.fixture
def auth_headers() -> dict:
    """返回包含认证 token 的请求头。"""
    return {
        "Authorization": "Bearer dev-internal-token-change-in-production"
    }
