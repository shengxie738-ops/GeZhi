"""Mock 向量存储 — 内存模拟，用于本地开发和测试。"""

from __future__ import annotations

import logging
import uuid
from typing import Any, Dict, List, Optional

from app.vectorstore.base import BaseVectorStore, SearchResult, VectorRecord

logger = logging.getLogger(__name__)


class MockVectorStore(BaseVectorStore):
    """基于内存的 Mock 向量存储。"""

    def __init__(self):
        self._vectors: Dict[str, VectorRecord] = {}
        self._collection_created = False

    async def create_collection(self, dimension: int) -> None:
        """标记集合已创建。"""
        self._collection_created = True
        logger.info("[Mock] 向量集合创建完成, 维度=%d", dimension)

    async def upsert_vectors(self, records: List[VectorRecord]) -> int:
        """写入向量到内存。"""
        for record in records:
            self._vectors[record.id] = record
        logger.info("[Mock] 写入 %d 条向量, 总计 %d", len(records), len(self._vectors))
        return len(records)

    async def search(
        self,
        vector: List[float],
        top_k: int = 10,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[SearchResult]:
        """Mock 检索：返回随机匹配结果。"""
        results: List[SearchResult] = []
        for rid, record in self._vectors.items():
            # 检查过滤条件
            if filters:
                match = all(
                    record.payload.get(key) == value
                    for key, value in filters.items()
                )
                if not match:
                    continue

            # Mock 得分：使用简单的向量点积近似
            score = self._mock_score(vector, record.vector)
            results.append(
                SearchResult(id=rid, score=score, payload=record.payload)
            )

        results.sort(key=lambda r: r.score, reverse=True)
        return results[:top_k]

    async def delete_by_document(self, document_id: str) -> int:
        """按文档 ID 删除。"""
        to_delete = [
            rid
            for rid, rec in self._vectors.items()
            if rec.payload.get("document_id") == document_id
        ]
        for rid in to_delete:
            del self._vectors[rid]
        logger.info("[Mock] 按文档删除 %d 条向量: %s", len(to_delete), document_id)
        return len(to_delete)

    async def delete_by_course(self, course_id: str) -> int:
        """按课程 ID 删除。"""
        to_delete = [
            rid
            for rid, rec in self._vectors.items()
            if rec.payload.get("course_id") == course_id
        ]
        for rid in to_delete:
            del self._vectors[rid]
        logger.info("[Mock] 按课程删除 %d 条向量: %s", len(to_delete), course_id)
        return len(to_delete)

    async def update_payload(self, point_id: str, payload: Dict[str, Any]) -> bool:
        """更新 payload。"""
        if point_id not in self._vectors:
            return False
        self._vectors[point_id].payload.update(payload)
        return True

    @staticmethod
    def _mock_score(query_vec: List[float], stored_vec: List[float]) -> float:
        """简单的 Mock 得分计算。"""
        if not query_vec or not stored_vec:
            return 0.0
        min_len = min(len(query_vec), len(stored_vec))
        dot = sum(query_vec[i] * stored_vec[i] for i in range(min_len))
        norm_a = sum(x * x for x in query_vec[:min_len]) ** 0.5
        norm_b = sum(x * x for x in stored_vec[:min_len]) ** 0.5
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return dot / (norm_a * norm_b)
