"""文档入库 API 端点。"""

from __future__ import annotations

import logging
import uuid
from typing import List

from fastapi import APIRouter, Depends

from app.core.config import settings
from app.core.security import verify_internal_token
from app.db.mock_client import MockDBClient
from app.db.mysql_client import MySQLClient
from app.embedding.base import BaseEmbeddingProvider
from app.embedding.factory import EmbeddingFactory
from app.schemas.common import ApiResponse
from app.schemas.ingest import (
    IngestDocument,
    IngestRequest,
    IngestResponse,
    IngestResult,
    IngestStatus,
)
from app.vectorstore.base import BaseVectorStore
from app.vectorstore.mock_store import MockVectorStore
from app.vectorstore.qdrant_store import QdrantVectorStore
from app.workers.ingest_worker import IngestWorker

logger = logging.getLogger(__name__)
router = APIRouter()


def _get_vector_store() -> BaseVectorStore:
    """根据配置获取向量存储实例。"""
    if settings.mock_mode:
        return MockVectorStore()
    return QdrantVectorStore()


def _get_db_client():
    """根据配置获取数据库客户端实例。"""
    if settings.mock_mode:
        return MockDBClient()
    return MySQLClient()


def _get_embedding_provider() -> BaseEmbeddingProvider:
    """根据配置获取 Embedding Provider 实例。"""
    if settings.mock_mode:
        from app.embedding.local_provider import LocalEmbeddingProvider

        return LocalEmbeddingProvider()
    return EmbeddingFactory.create()


@router.post("/ingest", response_model=ApiResponse[IngestResponse])
async def ingest_documents(
    request: IngestRequest,
    _token: None = Depends(verify_internal_token),
) -> ApiResponse[IngestResponse]:
    """文档入库端点。

    接收文档列表，依次执行解析、切分、向量化、入库。
    """
    batch_id = str(uuid.uuid4())
    logger.info("收到入库请求, batch_id=%s, 文档数=%d", batch_id, len(request.documents))

    vector_store = _get_vector_store()
    embedding_provider = _get_embedding_provider()
    db_client = _get_db_client()

    # 确保向量集合存在
    await vector_store.create_collection(settings.embedding_dimension)

    worker = IngestWorker(
        vector_store=vector_store,
        embedding_provider=embedding_provider,
        db_client=db_client,
    )

    results: List[IngestResult] = []
    for doc in request.documents:
        result = await worker.ingest(doc)
        results.append(result)

    accepted = sum(1 for r in results if r.status != IngestStatus.FAILED)

    response_data = IngestResponse(
        batch_id=batch_id,
        total=len(request.documents),
        accepted=accepted,
        results=results,
    )

    return ApiResponse(data=response_data)
