"""本地 sentence-transformers Embedding。"""

from __future__ import annotations

import logging
from typing import List

from app.core.config import settings
from app.embedding.base import BaseEmbeddingProvider

logger = logging.getLogger(__name__)


class LocalEmbeddingProvider(BaseEmbeddingProvider):
    """使用 sentence-transformers 在本地生成文本向量。"""

    def __init__(self, model_name: str | None = None):
        self.model_name = model_name or settings.embedding_model
        self.dimension = settings.embedding_dimension
        self._model = None

    def _load_model(self):
        """延迟加载模型。"""
        if self._model is None:
            from sentence_transformers import SentenceTransformer

            logger.info("加载本地 Embedding 模型: %s", self.model_name)
            self._model = SentenceTransformer(self.model_name)
            self.dimension = self._model.get_sentence_embedding_dimension()
            logger.info("模型加载完成, 维度=%d", self.dimension)

    async def embed_text(self, text: str) -> List[float]:
        results = await self.embed_texts([text])
        return results[0]

    async def embed_texts(self, texts: List[str]) -> List[List[float]]:
        self._load_model()
        embeddings = self._model.encode(texts, show_progress_bar=False)
        result = [emb.tolist() for emb in embeddings]
        logger.debug("Local Embedding 完成: %d 条文本", len(texts))
        return result

    def get_dimension(self) -> int:
        return self.dimension
