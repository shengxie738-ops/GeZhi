"""混合检索器 — 融合 BM25 和向量检索结果。"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from app.core.config import settings

logger = logging.getLogger(__name__)


@dataclass
class HybridResult:
    """混合检索结果。"""

    chunk_id: str
    score: float
    source: str  # "vector" | "bm25" | "verified_qa" | "hybrid"
    payload: Dict[str, Any] = field(default_factory=dict)


class HybridRetriever:
    """混合检索器：融合向量检索和 BM25 检索。"""

    def __init__(
        self,
        keyword_weight: float | None = None,
        vector_weight: float | None = None,
        verified_qa_weight: float | None = None,
    ):
        self.keyword_weight = keyword_weight or settings.keyword_weight
        self.vector_weight = vector_weight or settings.vector_weight
        self.verified_qa_weight = verified_qa_weight or settings.verified_qa_weight

    def combine(
        self,
        vector_results: List[Dict[str, Any]],
        bm25_results: List[Dict[str, Any]],
        top_k: int | None = None,
    ) -> List[HybridResult]:
        """合并两种检索结果并加权融合。

        Args:
            vector_results: 向量检索结果，每条包含 chunk_id, score, payload。
            bm25_results: BM25 检索结果，每条包含 chunk_id, score, payload。
            top_k: 返回结果数量。

        Returns:
            融合后的 ``HybridResult`` 列表。
        """
        top_k = top_k or settings.hybrid_top_k

        # 归一化分数
        vector_normed = self._normalize_scores(vector_results)
        bm25_normed = self._normalize_scores(bm25_results)

        # 合并分数
        merged: Dict[str, HybridResult] = {}

        for item in vector_normed:
            cid = item["chunk_id"]
            payload = item.get("payload", {})
            verified = payload.get("teacher_verified", False)
            bonus = self.verified_qa_weight if verified else 0.0

            score = item["score"] * self.vector_weight + bonus
            merged[cid] = HybridResult(
                chunk_id=cid,
                score=score,
                source="vector",
                payload=payload,
            )

        for item in bm25_normed:
            cid = item["chunk_id"]
            payload = item.get("payload", {})
            verified = payload.get("teacher_verified", False)
            bonus = self.verified_qa_weight if verified else 0.0

            bm25_score = item["score"] * self.keyword_weight + bonus

            if cid in merged:
                merged[cid].score += bm25_score
                merged[cid].source = "hybrid"
            else:
                merged[cid] = HybridResult(
                    chunk_id=cid,
                    score=bm25_score,
                    source="bm25",
                    payload=payload,
                )

        # 排序并截断
        results = sorted(merged.values(), key=lambda r: r.score, reverse=True)
        return results[:top_k]

    @staticmethod
    def _normalize_scores(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Min-Max 归一化分数到 [0, 1]。"""
        if not items:
            return []
        scores = [item["score"] for item in items]
        min_s = min(scores)
        max_s = max(scores)
        range_s = max_s - min_s
        if range_s == 0:
            for item in items:
                item["score"] = 1.0
        else:
            for item in items:
                item["score"] = (item["score"] - min_s) / range_s
        return items
