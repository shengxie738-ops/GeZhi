"""重排序器 — 对检索结果进行精排。"""

from __future__ import annotations

import logging
from typing import Any, Dict, List

from app.core.config import settings

logger = logging.getLogger(__name__)


class Reranker:
    """检索结果重排序器。

    当前实现基于分数过滤和截断。如需接入交叉编码器模型，
    可在此扩展。
    """

    def __init__(
        self,
        top_n: int | None = None,
        min_score: float | None = None,
    ):
        self.top_n = top_n or settings.rerank_top_n
        self.min_score = min_score or settings.min_relevance_score

    def rerank(
        self,
        results: List[Dict[str, Any]],
        query: str | None = None,
    ) -> List[Dict[str, Any]]:
        """对检索结果重排序并截断。

        Args:
            results: 待排序的结果列表，每条需包含 ``score`` 字段。
            query: 原始查询（可用于交叉编码器重排，当前未使用）。

        Returns:
            重排序并过滤后的结果列表。
        """
        # 按分数降序排列
        sorted_results = sorted(results, key=lambda r: r.get("score", 0), reverse=True)

        # 过滤低分
        filtered = [r for r in sorted_results if r.get("score", 0) >= self.min_score]

        # 截断
        reranked = filtered[: self.top_n]

        logger.debug(
            "Reranker: %d -> %d 条结果 (min_score=%.2f)",
            len(results),
            len(reranked),
            self.min_score,
        )
        return reranked
