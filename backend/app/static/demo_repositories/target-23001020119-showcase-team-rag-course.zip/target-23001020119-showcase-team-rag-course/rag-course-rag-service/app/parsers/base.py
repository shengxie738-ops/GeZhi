"""文档解析器基类与公共数据结构。"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List


@dataclass
class ParsedPage:
    """解析后的单页内容。"""

    page_number: int = field(description="页码，从 1 开始")
    text: str = field(description="该页文本内容")


class BaseParser(ABC):
    """文档解析器抽象基类。

    所有解析器必须实现 ``parse`` 方法，将文件二进制内容转换为
    ``List[ParsedPage]``。
    """

    @abstractmethod
    def parse(self, file_bytes: bytes, file_name: str = "") -> List[ParsedPage]:
        """解析文档，返回按页组织的文本列表。

        Args:
            file_bytes: 文件原始二进制内容。
            file_name: 文件名（用于日志/调试）。

        Returns:
            按页码排序的 ``ParsedPage`` 列表。
        """
        ...

    @staticmethod
    def _clean_page_text(text: str) -> str:
        """基础文本清洗：去除首尾空白。"""
        return text.strip()
