"""生成模块测试。"""

from __future__ import annotations

import pytest

from app.generation.prompt_builder import PromptBuilder
from app.generation.citation_builder import CitationBuilder
from app.schemas.generate import Citation


class TestPromptBuilder:
    """Prompt 构建器测试。"""

    def test_build_system_prompt(self):
        """测试系统提示词构建。"""
        prompt = PromptBuilder.build_system_prompt()
        assert isinstance(prompt, str)
        assert len(prompt) > 0
        assert "人工智能" in prompt

    def test_build_user_prompt(self, sample_chunks_data: list):
        """测试用户 prompt 构建。"""
        prompt = PromptBuilder.build_user_prompt(
            query="什么是人工智能？",
            context_chunks=sample_chunks_data,
        )
        assert "什么是人工智能" in prompt
        assert "人工智能概述" in prompt
        assert "机器学习基础" in prompt
        assert "[1]" in prompt
        assert "[2]" in prompt

    def test_build_user_prompt_empty_context(self):
        """测试无上下文时的 prompt 构建。"""
        prompt = PromptBuilder.build_user_prompt(
            query="问题",
            context_chunks=[],
        )
        assert "无可用参考资料" in prompt

    def test_evidence_insufficient_template(self):
        """测试证据不足模板。"""
        response = PromptBuilder.build_evidence_insufficient_response()
        assert isinstance(response, str)
        assert "未找到" in response or "不足" in response


class TestCitationBuilder:
    """引用构建器测试。"""

    def test_build_citations(self, sample_chunks_data: list):
        """测试引用列表构建。"""
        citations = CitationBuilder.build_citations(sample_chunks_data)
        assert len(citations) == 2
        assert isinstance(citations[0], Citation)
        assert citations[0].citation_id == "[1]"
        assert citations[1].citation_id == "[2]"

    def test_build_citations_empty(self):
        """测试空结果构建引用。"""
        citations = CitationBuilder.build_citations([])
        assert citations == []

    def test_format_citation_source(self):
        """测试引用来源格式化。"""
        citation = Citation(
            citation_id="[1]",
            chunk_id="c1",
            document_id="d1",
            title="测试文档",
            source_text="测试内容",
            page_start=5,
            page_end=10,
            score=0.9,
        )
        formatted = CitationBuilder.format_citation_source(citation)
        assert "[1]" in formatted
        assert "测试文档" in formatted
        assert "第5-10页" in formatted

    def test_format_single_page(self):
        """测试单页引用格式。"""
        citation = Citation(
            citation_id="[1]",
            chunk_id="c1",
            document_id="d1",
            title="测试",
            source_text="内容",
            page_start=3,
            page_end=3,
            score=0.8,
        )
        formatted = CitationBuilder.format_citation_source(citation)
        assert "第3页" in formatted
