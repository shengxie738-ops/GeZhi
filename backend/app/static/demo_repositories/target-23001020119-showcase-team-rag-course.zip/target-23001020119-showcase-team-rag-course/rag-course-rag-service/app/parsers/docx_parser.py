"""DOCX 文档解析器 — 基于 python-docx。"""

from __future__ import annotations

import io
import logging
from typing import List

from app.parsers.base import BaseParser, ParsedPage

logger = logging.getLogger(__name__)


class DocxParser(BaseParser):
    """使用 python-docx 解析 Word 文档。

    python-docx 不原生支持按页拆分，此处按段落分组模拟分页（每 50 段为一页）。
    """

    PARAGRAPHS_PER_PAGE = 50

    def parse(self, file_bytes: bytes, file_name: str = "") -> List[ParsedPage]:
        """解析 DOCX 文件。

        Args:
            file_bytes: DOCX 文件的原始二进制内容。
            file_name: 文件名（用于日志）。

        Returns:
            ``ParsedPage`` 列表。
        """
        try:
            from docx import Document
        except ImportError:
            logger.error("python-docx 未安装，无法解析 DOCX 文件")
            raise

        doc = Document(io.BytesIO(file_bytes))
        pages: List[ParsedPage] = []
        current_texts: List[str] = []
        page_number = 1

        for para in doc.paragraphs:
            text = para.text.strip()
            if text:
                current_texts.append(text)

            if len(current_texts) >= self.PARAGRAPHS_PER_PAGE:
                combined = "\n".join(current_texts)
                cleaned = self._clean_page_text(combined)
                if cleaned:
                    pages.append(ParsedPage(page_number=page_number, text=cleaned))
                page_number += 1
                current_texts = []

        # 最后一页
        if current_texts:
            combined = "\n".join(current_texts)
            cleaned = self._clean_page_text(combined)
            if cleaned:
                pages.append(ParsedPage(page_number=page_number, text=cleaned))

        logger.info("DOCX 解析完成: %s, 共 %d 页", file_name, len(pages))
        return pages
