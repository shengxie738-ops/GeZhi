"""通用数据模型 — 分页、统一响应格式。"""

from __future__ import annotations

from typing import Any, Generic, List, Optional, TypeVar

from pydantic import BaseModel, Field

T = TypeVar("T")


class PaginationParams(BaseModel):
    """分页请求参数。"""

    page: int = Field(default=1, ge=1, description="页码，从 1 开始")
    page_size: int = Field(default=20, ge=1, le=100, description="每页条数")


class PaginationMeta(BaseModel):
    """分页元信息。"""

    total: int = Field(description="总条数")
    page: int = Field(description="当前页码")
    page_size: int = Field(description="每页条数")
    total_pages: int = Field(description="总页数")


class ApiResponse(BaseModel, Generic[T]):
    """统一 API 响应格式。"""

    success: bool = Field(default=True, description="是否成功")
    code: int = Field(default=200, description="业务状态码")
    message: str = Field(default="ok", description="消息")
    data: Optional[T] = Field(default=None, description="响应数据")
    errors: Optional[List[str]] = Field(default=None, description="错误列表")


class ErrorResponse(BaseModel):
    """错误响应。"""

    success: bool = Field(default=False)
    code: int = Field(description="错误码")
    message: str = Field(description="错误信息")
    errors: Optional[List[str]] = Field(default=None)


class FileUploadInfo(BaseModel):
    """上传文件信息。"""

    file_key: str = Field(description="文件在存储中的 key")
    file_name: str = Field(description="原始文件名")
    file_size: int = Field(description="文件大小（字节）")
    file_type: str = Field(description="MIME 类型")
    bucket: Optional[str] = Field(default=None, description="存储桶名")
