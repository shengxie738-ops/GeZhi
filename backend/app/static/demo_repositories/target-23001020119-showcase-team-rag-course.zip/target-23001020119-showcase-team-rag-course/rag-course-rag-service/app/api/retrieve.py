"""检索 API 端点。"""

from __future__ import annotations

import logging
from typing import Any, Dict, List

from fastapi import APIRouter, Depends

from app.core.config import settings
from app.core.security import verify_internal_token
from app.db.mock_client import MockDBClient
from app.db.mysql_client import MySQLClient
from app.embedding.base import BaseEmbeddingProvider
from app.embedding.factory import EmbeddingFactory
from app.retrieval.bm25 import BM25Retriever
from app.retrieval.hybrid import HybridRetriever
from app.retrieval.reranker import Reranker
from app.retrieval.vector import VectorRetriever
from app.schemas.common import ApiResponse
from app.schemas.retrieve import (
    RetrieveRequest,
    RetrieveResponse,
    RetrievedChunk,
)
from app.vectorstore.base import BaseVectorStore
from app.vectorstore.mock_store import MockVectorStore
from app.vectorstore.qdrant_store import QdrantVectorStore

logger = logging.getLogger(__name__)
router = APIRouter()


def _get_vector_store() -> BaseVectorStore:
    if settings.mock_mode:
        return MockVectorStore()
    return QdrantVectorStore()


def _get_db_client():
    if settings.mock_mode:
        return MockDBClient()
    return MySQLClient()


def _get_embedding_provider() -> BaseEmbeddingProvider:
    if settings.mock_mode:
        from app.embedding.local_provider import LocalEmbeddingProvider
        return LocalEmbeddingProvider()
    return EmbeddingFactory.create()


@router.post("/retrieve", response_model=ApiResponse[RetrieveResponse])
async def retrieve(
    request: RetrieveRequest,
    _token: None = Depends(verify_internal_token),
) -> ApiResponse[RetrieveResponse]:
    """检索端点。

    执行向量检索 / 混合检索，返回相关知识块。
    """
    logger.info("收到检索请求: query=%s, course_id=%s", request.query, request.course_id)

    vector_store = _get_vector_store()
    embedding_provider = _get_embedding_provider()
    db_client = _get_db_client()

    # 向量化查询
    query_vector = await embedding_provider.embed_text(request.query)

    # 向量检索
    vector_retriever = VectorRetriever(vector_store=vector_store)
    vector_results = await vector_retriever.search(
        query_vector=query_vector,
        top_k=settings.vector_search_top_k,
        course_id=request.course_id,
    )

    retrieval_method = "vector"
    final_results: List[Dict[str, Any]] = []

    if request.use_hybrid:
        # BM25 检索
        bm25_retriever = BM25Retriever()

        # 获取课程下所有知识块用于 BM25 索引
        all_chunks = await db_client.get_chunks_by_course(request.course_id)
        if all_chunks:
            bm25_retriever.index_corpus(
                chunk_ids=[c.get("vector_id", c.get("id", "")) for c in all_chunks],
                texts=[c.get("text", "") for c in all_chunks],
            )
            bm25_results_raw = bm25_retriever.search(
                request.query, top_k=settings.bm25_search_top_k
            )
            bm25_results = [
                {"chunk_id": cid, "score": score, "payload": {}}
                for cid, score in bm25_results_raw
            ]
        else:
            bm25_results = []

        # 混合融合
        hybrid_retriever = HybridRetriever()
        vector_dicts = [
            {"chunk_id": r.id, "score": r.score, "payload": r.payload}
            for r in vector_results
        ]
        hybrid_results = hybrid_retriever.combine(
            vector_results=vector_dicts,
            bm25_results=bm25_results,
            top_k=request.top_k,
        )
        retrieval_method = "hybrid"
        final_results = [
            {
                "chunk_id": h.chunk_id,
                "score": h.score,
                "payload": h.payload,
                "source": h.source,
            }
            for h in hybrid_results
        ]
    else:
        final_results = [
            {"chunk_id": r.id, "score": r.score, "payload": r.payload}
            for r in vector_results[: request.top_k]
        ]

    # 重排序
    if request.use_rerank and final_results:
        reranker = Reranker()
        final_results = reranker.rerank(final_results, query=request.query)

    # 构建响应
    chunks: List[RetrievedChunk] = []
    for item in final_results:
        payload = item.get("payload", {})
        chunk = RetrievedChunk(
            chunk_id=item["chunk_id"],
            document_id=payload.get("document_id", ""),
            course_id=payload.get("course_id", request.course_id),
            chapter_id=payload.get("chapter_id"),
            title=payload.get("title"),
            text=payload.get("text_preview", ""),
            text_preview=payload.get("text_preview"),
            page_start=payload.get("page_start"),
            page_end=payload.get("page_end"),
            title_path=payload.get("title_path"),
            score=item["score"],
            source_type=payload.get("source_type", "document"),
            teacher_verified=payload.get("teacher_verified", False),
        )
        chunks.append(chunk)

    response_data = RetrieveResponse(
        query=request.query,
        chunks=chunks,
        total=len(chunks),
        retrieval_method=retrieval_method,
    )

    return ApiResponse(data=response_data)
