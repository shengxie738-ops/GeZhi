"""检索（Retrieve）请求 / 响应模型。"""

from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, Field


class RetrieveRequest(BaseModel):
    """检索请求体。"""

    query: str = Field(min_length=1, max_length=1000, description="用户查询文本")
    course_id: str = Field(description="课程 ID")
    chapter_id: Optional[str] = Field(default=None, description="章节 ID（可选过滤）")
    top_k: int = Field(default=5, ge=1, le=50, description="返回结果数量")
    use_hybrid: bool = Field(default=True, description="是否使用混合检索")
    use_rerank: bool = Field(default=True, description="是否使用重排序")
    teacher_verified_only: bool = Field(default=False, description="仅返回教师审核通过的内容")


class RetrievedChunk(BaseModel):
    """单个检索到的知识块。"""

    chunk_id: str = Field(description="知识块 ID")
    document_id: str = Field(description="文档 ID")
    course_id: str = Field(description="课程 ID")
    chapter_id: Optional[str] = Field(default=None, description="章节 ID")
    title: Optional[str] = Field(default=None, description="文档标题")
    text: str = Field(description="知识块文本内容")
    text_preview: Optional[str] = Field(default=None, description="文本预览（截断）")
    page_start: Optional[int] = Field(default=None, description="起始页码")
    page_end: Optional[int] = Field(default=None, description="结束页码")
    title_path: Optional[str] = Field(default=None, description="标题层级路径")
    score: float = Field(description="相关性得分")
    source_type: str = Field(default="document", description="来源类型")
    teacher_verified: bool = Field(default=False, description="是否教师审核通过")


class RetrieveResponse(BaseModel):
    """检索响应体。"""

    query: str = Field(description="原始查询")
    chunks: List[RetrievedChunk] = Field(default_factory=list, description="检索结果列表")
    total: int = Field(description="返回结果总数")
    retrieval_method: str = Field(description="使用的检索方法：hybrid | vector | bm25")
