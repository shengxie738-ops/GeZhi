"""数据库操作抽象基类 — 定义接口签名。"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional


class BaseDBClient(ABC):
    """数据库客户端抽象基类。"""

    @abstractmethod
    async def save_chunks(
        self,
        document_id: str,
        course_id: str,
        chapter_id: Optional[str],
        chunks: List[Any],
        chunk_ids: List[str],
    ) -> int:
        """保存知识块到数据库。

        Args:
            document_id: 文档 ID。
            course_id: 课程 ID。
            chapter_id: 章节 ID。
            chunks: 切分后的知识块列表。
            chunk_ids: 对应的向量 ID 列表。

        Returns:
            保存成功条数。
        """
        ...

    @abstractmethod
    async def update_chunk_vector_id(
        self,
        chunk_db_id: str,
        vector_id: str,
    ) -> bool:
        """更新知识块的向量 ID。

        Args:
            chunk_db_id: 数据库中的知识块 ID。
            vector_id: Qdrant 中的向量 ID。

        Returns:
            是否更新成功。
        """
        ...

    @abstractmethod
    async def update_document_status(
        self,
        document_id: str,
        status: str,
    ) -> bool:
        """更新文档入库状态。

        Args:
            document_id: 文档 ID。
            status: 新状态。

        Returns:
            是否更新成功。
        """
        ...

    @abstractmethod
    async def get_chunks_by_document(
        self,
        document_id: str,
    ) -> List[Dict[str, Any]]:
        """获取文档的所有知识块。

        Args:
            document_id: 文档 ID。

        Returns:
            知识块字典列表。
        """
        ...

    @abstractmethod
    async def get_chunks_by_course(
        self,
        course_id: str,
    ) -> List[Dict[str, Any]]:
        """获取课程的所有知识块。

        Args:
            course_id: 课程 ID。

        Returns:
            知识块字典列表。
        """
        ...

    @abstractmethod
    async def save_chat_message(
        self,
        course_id: str,
        query: str,
        answer: str,
        model_used: Optional[str] = None,
    ) -> str:
        """保存聊天消息。

        Args:
            course_id: 课程 ID。
            query: 用户提问。
            answer: 生成的回答。
            model_used: 使用的模型。

        Returns:
            消息 ID。
        """
        ...

    @abstractmethod
    async def save_citation(
        self,
        message_id: str,
        chunk_id: str,
        citation_text: str,
        score: float,
    ) -> bool:
        """保存引用记录。

        Args:
            message_id: 关联的消息 ID。
            chunk_id: 知识块 ID。
            citation_text: 引用文本。
            score: 相关性得分。

        Returns:
            是否保存成功。
        """
        ...
