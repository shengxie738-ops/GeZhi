"""文本切分器测试。"""

from __future__ import annotations

import pytest

from app.chunking.overlap_chunker import OverlapChunker
from app.chunking.semantic_chunker import SemanticChunker
from app.chunking.base import TextChunk


class TestOverlapChunker:
    """重叠窗口切分器测试。"""

    def setup_method(self):
        self.chunker = OverlapChunker(chunk_size=100, chunk_overlap=20)

    def test_chunk_returns_list(self, sample_text_content: str):
        """测试切分返回列表。"""
        result = self.chunker.chunk([sample_text_content])
        assert isinstance(result, list)
        assert len(result) > 0

    def test_chunk_returns_text_chunks(self, sample_text_content: str):
        """测试每个元素都是 TextChunk。"""
        result = self.chunker.chunk([sample_text_content])
        for chunk in result:
            assert isinstance(chunk, TextChunk)
            assert chunk.text.strip()
            assert chunk.chunk_no >= 1
            assert chunk.token_count > 0

    def test_chunk_sequential_numbering(self, sample_text_content: str):
        """测试块编号连续。"""
        result = self.chunker.chunk([sample_text_content])
        chunk_nos = [c.chunk_no for c in result]
        assert chunk_nos == list(range(1, len(result) + 1))

    def test_chunk_preserves_page_numbers(self, sample_text_content: str):
        """测试切分保留页码信息。"""
        result = self.chunker.chunk(
            [sample_text_content], page_numbers=[1]
        )
        for chunk in result:
            assert chunk.page_start >= 1


class TestSemanticChunker:
    """语义切分器测试（回退模式）。"""

    def test_chunk_short_text(self):
        """短文本不应被切分。"""
        chunker = SemanticChunker(max_chunk_size=1000, min_chunk_size=10)
        result = chunker.chunk(["这是一段很短的文本。"])
        assert len(result) >= 1
        assert isinstance(result[0], TextChunk)
