"""OpenAI 兼容 Embedding API。"""

from __future__ import annotations

import logging
from typing import List

import httpx

from app.core.config import settings
from app.embedding.base import BaseEmbeddingProvider

logger = logging.getLogger(__name__)


class OpenAIEmbeddingProvider(BaseEmbeddingProvider):
    """通过 OpenAI 兼容 API 获取文本向量。"""

    def __init__(self, model: str | None = None, api_key: str | None = None, base_url: str | None = None):
        self.model = model or settings.embedding_model
        self.api_key = api_key or settings.model_api_key
        self.base_url = (base_url or settings.model_base_url).rstrip("/")
        self.dimension = settings.embedding_dimension

    async def embed_text(self, text: str) -> List[float]:
        results = await self.embed_texts([text])
        return results[0]

    async def embed_texts(self, texts: List[str]) -> List[List[float]]:
        url = f"{self.base_url}/embeddings"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.model,
            "input": texts,
        }

        async with httpx.AsyncClient(timeout=60) as client:
            resp = await client.post(url, json=payload, headers=headers)
            resp.raise_for_status()
            data = resp.json()

        # 按 index 排序确保顺序一致
        sorted_items = sorted(data["data"], key=lambda x: x["index"])
        embeddings = [item["embedding"] for item in sorted_items]
        logger.debug("OpenAI Embedding 完成: %d 条文本", len(texts))
        return embeddings

    def get_dimension(self) -> int:
        return self.dimension
