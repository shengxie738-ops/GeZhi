"""文档入库工作流 — 完整的解析→切分→向量化→入库流水线。"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List

from app.chunking.factory import ChunkerFactory
from app.core.config import settings
from app.db.base import BaseDBClient
from app.embedding.base import BaseEmbeddingProvider
from app.parsers.factory import ParserFactory
from app.parsers.text_cleaner import TextCleaner
from app.schemas.ingest import IngestDocument, IngestResult, IngestStatus
from app.vectorstore.base import BaseVectorStore, VectorRecord

logger = logging.getLogger(__name__)


class IngestWorker:
    """文档入库工作流。

    流程：
    1. 读取文件 → 2. 解析文本 → 3. 清洗 → 4. 切分 →
    5. 生成关键词 → 6. 生成向量 → 7. 写入 Qdrant →
    8. 保存知识块到 MySQL → 9. 更新状态
    """

    def __init__(
        self,
        vector_store: BaseVectorStore,
        embedding_provider: BaseEmbeddingProvider,
        db_client: BaseDBClient,
    ):
        self.vector_store = vector_store
        self.embedding_provider = embedding_provider
        self.db_client = db_client
        self.cleaner = TextCleaner()

    async def ingest(self, document: IngestDocument) -> IngestResult:
        """执行单个文档的入库流程。

        Args:
            document: 入库文档描述。

        Returns:
            入库结果。
        """
        started_at = datetime.now(timezone.utc)
        result = IngestResult(
            document_id=document.document_id,
            status=IngestStatus.PENDING,
            started_at=started_at,
        )

        try:
            # 1. 读取文件
            logger.info("[Ingest] 读取文件: %s", document.file_info.file_name)
            file_bytes = await self._read_file(document.file_info.file_key)

            # 2. 解析文本
            result.status = IngestStatus.PARSING
            await self.db_client.update_document_status(
                document.document_id, IngestStatus.PARSING.value
            )
            parser = ParserFactory.get_parser(document.file_info.file_name)
            parsed_pages = parser.parse(file_bytes, document.file_info.file_name)
            logger.info("[Ingest] 解析完成: %d 页", len(parsed_pages))

            # 3. 清洗
            texts = [page.text for page in parsed_pages]
            page_numbers = [page.page_number for page in parsed_pages]
            cleaned_texts = self.cleaner.clean(texts)

            # 4. 切分
            result.status = IngestStatus.CHUNKING
            chunker = ChunkerFactory.get_chunker(method="overlap")
            chunks = chunker.chunk(cleaned_texts, page_numbers)
            logger.info("[Ingest] 切分完成: %d 块", len(chunks))

            # 5-6. 生成向量
            result.status = IngestStatus.EMBEDDING
            chunk_texts = [c.text for c in chunks]
            embeddings = await self.embedding_provider.embed_texts(chunk_texts)
            logger.info("[Ingest] 向量化完成: %d 个向量", len(embeddings))

            # 7. 写入 Qdrant
            result.status = IngestStatus.INDEXING
            records = self._build_vector_records(
                chunks, embeddings, document
            )
            vector_count = await self.vector_store.upsert_vectors(records)

            # 8. 保存知识块到 MySQL
            chunk_ids = [r.id for r in records]
            await self.db_client.save_chunks(
                document_id=document.document_id,
                course_id=document.course_id,
                chapter_id=document.chapter_id,
                chunks=chunks,
                chunk_ids=chunk_ids,
            )

            # 9. 更新状态
            result.status = IngestStatus.COMPLETED
            result.chunk_count = len(chunks)
            result.vector_count = vector_count
            await self.db_client.update_document_status(
                document.document_id, IngestStatus.COMPLETED.value
            )

            result.completed_at = datetime.now(timezone.utc)
            logger.info(
                "[Ingest] 文档入库完成: %s, %d 块, %d 向量",
                document.document_id,
                len(chunks),
                vector_count,
            )

        except Exception as e:
            result.status = IngestStatus.FAILED
            result.error_message = str(e)
            result.completed_at = datetime.now(timezone.utc)
            logger.exception("[Ingest] 文档入库失败: %s", document.document_id)
            try:
                await self.db_client.update_document_status(
                    document.document_id, IngestStatus.FAILED.value
                )
            except Exception:
                logger.exception("更新文档状态失败")

        return result

    async def _read_file(self, file_key: str) -> bytes:
        """读取文件内容。

        实际实现应从 MinIO/S3 下载文件，Mock 模式返回空字节。
        """
        if settings.mock_mode:
            logger.info("[Mock] 读取文件: %s (返回模拟数据)", file_key)
            return b"Mock file content for development and testing."
        # TODO: 实现 MinIO/S3 文件下载
        raise NotImplementedError("MinIO 文件读取尚未实现")

    @staticmethod
    def _build_vector_records(
        chunks,
        embeddings: List[List[float]],
        document: IngestDocument,
    ) -> List[VectorRecord]:
        """构建向量记录。"""
        records: List[VectorRecord] = []
        for chunk, embedding in zip(chunks, embeddings):
            chunk_id = str(uuid.uuid4())
            payload = {
                "course_id": document.course_id,
                "chapter_id": document.chapter_id or "",
                "document_id": document.document_id,
                "chunk_id": chunk_id,
                "source_type": document.source_type,
                "title": document.title or document.file_info.file_name,
                "page_start": chunk.page_start,
                "page_end": chunk.page_end,
                "title_path": chunk.title_path or "",
                "enabled": True,
                "teacher_verified": document.teacher_verified,
                "text_preview": chunk.text[:200],
            }
            records.append(
                VectorRecord(id=chunk_id, vector=embedding, payload=payload)
            )
        return records
