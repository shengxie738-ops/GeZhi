"""纯文本文件解析器。"""

from __future__ import annotations

import logging
from typing import List

from app.parsers.base import BaseParser, ParsedPage

logger = logging.getLogger(__name__)


class TextParser(BaseParser):
    """将纯文本文件作为单页返回。"""

    def parse(self, file_bytes: bytes, file_name: str = "") -> List[ParsedPage]:
        """解析纯文本文件。

        Args:
            file_bytes: 文件的原始二进制内容。
            file_name: 文件名。

        Returns:
            ``ParsedPage`` 列表（通常只有一页）。
        """
        content = file_bytes.decode("utf-8", errors="replace")
        cleaned = self._clean_page_text(content)

        pages = [ParsedPage(page_number=1, text=cleaned)] if cleaned else []
        logger.info("文本解析完成: %s, 共 %d 页", file_name, len(pages))
        return pages
