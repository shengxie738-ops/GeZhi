"""Mock 数据库客户端 — 内存存储，用于开发和测试。"""

from __future__ import annotations

import logging
import uuid
from typing import Any, Dict, List, Optional

from app.db.base import BaseDBClient

logger = logging.getLogger(__name__)


class MockDBClient(BaseDBClient):
    """基于内存的 Mock 数据库客户端。"""

    def __init__(self):
        self._chunks: Dict[str, Dict[str, Any]] = {}  # chunk_id -> chunk data
        self._documents: Dict[str, Dict[str, Any]] = {}  # document_id -> status etc.
        self._messages: Dict[str, Dict[str, Any]] = {}  # message_id -> message data
        self._citations: List[Dict[str, Any]] = []

    async def save_chunks(
        self,
        document_id: str,
        course_id: str,
        chapter_id: Optional[str],
        chunks: List[Any],
        chunk_ids: List[str],
    ) -> int:
        """保存知识块到内存。"""
        count = 0
        for chunk, vector_id in zip(chunks, chunk_ids):
            chunk_data = {
                "id": str(uuid.uuid4()),
                "document_id": document_id,
                "course_id": course_id,
                "chapter_id": chapter_id or "",
                "chunk_no": chunk.chunk_no,
                "text": chunk.text,
                "page_start": chunk.page_start,
                "page_end": chunk.page_end,
                "title_path": chunk.title_path or "",
                "token_count": chunk.token_count,
                "vector_id": vector_id,
                "source_type": "document",
                "title": "",
                "enabled": True,
                "teacher_verified": False,
            }
            self._chunks[vector_id] = chunk_data
            count += 1

        logger.info("[Mock] 保存 %d 个知识块 (文档: %s)", count, document_id)
        return count

    async def update_chunk_vector_id(
        self,
        chunk_db_id: str,
        vector_id: str,
    ) -> bool:
        """更新知识块向量 ID。"""
        for cid, chunk in self._chunks.items():
            if chunk["id"] == chunk_db_id:
                chunk["vector_id"] = vector_id
                return True
        return False

    async def update_document_status(
        self,
        document_id: str,
        status: str,
    ) -> bool:
        """更新文档状态。"""
        if document_id not in self._documents:
            self._documents[document_id] = {"document_id": document_id}
        self._documents[document_id]["status"] = status
        logger.debug("[Mock] 更新文档状态: %s -> %s", document_id, status)
        return True

    async def get_chunks_by_document(
        self,
        document_id: str,
    ) -> List[Dict[str, Any]]:
        """获取文档的所有知识块。"""
        return [
            chunk
            for chunk in self._chunks.values()
            if chunk["document_id"] == document_id
        ]

    async def get_chunks_by_course(
        self,
        course_id: str,
    ) -> List[Dict[str, Any]]:
        """获取课程的所有知识块。"""
        return [
            chunk
            for chunk in self._chunks.values()
            if chunk["course_id"] == course_id
        ]

    async def save_chat_message(
        self,
        course_id: str,
        query: str,
        answer: str,
        model_used: Optional[str] = None,
    ) -> str:
        """保存聊天消息。"""
        message_id = str(uuid.uuid4())
        self._messages[message_id] = {
            "message_id": message_id,
            "course_id": course_id,
            "query": query,
            "answer": answer,
            "model_used": model_used,
        }
        logger.debug("[Mock] 保存聊天消息: %s", message_id)
        return message_id

    async def save_citation(
        self,
        message_id: str,
        chunk_id: str,
        citation_text: str,
        score: float,
    ) -> bool:
        """保存引用记录。"""
        self._citations.append({
            "message_id": message_id,
            "chunk_id": chunk_id,
            "citation_text": citation_text,
            "score": score,
        })
        return True
