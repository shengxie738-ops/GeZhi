"""基于重叠窗口的文本切分器。"""

from __future__ import annotations

import logging
import re
from typing import List, Optional

from app.chunking.base import BaseChunker, TextChunk
from app.core.config import settings

logger = logging.getLogger(__name__)


class OverlapChunker(BaseChunker):
    """按段落/标题层级切分，支持重叠窗口。

    切分策略：
    1. 优先按标题层级（## ）拆分为语义段落。
    2. 如果段落超出 chunk_size，按句子/字符滑动窗口切分。
    3. 相邻块之间保留 overlap 个字符的重叠。
    """

    def __init__(
        self,
        chunk_size: int | None = None,
        chunk_overlap: int | None = None,
    ):
        self.chunk_size = chunk_size or settings.chunk_size
        self.chunk_overlap = chunk_overlap or settings.chunk_overlap

    def chunk(
        self,
        pages: List[str],
        page_numbers: Optional[List[int]] = None,
    ) -> List[TextChunk]:
        """执行重叠窗口切分。"""
        if page_numbers is None:
            page_numbers = list(range(1, len(pages) + 1))

        full_text = "\n\n".join(pages)
        # 按标题拆分为段落
        sections = self._split_by_headings(full_text)

        chunks: List[TextChunk] = []
        chunk_no = 1

        for section_text in sections:
            if len(section_text) <= self.chunk_size:
                page_num = self._estimate_page(section_text, pages, page_numbers)
                chunks.append(
                    TextChunk(
                        chunk_no=chunk_no,
                        text=section_text,
                        page_start=page_num,
                        page_end=page_num,
                        title_path=self._extract_title(section_text),
                        token_count=len(section_text),
                    )
                )
                chunk_no += 1
            else:
                sub_chunks = self._sliding_window(section_text, pages, page_numbers, chunk_no)
                chunks.extend(sub_chunks)
                chunk_no += len(sub_chunks)

        logger.info("OverlapChunker 切分完成: %d 块", len(chunks))
        return chunks

    def _split_by_headings(self, text: str) -> List[str]:
        """按 Markdown 标题拆分为段落。"""
        heading_pattern = re.compile(r"^#{1,3}\s+.+$", re.MULTILINE)
        parts = heading_pattern.split(text)
        # 保留标题作为前缀
        headings = heading_pattern.findall(text)
        sections: List[str] = []

        idx = 0
        for i, part in enumerate(parts):
            part = part.strip()
            if not part:
                continue
            prefix = headings[i] if i < len(headings) else ""
            combined = f"{prefix}\n{part}".strip() if prefix else part
            sections.append(combined)

        return sections if sections else [text]

    def _sliding_window(
        self,
        text: str,
        pages: List[str],
        page_numbers: List[int],
        start_no: int,
    ) -> List[TextChunk]:
        """滑动窗口切分长文本。"""
        chunks: List[TextChunk] = []
        start = 0

        while start < len(text):
            end = min(start + self.chunk_size, len(text))
            chunk_text = text[start:end]
            page_num = self._estimate_page(chunk_text, pages, page_numbers)

            chunks.append(
                TextChunk(
                    chunk_no=start_no + len(chunks),
                    text=chunk_text.strip(),
                    page_start=page_num,
                    page_end=page_num,
                    token_count=len(chunk_text),
                )
            )

            start += self.chunk_size - self.chunk_overlap
            if start >= len(text):
                break

        return chunks

    @staticmethod
    def _estimate_page(
        text: str,
        pages: List[str],
        page_numbers: List[int],
    ) -> int:
        """根据文本片段估算所在页码。"""
        first_line = text[:100].strip()
        for i, page_text in enumerate(pages):
            if first_line in page_text and i < len(page_numbers):
                return page_numbers[i]
        return page_numbers[0] if page_numbers else 1

    @staticmethod
    def _extract_title(text: str) -> Optional[str]:
        """提取文本中的标题行。"""
        match = re.match(r"^(#{1,6}\s+.+)$", text, re.MULTILINE)
        return match.group(1).strip() if match else None
