"""答案生成器 — 调用 LLM 生成回答。"""

from __future__ import annotations

import json
import logging
from typing import Any, AsyncIterator, Dict, List, Optional

import httpx

from app.core.config import settings
from app.generation.prompt_builder import PromptBuilder

logger = logging.getLogger(__name__)


class AnswerGenerator:
    """答案生成器，支持 OpenAI 兼容 API。"""

    def __init__(self):
        self.mock_mode = settings.mock_mode
        self.provider = settings.chat_provider
        self.model = settings.chat_model
        self.api_key = settings.model_api_key
        self.base_url = settings.model_base_url.rstrip("/")

    async def generate(
        self,
        query: str,
        context_chunks: List[Dict[str, Any]],
        conversation_history: Optional[List[Dict[str, str]]] = None,
    ) -> Dict[str, Any]:
        """生成回答。

        Args:
            query: 用户提问。
            context_chunks: 检索到的上下文知识块。
            conversation_history: 对话历史。

        Returns:
            包含 answer, model_used, token_usage 的字典。
        """
        if self.mock_mode:
            return self._mock_generate(query, context_chunks)

        system_prompt = PromptBuilder.build_system_prompt()
        user_prompt = PromptBuilder.build_user_prompt(query, context_chunks)

        messages = [{"role": "system", "content": system_prompt}]
        if conversation_history:
            messages.extend(conversation_history)
        messages.append({"role": "user", "content": user_prompt})

        try:
            return await self._call_openai_api(messages)
        except Exception:
            logger.exception("LLM 调用失败")
            return {
                "answer": PromptBuilder.build_evidence_insufficient_response(),
                "model_used": self.model,
                "token_usage": {},
                "status": "error",
            }

    async def stream_generate(
        self,
        query: str,
        context_chunks: List[Dict[str, Any]],
        conversation_history: Optional[List[Dict[str, str]]] = None,
    ) -> AsyncIterator[str]:
        """流式生成回答（SSE）。

        Args:
            query: 用户提问。
            context_chunks: 检索到的上下文知识块。
            conversation_history: 对话历史。

        Yields:
            SSE 格式的 JSON 字符串。
        """
        if self.mock_mode:
            mock_answer = self._mock_generate(query, context_chunks)["answer"]
            # 模拟流式输出
            chunk_size = 20
            for i in range(0, len(mock_answer), chunk_size):
                text = mock_answer[i : i + chunk_size]
                yield f"data: {json.dumps({'content': text, 'done': False})}\n\n"
            yield f"data: {json.dumps({'content': '', 'done': True})}\n\n"
            return

        system_prompt = PromptBuilder.build_system_prompt()
        user_prompt = PromptBuilder.build_user_prompt(query, context_chunks)

        messages = [{"role": "system", "content": system_prompt}]
        if conversation_history:
            messages.extend(conversation_history)
        messages.append({"role": "user", "content": user_prompt})

        try:
            async for chunk in self._stream_openai_api(messages):
                yield f"data: {json.dumps({'content': chunk, 'done': False})}\n\n"
            yield f"data: {json.dumps({'content': '', 'done': True})}\n\n"
        except Exception:
            logger.exception("流式 LLM 调用失败")
            error_msg = PromptBuilder.build_evidence_insufficient_response()
            yield f"data: {json.dumps({'content': error_msg, 'done': True, 'error': True})}\n\n"

    async def _call_openai_api(self, messages: List[Dict[str, str]]) -> Dict[str, Any]:
        """调用 OpenAI 兼容 API（非流式）。"""
        url = f"{self.base_url}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": 0.3,
            "max_tokens": 2048,
        }

        async with httpx.AsyncClient(timeout=120) as client:
            resp = await client.post(url, json=payload, headers=headers)
            resp.raise_for_status()
            data = resp.json()

        choice = data["choices"][0]
        usage = data.get("usage", {})

        return {
            "answer": choice["message"]["content"],
            "model_used": data.get("model", self.model),
            "token_usage": {
                "prompt_tokens": usage.get("prompt_tokens", 0),
                "completion_tokens": usage.get("completion_tokens", 0),
                "total_tokens": usage.get("total_tokens", 0),
            },
            "status": "success",
        }

    async def _stream_openai_api(
        self, messages: List[Dict[str, str]]
    ) -> AsyncIterator[str]:
        """调用 OpenAI 兼容 API（流式）。"""
        url = f"{self.base_url}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": 0.3,
            "max_tokens": 2048,
            "stream": True,
        }

        async with httpx.AsyncClient(timeout=120) as client:
            async with client.stream("POST", url, json=payload, headers=headers) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    data_str = line[6:]
                    if data_str.strip() == "[DONE]":
                        break
                    data = json.loads(data_str)
                    delta = data["choices"][0].get("delta", {})
                    content = delta.get("content")
                    if content:
                        yield content

    @staticmethod
    def _mock_generate(
        query: str,
        context_chunks: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """Mock 模式下生成预设回答。"""
        if not context_chunks:
            return {
                "answer": PromptBuilder.build_evidence_insufficient_response(),
                "model_used": "mock-model",
                "token_usage": {},
                "status": "success",
            }

        references = []
        for i, chunk in enumerate(context_chunks, 1):
            title = chunk.get("title", "未知")
            page = chunk.get("page_start", "?")
            references.append(f"[{i}] 《{title}》 第{page}页")

        answer = (
            f"根据课程资料，关于「{query}」的回答如下：\n\n"
            f"（这是 Mock 模式的预设回答，用于开发调试。"
            f"实际部署时将使用 LLM 生成真实回答。）\n\n"
            f"检索到 {len(context_chunks)} 条相关资料。\n\n"
            f"**参考来源：**\n" + "\n".join(references)
        )

        return {
            "answer": answer,
            "model_used": "mock-model",
            "token_usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
            "status": "success",
        }
