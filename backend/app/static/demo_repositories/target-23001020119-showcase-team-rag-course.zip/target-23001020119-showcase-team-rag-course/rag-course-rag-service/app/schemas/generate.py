"""生成（Generate）请求 / 响应模型。"""

from __future__ import annotations

from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field

from app.schemas.retrieve import RetrievedChunk


class AnswerStatus(str, Enum):
    """生成答案状态。"""

    SUCCESS = "success"
    EVIDENCE_INSUFFICIENT = "evidence_insufficient"
    ERROR = "error"


class Citation(BaseModel):
    """引用信息。"""

    citation_id: str = Field(description="引用编号，如 [1]、[2]")
    chunk_id: str = Field(description="对应知识块 ID")
    document_id: str = Field(description="文档 ID")
    title: Optional[str] = Field(default=None, description="文档标题")
    source_text: str = Field(description="引用的原文片段")
    page_start: Optional[int] = Field(default=None, description="起始页码")
    page_end: Optional[int] = Field(default=None, description="结束页码")
    score: float = Field(description="相关性得分")


class GenerateRequest(BaseModel):
    """生成请求体。"""

    query: str = Field(min_length=1, max_length=1000, description="用户提问")
    course_id: str = Field(description="课程 ID")
    chapter_id: Optional[str] = Field(default=None, description="章节 ID")
    conversation_history: Optional[List[dict]] = Field(
        default=None, description="对话历史（可选，用于多轮对话）"
    )
    top_k: int = Field(default=5, ge=1, le=20, description="使用的检索结果数量")
    stream: bool = Field(default=False, description="是否使用流式输出")


class GenerateResponse(BaseModel):
    """生成响应体。"""

    query: str = Field(description="用户提问")
    answer: str = Field(description="生成的回答")
    status: AnswerStatus = Field(description="答案状态")
    citations: List[Citation] = Field(default_factory=list, description="引用列表")
    retrieved_chunks: List[RetrievedChunk] = Field(
        default_factory=list, description="检索到的知识块"
    )
    model_used: Optional[str] = Field(default=None, description="使用的模型名称")
    token_usage: Optional[dict] = Field(default=None, description="Token 使用统计")
