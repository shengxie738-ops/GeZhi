"""通义千问 Embedding API — 通过 DashScope 调用。"""

from __future__ import annotations

import logging
from typing import List

import httpx

from app.core.config import settings
from app.embedding.base import BaseEmbeddingProvider

logger = logging.getLogger(__name__)

DASHSCOPE_EMBEDDING_URL = "https://dashscope.aliyuncs.com/api/v1/services/embeddings/text-embedding/text-embedding"


class QwenEmbeddingProvider(BaseEmbeddingProvider):
    """通过通义千问 DashScope API 获取文本向量。"""

    def __init__(self, model: str | None = None, api_key: str | None = None):
        self.model = model or settings.embedding_model
        self.api_key = api_key or settings.model_api_key
        self.dimension = settings.embedding_dimension

    async def embed_text(self, text: str) -> List[float]:
        results = await self.embed_texts([text])
        return results[0]

    async def embed_texts(self, texts: List[str]) -> List[List[float]]:
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.model,
            "input": {"texts": texts},
        }

        async with httpx.AsyncClient(timeout=60) as client:
            resp = await client.post(DASHSCOPE_EMBEDDING_URL, json=payload, headers=headers)
            resp.raise_for_status()
            data = resp.json()

        embeddings = [item["embedding"] for item in data["output"]["embeddings"]]
        logger.debug("Qwen Embedding 完成: %d 条文本", len(texts))
        return embeddings

    def get_dimension(self) -> int:
        return self.dimension
