"""MySQL 客户端 — 通过 httpx 调用 Spring Boot 后端接口，或直连 MySQL。"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import httpx

from app.core.config import settings
from app.db.base import BaseDBClient

logger = logging.getLogger(__name__)


class MySQLClient(BaseDBClient):
    """MySQL 数据库客户端（通过 HTTP API 访问 Spring Boot 后端）。"""

    def __init__(self, base_url: str | None = None):
        self.base_url = (base_url or "http://localhost:8080").rstrip("/")
        self._timeout = 30

    async def save_chunks(
        self,
        document_id: str,
        course_id: str,
        chapter_id: Optional[str],
        chunks: List[Any],
        chunk_ids: List[str],
    ) -> int:
        """通过 HTTP API 保存知识块。"""
        payload = {
            "documentId": document_id,
            "courseId": course_id,
            "chapterId": chapter_id,
            "chunks": [
                {
                    "chunkNo": c.chunk_no,
                    "text": c.text,
                    "pageStart": c.page_start,
                    "pageEnd": c.page_end,
                    "titlePath": c.title_path or "",
                    "tokenCount": c.token_count,
                    "vectorId": vid,
                }
                for c, vid in zip(chunks, chunk_ids)
            ],
        }

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.post(
                f"{self.base_url}/api/internal/chunks/batch",
                json=payload,
            )
            resp.raise_for_status()
            data = resp.json()

        saved_count = data.get("saved", len(chunks))
        logger.info("保存 %d 个知识块到 MySQL (文档: %s)", saved_count, document_id)
        return saved_count

    async def update_chunk_vector_id(
        self,
        chunk_db_id: str,
        vector_id: str,
    ) -> bool:
        """更新知识块的向量 ID。"""
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.put(
                f"{self.base_url}/api/internal/chunks/{chunk_db_id}/vector-id",
                json={"vectorId": vector_id},
            )
            resp.raise_for_status()
        return True

    async def update_document_status(
        self,
        document_id: str,
        status: str,
    ) -> bool:
        """更新文档状态。"""
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.put(
                f"{self.base_url}/api/internal/documents/{document_id}/status",
                json={"status": status},
            )
            resp.raise_for_status()
        return True

    async def get_chunks_by_document(
        self,
        document_id: str,
    ) -> List[Dict[str, Any]]:
        """获取文档的所有知识块。"""
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.get(
                f"{self.base_url}/api/internal/documents/{document_id}/chunks",
            )
            resp.raise_for_status()
            data = resp.json()
        return data.get("chunks", [])

    async def get_chunks_by_course(
        self,
        course_id: str,
    ) -> List[Dict[str, Any]]:
        """获取课程的所有知识块。"""
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.get(
                f"{self.base_url}/api/internal/courses/{course_id}/chunks",
            )
            resp.raise_for_status()
            data = resp.json()
        return data.get("chunks", [])

    async def save_chat_message(
        self,
        course_id: str,
        query: str,
        answer: str,
        model_used: Optional[str] = None,
    ) -> str:
        """保存聊天消息。"""
        payload = {
            "courseId": course_id,
            "query": query,
            "answer": answer,
            "modelUsed": model_used,
        }
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.post(
                f"{self.base_url}/api/internal/chat/messages",
                json=payload,
            )
            resp.raise_for_status()
            data = resp.json()
        return data.get("messageId", "")

    async def save_citation(
        self,
        message_id: str,
        chunk_id: str,
        citation_text: str,
        score: float,
    ) -> bool:
        """保存引用记录。"""
        payload = {
            "messageId": message_id,
            "chunkId": chunk_id,
            "citationText": citation_text,
            "score": score,
        }
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.post(
                f"{self.base_url}/api/internal/citations",
                json=payload,
            )
            resp.raise_for_status()
        return True
