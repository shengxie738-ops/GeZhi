"""文本清洗工具 — 去页眉页脚、去重复空白、去特殊字符。"""

from __future__ import annotations

import re
from typing import List


class TextCleaner:
    """通用文本清洗器，可组合多种清洗策略。"""

    def clean(self, pages: List[str]) -> List[str]:
        """对文本列表执行全部清洗步骤。

        Args:
            pages: 待清洗的文本列表。

        Returns:
            清洗后的文本列表。
        """
        cleaned: List[str] = []
        for text in pages:
            text = self.remove_headers_footers(text)
            text = self.normalize_whitespace(text)
            text = self.remove_special_chars(text)
            text = text.strip()
            if text:
                cleaned.append(text)
        return cleaned

    @staticmethod
    def remove_headers_footers(text: str) -> str:
        """去除常见页眉页脚模式。

        - 以数字开头结尾的短行（如页码）
        - 包含"第X页/共X页"等模式的行
        """
        lines = text.splitlines()
        cleaned_lines: List[str] = []
        page_pattern = re.compile(
            r"^(第?\s*\d+\s*页|共\s*\d+\s*页|Page\s*\d+|-\s*\d+\s*-|\d+\s*/\s*\d+)$",
            re.IGNORECASE,
        )
        for line in lines:
            stripped = line.strip()
            if stripped and page_pattern.match(stripped):
                continue
            cleaned_lines.append(line)
        return "\n".join(cleaned_lines)

    @staticmethod
    def normalize_whitespace(text: str) -> str:
        """归一化空白：去除重复空格、空行。"""
        # 将连续空白行替换为单个换行
        text = re.sub(r"\n\s*\n", "\n\n", text)
        # 将连续空格替换为单个空格
        text = re.sub(r"[^\S\n]+", " ", text)
        return text

    @staticmethod
    def remove_special_chars(text: str) -> str:
        """去除无意义的特殊字符，保留中英文标点。"""
        # 去除控制字符
        text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", text)
        # 去除连续的特殊符号（如 ***、--- 等装饰线）
        text = re.sub(r"[*=_\-]{4,}", "", text)
        return text
