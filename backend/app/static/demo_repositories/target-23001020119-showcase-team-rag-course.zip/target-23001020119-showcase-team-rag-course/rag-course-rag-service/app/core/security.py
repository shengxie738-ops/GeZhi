"""内部 API Token 验证。"""

from __future__ import annotations

from fastapi import Header, HTTPException, status

from app.core.config import settings


async def verify_internal_token(
    authorization: str = Header(..., description="Bearer <RAG_INTERNAL_TOKEN>"),
) -> None:
    """验证请求头中的内部 API Token。

    要求 ``Authorization: Bearer <token>`` 格式。

    Raises:
        HTTPException: token 缺失或不匹配时返回 401。
    """
    scheme, _, token = authorization.partition(" ")
    if scheme.lower() != "bearer" or token != settings.rag_internal_token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing internal token",
        )
