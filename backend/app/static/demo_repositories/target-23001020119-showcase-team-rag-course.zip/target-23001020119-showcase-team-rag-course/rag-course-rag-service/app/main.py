"""FastAPI 应用入口 — RAG Course 微服务。

提供文档入库（ingest）、检索（retrieve）、生成（generate）三大核心 API，
以及健康检查端点。支持 Mock 模式用于本地开发。
"""

from __future__ import annotations

import logging
import time
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.core.logging import setup_logging
from app.api.router import api_router

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Application lifespan
# ---------------------------------------------------------------------------

_start_time: float = 0.0


@asynccontextmanager
async def lifespan(application: FastAPI):
    """Application startup / shutdown lifecycle."""
    global _start_time  # noqa: PLW0603
    setup_logging()
    _start_time = time.time()
    logger.info("RAG Course Service starting (mock_mode=%s)", settings.mock_mode)

    # --- Startup: initialise external resources here ---
    # Example: await init_qdrant(), await init_mysql(), await init_redis()

    yield

    # --- Shutdown: release resources here ---
    logger.info("RAG Course Service shutting down")


# ---------------------------------------------------------------------------
# FastAPI application
# ---------------------------------------------------------------------------

app = FastAPI(
    title="RAG Course Service",
    description="人工智能技术基础课程 — RAG 微服务",
    version="0.1.0",
    lifespan=lifespan,
    docs_url="/docs" if settings.app_debug else None,
    redoc_url="/redoc" if settings.app_debug else None,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routes
app.include_router(api_router, prefix="/internal/v1")


# ---------------------------------------------------------------------------
# Extra root-level endpoints
# ---------------------------------------------------------------------------

@app.get("/", tags=["root"])
async def root():
    """Root endpoint — service information."""
    return {
        "service": "rag-course-service",
        "version": "0.1.0",
        "mock_mode": settings.mock_mode,
        "uptime_seconds": round(time.time() - _start_time, 2),
    }
