"""BM25 检索器测试。"""

from __future__ import annotations

import pytest

from app.retrieval.bm25 import BM25Retriever


class TestBM25Retriever:
    """BM25 关键词检索器测试。"""

    def setup_method(self):
        self.retriever = BM25Retriever()

    def test_index_and_search(self):
        """测试索引和检索基本功能。"""
        chunk_ids = ["c1", "c2", "c3"]
        texts = [
            "人工智能是计算机科学的一个分支",
            "机器学习是人工智能的核心技术",
            "深度学习是一种特殊的机器学习方法",
        ]
        self.retriever.index_corpus(chunk_ids, texts)

        results = self.retriever.search("人工智能", top_k=2)
        assert len(results) <= 2
        assert len(results) > 0
        # 所有结果都应该是 (chunk_id, score) 元组
        for cid, score in results:
            assert cid in chunk_ids
            assert isinstance(score, float)

    def test_search_empty_corpus(self):
        """测试空语料库检索。"""
        results = self.retriever.search("查询", top_k=5)
        assert results == []

    def test_search_relevance(self):
        """测试相关性排序。"""
        chunk_ids = ["c1", "c2", "c3"]
        texts = [
            "今天天气很好适合出门",
            "人工智能技术发展迅速",
            "自然语言处理是人工智能的重要方向",
        ]
        self.retriever.index_corpus(chunk_ids, texts)

        results = self.retriever.search("人工智能", top_k=3)
        # 包含"人工智能"的文档应该排在前面
        if results:
            assert results[0][0] in ["c2", "c3"]

    def test_clear(self):
        """测试清空索引。"""
        self.retriever.index_corpus(["c1"], ["测试文本"])
        self.retriever.clear()
        results = self.retriever.search("测试")
        assert results == []

    def test_chinese_tokenization(self):
        """测试中文分词。"""
        tokens = BM25Retriever._tokenize("自然语言处理技术")
        assert len(tokens) > 1
        assert all(isinstance(t, str) for t in tokens)
