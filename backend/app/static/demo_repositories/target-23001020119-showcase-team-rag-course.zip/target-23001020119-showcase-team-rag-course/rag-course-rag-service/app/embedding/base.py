"""Embedding Provider 抽象基类。"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import List


class BaseEmbeddingProvider(ABC):
    """Embedding 提供者抽象基类。"""

    @abstractmethod
    async def embed_text(self, text: str) -> List[float]:
        """将单条文本转换为向量。

        Args:
            text: 输入文本。

        Returns:
            向量列表。
        """
        ...

    @abstractmethod
    async def embed_texts(self, texts: List[str]) -> List[List[float]]:
        """批量将文本转换为向量。

        Args:
            texts: 输入文本列表。

        Returns:
            向量列表的列表。
        """
        ...

    @abstractmethod
    def get_dimension(self) -> int:
        """返回向量维度。"""
        ...
