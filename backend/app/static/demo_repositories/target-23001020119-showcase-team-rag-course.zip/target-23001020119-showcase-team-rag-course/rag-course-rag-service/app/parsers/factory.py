"""解析器工厂 — 根据文件类型选择合适的解析器。"""

from __future__ import annotations

import logging
from typing import Dict, Type

from app.parsers.base import BaseParser
from app.parsers.docx_parser import DocxParser
from app.parsers.markdown_parser import MarkdownParser
from app.parsers.pdf_parser import PDFParser
from app.parsers.text_parser import TextParser

logger = logging.getLogger(__name__)

# 扩展名 → 解析器映射
_PARSER_MAP: Dict[str, Type[BaseParser]] = {
    ".pdf": PDFParser,
    ".docx": DocxParser,
    ".doc": DocxParser,
    ".md": MarkdownParser,
    ".markdown": MarkdownParser,
    ".txt": TextParser,
    ".text": TextParser,
    ".rst": TextParser,
    ".csv": TextParser,
}


class ParserFactory:
    """根据文件扩展名获取对应的文档解析器。"""

    @staticmethod
    def get_parser(file_name: str) -> BaseParser:
        """获取与文件类型对应的解析器实例。

        Args:
            file_name: 文件名或带扩展名的路径。

        Returns:
            对应的 ``BaseParser`` 实例。

        Raises:
            ValueError: 不支持的文件类型。
        """
        import os

        ext = os.path.splitext(file_name.lower())[1]
        parser_cls = _PARSER_MAP.get(ext)

        if parser_cls is None:
            supported = ", ".join(sorted(_PARSER_MAP.keys()))
            raise ValueError(
                f"不支持的文件类型: '{ext}'。支持的类型: {supported}"
            )

        logger.debug("选用解析器: %s -> %s", file_name, parser_cls.__name__)
        return parser_cls()
