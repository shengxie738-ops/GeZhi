"""API 路由汇总。"""

from __future__ import annotations

from fastapi import APIRouter

from app.api.health import router as health_router
from app.api.ingest import router as ingest_router
from app.api.retrieve import router as retrieve_router
from app.api.generate import router as generate_router

api_router = APIRouter()

api_router.include_router(health_router, tags=["health"])
api_router.include_router(ingest_router, tags=["ingest"])
api_router.include_router(retrieve_router, tags=["retrieve"])
api_router.include_router(generate_router, tags=["generate"])
