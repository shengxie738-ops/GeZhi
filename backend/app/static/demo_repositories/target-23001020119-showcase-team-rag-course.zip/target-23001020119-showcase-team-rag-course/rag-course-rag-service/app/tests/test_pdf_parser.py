"""PDF 解析器测试。"""

from __future__ import annotations

import pytest

from app.parsers.pdf_parser import PDFParser
from app.parsers.base import ParsedPage


class TestPDFParser:
    """PDF 解析器单元测试。"""

    def setup_method(self):
        self.parser = PDFParser()

    def test_parse_returns_list(self, sample_pdf_bytes: bytes):
        """测试解析返回列表类型。"""
        result = self.parser.parse(sample_pdf_bytes, "test.pdf")
        assert isinstance(result, list)

    def test_parse_returns_parsed_pages(self, sample_pdf_bytes: bytes):
        """测试每条结果都是 ParsedPage 类型。"""
        result = self.parser.parse(sample_pdf_bytes, "test.pdf")
        for page in result:
            assert isinstance(page, ParsedPage)
            assert hasattr(page, "page_number")
            assert hasattr(page, "text")
            assert page.page_number >= 1

    def test_parse_empty_content(self):
        """测试解析空内容时不报错。"""
        # 空字节不是有效 PDF，应该抛出异常
        with pytest.raises(Exception):
            self.parser.parse(b"", "empty.pdf")
