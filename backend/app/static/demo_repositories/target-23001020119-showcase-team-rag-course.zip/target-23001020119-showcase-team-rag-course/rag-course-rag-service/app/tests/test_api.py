"""API 端点集成测试。"""

from __future__ import annotations

import os

import pytest

# 确保 Mock 模式
os.environ["MOCK_MODE"] = "true"

from fastapi.testclient import TestClient

from app.main import app


@pytest.fixture
def client() -> TestClient:
    """创建测试客户端。"""
    return TestClient(app)


@pytest.fixture
def valid_headers() -> dict:
    """有效的认证头。"""
    return {"Authorization": "Bearer dev-internal-token-change-in-production"}


class TestHealthEndpoint:
    """健康检查端点测试。"""

    def test_health_check(self, client: TestClient):
        """测试健康检查返回 200。"""
        resp = client.get("/internal/v1/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "healthy"

    def test_root_endpoint(self, client: TestClient):
        """测试根端点。"""
        resp = client.get("/")
        assert resp.status_code == 200
        data = resp.json()
        assert data["service"] == "rag-course-service"


class TestIngestEndpoint:
    """入库端点测试。"""

    def test_ingest_requires_auth(self, client: TestClient):
        """测试入库端点需要认证。"""
        resp = client.post(
            "/internal/v1/ingest",
            json={"documents": []},
        )
        assert resp.status_code == 422  # 缺少 Authorization header

    def test_ingest_invalid_token(self, client: TestClient):
        """测试无效 token 被拒绝。"""
        resp = client.post(
            "/internal/v1/ingest",
            json={"documents": []},
            headers={"Authorization": "Bearer wrong-token"},
        )
        assert resp.status_code == 401

    def test_ingest_empty_documents(self, client: TestClient, valid_headers: dict):
        """测试空文档列表。"""
        resp = client.post(
            "/internal/v1/ingest",
            json={"documents": []},
            headers=valid_headers,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert data["data"]["total"] == 0

    def test_ingest_with_document(self, client: TestClient, valid_headers: dict):
        """测试正常入库请求。"""
        payload = {
            "documents": [
                {
                    "document_id": "test-doc-1",
                    "course_id": "course-1",
                    "chapter_id": "ch-1",
                    "title": "测试文档",
                    "source_type": "document",
                    "file_info": {
                        "file_key": "test/doc1.pdf",
                        "file_name": "test.pdf",
                        "file_size": 1024,
                        "file_type": "application/pdf",
                    },
                    "teacher_verified": False,
                }
            ]
        }
        resp = client.post(
            "/internal/v1/ingest",
            json=payload,
            headers=valid_headers,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert data["data"]["total"] == 1


class TestRetrieveEndpoint:
    """检索端点测试。"""

    def test_retrieve_requires_auth(self, client: TestClient):
        """测试检索端点需要认证。"""
        resp = client.post(
            "/internal/v1/retrieve",
            json={"query": "测试", "course_id": "c1"},
        )
        assert resp.status_code == 422

    def test_retrieve_basic(self, client: TestClient, valid_headers: dict):
        """测试基本检索。"""
        payload = {
            "query": "人工智能",
            "course_id": "course-1",
            "top_k": 5,
            "use_hybrid": False,
            "use_rerank": False,
        }
        resp = client.post(
            "/internal/v1/retrieve",
            json=payload,
            headers=valid_headers,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert data["data"]["query"] == "人工智能"


class TestGenerateEndpoint:
    """生成端点测试。"""

    def test_generate_requires_auth(self, client: TestClient):
        """测试生成端点需要认证。"""
        resp = client.post(
            "/internal/v1/generate",
            json={"query": "测试", "course_id": "c1"},
        )
        assert resp.status_code == 422

    def test_generate_basic(self, client: TestClient, valid_headers: dict):
        """测试基本生成。"""
        payload = {
            "query": "什么是人工智能？",
            "course_id": "course-1",
            "top_k": 5,
            "stream": False,
        }
        resp = client.post(
            "/internal/v1/generate",
            json=payload,
            headers=valid_headers,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["success"] is True
        assert "answer" in data["data"]
        assert data["data"]["status"] in ["success", "evidence_insufficient", "error"]
