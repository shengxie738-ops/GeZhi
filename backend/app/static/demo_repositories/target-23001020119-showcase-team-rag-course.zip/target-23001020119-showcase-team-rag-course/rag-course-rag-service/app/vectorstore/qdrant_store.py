"""Qdrant 向量存储实现。"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from app.core.config import settings
from app.vectorstore.base import BaseVectorStore, SearchResult, VectorRecord

logger = logging.getLogger(__name__)


class QdrantVectorStore(BaseVectorStore):
    """基于 Qdrant 的向量存储。"""

    def __init__(
        self,
        url: str | None = None,
        api_key: str | None = None,
        collection: str | None = None,
    ):
        self.url = url or settings.qdrant_url
        self.api_key = api_key or settings.qdrant_api_key
        self.collection = collection or settings.qdrant_collection
        self._client = None

    def _get_client(self):
        """延迟初始化 Qdrant 客户端。"""
        if self._client is None:
            from qdrant_client import QdrantClient

            kwargs: Dict[str, Any] = {"url": self.url}
            if self.api_key:
                kwargs["api_key"] = self.api_key
            self._client = QdrantClient(**kwargs)
        return self._client

    async def create_collection(self, dimension: int) -> None:
        """创建 Qdrant 集合。"""
        from qdrant_client.models import Distance, VectorParams

        client = self._get_client()

        # 检查集合是否已存在
        collections = client.get_collections().collections
        existing_names = [c.name for c in collections]

        if self.collection in existing_names:
            logger.info("Qdrant 集合 '%s' 已存在，跳过创建", self.collection)
            return

        client.create_collection(
            collection_name=self.collection,
            vectors_config=VectorParams(size=dimension, distance=Distance.COSINE),
        )
        logger.info(
            "Qdrant 集合 '%s' 创建成功, 维度=%d", self.collection, dimension
        )

    async def upsert_vectors(self, records: List[VectorRecord]) -> int:
        """批量写入向量到 Qdrant。"""
        from qdrant_client.models import PointStruct

        client = self._get_client()
        points = [
            PointStruct(id=r.id, vector=r.vector, payload=r.payload)
            for r in records
        ]

        # 分批写入，每批 100 条
        batch_size = 100
        total = 0
        for i in range(0, len(points), batch_size):
            batch = points[i : i + batch_size]
            client.upsert(collection_name=self.collection, points=batch)
            total += len(batch)

        logger.info("Qdrant 写入 %d 条向量到集合 '%s'", total, self.collection)
        return total

    async def search(
        self,
        vector: List[float],
        top_k: int = 10,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[SearchResult]:
        """向量相似度检索。"""
        from qdrant_client.models import Filter, FieldCondition, MatchValue

        client = self._get_client()

        qdrant_filter = None
        if filters:
            conditions = []
            for key, value in filters.items():
                conditions.append(
                    FieldCondition(key=key, match=MatchValue(value=value))
                )
            qdrant_filter = Filter(must=conditions)

        results = client.search(
            collection_name=self.collection,
            query_vector=vector,
            limit=top_k,
            query_filter=qdrant_filter,
        )

        search_results = [
            SearchResult(
                id=str(hit.id),
                score=hit.score,
                payload=hit.payload or {},
            )
            for hit in results
        ]
        logger.debug("Qdrant 检索返回 %d 条结果", len(search_results))
        return search_results

    async def delete_by_document(self, document_id: str) -> int:
        """按文档 ID 删除向量。"""
        from qdrant_client.models import Filter, FieldCondition, MatchValue

        client = self._get_client()
        qdrant_filter = Filter(
            must=[FieldCondition(key="document_id", match=MatchValue(value=document_id))]
        )
        result = client.delete(
            collection_name=self.collection, points_selector=qdrant_filter
        )
        deleted = result.deleted_count if hasattr(result, "deleted_count") else 0
        logger.info("按文档删除 %d 条向量: %s", deleted, document_id)
        return deleted

    async def delete_by_course(self, course_id: str) -> int:
        """按课程 ID 删除向量。"""
        from qdrant_client.models import Filter, FieldCondition, MatchValue

        client = self._get_client()
        qdrant_filter = Filter(
            must=[FieldCondition(key="course_id", match=MatchValue(value=course_id))]
        )
        result = client.delete(
            collection_name=self.collection, points_selector=qdrant_filter
        )
        deleted = result.deleted_count if hasattr(result, "deleted_count") else 0
        logger.info("按课程删除 %d 条向量: %s", deleted, course_id)
        return deleted

    async def update_payload(self, point_id: str, payload: Dict[str, Any]) -> bool:
        """更新向量 payload。"""
        from qdrant_client.models import PointIdsList

        client = self._get_client()
        try:
            client.set_payload(
                collection_name=self.collection,
                payload=payload,
                points=PointIdsList(points=[point_id]),
            )
            return True
        except Exception:
            logger.exception("更新 payload 失败: %s", point_id)
            return False
