"""文本切分器基类与公共数据结构。"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class TextChunk:
    """切分后的文本块。"""

    chunk_no: int = field(description="块序号（文档内唯一）")
    text: str = field(description="文本内容")
    page_start: int = field(default=0, description="起始页码")
    page_end: int = field(default=0, description="结束页码")
    title_path: Optional[str] = field(default=None, description="标题层级路径，如 '第1章 > 1.1节'")
    token_count: int = field(default=0, description="Token/字符数量")


class BaseChunker(ABC):
    """文本切分器抽象基类。"""

    @abstractmethod
    def chunk(
        self,
        pages: List[str],
        page_numbers: Optional[List[int]] = None,
    ) -> List[TextChunk]:
        """将文本按策略切分为若干块。

        Args:
            pages: 按页组织的文本列表。
            page_numbers: 对应的页码列表（可选，用于追踪来源页码）。

        Returns:
            ``TextChunk`` 列表。
        """
        ...
