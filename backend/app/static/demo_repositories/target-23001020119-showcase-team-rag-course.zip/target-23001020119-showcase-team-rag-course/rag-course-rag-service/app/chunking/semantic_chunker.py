"""基于句子相似度的语义切分器。"""

from __future__ import annotations

import logging
import re
from typing import List, Optional

from app.chunking.base import BaseChunker, TextChunk

logger = logging.getLogger(__name__)


class SemanticChunker(BaseChunker):
    """基于句子语义相似度的切分器。

    策略：
    1. 将文本拆分为句子。
    2. 计算相邻句子的余弦相似度。
    3. 在相似度低于阈值的位置切分，形成语义完整的块。
    4. 对过长的块进一步做字符级切分。
    """

    def __init__(
        self,
        similarity_threshold: float = 0.5,
        max_chunk_size: int = 512,
        min_chunk_size: int = 50,
    ):
        self.similarity_threshold = similarity_threshold
        self.max_chunk_size = max_chunk_size
        self.min_chunk_size = min_chunk_size

    def chunk(
        self,
        pages: List[str],
        page_numbers: Optional[List[int]] = None,
    ) -> List[TextChunk]:
        """执行语义切分。"""
        if page_numbers is None:
            page_numbers = list(range(1, len(pages) + 1))

        full_text = "\n\n".join(pages)
        sentences = self._split_sentences(full_text)

        if len(sentences) <= 2:
            return [
                TextChunk(
                    chunk_no=1,
                    text=full_text.strip(),
                    page_start=page_numbers[0],
                    page_end=page_numbers[-1],
                    token_count=len(full_text),
                )
            ]

        # 尝试基于相似度切分
        try:
            from sentence_transformers import SentenceTransformer
            import numpy as np

            model = SentenceTransformer("shibing624/text2vec-base-chinese")
            embeddings = model.encode(sentences)
            similarities = self._compute_similarities(embeddings)
            split_indices = self._find_split_points(similarities)
        except (ImportError, Exception):
            logger.warning("sentence-transformers 不可用，回退到按字符数切分")
            split_indices = self._char_based_split_indices(sentences)

        # 构建语义块
        chunks: List[TextChunk] = []
        prev_idx = 0

        for idx in split_indices:
            chunk_text = " ".join(sentences[prev_idx:idx]).strip()
            if chunk_text and len(chunk_text) >= self.min_chunk_size:
                chunks.append(
                    TextChunk(
                        chunk_no=len(chunks) + 1,
                        text=chunk_text,
                        page_start=page_numbers[0],
                        page_end=page_numbers[-1],
                        token_count=len(chunk_text),
                    )
                )
            prev_idx = idx

        # 处理最后一个块
        if prev_idx < len(sentences):
            chunk_text = " ".join(sentences[prev_idx:]).strip()
            if chunk_text and len(chunk_text) >= self.min_chunk_size:
                chunks.append(
                    TextChunk(
                        chunk_no=len(chunks) + 1,
                        text=chunk_text,
                        page_start=page_numbers[0],
                        page_end=page_numbers[-1],
                        token_count=len(chunk_text),
                    )
                )

        # 对过长的块再切分
        final_chunks: List[TextChunk] = []
        for chunk in chunks:
            if len(chunk.text) > self.max_chunk_size:
                sub = self._split_long_chunk(chunk)
                final_chunks.extend(sub)
            else:
                final_chunks.append(chunk)

        # 重新编号
        for i, chunk in enumerate(final_chunks):
            chunk.chunk_no = i + 1

        logger.info("SemanticChunker 切分完成: %d 块", len(final_chunks))
        return final_chunks

    @staticmethod
    def _split_sentences(text: str) -> List[str]:
        """将文本拆分为句子（中英文混合支持）。"""
        # 按句号、问号、感叹号拆分
        raw = re.split(r"(?<=[。！？.!?])\s*", text)
        return [s.strip() for s in raw if s.strip()]

    @staticmethod
    def _compute_similarities(embeddings) -> list:
        """计算相邻向量的余弦相似度。"""
        import numpy as np

        sims: list = []
        for i in range(len(embeddings) - 1):
            dot = np.dot(embeddings[i], embeddings[i + 1])
            norm_a = np.linalg.norm(embeddings[i])
            norm_b = np.linalg.norm(embeddings[i + 1])
            if norm_a > 0 and norm_b > 0:
                sims.append(float(dot / (norm_a * norm_b)))
            else:
                sims.append(0.0)
        return sims

    def _find_split_points(self, similarities: list) -> List[int]:
        """根据相似度阈值找切分点。"""
        split_indices: List[int] = []
        for i, sim in enumerate(similarities):
            if sim < self.similarity_threshold:
                split_indices.append(i + 1)
        # 确保至少有头有尾
        if not split_indices or split_indices[0] != 0:
            pass  # 不在开头切分
        return split_indices

    def _char_based_split_indices(self, sentences: List[str]) -> List[int]:
        """字符数兜底切分。"""
        indices: List[int] = []
        char_count = 0
        for i, s in enumerate(sentences):
            char_count += len(s)
            if char_count >= self.max_chunk_size:
                indices.append(i + 1)
                char_count = 0
        return indices

    def _split_long_chunk(self, chunk: TextChunk) -> List[TextChunk]:
        """将过长的块按字符数切分。"""
        sub_chunks: List[TextChunk] = []
        text = chunk.text
        start = 0

        while start < len(text):
            end = min(start + self.max_chunk_size, len(text))
            sub_text = text[start:end].strip()
            if sub_text:
                sub_chunks.append(
                    TextChunk(
                        chunk_no=0,
                        text=sub_text,
                        page_start=chunk.page_start,
                        page_end=chunk.page_end,
                        token_count=len(sub_text),
                    )
                )
            start += self.max_chunk_size - self.min_chunk_size

        return sub_chunks
