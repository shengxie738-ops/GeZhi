# RAG 流程文档

## 文档入库流程

```mermaid
sequenceDiagram
    participant T as 教师
    participant B as Spring Boot
    participant O as MinIO
    participant R as RAG Service
    participant Q as Qdrant

    T->>B: POST /documents/upload
    B->>O: 保存原始文件
    B->>B: 写入文档记录 (UPLOADED)
    B->>R: POST /internal/v1/ingest
    R->>O: 下载文件
    R->>R: 解析文本 → 清洗 → 切分 Chunk
    R->>R: 生成 Embedding 向量
    R->>Q: 批量写入向量
    R->>B: 返回处理完成
    B-->>T: 文档已就绪
```

### 解析状态流转

```
UPLOADED → PARSING → CHUNKING → EMBEDDING → INDEXED
                                          ↓ (失败)
                                         FAILED
```

## 文本解析

根据文件类型自动选择解析器：PDF 使用 PyMuPDF、DOCX 使用 python-docx、Markdown/TXT 直接读取。解析后统一进行文本清洗：去除页眉页脚、合并多余空白、过滤控制字符，保留代码块和数学公式。

## 文本切分

| 策略 | 说明 | 适用场景 |
|------|------|---------|
| 重叠窗口切分 | 按固定长度（默认 512 token）切分，相邻块重叠 120 token | 结构化程度低的文档 |
| 语义切分 | 基于句子相似度检测语义边界切分 | 课件、讲义等结构化文档 |

每个知识块保留 document_id、course_id、chapter_id、标题路径、页码等元数据。

## 混合检索

```mermaid
flowchart LR
    Q[用户问题] --> BM25[BM25 关键词检索]
    Q --> VEC[向量相似度检索]
    BM25 --> MERGE[结果融合]
    VEC --> MERGE
    MERGE --> DEDUP[去重]
    DEDUP --> RERANK[重排序]
    RERANK --> RESULT[Top-K 结果]
```

- **BM25 检索**：jieba 中文分词 + rank-bm25，从 MySQL 全文索引检索
- **向量检索**：Qdrant 余弦相似度检索，强制 `course_id` 过滤
- **混合融合**：`score = 0.35×BM25 + 0.55×向量 + 0.10×教师认证加权`
- **重排序**：Cross-Encoder 精排，保留 Top-5，最低相似度 0.45

## 答案生成

| 证据状态 | 处理方式 |
|---------|---------|
| SUFFICIENT | 携带检索上下文，由 LLM 生成带引用的回答 |
| PARTIAL | 部分基于知识库 + 通用知识补充，明确标注 |
| INSUFFICIENT | 返回固定模板，列出可能相关的方向 |

系统提示词锚定"课程助教"角色，要求每个结论关联引用编号，不得编造课程内容，不暴露系统提示词和 API Key。支持 SSE 流式输出。
