# 数据库文档

> 数据库：`rag_course` | 字符集：`utf8mb4` | 引擎：`InnoDB` | 共 19 张表

## ER 关系图

```mermaid
erDiagram
    sys_user ||--o{ course : "创建"
    sys_user ||--o{ course_member : "加入"
    course ||--o{ course_member : "成员"
    course ||--o{ knowledge_document : "文档"
    course ||--o{ forum_question : "问题"
    course ||--o{ chat_session : "会话"
    course ||--o{ wrong_question : "错题"
    course ||--o| rag_config : "配置"
    knowledge_document ||--o{ knowledge_chunk : "知识块"
    knowledge_document ||--o{ ingest_job : "解析任务"
    forum_question ||--o{ forum_answer : "回答"
    chat_session ||--o{ chat_message : "消息"
    chat_message ||--o{ message_citation : "引用"
    chat_message ||--o| answer_feedback : "反馈"
```

## 核心表结构

### 用户与课程

| 表名 | 核心字段 | 说明 |
|------|---------|------|
| `sys_user` | username, password_hash, real_name, role(student/teacher/admin) | 用户表，BCrypt 密码 |
| `course` | name, code, teacher_id, invite_code, status | 课程表 |
| `course_member` | course_id, user_id, member_role | 课程成员表，唯一约束 |
| `course_chapter` | course_id, title, sort_no | 课程章节表 |

### 知识库

| 表名 | 核心字段 | 说明 |
|------|---------|------|
| `knowledge_document` | course_id, title, parse_status, source_type, storage_object_key | 文档表，记录解析状态 |
| `knowledge_chunk` | document_id, course_id, cleaned_text, vector_id, token_count | 知识块表，全文索引支持 BM25 |
| `ingest_job` | document_id, status, progress, error_message | 解析任务表 |

### 论坛与问答

| 表名 | 核心字段 | 说明 |
|------|---------|------|
| `forum_question` | course_id, title, content, tags, status | 问题表，全文索引 |
| `forum_answer` | question_id, content, is_accepted, teacher_verified | 回答表 |
| `wrong_question` | course_id, user_id, question_content, correct_answer, knowledge_tags | 错题表 |
| `favorite` | user_id, target_type, target_id | 收藏表 |

### 聊天与会话

| 表名 | 核心字段 | 说明 |
|------|---------|------|
| `chat_session` | user_id, course_id, title | 会话表 |
| `chat_message` | session_id, role, content, model_name, evidence_score | 消息表 |
| `message_citation` | message_id, source_type, chunk_id, quote_text, score | 引用表 |
| `answer_feedback` | message_id, user_id, feedback_type | 反馈表 |

### 系统配置

| 表名 | 核心字段 | 说明 |
|------|---------|------|
| `model_config` | provider, model_name, encrypted_api_key, temperature | 模型配置表 |
| `rag_config` | course_id, chunk_size, top_k, keyword_weight, vector_weight | 课程 RAG 配置表 |
| `notification` | user_id, title, type, is_read | 通知表 |
| `audit_log` | user_id, module, action, request_ip | 审计日志表 |

## 数据隔离策略

所有业务数据通过 `course_id` 实现课程级隔离：学生只能访问已加入课程的数据，教师只能管理自己创建的课程，Qdrant 向量检索强制使用 `course_id` 过滤条件。
