# 部署文档

## 服务清单

| 服务 | 端口 | 说明 |
|------|------|------|
| nginx | 80, 443 | 反向代理和静态资源 |
| backend | 8080 | Spring Boot 主后端 |
| rag-service | 8000 | FastAPI RAG 服务 |
| mysql | 3306 | MySQL 8 关系型数据库 |
| redis | 6379 | Redis 7 缓存 |
| qdrant | 6333 | Qdrant 向量数据库 |
| minio | 9000, 9001 | MinIO 对象存储 |

## 快速部署

```bash
git clone <repository-url> && cd rag-course
cp .env.example .env   # 编辑 .env，设置生产环境密钥
docker compose up -d --build
docker compose ps      # 验证所有服务状态
```

## 环境变量（关键项）

| 变量 | 说明 | 生产要求 |
|------|------|---------|
| `JWT_SECRET` | JWT 签名密钥 | 替换为 256 位以上随机值 |
| `MODEL_API_KEY` | LLM API Key | 必须设置 |
| `MINIO_ACCESS_KEY/SECRET_KEY` | MinIO 凭证 | 替换默认 minioadmin |
| `RAG_INTERNAL_TOKEN` | 内部 API Token | 替换为强随机值 |
| `MYSQL_ROOT_PASSWORD` | MySQL root 密码 | 必须设置 |
| `EMBEDDING_PROVIDER/MODEL` | Embedding 模型 | 根据需求选择 |

## 数据持久化

通过 Docker Named Volumes 持久化：MySQL（`/var/lib/mysql`）、Redis（`/data`）、MinIO（`/data`）、Qdrant（`/qdrant/storage`）。生产环境不使用 bind mount。

## 备份策略

| 数据 | 频率 | 保留 | 方式 |
|------|------|------|------|
| MySQL | 每日 02:00 | 30 天 | mysqldump |
| MinIO | 每周日 03:00 | 90 天 | mc mirror |
| Qdrant | 每日 03:00 | 7 天 | API snapshot |

## HTTPS 配置

生产环境通过 Nginx 反向代理配置 SSL 证书，所有服务通过 HTTPS 访问。

## 安全加固清单

- [ ] 修改所有默认密码（MySQL、MinIO、Redis）
- [ ] 替换 JWT Secret 和 RAG Internal Token
- [ ] 配置 HTTPS / TLS
- [ ] 限制 Redis 不监听外网
- [ ] 配置防火墙规则
- [ ] 启用 MySQL 慢查询日志
- [ ] 设置 Docker 容器资源限制
