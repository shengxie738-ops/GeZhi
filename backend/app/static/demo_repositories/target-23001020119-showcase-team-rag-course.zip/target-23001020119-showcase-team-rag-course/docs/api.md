# API 接口文档

> 统一前缀：`/api` | 通用响应格式：`{ "code": 0, "message": "success", "data": { ... } }`

## 接口总览

### 1. 认证模块（5 个）

| 方法 | 路径 | 简述 | 权限 |
|------|------|------|------|
| POST | `/auth/login` | 用户登录，返回 Token + 用户信息 | 公开 |
| POST | `/auth/register` | 学生注册 | 公开 |
| POST | `/auth/refresh` | 刷新 AccessToken | 需有效 refresh_token |
| POST | `/auth/logout` | 用户登出 | 需登录 |
| GET | `/auth/profile` | 获取当前用户信息 | 需登录 |

### 2. 课程模块（7 个）

| 方法 | 路径 | 简述 | 权限 |
|------|------|------|------|
| GET | `/courses` | 课程列表（分页） | 需登录 |
| POST | `/courses` | 创建课程 | 教师/管理员 |
| GET | `/courses/{courseId}` | 课程详情 | 课程成员 |
| PUT | `/courses/{courseId}` | 更新课程 | 课程创建者 |
| DELETE | `/courses/{courseId}` | 删除课程 | 课程创建者/管理员 |
| POST | `/courses/{courseId}/join` | 通过邀请码加入课程 | 学生 |
| GET | `/courses/{courseId}/members` | 课程成员列表 | 课程成员 |

### 3. 文档模块（9 个）

| 方法 | 路径 | 简述 | 权限 |
|------|------|------|------|
| POST | `/documents/upload` | 上传文档（PDF/DOCX/MD/TXT） | 教师 |
| GET | `/courses/{courseId}/documents` | 文档列表 | 课程成员 |
| GET | `/documents/{documentId}` | 文档详情 | 课程成员 |
| DELETE | `/documents/{documentId}` | 删除文档 | 教师 |
| POST | `/documents/{documentId}/parse` | 触发文档解析 | 教师 |
| POST | `/documents/{documentId}/reindex` | 重新索引文档 | 教师 |
| GET | `/documents/{documentId}/chunks` | 文档分块列表 | 教师 |
| PUT | `/chunks/{chunkId}` | 更新分块内容 | 教师 |
| GET | `/documents/{documentId}/status` | 获取解析状态 | 课程成员 |

### 4. RAG 问答模块（7 个）

| 方法 | 路径 | 简述 | 权限 |
|------|------|------|------|
| POST | `/rag/search` | 知识库搜索 | 课程成员 |
| POST | `/rag/ask` | RAG 提问（非流式） | 课程成员 |
| POST | `/rag/ask/stream` | RAG 提问（SSE 流式） | 课程成员 |
| GET | `/chat/sessions` | 会话列表 | 课程成员 |
| POST | `/chat/sessions` | 创建会话 | 课程成员 |
| GET | `/chat/sessions/{sessionId}` | 获取会话消息 | 会话所有者 |
| POST | `/chat/messages/{messageId}/feedback` | 提交回答反馈 | 课程成员 |

### 5. 论坛模块（10 个）

| 方法 | 路径 | 简述 | 权限 |
|------|------|------|------|
| GET | `/courses/{courseId}/forum/questions` | 问题列表 | 课程成员 |
| POST | `/courses/{courseId}/forum/questions` | 创建问题 | 学生 |
| GET | `/forum/questions/{questionId}` | 问题详情 | 课程成员 |
| PUT | `/forum/questions/{questionId}` | 更新问题 | 问题作者 |
| DELETE | `/forum/questions/{questionId}` | 删除问题 | 问题作者/教师 |
| POST | `/forum/questions/{questionId}/like` | 点赞问题 | 课程成员 |
| GET | `/forum/questions/{questionId}/answers` | 回答列表 | 课程成员 |
| POST | `/forum/questions/{questionId}/answers` | 创建回答 | 课程成员 |
| POST | `/forum/answers/{answerId}/accept` | 接受最佳答案 | 问题作者 |
| POST | `/forum/answers/{answerId}/verify` | 教师认证回答 | 教师 |

### 6. 错题模块（6 个）

| 方法 | 路径 | 简述 | 权限 |
|------|------|------|------|
| GET | `/courses/{courseId}/wrong-questions` | 错题列表 | 课程成员 |
| POST | `/wrong-questions` | 创建错题 | 学生 |
| GET | `/wrong-questions/{id}` | 错题详情 | 课程成员 |
| PUT | `/wrong-questions/{id}` | 更新错题 | 错题所有者 |
| DELETE | `/wrong-questions/{id}` | 删除错题 | 错题所有者 |
| POST | `/wrong-questions/import` | 批量导入错题 | 教师 |

### 7. 教师分析模块（6 个）

| 方法 | 路径 | 简述 | 权限 |
|------|------|------|------|
| GET | `/analytics/overview` | 分析概览 | 教师 |
| GET | `/analytics/hot-questions` | 热门问题 | 教师 |
| GET | `/analytics/unresolved` | 未解决问题 | 教师 |
| GET | `/analytics/knowledge-gaps` | 知识缺口分析 | 教师 |
| GET | `/analytics/documents` | 文档使用统计 | 教师 |
| GET | `/analytics/model-usage` | 模型使用统计 | 教师 |

### 8. 模型配置模块（7 个）

| 方法 | 路径 | 简述 | 权限 |
|------|------|------|------|
| GET | `/models` | 模型配置列表 | 管理员 |
| POST | `/models` | 创建模型配置 | 管理员 |
| PUT | `/models/{id}` | 更新模型配置 | 管理员 |
| DELETE | `/models/{id}` | 删除模型配置 | 管理员 |
| POST | `/models/test` | 测试模型连接 | 管理员 |
| GET | `/rag/config` | 获取课程 RAG 配置 | 教师 |
| PUT | `/rag/config` | 更新课程 RAG 配置 | 教师 |

### 9. 通知模块（4 个）

| 方法 | 路径 | 简述 | 权限 |
|------|------|------|------|
| GET | `/notifications` | 通知列表 | 需登录 |
| GET | `/notifications/unread-count` | 未读通知数量 | 需登录 |
| PUT | `/notifications/{notificationId}/read` | 标记单条已读 | 通知所有者 |
| PUT | `/notifications/read-all` | 标记全部已读 | 需登录 |

## 请求/响应示例

### 登录请求

```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"teacher","password":"Teacher@123"}'
```

### 登录响应

```json
{
  "code": 0,
  "message": "success",
  "data": {
    "access_token": "eyJhbGciOiJIUzI1NiJ9...",
    "refresh_token": "eyJhbGciOiJIUzI1NiJ9...",
    "token_type": "Bearer",
    "expires_in": 3600,
    "user": {
      "id": 1,
      "username": "teacher",
      "real_name": "张老师",
      "role": "teacher",
      "avatar_url": null
    }
  }
}
```

### RAG 流式提问（SSE）

```bash
curl -X POST http://localhost:8080/api/rag/ask/stream \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"course_id":1001,"question":"什么是向量检索？"}'
```

SSE 流式事件：

```
data: {"type":"token","data":"向量检索"}
data: {"type":"token","data":"是一种..."}
data: {"type":"citation","data":[{"source_type":"COURSE_FILE","document_title":"RAG讲义","page_no":18,"score":0.82}]}
data: {"type":"done","data":{"answer":"向量检索是...","evidence_status":"SUFFICIENT"}}
data: [DONE]
```

> 完整 Swagger UI 文档：`http://localhost:8080/api/swagger-ui.html`
