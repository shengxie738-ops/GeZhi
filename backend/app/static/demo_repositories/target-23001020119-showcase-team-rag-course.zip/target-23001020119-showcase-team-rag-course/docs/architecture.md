# 系统架构文档

## 整体架构

```mermaid
flowchart TB
    subgraph Client[客户端]
        W[Vue 3 SPA]
    end
    subgraph Gateway[网关层]
        N[Nginx 反向代理]
    end
    subgraph Backend[后端服务]
        B[Spring Boot 主后端 :8080]
        R[FastAPI RAG 服务 :8000]
    end
    subgraph Storage[存储层]
        M[(MySQL 8)]
        RE[(Redis 7)]
        O[(MinIO)]
        Q[(Qdrant)]
    end
    subgraph External[外部服务]
        LLM[通义千问 / OpenAI 兼容 API]
    end

    W -->|HTTP / SSE| N
    N -->|/api/*| B
    B -->|Internal API| R
    B --> M
    B --> RE
    B --> O
    R --> M
    R --> Q
    R --> LLM
```

## 前端

Vue 3 + TypeScript + Vite 单页应用。通过 Vue Router 按角色（学生/教师/管理员）划分页面，Pinia 管理全局状态，Axios 封装 API 请求并自动附加 JWT Token。前端提供聊天界面、论坛问答、知识库管理和教学分析面板。

## 后端

Spring Boot 3.4 主后端，采用 Controller → Service → Mapper → Entity 四层架构。负责用户认证（JWT + BCrypt）、课程管理、文档上传（存储至 MinIO）、会话管理和教学分析。内部通过专用 Token 调用 RAG 服务的 API。

## RAG 服务

FastAPI 微服务，采用 Pipeline 设计模式，各模块松耦合可独立替换。核心流程：文档解析 → 文本清洗与切分 → Embedding 向量生成 → 混合检索（BM25 + 向量） → 重排序 → LLM 答案生成。支持 SSE 流式响应，内置 Mock 模式用于开发调试。

## 数据库

MySQL 8 存储核心业务数据（用户、课程、文档、知识块、会话、消息等 19 张表），通过 `course_id` 实现课程级数据隔离。Redis 用于 JWT Token 存储和请求限流计数。Qdrant 向量数据库存储文档 Embedding，支持语义检索。MinIO 对象存储保存上传的课程文档文件。
