﻿<template>
  <div class="search-view">
    <PageHeader title="知识库搜索" description="在课程知识库中搜索相关内容" />

    <div class="search-layout">
      <!-- 搜索输入 -->
      <div class="search-bar-card">
        <div class="search-bar">
          <el-input
            v-model="searchQuery"
            placeholder="输入关键词搜索..."
            :prefix-icon="Search"
            clearable
            size="large"
            @keydown.enter="handleSearch"
          />
          <el-button
            type="primary"
            :icon="Search"
            size="large"
            :loading="searching"
            @click="handleSearch"
          >
            搜索
          </el-button>
        </div>

        <!-- 筛选条件 -->
        <div class="search-filters">
          <el-select v-model="selectedCourseId" placeholder="选择课程" clearable size="small">
            <el-option
              v-for="course in courses"
              :key="course.id"
              :label="course.name"
              :value="course.id"
            />
          </el-select>
          <el-select v-model="selectedFileType" placeholder="文件类型" clearable size="small">
            <el-option label="PDF" value="pdf" />
            <el-option label="DOCX" value="docx" />
            <el-option label="Markdown" value="md" />
            <el-option label="TXT" value="txt" />
          </el-select>
        </div>
      </div>

      <!-- 搜索结果 -->
      <div class="search-results" v-if="hasSearched">
        <div class="results-header" v-if="results.length > 0">
          <span>找到 {{ results.length }} 条相关结果</span>
        </div>

        <div class="results-list" v-loading="searching">
          <div
            v-for="(item, index) in results"
            :key="index"
            class="result-item"
            @click="toggleResult(index)"
          >
            <div class="result-top">
              <el-tag size="small" type="info">知识块</el-tag>
              <span class="result-title">{{ item.document_title }}</span>
              <el-tag v-if="item.page_number" size="small" type="info">
                P.{{ item.page_number }}
              </el-tag>
              <span class="result-score">
                相关度 {{ (item.score * 100).toFixed(0) }}%
              </span>
            </div>

            <div class="result-snippet" v-html="highlightSnippet(item.content)" />

            <!-- 展开详情 -->
            <transition name="el-zoom-in-top">
              <div v-if="expandedIndex === index" class="result-detail">
                <div class="detail-content">
                  <MarkdownRenderer :content="item.content" />
                </div>
              </div>
            </transition>
          </div>

          <el-empty v-if="!searching && results.length === 0 && hasSearched" description="未找到相关内容，试试其他关键词？" />
        </div>
      </div>

      <!-- 搜索历史 -->
      <div class="search-history-card" v-if="searchHistory.length > 0 && !hasSearched">
        <div class="history-header">
          <h4>搜索历史</h4>
          <el-button text type="danger" size="small" @click="clearHistory">清空</el-button>
        </div>
        <div class="history-tags">
          <el-tag
            v-for="(item, index) in searchHistory"
            :key="index"
            class="history-tag"
            effect="plain"
            @click="searchQuery = item; handleSearch()"
          >
            {{ item }}
          </el-tag>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { Search } from '@element-plus/icons-vue'
import { getCourses } from '@/api/course'
import { search } from '@/api/rag'
import type { Course } from '@/types/course'
import type { SearchResult } from '@/types/rag'
import PageHeader from '@/components/common/PageHeader.vue'
import MarkdownRenderer from '@/components/common/MarkdownRenderer.vue'

const courses = ref<Course[]>([])
const searchQuery = ref('')
const selectedCourseId = ref<number | undefined>()
const selectedFileType = ref('')
const searching = ref(false)
const hasSearched = ref(false)
const results = ref<SearchResult[]>([])
const expandedIndex = ref<number | null>(null)
const searchHistory = ref<string[]>([])

async function fetchCourses() {
  try {
    const res = await getCourses({ page: 1, page_size: 100 })
    courses.value = res.data.items || []
    if (courses.value.length > 0) {
      selectedCourseId.value = courses.value[0].id
    }
  } catch { /* 忽略 */ }
}

async function handleSearch() {
  if (!searchQuery.value.trim() || !selectedCourseId.value) return
  searching.value = true
  hasSearched.value = true

  // 保存搜索历史
  saveHistory(searchQuery.value.trim())

  try {
    const res = await search({
      query: searchQuery.value.trim(),
      course_id: selectedCourseId.value,
      top_k: 20,
      filters: selectedFileType.value ? { file_types: [selectedFileType.value] } : undefined
    })
    results.value = res.data || []
  } catch {
    // 错误已处理
  } finally {
    searching.value = false
  }
}

function toggleResult(index: number) {
  expandedIndex.value = expandedIndex.value === index ? null : index
}

function highlightSnippet(text: string): string {
  const snippet = text.slice(0, 200) + (text.length > 200 ? '...' : '')
  if (!searchQuery.value.trim()) return snippet
  const regex = new RegExp(`(${searchQuery.value.trim()})`, 'gi')
  return snippet.replace(regex, '<mark>$1</mark>')
}

function saveHistory(query: string) {
  const filtered = searchHistory.value.filter(h => h !== query)
  filtered.unshift(query)
  searchHistory.value = filtered.slice(0, 10)
  localStorage.setItem('search_history', JSON.stringify(searchHistory.value))
}

function clearHistory() {
  searchHistory.value = []
  localStorage.removeItem('search_history')
}

onMounted(() => {
  fetchCourses()
  const saved = localStorage.getItem('search_history')
  if (saved) {
    try { searchHistory.value = JSON.parse(saved) } catch { /* 忽略 */ }
  }
})
</script>

<style scoped>
.search-view {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.search-layout {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.search-bar-card {
  background: #fff;
  border-radius: 10px;
  padding: 20px;
}

.search-bar {
  display: flex;
  gap: 12px;
}

.search-filters {
  display: flex;
  gap: 12px;
  margin-top: 12px;
}

/* 结果 */
.results-header {
  font-size: 13px;
  color: #909399;
  margin-bottom: 12px;
}

.results-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.result-item {
  background: #fff;
  border: 1px solid #ebeef5;
  border-radius: 8px;
  padding: 16px;
  cursor: pointer;
  transition: all 0.2s;
}

.result-item:hover {
  border-color: #409eff;
  box-shadow: 0 2px 8px rgba(64, 158, 255, 0.08);
}

.result-top {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
}

.result-title {
  font-weight: 600;
  color: #303133;
  font-size: 14px;
}

.result-score {
  margin-left: auto;
  font-size: 12px;
  color: #67c23a;
  font-weight: 500;
}

.result-snippet {
  font-size: 13px;
  color: #606266;
  line-height: 1.6;
}

.result-snippet :deep(mark) {
  background: #fdf6ec;
  color: #e6a23c;
  padding: 0 2px;
  border-radius: 2px;
}

.result-detail {
  margin-top: 12px;
  padding-top: 12px;
  border-top: 1px solid #f2f3f5;
}

.detail-content {
  line-height: 1.7;
}

/* 搜索历史 */
.search-history-card {
  background: #fff;
  border-radius: 10px;
  padding: 20px;
}

.history-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
}

.history-header h4 {
  margin: 0;
  font-size: 15px;
  color: #303133;
}

.history-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.history-tag {
  cursor: pointer;
}

.history-tag:hover {
  color: #409eff;
  border-color: #409eff;
}
</style>
