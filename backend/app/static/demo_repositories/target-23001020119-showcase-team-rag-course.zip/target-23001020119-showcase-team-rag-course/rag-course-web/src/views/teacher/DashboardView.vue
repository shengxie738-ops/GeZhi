<template>
  <div class="page-container">
    <PageHeader title="教师仪表板" description="教学数据总览与待办事项" />

    <!-- 统计卡片 -->
    <el-row :gutter="20" class="stat-row">
      <el-col :span="6">
        <StatCard title="课程总数" :value="overview.total_documents" :icon="Reading" color="#409EFF" />
      </el-col>
      <el-col :span="6">
        <StatCard title="学生总数" :value="overview.total_students" :icon="User" color="#67C23A" />
      </el-col>
      <el-col :span="6">
        <StatCard title="今日提问" :value="todayQuestions" :icon="ChatDotRound" color="#E6A23C" />
      </el-col>
      <el-col :span="6">
        <StatCard title="待审核数" :value="pendingReviewCount" :icon="Notebook" color="#F56C6C" />
      </el-col>
    </el-row>

    <el-row :gutter="20" class="main-row">
      <!-- 最近7天提问趋势 -->
      <el-col :span="16">
        <el-card shadow="never" class="section-card">
          <template #header>
            <span class="card-title">最近7天提问趋势</span>
          </template>
          <LineChart
            height="300px"
            :x-axis="trendDates"
            :series="trendSeries"
          />
        </el-card>
      </el-col>

      <!-- 热门问题 TOP5 -->
      <el-col :span="8">
        <el-card shadow="never" class="section-card">
          <template #header>
            <span class="card-title">热门问题 TOP 5</span>
          </template>
          <div class="hot-questions">
            <div
              v-for="(item, index) in hotQuestions"
              :key="item.id"
              class="hot-item"
            >
              <span class="hot-rank" :class="`rank-${index + 1}`">{{ index + 1 }}</span>
              <div class="hot-info">
                <span class="hot-question">{{ item.question }}</span>
                <span class="hot-count">提问 {{ item.count }} 次</span>
              </div>
            </div>
            <el-empty v-if="hotQuestions.length === 0" description="暂无数据" :image-size="80" />
          </div>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="20" class="main-row">
      <!-- 待处理任务 -->
      <el-col :span="12">
        <el-card shadow="never" class="section-card">
          <template #header>
            <div class="card-header">
              <span class="card-title">待处理任务</span>
              <el-button type="primary" link>查看全部</el-button>
            </div>
          </template>
          <el-table :data="pendingTasks" size="small" stripe>
            <el-table-column prop="type" label="类型" width="120">
              <template #default="{ row }">
                <el-tag size="small" :type="row.type === '审核问答' ? 'warning' : 'info'">
                  {{ row.type }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="title" label="标题" show-overflow-tooltip />
            <el-table-column prop="time" label="时间" width="120" />
            <el-table-column label="操作" width="80">
              <template #default>
                <el-button type="primary" link size="small">处理</el-button>
              </template>
            </el-table-column>
          </el-table>
          <el-empty v-if="pendingTasks.length === 0" description="暂无待处理任务" :image-size="80" />
        </el-card>
      </el-col>

      <!-- 课程快捷入口 -->
      <el-col :span="12">
        <el-card shadow="never" class="section-card">
          <template #header>
            <div class="card-header">
              <span class="card-title">课程快捷入口</span>
              <el-button type="primary" link @click="$router.push('/teacher/courses')">管理课程</el-button>
            </div>
          </template>
          <div class="course-shortcuts">
            <div
              v-for="course in courses"
              :key="course.id"
              class="course-shortcut-item"
              @click="$router.push(`/teacher/courses/${course.id}`)"
            >
              <div class="course-icon" :style="{ backgroundColor: getCourseColor(course.id) + '15', color: getCourseColor(course.id) }">
                <el-icon :size="20"><Reading /></el-icon>
              </div>
              <div class="course-info">
                <span class="course-name">{{ course.name }}</span>
                <span class="course-meta">{{ course.member_count }} 名成员 · {{ course.document_count }} 份文档</span>
              </div>
              <el-icon class="arrow"><ArrowRight /></el-icon>
            </div>
            <el-empty v-if="courses.length === 0" description="暂无课程" :image-size="80" />
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { Reading, User, ChatDotRound, Notebook, ArrowRight } from '@element-plus/icons-vue'
import PageHeader from '@/components/common/PageHeader.vue'
import StatCard from '@/components/charts/StatCard.vue'
import LineChart from '@/components/charts/LineChart.vue'
import * as analyticsApi from '@/api/analytics'
import * as courseApi from '@/api/course'
import type { AnalyticsOverview, HotQuestion } from '@/types/analytics'
import type { Course } from '@/types/course'
import dayjs from 'dayjs'

const overview = reactive<AnalyticsOverview>({
  total_students: 0,
  total_documents: 0,
  total_chunks: 0,
  total_questions: 0,
  total_chat_sessions: 0,
  active_students_today: 0,
  avg_response_latency: 0,
  avg_answer_quality: 0,
  daily_stats: []
})

const hotQuestions = ref<HotQuestion[]>([])
const courses = ref<Course[]>([])
const todayQuestions = ref(0)
const pendingReviewCount = ref(0)

const trendDates = ref<string[]>([])
const trendSeries = ref<{ name: string; data: number[] }[]>([])

const pendingTasks = ref([
  { type: '审核问答', title: '学生对"Transformer注意力机制"的追问', time: '10分钟前' },
  { type: '未解决问题', title: '关于RAG检索策略的选择问题', time: '30分钟前' },
  { type: '审核问答', title: '文档解析失败需要重新上传', time: '1小时前' }
])

const courseColors = ['#409EFF', '#67C23A', '#E6A23C', '#F56C6C', '#909399', '#b37feb']

function getCourseColor(id: number) {
  return courseColors[id % courseColors.length]
}

function generateLast7Days() {
  const days: string[] = []
  for (let i = 6; i >= 0; i--) {
    days.push(dayjs().subtract(i, 'day').format('MM-DD'))
  }
  return days
}

async function fetchData() {
  try {
    const [overviewRes, hotRes, coursesRes] = await Promise.all([
      analyticsApi.getOverview(),
      analyticsApi.getHotQuestions(undefined, 5),
      courseApi.getCourses({ page: 1, page_size: 6 })
    ])

    Object.assign(overview, overviewRes.data)

    hotQuestions.value = hotRes.data || []
    courses.value = coursesRes.data.items || []

    const last7 = generateLast7Days()
    trendDates.value = last7

    const dailyMap = new Map<string, number>()
    overviewRes.data.daily_stats.forEach((d) => {
      dailyMap.set(dayjs(d.date).format('MM-DD'), d.questions)
    })
    trendSeries.value = [
      {
        name: '提问数',
        data: last7.map((d) => dailyMap.get(d) || 0)
      }
    ]

    const today = dayjs().format('YYYY-MM-DD')
    const todayStat = overviewRes.data.daily_stats.find((d) => d.date === today)
    todayQuestions.value = todayStat?.questions || 0
  } catch {
    // 加载失败使用默认数据
    const last7 = generateLast7Days()
    trendDates.value = last7
    trendSeries.value = [{ name: '提问数', data: [12, 19, 8, 15, 22, 17, 14] }]
    todayQuestions.value = 14
    pendingReviewCount.value = 3
  }
}

onMounted(() => {
  fetchData()
})
</script>

<style scoped>
.stat-row {
  margin-bottom: 20px;
}

.main-row {
  margin-bottom: 20px;
}

.section-card {
  border-radius: 8px;
  height: 100%;
}

.card-title {
  font-size: 16px;
  font-weight: 600;
  color: #303133;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.hot-questions {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.hot-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 8px 0;
  border-bottom: 1px solid #F2F6FC;
}

.hot-item:last-child {
  border-bottom: none;
}

.hot-rank {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  font-weight: 600;
  color: #fff;
  background-color: #C0C4CC;
  flex-shrink: 0;
}

.hot-rank.rank-1 { background-color: #F56C6C; }
.hot-rank.rank-2 { background-color: #E6A23C; }
.hot-rank.rank-3 { background-color: #409EFF; }

.hot-info {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
}

.hot-question {
  font-size: 14px;
  color: #303133;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.hot-count {
  font-size: 12px;
  color: #909399;
}

.course-shortcuts {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.course-shortcut-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px 12px;
  border-radius: 8px;
  cursor: pointer;
  transition: background-color 0.2s;
}

.course-shortcut-item:hover {
  background-color: #F5F7FA;
}

.course-icon {
  width: 40px;
  height: 40px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.course-info {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}

.course-name {
  font-size: 14px;
  font-weight: 500;
  color: #303133;
}

.course-meta {
  font-size: 12px;
  color: #909399;
}

.arrow {
  color: #C0C4CC;
}
</style>
