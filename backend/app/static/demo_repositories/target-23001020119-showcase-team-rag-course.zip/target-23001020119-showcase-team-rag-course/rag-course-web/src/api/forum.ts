import request from './request'
import type { ApiResponse, PageRequest, PageResponse } from '@/types/common'
import type {
  ForumQuestion,
  ForumAnswer,
  CreateQuestionRequest,
  CreateAnswerRequest
} from '@/types/forum'

/** 获取问题列表 */
export function getQuestions(courseId: number, params?: PageRequest & { status?: string; tag?: string }) {
  return request.get<ApiResponse<PageResponse<ForumQuestion>>>(`/courses/${courseId}/forum/questions`, {
    params
  })
}

/** 创建问题 */
export function createQuestion(courseId: number, data: CreateQuestionRequest) {
  return request.post<ApiResponse<ForumQuestion>>(`/courses/${courseId}/forum/questions`, data)
}

/** 获取问题详情 */
export function getQuestion(questionId: number) {
  return request.get<ApiResponse<ForumQuestion>>(`/forum/questions/${questionId}`)
}

/** 更新问题 */
export function updateQuestion(questionId: number, data: Partial<CreateQuestionRequest>) {
  return request.put<ApiResponse<ForumQuestion>>(`/forum/questions/${questionId}`, data)
}

/** 删除问题 */
export function deleteQuestion(questionId: number) {
  return request.delete<ApiResponse<null>>(`/forum/questions/${questionId}`)
}

/** 点赞问题 */
export function likeQuestion(questionId: number) {
  return request.post<ApiResponse<{ liked: boolean; like_count: number }>>(
    `/forum/questions/${questionId}/like`
  )
}

/** 获取问题的回答列表 */
export function getAnswers(questionId: number, params?: PageRequest) {
  return request.get<ApiResponse<PageResponse<ForumAnswer>>>(`/forum/questions/${questionId}/answers`, {
    params
  })
}

/** 创建回答 */
export function createAnswer(questionId: number, data: CreateAnswerRequest) {
  return request.post<ApiResponse<ForumAnswer>>(`/forum/questions/${questionId}/answers`, data)
}

/** 接受回答 */
export function acceptAnswer(answerId: number) {
  return request.post<ApiResponse<ForumAnswer>>(`/forum/answers/${answerId}/accept`)
}

/** 验证回答（教师） */
export function verifyAnswer(answerId: number, verified: boolean) {
  return request.post<ApiResponse<ForumAnswer>>(`/forum/answers/${answerId}/verify`, { verified })
}

/** 将回答加入知识库（教师） */
export function addToKnowledge(answerId: number) {
  return request.post<ApiResponse<null>>(`/forum/answers/${answerId}/knowledge`)
}
