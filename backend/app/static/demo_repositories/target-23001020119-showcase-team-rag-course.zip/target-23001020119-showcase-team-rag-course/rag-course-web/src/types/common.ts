/** 通用分页请求参数 */
export interface PageRequest {
  page: number
  page_size: number
  keyword?: string
  sort_by?: string
  sort_order?: 'asc' | 'desc'
}

/** 通用分页响应 */
export interface PageResponse<T> {
  items: T[]
  total: number
  page: number
  page_size: number
  total_pages: number
}

/** 统一API响应 */
export interface ApiResponse<T = any> {
  code: number
  message: string
  data: T
}

/** 排序方向 */
export type SortOrder = 'asc' | 'desc'
