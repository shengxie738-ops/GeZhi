<template>
  <div class="question-card" @click="$emit('click')">
    <div class="question-left">
      <div class="question-stats">
        <div class="stat-item">
          <span class="stat-value">{{ question.answer_count }}</span>
          <span class="stat-label">回答</span>
        </div>
        <div class="stat-item">
          <span class="stat-value">{{ question.view_count }}</span>
          <span class="stat-label">浏览</span>
        </div>
        <div class="stat-item">
          <span class="stat-value">{{ question.like_count }}</span>
          <span class="stat-label">点赞</span>
        </div>
      </div>
    </div>

    <div class="question-content">
      <div class="question-title-row">
        <StatusTag :value="question.status" type="forum" />
        <h3 class="question-title">{{ question.title }}</h3>
      </div>

      <div class="question-tags" v-if="question.tags?.length">
        <el-tag
          v-for="tag in question.tags"
          :key="tag"
          size="small"
          type="info"
          effect="plain"
        >
          {{ tag }}
        </el-tag>
      </div>

      <div class="question-footer">
        <div class="question-author">
          <el-avatar :size="20" :src="question.user?.avatar">
            {{ question.user?.nickname?.charAt(0) }}
          </el-avatar>
          <span class="author-name">{{ question.user?.nickname }}</span>
          <span class="question-time">{{ formatRelativeTime(question.created_at) }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import type { ForumQuestion } from '@/types/forum'
import { formatRelativeTime } from '@/utils/format'
import StatusTag from '@/components/common/StatusTag.vue'

defineProps<{
  question: ForumQuestion
}>()

defineEmits<{
  click: []
}>()
</script>

<style scoped>
.question-card {
  display: flex;
  gap: 16px;
  padding: 16px;
  border: 1px solid #ebeef5;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s;
  background: #fff;
}

.question-card:hover {
  border-color: #409eff;
  box-shadow: 0 2px 12px rgba(64, 158, 255, 0.1);
}

.question-left {
  flex-shrink: 0;
}

.question-stats {
  display: flex;
  flex-direction: column;
  gap: 8px;
  min-width: 64px;
}

.stat-item {
  text-align: center;
  padding: 4px 0;
}

.stat-value {
  display: block;
  font-size: 18px;
  font-weight: 600;
  color: #303133;
}

.stat-label {
  display: block;
  font-size: 12px;
  color: #909399;
}

.question-content {
  flex: 1;
  min-width: 0;
}

.question-title-row {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
}

.question-title {
  font-size: 15px;
  font-weight: 600;
  color: #303133;
  margin: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.question-title:hover {
  color: #409eff;
}

.question-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-bottom: 8px;
}

.question-footer {
  display: flex;
  align-items: center;
}

.question-author {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
}

.author-name {
  color: #606266;
}

.question-time {
  color: #909399;
}
</style>
