import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import type { User, Role } from '@/types/user'
import { getToken, setToken, removeToken, setRefreshToken, removeRefreshToken } from '@/utils/auth'
import * as authApi from '@/api/auth'

export const useAuthStore = defineStore('auth', () => {
  const token = ref<string | null>(getToken())
  const user = ref<User | null>(null)
  const loading = ref(false)

  const isLoggedIn = computed(() => !!token.value)
  const userRole = computed<Role | null>(() => user.value?.role ?? null)
  const isStudent = computed(() => userRole.value === 'student')
  const isTeacher = computed(() => userRole.value === 'teacher')
  const isAdmin = computed(() => userRole.value === 'admin')
  const nickname = computed(() => user.value?.nickname || user.value?.username || '未登录')
  const avatar = computed(() => user.value?.avatar || '')

  /** 登录 */
  async function login(username: string, password: string) {
    loading.value = true
    try {
      const res = await authApi.login({ username, password })
      const data = res.data
      token.value = data.access_token
      user.value = data.user
      setToken(data.access_token)
      setRefreshToken(data.refresh_token)
      return data
    } finally {
      loading.value = false
    }
  }

  /** 登出 */
  async function logout() {
    try {
      await authApi.logout()
    } catch {
      // 忽略登出API错误
    } finally {
      token.value = null
      user.value = null
      removeToken()
      removeRefreshToken()
    }
  }

  /** 获取用户信息 */
  async function fetchProfile() {
    if (!token.value) return
    loading.value = true
    try {
      const res = await authApi.getProfile()
      user.value = res.data
    } catch {
      // token无效，清除状态
      await logout()
    } finally {
      loading.value = false
    }
  }

  /** 设置Token（用于外部恢复） */
  function setAccessToken(newToken: string) {
    token.value = newToken
    setToken(newToken)
  }

  return {
    token,
    user,
    loading,
    isLoggedIn,
    userRole,
    isStudent,
    isTeacher,
    isAdmin,
    nickname,
    avatar,
    login,
    logout,
    fetchProfile,
    setAccessToken
  }
})
