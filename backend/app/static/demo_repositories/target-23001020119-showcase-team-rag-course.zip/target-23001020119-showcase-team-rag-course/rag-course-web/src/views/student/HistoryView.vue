﻿<template>
  <div class="history-view">
    <PageHeader title="提问历史" description="查看你的所有提问记录" />

    <div class="history-content" v-loading="loading">
      <div v-if="groupedHistory.length === 0 && !loading" class="empty-wrapper">
        <el-empty description="暂无提问历史" />
      </div>

      <div
        v-for="group in groupedHistory"
        :key="group.date"
        class="history-group"
      >
        <div class="group-date">
          <el-icon><Calendar /></el-icon>
          {{ group.dateLabel }}
        </div>

        <div class="group-items">
          <div
            v-for="item in group.items"
            :key="item.id"
            class="history-item"
            @click="router.push(`/student/chat/${item.id}`)"
          >
            <div class="item-content">
              <div class="item-title">{{ item.title || '新会话' }}</div>
              <div class="item-summary">{{ item.summary || '暂无摘要' }}</div>
            </div>
            <div class="item-meta">
              <el-tag v-if="item.course_name" size="small" type="info">{{ item.course_name }}</el-tag>
              <span class="item-time">{{ formatTime(item.updated_at) }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { Calendar } from '@element-plus/icons-vue'
import dayjs from 'dayjs'
import 'dayjs/locale/zh-cn'
import PageHeader from '@/components/common/PageHeader.vue'

const router = useRouter()
const loading = ref(false)

interface HistoryItem {
  id: number
  title: string
  summary: string
  course_name: string
  created_at: string
  updated_at: string
}

const historyItems = ref<HistoryItem[]>([])

const groupedHistory = computed(() => {
  const groups: Record<string, HistoryItem[]> = {}

  historyItems.value.forEach(item => {
    const date = dayjs(item.updated_at).format('YYYY-MM-DD')
    if (!groups[date]) groups[date] = []
    groups[date].push(item)
  })

  return Object.entries(groups)
    .sort(([a], [b]) => b.localeCompare(a))
    .map(([date, items]) => ({
      date,
      dateLabel: getDateLabel(date),
      items: items.sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime())
    }))
})

function getDateLabel(dateStr: string): string {
  const date = dayjs(dateStr)
  const today = dayjs()
  if (date.isSame(today, 'day')) return '今天'
  if (date.isSame(today.subtract(1, 'day'), 'day')) return '昨天'
  if (date.isSame(today, 'week')) return '本周'
  return date.format('YYYY年MM月DD日')
}

function formatTime(dateStr: string): string {
  return dayjs(dateStr).format('HH:mm')
}

async function fetchHistory() {
  loading.value = true
  try {
    // TODO: 需要对应的API获取提问历史
    // 这里先用空数据
    historyItems.value = []
  } catch {
    // 忽略
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  fetchHistory()
})
</script>

<style scoped>
.history-view {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.history-content {
  background: #fff;
  border-radius: 10px;
  padding: 20px;
  min-height: 400px;
}

.empty-wrapper {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 300px;
}

.history-group {
  margin-bottom: 24px;
}

.group-date {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 14px;
  font-weight: 600;
  color: #606266;
  padding-bottom: 10px;
  border-bottom: 1px solid #f2f3f5;
  margin-bottom: 12px;
}

.group-items {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.history-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 16px;
  border: 1px solid #ebeef5;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s;
}

.history-item:hover {
  border-color: #409eff;
  background: #f0f7ff;
  box-shadow: 0 2px 8px rgba(64, 158, 255, 0.08);
}

.item-content {
  flex: 1;
  min-width: 0;
}

.item-title {
  font-size: 14px;
  font-weight: 500;
  color: #303133;
  margin-bottom: 4px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.item-summary {
  font-size: 13px;
  color: #909399;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.item-meta {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
  margin-left: 16px;
}

.item-time {
  font-size: 12px;
  color: #c0c4cc;
  white-space: nowrap;
}
</style>
