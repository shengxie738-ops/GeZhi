import { describe, it, expect, vi, beforeEach } from 'vitest'
import { mount } from '@vue/test-utils'
import { createTestingPinia } from '@pinia/testing'
import { createRouter, createWebHistory } from 'vue-router'
import ElementPlus from 'element-plus'
import QuestionCard from '@/components/forum/QuestionCard.vue'
import AnswerCard from '@/components/forum/AnswerCard.vue'
import type { ForumQuestion, ForumAnswer } from '@/types/forum'

vi.mock('@/utils/format', () => ({
  formatRelativeTime: vi.fn(() => '刚刚')
}))

const mockQuestion: ForumQuestion = {
  id: 1,
  course_id: 1001,
  title: 'RAG 和 Fine-tuning 有什么区别？',
  content: '我想了解 RAG 和 Fine-tuning 在实际应用中的区别',
  status: 'open',
  author_id: 1,
  user: {
    id: 1,
    nickname: '张三',
    avatar: ''
  },
  tags: ['RAG', '模型微调'],
  view_count: 120,
  like_count: 15,
  answer_count: 3,
  created_at: '2025-01-15 10:00:00',
  updated_at: '2025-01-15 10:00:00'
}

const mockAnswer: ForumAnswer = {
  id: 1,
  question_id: 1,
  content: 'RAG 通过检索外部知识库来增强模型回答，而 Fine-tuning 是直接训练模型参数。',
  author_id: 2,
  is_teacher_answer: true,
  is_accepted: false,
  teacher_verified: true,
  like_count: 10,
  created_at: '2025-01-15 11:00:00',
  updated_at: '2025-01-15 11:00:00'
}

const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/', component: { template: '<div />' } }
  ]
})

describe('QuestionCard 组件', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  it('渲染问题列表项', () => {
    const wrapper = mount(QuestionCard, {
      props: { question: mockQuestion },
      global: {
        plugins: [ElementPlus, router]
      }
    })

    // 检查问题标题
    expect(wrapper.text()).toContain('RAG 和 Fine-tuning 有什么区别？')

    // 检查统计数据
    expect(wrapper.text()).toContain('3') // answer_count
    expect(wrapper.text()).toContain('120') // view_count
    expect(wrapper.text()).toContain('15') // like_count

    // 检查标签
    expect(wrapper.text()).toContain('RAG')
    expect(wrapper.text()).toContain('模型微调')

    // 检查作者
    expect(wrapper.text()).toContain('张三')
  })

  it('点击卡片触发 click 事件', async () => {
    const wrapper = mount(QuestionCard, {
      props: { question: mockQuestion },
      global: {
        plugins: [ElementPlus, router]
      }
    })

    await wrapper.find('.question-card').trigger('click')
    expect(wrapper.emitted('click')).toBeTruthy()
  })
})

describe('AnswerCard 组件', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  it('渲染回答内容', () => {
    const wrapper = mount(AnswerCard, {
      props: { answer: mockAnswer },
      global: {
        plugins: [ElementPlus, router]
      }
    })

    expect(wrapper.text()).toContain('RAG 通过检索外部知识库来增强模型回答')
  })
})

describe('论坛发布问题对话框', () => {
  it('创建问题对话框结构', () => {
    const wrapper = mount(
      {
        template: `
          <el-dialog v-model="visible" title="发布新问题" width="600px">
            <el-form :model="form" label-width="80px">
              <el-form-item label="标题">
                <el-input v-model="form.title" placeholder="请输入问题标题" />
              </el-form-item>
              <el-form-item label="内容">
                <el-input v-model="form.content" type="textarea" :rows="6" placeholder="详细描述你的问题" />
              </el-form-item>
              <el-form-item label="标签">
                <el-input v-model="form.tags" placeholder="用逗号分隔多个标签" />
              </el-form-item>
            </el-form>
            <template #footer>
              <el-button @click="visible = false">取消</el-button>
              <el-button type="primary" @click="visible = false">发布</el-button>
            </template>
          </el-dialog>
        `,
        setup() {
          const visible = ref(true)
          const form = reactive({
            title: '',
            content: '',
            tags: ''
          })
          return { visible, form }
        }
      },
      {
        global: {
          plugins: [ElementPlus, router]
        }
      }
    )

    // 检查对话框渲染
    expect(wrapper.find('.el-dialog').exists()).toBe(true)
    expect(wrapper.text()).toContain('发布新问题')
    expect(wrapper.text()).toContain('标题')
    expect(wrapper.text()).toContain('内容')
    expect(wrapper.text()).toContain('标签')
  })
})
