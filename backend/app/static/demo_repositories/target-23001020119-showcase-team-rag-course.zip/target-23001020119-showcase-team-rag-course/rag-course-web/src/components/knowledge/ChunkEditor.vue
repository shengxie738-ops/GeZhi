<template>
  <el-dialog
    v-model="visible"
    title="编辑知识块"
    width="700px"
    :close-on-click-modal="false"
    @close="handleClose"
  >
    <div class="chunk-editor" v-if="chunk">
      <div class="chunk-meta">
        <el-tag size="small" type="info">页码: {{ chunk.start_page ?? '—' }}-{{ chunk.end_page ?? '—' }}</el-tag>
        <el-tag size="small" type="info">序号: {{ chunk.chunk_index }}</el-tag>
        <el-tag size="small" type="info">Token: {{ chunk.token_count }}</el-tag>
        <el-tag v-if="chunk.embedding_id" size="small" type="success">已向量化</el-tag>
        <el-tag v-else size="small" type="warning">未向量化</el-tag>
      </div>

      <div class="chunk-title-path" v-if="titlePath">
        <span class="label">标题路径:</span>
        <span class="value">{{ titlePath }}</span>
      </div>

      <el-form-item label="知识块内容" class="chunk-form-item">
        <el-input
          v-model="editContent"
          type="textarea"
          :autosize="{ minRows: 10, maxRows: 20 }"
          placeholder="编辑知识块内容..."
        />
      </el-form-item>

      <div class="chunk-footer-info">
        <span>字数: {{ editContent.length }}</span>
      </div>
    </div>

    <template #footer>
      <el-button @click="handleClose">取消</el-button>
      <el-button type="primary" :loading="saving" @click="handleSave">
        保存并重新生成向量
      </el-button>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import type { Chunk } from '@/types/document'

const props = defineProps<{
  chunk: Chunk | null
  titlePath?: string
}>()

const emit = defineEmits<{
  save: [chunkId: number, content: string]
  close: []
}>()

const visible = ref(false)
const editContent = ref('')
const saving = ref(false)

watch(
  () => props.chunk,
  (val) => {
    if (val) {
      editContent.value = val.content || ''
      visible.value = true
    }
  }
)

function handleClose() {
  visible.value = false
  emit('close')
}

function handleSave() {
  if (!props.chunk) return
  if (!editContent.value.trim()) {
    ElMessage.warning('内容不能为空')
    return
  }
  saving.value = true
  emit('save', props.chunk.id, editContent.value.trim())
  setTimeout(() => {
    saving.value = false
    visible.value = false
  }, 300)
}
</script>

<style scoped>
.chunk-editor {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.chunk-meta {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.chunk-title-path {
  font-size: 13px;
  color: #606266;
  padding: 8px 12px;
  background: #f5f7fa;
  border-radius: 6px;
}

.chunk-title-path .label {
  color: #909399;
  margin-right: 8px;
}

.chunk-form-item {
  margin-bottom: 0;
}

.chunk-footer-info {
  font-size: 12px;
  color: #909399;
  text-align: right;
}
</style>
