import type { Citation } from './chat'

/** 搜索请求 */
export interface SearchRequest {
  query: string
  course_id: number
  top_k?: number
  score_threshold?: number
  filters?: SearchFilters
}

/** 搜索过滤器 */
export interface SearchFilters {
  document_ids?: number[]
  file_types?: string[]
}

/** 搜索结果项 */
export interface SearchResult {
  chunk_id: number
  document_id: number
  document_title: string
  content: string
  score: number
  page_number: number | null
  metadata: Record<string, any>
}

/** 提问请求 */
export interface AskRequest {
  question: string
  course_id: number
  session_id?: number
  top_k?: number
  model?: string
}

/** 提问响应（非流式） */
export interface AskResponse {
  session_id: number
  message_id: number
  answer: string
  citations: Citation[]
  model_used: string
  token_count: number
  latency_ms: number
}

/** 证据状态 */
export type EvidenceStatus = 'support' | 'partial' | 'contradict' | 'irrelevant'

/** SSE 流式事件 */
export interface StreamEvent {
  type: 'token' | 'citation' | 'done' | 'error'
  data: string | Citation[]
}
