﻿<template>
  <div class="page-container">
    <PageHeader title="课程管理" description="管理您的课程列表">
      <el-button type="primary" @click="openCreateDialog">
        <el-icon><Plus /></el-icon> 创建课程
      </el-button>
    </PageHeader>

    <el-card shadow="never">
      <!-- 搜索栏 -->
      <div class="toolbar">
        <el-input
          v-model="searchKeyword"
          placeholder="搜索课程名称或代码"
          clearable
          prefix-icon="Search"
          style="width: 280px"
          @clear="handleSearch"
          @keyup.enter="handleSearch"
        />
        <el-select v-model="statusFilter" placeholder="状态筛选" clearable style="width: 140px" @change="handleSearch">
          <el-option label="进行中" value="active" />
          <el-option label="已停用" value="inactive" />
          <el-option label="已归档" value="archived" />
        </el-select>
      </div>

      <!-- 课程表格 -->
      <el-table :data="courses" v-loading="loading" stripe border style="width: 100%">
        <el-table-column prop="name" label="课程名称" min-width="200">
          <template #default="{ row }">
            <div class="course-name-cell">
              <span class="name">{{ row.name }}</span>
              <span class="code">{{ row.code }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100">
          <template #default="{ row }">
            <el-tag
              :type="row.status === 'active' ? 'success' : row.status === 'inactive' ? 'info' : 'warning'"
              size="small"
            >
              {{ statusMap[row.status] || row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="member_count" label="成员数" width="90" align="center" />
        <el-table-column prop="document_count" label="文档数" width="90" align="center" />
        <el-table-column prop="created_at" label="创建时间" width="170">
          <template #default="{ row }">{{ formatDate(row.created_at) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="220" fixed="right">
          <template #default="{ row }">
            <el-button type="primary" link size="small" @click="goToDetail(row.id)">详情</el-button>
            <el-button type="primary" link size="small" @click="openEditDialog(row)">编辑</el-button>
            <el-popconfirm
              :title="`确定要归档课程「${row.name}」吗？`"
              confirm-button-text="确定"
              cancel-button-text="取消"
              @confirm="handleArchive(row)"
            >
              <template #reference>
                <el-button type="warning" link size="small">归档</el-button>
              </template>
            </el-popconfirm>
            <el-popconfirm
              :title="`确定要删除课程「${row.name}」吗？此操作不可恢复！`"
              confirm-button-text="确定删除"
              cancel-button-text="取消"
              confirm-button-type="danger"
              @confirm="handleDelete(row)"
            >
              <template #reference>
                <el-button type="danger" link size="small">删除</el-button>
              </template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>

      <Pagination
        v-model:page="pagination.page"
        v-model:page-size="pagination.pageSize"
        :total="pagination.total"
        @change="fetchCourses"
      />
    </el-card>

    <!-- 创建/编辑课程对话框 -->
    <el-dialog
      v-model="dialogVisible"
      :title="isEdit ? '编辑课程' : '创建课程'"
      width="560px"
      :close-on-click-modal="false"
    >
      <el-form ref="formRef" :model="formData" :rules="formRules" label-width="80px">
        <el-form-item label="课程名称" prop="name">
          <el-input v-model="formData.name" placeholder="请输入课程名称" maxlength="100" show-word-limit />
        </el-form-item>
        <el-form-item label="课程代码" prop="code">
          <el-input v-model="formData.code" placeholder="如：CS101" maxlength="20" />
        </el-form-item>
        <el-form-item label="学期" prop="semester">
          <el-input v-model="formData.semester" placeholder="如：2024-2025春季" maxlength="50" />
        </el-form-item>
        <el-form-item label="课程描述" prop="description">
          <el-input
            v-model="formData.description"
            type="textarea"
            :rows="4"
            placeholder="请输入课程描述"
            maxlength="500"
            show-word-limit
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="submitLoading" @click="handleSubmit">
          {{ isEdit ? '保存修改' : '创建课程' }}
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { Plus } from '@element-plus/icons-vue'
import { ElMessage, type FormInstance, type FormRules } from 'element-plus'
import PageHeader from '@/components/common/PageHeader.vue'
import Pagination from '@/components/common/Pagination.vue'
import * as courseApi from '@/api/course'
import { formatDate } from '@/utils/format'
import type { Course } from '@/types/course'

const router = useRouter()
const loading = ref(false)
const courses = ref<Course[]>([])
const searchKeyword = ref('')
const statusFilter = ref('')
const dialogVisible = ref(false)
const isEdit = ref(false)
const editId = ref(0)
const submitLoading = ref(false)
const formRef = ref<FormInstance>()

const statusMap: Record<string, string> = {
  active: '进行中',
  inactive: '已停用',
  archived: '已归档'
}

const pagination = reactive({ page: 1, pageSize: 10, total: 0 })

const formData = reactive({
  name: '',
  code: '',
  description: '',
  semester: ''
})

const formRules: FormRules = {
  name: [{ required: true, message: '请输入课程名称', trigger: 'blur' }],
  code: [{ required: true, message: '请输入课程代码', trigger: 'blur' }],
  semester: [{ required: true, message: '请输入学期', trigger: 'blur' }]
}

async function fetchCourses() {
  loading.value = true
  try {
    const res = await courseApi.getCourses({
      page: pagination.page,
      page_size: pagination.pageSize,
      keyword: searchKeyword.value || undefined,
      status: statusFilter.value || undefined
    })
    courses.value = res.data.items
    pagination.total = res.data.total
  } catch {
    // 错误已由拦截器处理
  } finally {
    loading.value = false
  }
}

function handleSearch() {
  pagination.page = 1
  fetchCourses()
}

function openCreateDialog() {
  isEdit.value = false
  editId.value = 0
  formData.name = ''
  formData.code = ''
  formData.description = ''
  formData.semester = ''
  dialogVisible.value = true
}

function openEditDialog(course: Course) {
  isEdit.value = true
  editId.value = course.id
  formData.name = course.name
  formData.code = course.code
  formData.description = course.description
  formData.semester = course.semester
  dialogVisible.value = true
}

async function handleSubmit() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return

  submitLoading.value = true
  try {
    if (isEdit.value) {
      await courseApi.updateCourse(editId.value, { ...formData })
      ElMessage.success('课程更新成功')
    } else {
      await courseApi.createCourse({ ...formData })
      ElMessage.success('课程创建成功')
    }
    dialogVisible.value = false
    fetchCourses()
  } finally {
    submitLoading.value = false
  }
}

async function handleArchive(course: Course) {
  try {
    await courseApi.updateCourse(course.id, { status: 'archived' })
    ElMessage.success('课程已归档')
    fetchCourses()
  } catch { /* handled */ }
}

async function handleDelete(course: Course) {
  try {
    await courseApi.deleteCourse(course.id)
    ElMessage.success('课程已删除')
    fetchCourses()
  } catch { /* handled */ }
}

function goToDetail(id: number) {
  router.push(`/teacher/courses/${id}`)
}

onMounted(() => {
  fetchCourses()
})
</script>

<style scoped>
.toolbar {
  display: flex;
  gap: 12px;
  margin-bottom: 16px;
}

.course-name-cell {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.course-name-cell .name {
  font-weight: 500;
  color: #303133;
}

.course-name-cell .code {
  font-size: 12px;
  color: #909399;
}
</style>
