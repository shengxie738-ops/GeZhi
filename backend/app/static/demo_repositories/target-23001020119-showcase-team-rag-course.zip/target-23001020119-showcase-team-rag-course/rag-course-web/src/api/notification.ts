import request from './request'
import type { ApiResponse, PageRequest, PageResponse } from '@/types/common'
import type { Notification } from '@/types/notification'

/** 获取通知列表 */
export function getNotifications(params?: PageRequest & { is_read?: boolean }) {
  return request.get<ApiResponse<PageResponse<Notification>>>('/notifications', { params })
}

/** 获取未读通知数量 */
export function getUnreadCount() {
  return request.get<ApiResponse<{ count: number }>>('/notifications/unread-count')
}

/** 标记通知已读 */
export function markRead(notificationId: number) {
  return request.put<ApiResponse<null>>(`/notifications/${notificationId}/read`)
}

/** 标记所有通知已读 */
export function markAllRead() {
  return request.put<ApiResponse<null>>('/notifications/read-all')
}
