import request from './request'
import type { ApiResponse, PageRequest, PageResponse } from '@/types/common'
import type {
  WrongQuestion,
  CreateWrongQuestionRequest,
  ImportWrongQuestionsRequest
} from '@/types/wrongQuestion'

/** 获取错题列表 */
export function getWrongQuestions(courseId: number, params?: PageRequest & { status?: string }) {
  return request.get<ApiResponse<PageResponse<WrongQuestion>>>(`/courses/${courseId}/wrong-questions`, {
    params
  })
}

/** 获取错题详情 */
export function getWrongQuestion(id: number) {
  return request.get<ApiResponse<WrongQuestion>>(`/wrong-questions/${id}`)
}

/** 创建错题 */
export function createWrongQuestion(data: CreateWrongQuestionRequest) {
  return request.post<ApiResponse<WrongQuestion>>('/wrong-questions', data)
}

/** 更新错题 */
export function updateWrongQuestion(id: number, data: Partial<CreateWrongQuestionRequest & { status: string }>) {
  return request.put<ApiResponse<WrongQuestion>>(`/wrong-questions/${id}`, data)
}

/** 删除错题 */
export function deleteWrongQuestion(id: number) {
  return request.delete<ApiResponse<null>>(`/wrong-questions/${id}`)
}

/** 批量导入错题 */
export function importWrongQuestions(data: ImportWrongQuestionsRequest) {
  return request.post<ApiResponse<{ imported: number; skipped: number }>>('/wrong-questions/import', data)
}

/** 标记错题已掌握 */
export function markMastered(id: number) {
  return request.put<ApiResponse<WrongQuestion>>(`/wrong-questions/${id}`, { status: 'mastered' })
}

/** 标记错题为复习中 */
export function markReviewing(id: number) {
  return request.put<ApiResponse<WrongQuestion>>(`/wrong-questions/${id}`, { status: 'reviewing' })
}
