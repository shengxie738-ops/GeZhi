<template>
  <div class="stat-card">
    <div class="stat-card-body">
      <div class="stat-info">
        <span class="stat-title">{{ title }}</span>
        <div class="stat-value-row">
          <span class="stat-value">{{ displayValue }}</span>
          <span v-if="suffix" class="stat-suffix">{{ suffix }}</span>
        </div>
      </div>
      <div class="stat-icon-wrapper" v-if="icon">
        <el-icon :size="32" class="stat-icon">
          <component :is="icon" />
        </el-icon>
      </div>
    </div>
    <div class="stat-trend" v-if="trend && trendValue">
      <span :class="['trend-badge', trend === 'up' ? 'trend-up' : 'trend-down']">
        <el-icon :size="12">
          <Top v-if="trend === 'up'" />
          <Bottom v-else />
        </el-icon>
        {{ trendValue }}
      </span>
      <span class="trend-label">较上期</span>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { Top, Bottom } from '@element-plus/icons-vue'
import type { Component } from 'vue'

const props = withDefaults(
  defineProps<{
    title: string
    value: number | string
    icon?: Component
    trend?: 'up' | 'down'
    trendValue?: string
    suffix?: string
  }>(),
  {
    suffix: ''
  }
)

const displayValue = computed(() => {
  if (typeof props.value === 'number') {
    return props.value.toLocaleString()
  }
  return props.value
})
</script>

<style scoped>
.stat-card {
  background: #fff;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
  transition: box-shadow 0.2s;
}

.stat-card:hover {
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.12);
}

.stat-card-body {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
}

.stat-info {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.stat-title {
  font-size: 13px;
  color: #909399;
}

.stat-value-row {
  display: flex;
  align-items: baseline;
  gap: 4px;
}

.stat-value {
  font-size: 28px;
  font-weight: 600;
  color: #303133;
  line-height: 1.2;
}

.stat-suffix {
  font-size: 14px;
  color: #909399;
}

.stat-icon-wrapper {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  background: #ecf5ff;
  display: flex;
  align-items: center;
  justify-content: center;
}

.stat-icon {
  color: #409eff;
}

.stat-trend {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-top: 12px;
  font-size: 12px;
}

.trend-badge {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  padding: 2px 6px;
  border-radius: 4px;
  font-weight: 500;
}

.trend-up {
  color: #67c23a;
  background: #f0f9eb;
}

.trend-down {
  color: #f56c6c;
  background: #fef0f0;
}

.trend-label {
  color: #c0c4cc;
}
</style>
