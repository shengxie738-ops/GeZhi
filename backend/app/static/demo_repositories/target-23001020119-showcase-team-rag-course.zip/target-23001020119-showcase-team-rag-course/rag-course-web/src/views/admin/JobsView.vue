﻿<template>
  <div class="page-container">
    <PageHeader title="任务队列管理" description="全局任务队列监控与管理">
      <el-button @click="fetchJobs" :loading="loading">
        <el-icon><Refresh /></el-icon> 刷新
      </el-button>
    </PageHeader>

    <!-- 任务统计 -->
    <el-row :gutter="20" class="stat-row">
      <el-col :span="6">
        <StatCard title="等待中" :value="jobStats.pending" icon="clock" color="#909399" />
      </el-col>
      <el-col :span="6">
        <StatCard title="运行中" :value="jobStats.running" icon="cpu" color="#E6A23C" />
      </el-col>
      <el-col :span="6">
        <StatCard title="已完成" :value="jobStats.completed" icon="data" color="#67C23A" />
      </el-col>
      <el-col :span="6">
        <StatCard title="失败" :value="jobStats.failed" icon="monitor" color="#F56C6C" />
      </el-col>
    </el-row>

    <!-- 任务统计图表 -->
    <el-card shadow="never" class="chart-card">
      <BarChart
        height="250px"
        :x-axis-data="['等待中', '运行中', '已完成', '失败']"
        :series-data="[{ name: '任务数', data: [jobStats.pending, jobStats.running, jobStats.completed, jobStats.failed] }]"
        :show-legend="false"
        :show-label="true"
      />
    </el-card>

    <!-- 任务列表 -->
    <el-card shadow="never">
      <div class="toolbar">
        <el-select v-model="statusFilter" placeholder="状态筛选" clearable style="width: 140px" @change="handleSearch">
          <el-option label="等待中" value="pending" />
          <el-option label="运行中" value="running" />
          <el-option label="已完成" value="completed" />
          <el-option label="失败" value="failed" />
        </el-select>
      </div>

      <el-table :data="jobs" v-loading="loading" stripe border>
        <el-table-column prop="id" label="任务号" width="80" />
        <el-table-column label="文档" min-width="200">
          <template #default="{ row }">
            <span class="doc-name">{{ row.document?.title || `文档#${row.document_id}` }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100">
          <template #default="{ row }">
            <StatusTag :value="row.status" type="job" />
          </template>
        </el-table-column>
        <el-table-column label="进度" width="200">
          <template #default="{ row }">
            <el-progress
              :percentage="row.progress"
              :status="row.status === 'failed' ? 'exception' : row.status === 'completed' ? 'success' : undefined"
              :stroke-width="10"
            />
          </template>
        </el-table-column>
        <el-table-column label="步骤" width="100" align="center">
          <template #default="{ row }">{{ row.processed_chunks }}/{{ row.total_chunks }}</template>
        </el-table-column>
        <el-table-column prop="started_at" label="开始时间" width="170">
          <template #default="{ row }">{{ formatDate(row.started_at) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="160" fixed="right">
          <template #default="{ row }">
            <el-button v-if="row.status === 'failed'" type="warning" link size="small" @click="handleRetry(row)">重试</el-button>
            <el-button v-if="['running', 'pending'].includes(row.status)" type="danger" link size="small" @click="handleCancel(row)">取消</el-button>
          </template>
        </el-table-column>
      </el-table>

      <Pagination
        v-model:page="pagination.page"
        v-model:page-size="pagination.pageSize"
        :total="pagination.total"
        @change="fetchJobs"
      />
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, onBeforeUnmount } from 'vue'
import { Refresh } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import PageHeader from '@/components/common/PageHeader.vue'
import Pagination from '@/components/common/Pagination.vue'
import StatusTag from '@/components/common/StatusTag.vue'
import StatCard from '@/components/charts/StatCard.vue'
import BarChart from '@/components/charts/BarChart.vue'
import * as modelConfigApi from '@/api/modelConfig'
import { formatDate } from '@/utils/format'
import type { IngestJob } from '@/types/document'

const loading = ref(false)
const jobs = ref<IngestJob[]>([])
const statusFilter = ref('')
const pagination = reactive({ page: 1, pageSize: 15, total: 0 })
const jobStats = reactive({ pending: 3, running: 5, completed: 156, failed: 2 })
let pollingTimer: ReturnType<typeof setInterval> | null = null

async function fetchJobs() {
  loading.value = true
  try {
    const res = await modelConfigApi.getJobs({
      page: pagination.page,
      page_size: pagination.pageSize,
      status: statusFilter.value || undefined
    })
    jobs.value = res.data.items
    pagination.total = res.data.total
  } catch { /* handled */ }
  finally { loading.value = false }
}

function handleSearch() {
  pagination.page = 1
  fetchJobs()
}

async function handleRetry(job: IngestJob) {
  await modelConfigApi.retryJob(job.id)
  ElMessage.success('已重试')
  fetchJobs()
}

async function handleCancel(job: IngestJob) {
  await modelConfigApi.cancelJob(job.id)
  ElMessage.success('已取消')
  fetchJobs()
}

onMounted(() => {
  fetchJobs()
  pollingTimer = setInterval(() => {
    const hasActive = jobs.value.some((j) => j.status === 'running' || j.status === 'pending')
    if (hasActive) fetchJobs()
  }, 5000)
})

onBeforeUnmount(() => {
  if (pollingTimer) clearInterval(pollingTimer)
})
</script>

<style scoped>
.stat-row { margin-bottom: 20px; }
.chart-card { margin-bottom: 20px; border-radius: 8px; }
.toolbar { display: flex; gap: 12px; margin-bottom: 16px; }
.doc-name { font-size: 13px; color: #409EFF; }
</style>
