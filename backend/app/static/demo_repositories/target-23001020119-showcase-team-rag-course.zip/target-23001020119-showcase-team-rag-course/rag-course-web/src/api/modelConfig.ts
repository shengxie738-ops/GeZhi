import request from './request'
import type { ApiResponse, PageRequest, PageResponse } from '@/types/common'
import type {
  ModelConfig,
  RagConfig,
  CreateModelConfigRequest,
  UpdateModelConfigRequest,
  ModelTestRequest,
  ModelTestResponse
} from '@/types/model'
import type { IngestJob as DocIngestJob } from '@/types/document'

/** 获取模型配置列表 */
export function getModelConfigs(params?: PageRequest) {
  return request.get<ApiResponse<PageResponse<ModelConfig>>>('/models', { params })
}

/** 获取模型配置详情 */
export function getModelConfig(id: number) {
  return request.get<ApiResponse<ModelConfig>>(`/models/${id}`)
}

/** 创建模型配置 */
export function createModelConfig(data: CreateModelConfigRequest) {
  return request.post<ApiResponse<ModelConfig>>('/models', data)
}

/** 更新模型配置 */
export function updateModelConfig(id: number, data: UpdateModelConfigRequest) {
  return request.put<ApiResponse<ModelConfig>>(`/models/${id}`, data)
}

/** 删除模型配置 */
export function deleteModelConfig(id: number) {
  return request.delete<ApiResponse<null>>(`/models/${id}`)
}

/** 测试模型连接 */
export function testModel(data: ModelTestRequest) {
  return request.post<ApiResponse<ModelTestResponse>>('/models/test', data)
}

/** 获取RAG配置 */
export function getRagConfig() {
  return request.get<ApiResponse<RagConfig>>('/rag/config')
}

/** 更新RAG配置 */
export function updateRagConfig(data: Partial<RagConfig>) {
  return request.put<ApiResponse<RagConfig>>('/rag/config', data)
}

/** 获取任务队列列表 */
export function getJobs(params?: PageRequest & { status?: string }) {
  return request.get<ApiResponse<PageResponse<DocIngestJob>>>('/jobs', { params })
}

/** 获取任务详情 */
export function getJob(id: number) {
  return request.get<ApiResponse<DocIngestJob>>(`/jobs/${id}`)
}

/** 取消任务 */
export function cancelJob(id: number) {
  return request.post<ApiResponse<null>>(`/jobs/${id}/cancel`)
}

/** 重试任务 */
export function retryJob(id: number) {
  return request.post<ApiResponse<DocIngestJob>>(`/jobs/${id}/retry`)
}
