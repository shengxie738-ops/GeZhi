﻿<template>
  <div class="page-container">
    <PageHeader title="系统设置" description="系统基础配置与维护" />

    <el-tabs v-model="activeTab" type="border-card">
      <!-- 基础配置 -->
      <el-tab-pane label="基础配置" name="basic">
        <el-card shadow="never" style="max-width: 700px">
          <el-form :model="basicConfig" label-width="120px">
            <el-form-item label="系统名称">
              <el-input v-model="basicConfig.siteName" />
            </el-form-item>
            <el-form-item label="系统描述">
              <el-input v-model="basicConfig.siteDescription" type="textarea" :rows="3" />
            </el-form-item>
            <el-form-item label="Logo URL">
              <el-input v-model="basicConfig.logoUrl" placeholder="https://..." />
            </el-form-item>
            <el-form-item label="允许注册">
              <el-switch v-model="basicConfig.allowRegister" />
            </el-form-item>
            <el-form-item label="维护模式">
              <el-switch v-model="basicConfig.maintenanceMode" />
              <div class="form-tip">开启后仅管理员可以访问系统</div>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" :loading="saving" @click="handleSaveBasic">保存设置</el-button>
            </el-form-item>
          </el-form>
        </el-card>
      </el-tab-pane>

      <!-- 安全设置 -->
      <el-tab-pane label="安全设置" name="security">
        <el-card shadow="never" style="max-width: 700px">
          <el-form :model="securityConfig" label-width="140px">
            <el-form-item label="Token 有效期(分)">
              <el-input-number v-model="securityConfig.tokenExpiry" :min="5" :max="1440" />
            </el-form-item>
            <el-form-item label="Refresh Token 有效期(天)">
              <el-input-number v-model="securityConfig.refreshTokenExpiry" :min="1" :max="90" />
            </el-form-item>
            <el-form-item label="最大登录失败次数">
              <el-input-number v-model="securityConfig.maxLoginAttempts" :min="3" :max="20" />
            </el-form-item>
            <el-form-item label="密码最小长度">
              <el-input-number v-model="securityConfig.minPasswordLength" :min="6" :max="32" />
            </el-form-item>
            <el-form-item label="启用 CORS">
              <el-switch v-model="securityConfig.enableCors" />
            </el-form-item>
            <el-form-item label="允许的域名">
              <el-input v-model="securityConfig.allowedOrigins" placeholder="* 或逗号分隔的域名列表" />
            </el-form-item>
            <el-form-item>
              <el-button type="primary" :loading="saving" @click="handleSaveSecurity">保存设置</el-button>
            </el-form-item>
          </el-form>
        </el-card>
      </el-tab-pane>

      <!-- 敏感词配置 -->
      <el-tab-pane label="敏感词配置" name="sensitive">
        <el-card shadow="never">
          <div class="toolbar">
            <el-input
              v-model="newKeyword"
              placeholder="输入敏感词"
              style="width: 240px"
              @keyup.enter="handleAddKeyword"
            />
            <el-button type="primary" @click="handleAddKeyword" :disabled="!newKeyword.trim()">
              添加
            </el-button>
            <el-button type="danger" @click="handleClearAll" :disabled="sensitiveWords.length === 0">
              清空全部
            </el-button>
          </div>
          <el-table :data="sensitiveWordsTableData" stripe border size="small">
            <el-table-column type="index" label="#" width="60" />
            <el-table-column prop="word" label="敏感词" min-width="200" />
            <el-table-column prop="added_at" label="添加时间" width="170" />
            <el-table-column label="操作" width="100">
              <template #default="{ row, $index }">
                <el-popconfirm title="确定删除此敏感词？" @confirm="handleRemoveKeyword($index)">
                  <template #reference>
                    <el-button type="danger" link size="small">删除</el-button>
                  </template>
                </el-popconfirm>
              </template>
            </el-table-column>
          </el-table>
          <el-empty v-if="sensitiveWords.length === 0" description="暂无敏感词" />
        </el-card>
      </el-tab-pane>

      <!-- 系统维护 -->
      <el-tab-pane label="系统维护" name="maintenance">
        <el-card shadow="never" style="max-width: 700px">
          <el-divider content-position="left">缓存管理</el-divider>
          <div class="maintain-action">
            <div class="maintain-info">
              <span class="maintain-title">清除系统缓存</span>
              <span class="maintain-desc">清除Redis缓存，不会影响数据</span>
            </div>
            <el-button type="warning" @click="handleClearCache">清除缓存</el-button>
          </div>

          <el-divider content-position="left">数据维护</el-divider>
          <div class="maintain-action">
            <div class="maintain-info">
              <span class="maintain-title">重建向量索引</span>
              <span class="maintain-desc">重新构建Qdrant向量索引，耗时较长</span>
            </div>
            <el-button type="warning" @click="handleRebuildIndex">重建索引</el-button>
          </div>
          <div class="maintain-action">
            <div class="maintain-info">
              <span class="maintain-title">清理过期文件</span>
              <span class="maintain-desc">删除90天未使用的临时文件</span>
            </div>
            <el-button type="danger" @click="handleCleanFiles">清理</el-button>
          </div>

          <el-divider content-position="left">系统信息</el-divider>
          <el-descriptions :column="2" border size="small">
            <el-descriptions-item label="系统版本">v1.0.0</el-descriptions-item>
            <el-descriptions-item label="Python 版本">3.11.5</el-descriptions-item>
            <el-descriptions-item label="Vue 版本">3.4.x</el-descriptions-item>
            <el-descriptions-item label="Node 版本">18.x</el-descriptions-item>
            <el-descriptions-item label="数据库">PostgreSQL 15</el-descriptions-item>
            <el-descriptions-item label="向量库">Qdrant 1.7</el-descriptions-item>
            <el-descriptions-item label="对象存储">MinIO</el-descriptions-item>
            <el-descriptions-item label="缓存">Redis 7</el-descriptions-item>
          </el-descriptions>
        </el-card>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import PageHeader from '@/components/common/PageHeader.vue'
import dayjs from 'dayjs'

const activeTab = ref('basic')
const saving = ref(false)

// 基础配置
const basicConfig = reactive({
  siteName: 'RAG Course - 人工智能技术基础课程',
  siteDescription: '基于RAG技术的智能教学辅助系统',
  logoUrl: '',
  allowRegister: true,
  maintenanceMode: false
})

// 安全设置
const securityConfig = reactive({
  tokenExpiry: 30,
  refreshTokenExpiry: 7,
  maxLoginAttempts: 5,
  minPasswordLength: 8,
  enableCors: true,
  allowedOrigins: '*'
})

// 敏感词
const newKeyword = ref('')
const sensitiveWords = ref<string[]>(['暴力', '色情', '赌博', '诈骗'])
const sensitiveWordsTableData = ref(
  sensitiveWords.value.map((w, i) => ({
    word: w,
    added_at: dayjs().subtract(i, 'day').format('YYYY-MM-DD HH:mm:ss')
  }))
)

async function handleSaveBasic() {
  saving.value = true
  try {
    ElMessage.success('基础配置已保存')
  } finally { saving.value = false }
}

async function handleSaveSecurity() {
  saving.value = true
  try {
    ElMessage.success('安全设置已保存')
  } finally { saving.value = false }
}

function handleAddKeyword() {
  const word = newKeyword.value.trim()
  if (!word) return
  if (sensitiveWords.value.includes(word)) {
    ElMessage.warning('该敏感词已存在')
    return
  }
  sensitiveWords.value.push(word)
  sensitiveWordsTableData.value.push({
    word,
    added_at: dayjs().format('YYYY-MM-DD HH:mm:ss')
  })
  newKeyword.value = ''
  ElMessage.success('已添加')
}

function handleRemoveKeyword(index: number) {
  sensitiveWords.value.splice(index, 1)
  sensitiveWordsTableData.value.splice(index, 1)
  ElMessage.success('已删除')
}

function handleClearAll() {
  ElMessageBox.confirm('确定要清空所有敏感词？', '确认', { type: 'warning' }).then(() => {
    sensitiveWords.value = []
    sensitiveWordsTableData.value = []
    ElMessage.success('已清空')
  }).catch(() => {})
}

function handleClearCache() {
  ElMessage.success('缓存已清除')
}

function handleRebuildIndex() {
  ElMessageBox.confirm('重建索引可能耗时较长，确定继续？', '确认', { type: 'warning' }).then(() => {
    ElMessage.success('重建索引任务已提交')
  }).catch(() => {})
}

function handleCleanFiles() {
  ElMessageBox.confirm('确定要清理过期临时文件？', '确认', { type: 'warning' }).then(() => {
    ElMessage.success('清理任务已提交')
  }).catch(() => {})
}
</script>

<style scoped>
.toolbar {
  display: flex;
  gap: 12px;
  margin-bottom: 16px;
}

.form-tip {
  font-size: 12px;
  color: #909399;
  margin-top: 4px;
}

.maintain-action {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 0;
  border-bottom: 1px solid #F2F6FC;
}

.maintain-action:last-child {
  border-bottom: none;
}

.maintain-info {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.maintain-title {
  font-size: 14px;
  font-weight: 500;
  color: #303133;
}

.maintain-desc {
  font-size: 12px;
  color: #909399;
}
</style>
