<template>
  <el-container class="layout-container">
    <!-- 左侧菜单 -->
    <el-aside :width="appStore.sidebarCollapsed ? '64px' : '220px'" class="layout-aside">
      <div class="aside-logo" @click="router.push('/teacher/dashboard')">
        <img src="@/assets/logo.svg" alt="Logo" class="logo-img" v-if="!appStore.sidebarCollapsed" />
        <span class="logo-text" v-if="!appStore.sidebarCollapsed">RAG Course</span>
        <span class="logo-text-mini" v-else>RC</span>
      </div>

      <el-menu
        :default-active="activeMenu"
        :collapse="appStore.sidebarCollapsed"
        :collapse-transition="false"
        router
        class="aside-menu"
      >
        <el-menu-item index="/teacher/dashboard">
          <el-icon><Odometer /></el-icon>
          <template #title>仪表板</template>
        </el-menu-item>

        <el-sub-menu index="courses-group">
          <template #title>
            <el-icon><Reading /></el-icon>
            <span>课程管理</span>
          </template>
          <el-menu-item index="/teacher/courses">课程列表</el-menu-item>
        </el-sub-menu>

        <el-sub-menu index="knowledge-group">
          <template #title>
            <el-icon><Collection /></el-icon>
            <span>知识库管理</span>
          </template>
          <el-menu-item index="/teacher/knowledge/documents">文档管理</el-menu-item>
          <el-menu-item index="/teacher/knowledge/chunks">分块管理</el-menu-item>
          <el-menu-item index="/teacher/knowledge/forum-review">论坛审核</el-menu-item>
        </el-sub-menu>

        <el-menu-item index="/teacher/questions/unresolved">
          <el-icon><QuestionFilled /></el-icon>
          <template #title>未解决问题</template>
        </el-menu-item>

        <el-menu-item index="/teacher/analytics">
          <el-icon><DataAnalysis /></el-icon>
          <template #title>教学分析</template>
        </el-menu-item>

        <el-menu-item index="/teacher/model-settings">
          <el-icon><Setting /></el-icon>
          <template #title>模型设置</template>
        </el-menu-item>

        <el-menu-item index="/teacher/jobs">
          <el-icon><List /></el-icon>
          <template #title>任务队列</template>
        </el-menu-item>

        <el-menu-item index="/teacher/notifications">
          <el-icon><Bell /></el-icon>
          <template #title>通知</template>
        </el-menu-item>
      </el-menu>
    </el-aside>

    <!-- 右侧内容 -->
    <el-container class="layout-main">
      <!-- 顶部导航 -->
      <el-header class="layout-header">
        <div class="header-left">
          <el-icon class="collapse-btn" :size="20" @click="appStore.toggleSidebar()">
            <Fold v-if="!appStore.sidebarCollapsed" />
            <Expand v-else />
          </el-icon>
          <Breadcrumb />
        </div>

        <div class="header-right">
          <el-badge :value="unreadCount" :hidden="unreadCount === 0" :max="99">
            <el-button :icon="Bell" circle size="small" @click="router.push('/teacher/notifications')" />
          </el-badge>

          <el-dropdown trigger="click" @command="handleCommand">
            <div class="user-info">
              <el-avatar :size="32" :src="authStore.avatar">
                {{ authStore.nickname?.charAt(0) }}
              </el-avatar>
              <span class="user-name">{{ authStore.nickname }}</span>
              <el-icon class="el-icon--right"><ArrowDown /></el-icon>
            </div>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item command="profile">
                  <el-icon><User /></el-icon>个人中心
                </el-dropdown-item>
                <el-dropdown-item divided command="logout">
                  <el-icon><SwitchButton /></el-icon>退出登录
                </el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </el-header>

      <!-- 主要内容 -->
      <el-main class="layout-content">
        <router-view v-slot="{ Component }">
          <transition name="fade-transform" mode="out-in">
            <component :is="Component" />
          </transition>
        </router-view>
      </el-main>
    </el-container>
  </el-container>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ElMessageBox } from 'element-plus'
import {
  Odometer,
  Reading,
  Collection,
  QuestionFilled,
  DataAnalysis,
  Setting,
  List,
  Bell,
  Fold,
  Expand,
  ArrowDown,
  User,
  SwitchButton
} from '@element-plus/icons-vue'
import { useAppStore } from '@/stores/app'
import { useAuthStore } from '@/stores/auth'
import { getUnreadCount } from '@/api/notification'
import Breadcrumb from '@/components/common/Breadcrumb.vue'

const router = useRouter()
const route = useRoute()
const appStore = useAppStore()
const authStore = useAuthStore()

const unreadCount = ref(0)

const activeMenu = computed(() => {
  const { path } = route
  if (path.includes('/knowledge/documents/')) return '/teacher/knowledge/documents'
  if (path.includes('/courses/')) return '/teacher/courses'
  return path
})

async function fetchUnreadCount() {
  try {
    const res = await getUnreadCount()
    unreadCount.value = res.data.count
  } catch {
    // 忽略错误
  }
}

function handleCommand(command: string) {
  switch (command) {
    case 'profile':
      break
    case 'logout':
      ElMessageBox.confirm('确定要退出登录吗？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(async () => {
        await authStore.logout()
        router.push('/login')
      })
      break
  }
}

onMounted(() => {
  fetchUnreadCount()
})
</script>

<style scoped>
.layout-container {
  height: 100vh;
  overflow: hidden;
}

.layout-aside {
  background: #1d1e2c;
  transition: width 0.3s;
  overflow: hidden;
}

.aside-logo {
  height: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  cursor: pointer;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.logo-img {
  width: 32px;
  height: 32px;
}

.logo-text {
  color: #fff;
  font-size: 16px;
  font-weight: 600;
  white-space: nowrap;
}

.logo-text-mini {
  color: #fff;
  font-size: 16px;
  font-weight: 600;
}

.aside-menu {
  border-right: none;
  background: transparent;
}

.aside-menu:not(.el-menu--collapse) {
  width: 220px;
}

.aside-menu .el-menu-item,
.aside-menu :deep(.el-sub-menu__title) {
  color: rgba(255, 255, 255, 0.7);
}

.aside-menu .el-menu-item:hover,
.aside-menu :deep(.el-sub-menu__title:hover) {
  background: rgba(255, 255, 255, 0.1);
  color: #fff;
}

.aside-menu .el-menu-item.is-active {
  background: #409eff;
  color: #fff;
}

.layout-main {
  flex-direction: column;
}

.layout-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #fff;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.08);
  padding: 0 20px;
  height: 60px;
  z-index: 10;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 16px;
}

.collapse-btn {
  cursor: pointer;
  color: #666;
}

.collapse-btn:hover {
  color: #409eff;
}

.header-right {
  display: flex;
  align-items: center;
  gap: 16px;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  padding: 4px 8px;
  border-radius: 4px;
}

.user-info:hover {
  background: #f5f7fa;
}

.user-name {
  font-size: 14px;
  color: #333;
  max-width: 100px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.layout-content {
  background: #f0f2f5;
  overflow-y: auto;
  padding: 20px;
}

.fade-transform-enter-active,
.fade-transform-leave-active {
  transition: all 0.2s;
}

.fade-transform-enter-from {
  opacity: 0;
  transform: translateX(-20px);
}

.fade-transform-leave-to {
  opacity: 0;
  transform: translateX(20px);
}
</style>
