<template>
  <el-dialog
    v-model="visible"
    :title="title"
    :width="width"
    :close-on-click-modal="false"
    :close-on-press-escape="true"
    @close="handleCancel"
  >
    <div class="confirm-dialog-body">
      <el-icon class="confirm-icon" :size="24" v-if="icon">
        <component :is="icon" :style="{ color: iconColor }" />
      </el-icon>
      <div class="confirm-content">
        <p class="confirm-message">{{ message }}</p>
        <p class="confirm-detail" v-if="detail">{{ detail }}</p>
      </div>
    </div>

    <template #footer>
      <el-button @click="handleCancel">{{ cancelText }}</el-button>
      <el-button
        :type="confirmType"
        :loading="loading"
        @click="handleConfirm"
      >
        {{ confirmText }}
      </el-button>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { WarningFilled, InfoFilled, CircleCloseFilled } from '@element-plus/icons-vue'

const props = withDefaults(
  defineProps<{
    modelValue: boolean
    title?: string
    message: string
    detail?: string
    confirmText?: string
    cancelText?: string
    confirmType?: 'primary' | 'success' | 'warning' | 'danger' | 'info'
    loading?: boolean
    width?: string
    type?: 'warning' | 'info' | 'danger'
  }>(),
  {
    title: '确认操作',
    confirmText: '确定',
    cancelText: '取消',
    confirmType: 'primary',
    loading: false,
    width: '420px',
    type: 'warning'
  }
)

const emit = defineEmits<{
  'update:modelValue': [value: boolean]
  confirm: []
  cancel: []
}>()

const visible = computed({
  get: () => props.modelValue,
  set: (val) => emit('update:modelValue', val)
})

const icon = computed(() => {
  const map: Record<string, any> = {
    warning: WarningFilled,
    info: InfoFilled,
    danger: CircleCloseFilled
  }
  return map[props.type] || WarningFilled
})

const iconColor = computed(() => {
  const map: Record<string, string> = {
    warning: '#E6A23C',
    info: '#409EFF',
    danger: '#F56C6C'
  }
  return map[props.type] || '#E6A23C'
})

function handleConfirm() {
  emit('confirm')
}

function handleCancel() {
  visible.value = false
  emit('cancel')
}
</script>

<style scoped>
.confirm-dialog-body {
  display: flex;
  gap: 16px;
  align-items: flex-start;
}

.confirm-icon {
  flex-shrink: 0;
  margin-top: 2px;
}

.confirm-message {
  font-size: 14px;
  color: #303133;
  line-height: 1.6;
  margin: 0;
}

.confirm-detail {
  font-size: 13px;
  color: #909399;
  margin: 8px 0 0;
  line-height: 1.5;
}
</style>
