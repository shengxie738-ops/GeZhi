<template>
  <div class="notifications-view">
    <PageHeader title="通知中心">
      <template #default>
        <el-button
          text
          type="primary"
          :disabled="unreadCount === 0"
          @click="handleMarkAllRead"
        >
          全部已读
        </el-button>
      </template>
    </PageHeader>

    <div class="notifications-content" v-loading="loading">
      <!-- 通知列表 -->
      <div class="notification-list" v-if="notifications.length > 0">
        <div
          v-for="notification in notifications"
          :key="notification.id"
          class="notification-item"
          :class="{ 'is-unread': !notification.is_read }"
          @click="handleClick(notification)"
        >
          <div class="notif-icon" :class="`notif-icon--${notification.type}`">
            <el-icon :size="20">
              <component :is="getIcon(notification.type)" />
            </el-icon>
          </div>

          <div class="notif-content">
            <div class="notif-title">{{ notification.title }}</div>
            <div class="notif-text">{{ notification.content }}</div>
            <div class="notif-time">{{ formatRelativeTime(notification.created_at) }}</div>
          </div>

          <div class="notif-actions" v-if="!notification.is_read">
            <el-button
              text
              size="small"
              @click.stop="handleMarkRead(notification)"
            >
              标为已读
            </el-button>
          </div>
        </div>
      </div>

      <el-empty v-if="!loading && notifications.length === 0" description="暂无通知" />

      <Pagination
        v-if="total > 0"
        :total="total"
        :page="page"
        :page-size="pageSize"
        @change="handlePageChange"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import {
  Bell,
  Message,
  CircleCheck,
  Document,
  Warning,
  InfoFilled
} from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import {
  getNotifications,
  markRead,
  markAllRead
} from '@/api/notification'
import { formatRelativeTime } from '@/utils/format'
import type { Notification, NotificationType } from '@/types/notification'
import PageHeader from '@/components/common/PageHeader.vue'
import Pagination from '@/components/common/Pagination.vue'

const router = useRouter()

const loading = ref(false)
const notifications = ref<Notification[]>([])
const total = ref(0)
const page = ref(1)
const pageSize = ref(20)

// 注意：这里只计算当前页的未读数量，用于控制"全部已读"按钮状态
// 如果需要显示全局未读数，应该调用API获取
const unreadCount = computed(() =>
  notifications.value.filter(n => !n.is_read).length
)

function getIcon(type: NotificationType) {
  const iconMap: Record<string, any> = {
    system: Bell,
    course_invite: Message,
    question_answered: Message,
    answer_accepted: CircleCheck,
    document_parsed: Document,
    document_failed: Warning,
    job_completed: CircleCheck,
    job_failed: Warning
  }
  return iconMap[type] || InfoFilled
}

async function fetchNotifications() {
  loading.value = true
  try {
    const res = await getNotifications({
      page: page.value,
      page_size: pageSize.value
    })
    notifications.value = res.data.items || []
    total.value = res.data.total || 0
  } catch {
    // 错误已处理
  } finally {
    loading.value = false
  }
}

function handlePageChange(newPage: number, newPageSize: number) {
  page.value = newPage
  pageSize.value = newPageSize
  fetchNotifications()
}

async function handleClick(notification: Notification) {
  if (!notification.is_read) {
    await handleMarkRead(notification)
  }
  if (notification.link) {
    router.push(notification.link)
  }
}

async function handleMarkRead(notification: Notification) {
  try {
    await markRead(notification.id)
    notification.is_read = true
  } catch { /* 忽略 */ }
}

async function handleMarkAllRead() {
  try {
    await markAllRead()
    notifications.value.forEach(n => { n.is_read = true })
    ElMessage.success('已全部标记为已读')
  } catch { /* 忽略 */ }
}

onMounted(() => {
  fetchNotifications()
})
</script>

<style scoped>
.notifications-view {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.notifications-content {
  background: #fff;
  border-radius: 10px;
  padding: 20px;
  min-height: 400px;
}

.notification-list {
  display: flex;
  flex-direction: column;
}

.notification-item {
  display: flex;
  align-items: flex-start;
  gap: 14px;
  padding: 16px;
  border-bottom: 1px solid #f2f3f5;
  cursor: pointer;
  transition: background 0.2s;
}

.notification-item:last-child {
  border-bottom: none;
}

.notification-item:hover {
  background: #f5f7fa;
}

.notification-item.is-unread {
  background: #f0f7ff;
}

.notif-icon {
  width: 40px;
  height: 40px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.notif-icon--system { background: #ecf5ff; color: #409eff; }
.notif-icon--course_invite { background: #fdf6ec; color: #e6a23c; }
.notif-icon--question_answered { background: #ecf5ff; color: #409eff; }
.notif-icon--answer_accepted { background: #f0f9eb; color: #67c23a; }
.notif-icon--document_parsed { background: #f4f4f5; color: #909399; }
.notif-icon--document_failed { background: #fef0f0; color: #f56c6c; }
.notif-icon--job_completed { background: #f0f9eb; color: #67c23a; }
.notif-icon--job_failed { background: #fef0f0; color: #f56c6c; }

.notif-content {
  flex: 1;
  min-width: 0;
}

.notif-title {
  font-size: 14px;
  font-weight: 600;
  color: #303133;
  margin-bottom: 4px;
}

.notif-text {
  font-size: 13px;
  color: #606266;
  line-height: 1.5;
  margin-bottom: 4px;
}

.notif-time {
  font-size: 12px;
  color: #c0c4cc;
}

.notif-actions {
  flex-shrink: 0;
}
</style>
