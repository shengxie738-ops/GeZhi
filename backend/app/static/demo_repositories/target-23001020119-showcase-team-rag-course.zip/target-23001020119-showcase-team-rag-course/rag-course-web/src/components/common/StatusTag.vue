<template>
  <el-tag :type="tagType" :effect="effect" :size="size" :round="round">
    {{ displayLabel }}
  </el-tag>
</template>

<script setup lang="ts">
import { computed } from 'vue'

const props = withDefaults(
  defineProps<{
    value: string
    type?: 'parse' | 'forum' | 'job' | 'wrong-question' | 'model' | 'general'
    effect?: 'dark' | 'light' | 'plain'
    size?: 'large' | 'default' | 'small'
    round?: boolean
  }>(),
  {
    type: 'general',
    effect: 'light',
    size: 'small',
    round: false
  }
)

const parseStatusMap: Record<string, { label: string; type: string }> = {
  pending: { label: '等待解析', type: 'info' },
  parsing: { label: '解析中', type: 'warning' },
  parsed: { label: '已解析', type: '' },
  failed: { label: '解析失败', type: 'danger' },
  indexing: { label: '索引中', type: 'warning' },
  indexed: { label: '已索引', type: 'success' },
  reindexing: { label: '重建索引', type: 'warning' }
}

const forumStatusMap: Record<string, { label: string; type: string }> = {
  open: { label: '开放', type: 'primary' },
  answered: { label: '已回答', type: 'success' },
  closed: { label: '已关闭', type: 'info' },
  verified: { label: '已验证', type: 'success' }
}

const jobStatusMap: Record<string, { label: string; type: string }> = {
  pending: { label: '等待中', type: 'info' },
  running: { label: '运行中', type: 'warning' },
  completed: { label: '已完成', type: 'success' },
  failed: { label: '失败', type: 'danger' }
}

const wrongQuestionStatusMap: Record<string, { label: string; type: string }> = {
  pending: { label: '待复习', type: 'warning' },
  mastered: { label: '已掌握', type: 'success' },
  reviewing: { label: '复习中', type: 'primary' }
}

const modelStatusMap: Record<string, { label: string; type: string }> = {
  active: { label: '启用', type: 'success' },
  inactive: { label: '停用', type: 'info' }
}

const statusMaps: Record<string, Record<string, { label: string; type: string }>> = {
  parse: parseStatusMap,
  forum: forumStatusMap,
  job: jobStatusMap,
  'wrong-question': wrongQuestionStatusMap,
  model: modelStatusMap,
  general: {}
}

const statusInfo = computed(() => {
  const map = statusMaps[props.type] || statusMaps.general
  return map[props.value] || { label: props.value, type: 'info' }
})

const tagType = computed(() => statusInfo.value.type as any)
const displayLabel = computed(() => statusInfo.value.label)
</script>
