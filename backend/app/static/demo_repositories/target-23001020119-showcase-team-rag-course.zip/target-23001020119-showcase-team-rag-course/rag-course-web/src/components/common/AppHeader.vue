<template>
  <el-header class="app-header">
    <div class="header-left">
      <slot name="left">
        <el-icon class="collapse-btn" :size="20" @click="$emit('toggle-collapse')">
          <Fold v-if="!collapsed" />
          <Expand v-else />
        </el-icon>
      </slot>
    </div>

    <div class="header-center">
      <slot name="center" />
    </div>

    <div class="header-right">
      <slot name="right" />
    </div>
  </el-header>
</template>

<script setup lang="ts">
import { Fold, Expand } from '@element-plus/icons-vue'

defineProps<{
  collapsed?: boolean
}>()

defineEmits<{
  'toggle-collapse': []
}>()
</script>

<style scoped>
.app-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #fff;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.08);
  padding: 0 20px;
  height: 60px;
  z-index: 10;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 16px;
}

.header-center {
  flex: 1;
  display: flex;
  justify-content: center;
}

.header-right {
  display: flex;
  align-items: center;
  gap: 16px;
}

.collapse-btn {
  cursor: pointer;
  color: #666;
}

.collapse-btn:hover {
  color: #409eff;
}
</style>
