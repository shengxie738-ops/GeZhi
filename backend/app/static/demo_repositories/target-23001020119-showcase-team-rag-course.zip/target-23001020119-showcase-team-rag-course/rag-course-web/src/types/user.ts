/** 用户角色 */
export type Role = 'student' | 'teacher' | 'admin'

/** 用户信息 */
export interface User {
  id: number
  username: string
  email: string
  nickname: string
  avatar: string
  role: Role
  phone: string
  student_no: string
  department: string
  created_at: string
  updated_at: string
  last_login_at: string
  is_active: boolean
}

/** 登录请求 */
export interface LoginRequest {
  username: string
  password: string
}

/** 登录响应 */
export interface LoginResponse {
  access_token: string
  refresh_token: string
  token_type: string
  expires_in: number
  user: User
}

/** 注册请求 */
export interface RegisterRequest {
  username: string
  password: string
  email: string
  nickname: string
  role?: Role
  student_no?: string
  department?: string
}

/** 刷新Token响应 */
export interface RefreshTokenResponse {
  access_token: string
  expires_in: number
}
