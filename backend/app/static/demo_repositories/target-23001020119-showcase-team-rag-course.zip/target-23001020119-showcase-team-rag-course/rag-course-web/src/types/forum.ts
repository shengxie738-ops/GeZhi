import type { User } from './user'

/** 论坛问题状态 */
export type ForumStatus = 'open' | 'answered' | 'closed' | 'verified'

/** 论坛问题 */
export interface ForumQuestion {
  id: number
  course_id: number
  user_id: number
  user: User
  title: string
  content: string
  tags: string[]
  status: ForumStatus
  view_count: number
  like_count: number
  answer_count: number
  accepted_answer_id: number | null
  is_anonymous: boolean
  created_at: string
  updated_at: string
}

/** 论坛回答 */
export interface ForumAnswer {
  id: number
  question_id: number
  user_id: number
  user: User
  content: string
  like_count: number
  is_accepted: boolean
  is_verified: boolean
  verified_by: number | null
  verified_at: string | null
  added_to_knowledge: boolean
  created_at: string
  updated_at: string
}

/** 创建问题请求 */
export interface CreateQuestionRequest {
  title: string
  content: string
  tags?: string[]
  is_anonymous?: boolean
}

/** 创建回答请求 */
export interface CreateAnswerRequest {
  content: string
}
