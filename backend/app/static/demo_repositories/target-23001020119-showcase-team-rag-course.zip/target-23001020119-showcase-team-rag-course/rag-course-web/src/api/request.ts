import axios from 'axios'
import type { AxiosInstance, AxiosRequestConfig, AxiosResponse, InternalAxiosRequestConfig } from 'axios'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getToken, setToken, removeToken, getRefreshToken, clearAuth } from '@/utils/auth'

const service: AxiosInstance = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json'
  }
})

// 是否正在刷新token
let isRefreshing = false
let pendingRequests: Array<(token: string) => void> = []

// 请求拦截器
service.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    const token = getToken()
    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// 响应拦截器
service.interceptors.response.use(
  (response: AxiosResponse) => {
    const res = response.data

    // 如果响应直接返回数据（非标准格式）
    if (response.config.responseType === 'blob' || response.config.responseType === 'arraybuffer') {
      return response
    }

    // 业务错误码处理
    if (res.code !== undefined && res.code !== 0 && res.code !== 200) {
      ElMessage.error(res.message || '请求失败')

      // 401: Token过期
      if (res.code === 401) {
        return handleUnauthorized(response.config)
      }

      return Promise.reject(new Error(res.message || '请求失败'))
    }

    return res
  },
  async (error) => {
    const { response, config } = error

    if (!response) {
      ElMessage.error('网络连接异常，请检查网络')
      return Promise.reject(error)
    }

    // 401: Token过期
    if (response.status === 401 && !config._isRetry) {
      return handleUnauthorized(config)
    }

    // 其他HTTP错误
    const errorMessage = response.data?.message || response.statusText || '请求失败'
    ElMessage.error(errorMessage)

    return Promise.reject(error)
  }
)

// 处理401未授权
async function handleUnauthorized(config: AxiosRequestConfig): Promise<any> {
  const refreshToken = getRefreshToken()

  if (!refreshToken) {
    clearAuth()
    window.location.href = '/login'
    return Promise.reject(new Error('未登录'))
  }

  if (!isRefreshing) {
    isRefreshing = true

    try {
      const { data } = await axios.post(
        `${import.meta.env.VITE_API_BASE_URL}/auth/refresh`,
        { refresh_token: refreshToken }
      )

      const newToken = data.data?.access_token || data.access_token
      if (newToken) {
        setToken(newToken)
        pendingRequests.forEach((cb) => cb(newToken))
        pendingRequests = []

        // 重试原请求
        config._isRetry = true
        if (config.headers) {
          config.headers.Authorization = `Bearer ${newToken}`
        }
        return service(config)
      }
    } catch {
      clearAuth()
      window.location.href = '/login'
      return Promise.reject(new Error('登录已过期'))
    } finally {
      isRefreshing = false
    }
  } else {
    // 正在刷新，等待
    return new Promise((resolve) => {
      pendingRequests.push((token: string) => {
        config._isRetry = true
        if (config.headers) {
          config.headers.Authorization = `Bearer ${token}`
        }
        resolve(service(config))
      })
    })
  }
}

export default service
