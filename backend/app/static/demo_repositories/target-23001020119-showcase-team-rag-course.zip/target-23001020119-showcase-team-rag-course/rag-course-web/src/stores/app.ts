import { defineStore } from 'pinia'
import { ref } from 'vue'

export const useAppStore = defineStore('app', () => {
  const sidebarCollapsed = ref(false)
  const currentCourseId = ref<number | null>(null)
  const currentCourseName = ref('')
  const pageTitle = ref('')
  const globalLoading = ref(false)

  function toggleSidebar() {
    sidebarCollapsed.value = !sidebarCollapsed.value
  }

  function setSidebarCollapsed(collapsed: boolean) {
    sidebarCollapsed.value = collapsed
  }

  function setCurrentCourse(id: number, name: string) {
    currentCourseId.value = id
    currentCourseName.value = name
  }

  function clearCurrentCourse() {
    currentCourseId.value = null
    currentCourseName.value = ''
  }

  function setPageTitle(title: string) {
    pageTitle.value = title
    document.title = title ? `${title} - RAG Course` : 'RAG Course - 人工智能技术基础课程'
  }

  function setGlobalLoading(loading: boolean) {
    globalLoading.value = loading
  }

  return {
    sidebarCollapsed,
    currentCourseId,
    currentCourseName,
    pageTitle,
    globalLoading,
    toggleSidebar,
    setSidebarCollapsed,
    setCurrentCourse,
    clearCurrentCourse,
    setPageTitle,
    setGlobalLoading
  }
})
