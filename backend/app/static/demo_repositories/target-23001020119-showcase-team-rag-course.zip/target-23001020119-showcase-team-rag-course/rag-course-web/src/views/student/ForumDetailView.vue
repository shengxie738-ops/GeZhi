<template>
  <div class="forum-detail-view" v-loading="loading">
    <PageHeader title="问题详情">
      <template #default>
        <el-button @click="router.back()">返回列表</el-button>
        <el-button
          v-if="question && question.status !== 'closed' && question.user_id === authStore.user?.id"
          type="success"
          @click="handleMarkResolved"
        >
          标记已解决
        </el-button>
      </template>
    </PageHeader>

    <template v-if="question">
      <!-- 问题卡片 -->
      <div class="question-card-full">
        <div class="question-header">
          <h2 class="question-title">{{ question.title }}</h2>
          <StatusTag :value="question.status" type="forum" />
        </div>

        <div class="question-meta">
          <div class="author-info">
            <el-avatar :size="32" :src="question.user?.avatar">
              {{ question.user?.nickname?.charAt(0) }}
            </el-avatar>
            <div>
              <span class="author-name">{{ question.user?.nickname }}</span>
              <span class="meta-time">{{ formatRelativeTime(question.created_at) }}</span>
            </div>
          </div>
          <div class="question-stats">
            <span><el-icon><View /></el-icon> {{ question.view_count }}</span>
            <span><el-icon><Star /></el-icon> {{ question.like_count }}</span>
            <span><el-icon><ChatLineSquare /></el-icon> {{ question.answer_count }}</span>
          </div>
        </div>

        <div class="question-body">
          <MarkdownRenderer :content="question.content" />
        </div>

        <div class="question-tags" v-if="question.tags?.length">
          <el-tag v-for="tag in question.tags" :key="tag" size="small" type="info" effect="plain">
            {{ tag }}
          </el-tag>
        </div>

        <div class="question-actions">
          <el-button text :type="liked ? 'primary' : ''" @click="handleLikeQuestion">
            <el-icon><Star /></el-icon> {{ question.like_count }} 点赞
          </el-button>
        </div>
      </div>

      <!-- 回答列表 -->
      <div class="answers-section">
        <h3 class="section-title">回答 ({{ answers.length }})</h3>

        <div class="answers-list">
          <AnswerCard
            v-for="answer in answers"
            :key="answer.id"
            :answer="answer"
            :show-accept="question.user_id === authStore.user?.id"
            @like="handleLikeAnswer(answer)"
            @accept="handleAcceptAnswer(answer)"
          />
        </div>

        <el-empty v-if="!loadingAnswers && answers.length === 0" description="暂无回答，快来抢沙发！" />
      </div>

      <!-- 回答输入 -->
      <div class="answer-input-card" v-if="question.status !== 'closed'">
        <h3 class="section-title">写下你的回答</h3>
        <el-input
          v-model="answerContent"
          type="textarea"
          :rows="5"
          placeholder="输入你的回答内容，支持Markdown格式..."
        />
        <div class="answer-actions">
          <el-button
            type="primary"
            :loading="submittingAnswer"
            :disabled="!answerContent.trim()"
            @click="handleSubmitAnswer"
          >
            提交回答
          </el-button>
        </div>
      </div>
    </template>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { View, Star, ChatLineSquare } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import { useAuthStore } from '@/stores/auth'
import {
  getQuestion,
  getAnswers,
  createAnswer,
  likeQuestion,
  acceptAnswer
} from '@/api/forum'
import { formatRelativeTime } from '@/utils/format'
import type { ForumQuestion, ForumAnswer } from '@/types/forum'
import PageHeader from '@/components/common/PageHeader.vue'
import StatusTag from '@/components/common/StatusTag.vue'
import MarkdownRenderer from '@/components/common/MarkdownRenderer.vue'
import AnswerCard from '@/components/forum/AnswerCard.vue'

const router = useRouter()
const route = useRoute()
const authStore = useAuthStore()
const questionId = Number(route.params.questionId)

const loading = ref(false)
const loadingAnswers = ref(false)
const submittingAnswer = ref(false)
const question = ref<ForumQuestion | null>(null)
const answers = ref<ForumAnswer[]>([])
const answerContent = ref('')
const liked = ref(false)

async function fetchQuestion() {
  loading.value = true
  try {
    const res = await getQuestion(questionId)
    question.value = res.data
  } catch {
    // 错误已处理
  } finally {
    loading.value = false
  }
}

async function fetchAnswers() {
  loadingAnswers.value = true
  try {
    const res = await getAnswers(questionId, { page: 1, page_size: 100 })
    answers.value = res.data.items || []
  } catch {
    // 错误已处理
  } finally {
    loadingAnswers.value = false
  }
}

async function handleLikeQuestion() {
  try {
    const res = await likeQuestion(questionId)
    liked.value = res.data.liked
    if (question.value) {
      question.value.like_count = res.data.like_count
    }
  } catch { /* 忽略 */ }
}

async function handleLikeAnswer(answer: ForumAnswer) {
  // 简化处理，实际应该有单独的点赞API
  answer.like_count++
}

async function handleAcceptAnswer(answer: ForumAnswer) {
  try {
    await acceptAnswer(answer.id)
    answers.value.forEach(a => { a.is_accepted = false })
    answer.is_accepted = true
    if (question.value) {
      question.value.accepted_answer_id = answer.id
      question.value.status = 'answered'
    }
    ElMessage.success('已采纳该回答')
  } catch {
    // 错误已处理
  }
}

async function handleSubmitAnswer() {
  if (!answerContent.value.trim()) return
  submittingAnswer.value = true
  try {
    const res = await createAnswer(questionId, { content: answerContent.value.trim() })
    answers.value.push(res.data)
    answerContent.value = ''
    if (question.value) {
      question.value.answer_count++
    }
    ElMessage.success('回答已提交')
  } catch {
    // 错误已处理
  } finally {
    submittingAnswer.value = false
  }
}

async function handleMarkResolved() {
  // 使用接受最佳答案来标记
  if (answers.value.length > 0) {
    await handleAcceptAnswer(answers.value[0])
  }
}

onMounted(() => {
  fetchQuestion()
  fetchAnswers()
})
</script>

<style scoped>
.forum-detail-view {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.question-card-full {
  background: #fff;
  border-radius: 10px;
  padding: 24px;
}

.question-header {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
}

.question-title {
  font-size: 20px;
  font-weight: 700;
  margin: 0;
  color: #303133;
  flex: 1;
}

.question-meta {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 16px;
}

.author-info {
  display: flex;
  align-items: center;
  gap: 10px;
}

.author-name {
  font-size: 14px;
  font-weight: 600;
  color: #303133;
  display: block;
}

.meta-time {
  font-size: 12px;
  color: #909399;
  display: block;
}

.question-stats {
  display: flex;
  gap: 16px;
  font-size: 13px;
  color: #909399;
}

.question-stats span {
  display: flex;
  align-items: center;
  gap: 4px;
}

.question-body {
  line-height: 1.7;
  padding: 16px 0;
  border-top: 1px solid #f2f3f5;
}

.question-tags {
  display: flex;
  gap: 6px;
  margin-top: 12px;
}

.question-actions {
  margin-top: 12px;
  padding-top: 12px;
  border-top: 1px solid #f2f3f5;
}

/* 回答区域 */
.answers-section {
  background: #fff;
  border-radius: 10px;
  padding: 24px;
}

.section-title {
  font-size: 16px;
  font-weight: 600;
  margin: 0 0 16px;
  color: #303133;
}

.answers-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

/* 回答输入 */
.answer-input-card {
  background: #fff;
  border-radius: 10px;
  padding: 24px;
}

.answer-actions {
  display: flex;
  justify-content: flex-end;
  margin-top: 12px;
}
</style>
