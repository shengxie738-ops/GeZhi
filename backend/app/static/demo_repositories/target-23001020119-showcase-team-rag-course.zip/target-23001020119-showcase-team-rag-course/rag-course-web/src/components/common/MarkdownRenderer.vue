<template>
  <div class="markdown-renderer" v-html="renderedHtml" />
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import MarkdownIt from 'markdown-it'
import hljs from 'highlight.js'
import 'highlight.js/styles/github.css'

const props = withDefaults(
  defineProps<{
    content: string
    highlight?: boolean
  }>(),
  {
    highlight: true
  }
)

const md = ref<MarkdownIt | null>(null)

onMounted(() => {
  md.value = new MarkdownIt({
    html: true,
    linkify: true,
    typographer: true,
    highlight: props.highlight
      ? (str: string, lang: string) => {
          if (lang && hljs.getLanguage(lang)) {
            try {
              const result = hljs.highlight(str, { language: lang, ignoreIllegals: true })
              return `<pre class="hljs"><code class="language-${lang}">${result.value}</code></pre>`
            } catch {
              // fallthrough
            }
          }
          const escaped = md.value!.utils.escapeHtml(str)
          return `<pre class="hljs"><code>${escaped}</code></pre>`
        }
      : undefined
  })
})

const renderedHtml = computed(() => {
  if (!md.value || !props.content) return ''
  return md.value.render(props.content)
})
</script>

<style>
.markdown-renderer {
  line-height: 1.8;
  color: #333;
}

.markdown-renderer h1,
.markdown-renderer h2,
.markdown-renderer h3,
.markdown-renderer h4 {
  margin: 16px 0 8px;
  font-weight: 600;
}

.markdown-renderer h1 {
  font-size: 24px;
}

.markdown-renderer h2 {
  font-size: 20px;
}

.markdown-renderer h3 {
  font-size: 16px;
}

.markdown-renderer p {
  margin: 8px 0;
}

.markdown-renderer ul,
.markdown-renderer ol {
  padding-left: 24px;
  margin: 8px 0;
}

.markdown-renderer li {
  margin: 4px 0;
}

.markdown-renderer code {
  background: #f5f7fa;
  padding: 2px 6px;
  border-radius: 3px;
  font-size: 13px;
  font-family: 'Courier New', Courier, monospace;
  color: #e83e8c;
}

.markdown-renderer pre {
  margin: 12px 0;
  border-radius: 6px;
  overflow: auto;
}

.markdown-renderer pre code {
  background: none;
  padding: 0;
  color: inherit;
}

.markdown-renderer blockquote {
  border-left: 4px solid #409eff;
  padding: 8px 16px;
  margin: 12px 0;
  background: #f0f7ff;
  color: #666;
}

.markdown-renderer table {
  border-collapse: collapse;
  width: 100%;
  margin: 12px 0;
}

.markdown-renderer th,
.markdown-renderer td {
  border: 1px solid #dcdfe6;
  padding: 8px 12px;
  text-align: left;
}

.markdown-renderer th {
  background: #f5f7fa;
  font-weight: 600;
}

.markdown-renderer img {
  max-width: 100%;
  border-radius: 4px;
}

.markdown-renderer a {
  color: #409eff;
  text-decoration: none;
}

.markdown-renderer a:hover {
  text-decoration: underline;
}

.markdown-renderer hr {
  border: none;
  border-top: 1px solid #dcdfe6;
  margin: 16px 0;
}
</style>
