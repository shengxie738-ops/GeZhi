/** 模型配置 */
export interface ModelConfig {
  id: number
  name: string
  provider: string
  model_id: string
  api_key: string
  base_url: string
  max_tokens: number
  temperature: number
  top_p: number
  is_active: boolean
  is_default: boolean
  usage_count: number
  created_at: string
  updated_at: string
}

/** RAG配置 */
export interface RagConfig {
  id: number
  embedding_model: string
  embedding_dimensions: number
  chunk_size: number
  chunk_overlap: number
  top_k: number
  score_threshold: number
  rerank_enabled: boolean
  rerank_model: string | null
  retrieval_strategy: 'similarity' | 'mmr' | 'hybrid'
  mmr_lambda: number
  prompt_template: string
  system_prompt: string
  updated_at: string
}

/** 创建模型配置请求 */
export interface CreateModelConfigRequest {
  name: string
  provider: string
  model_id: string
  api_key: string
  base_url: string
  max_tokens?: number
  temperature?: number
  top_p?: number
  is_default?: boolean
}

/** 更新模型配置请求 */
export interface UpdateModelConfigRequest {
  name?: string
  api_key?: string
  base_url?: string
  max_tokens?: number
  temperature?: number
  top_p?: number
  is_active?: boolean
  is_default?: boolean
}

/** 模型测试请求 */
export interface ModelTestRequest {
  model_id: number
  prompt?: string
}

/** 模型测试响应 */
export interface ModelTestResponse {
  success: boolean
  response: string
  latency_ms: number
  token_count: number
  error: string | null
}
