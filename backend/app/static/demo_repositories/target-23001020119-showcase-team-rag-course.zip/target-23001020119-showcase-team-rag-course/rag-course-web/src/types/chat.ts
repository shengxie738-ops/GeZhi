/** 引用来源 */
export interface Citation {
  document_id: number
  document_title: string
  chunk_id: number
  chunk_content: string
  score: number
  page_number: number | null
}

/** 用户反馈类型 */
export type FeedbackType = 'like' | 'dislike' | 'helpful' | 'not_helpful'

/** 回答状态 */
export type AnswerStatus = 'pending' | 'streaming' | 'completed' | 'error'

/** 聊天会话 */
export interface ChatSession {
  id: number
  user_id: number
  course_id: number
  title: string
  message_count: number
  created_at: string
  updated_at: string
}

/** 聊天消息 */
export interface ChatMessage {
  id: number
  session_id: number
  role: 'user' | 'assistant' | 'system'
  content: string
  citations: Citation[]
  feedback: FeedbackType | null
  status: AnswerStatus
  token_count: number
  model_used: string
  latency_ms: number
  created_at: string
}

/** 创建会话请求 */
export interface CreateSessionRequest {
  course_id: number
  title?: string
  first_message?: string
}
