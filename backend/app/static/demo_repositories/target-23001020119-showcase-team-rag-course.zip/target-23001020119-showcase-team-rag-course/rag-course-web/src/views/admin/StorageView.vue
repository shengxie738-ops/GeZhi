﻿<template>
  <div class="page-container">
    <PageHeader title="存储管理" description="MinIO 对象存储管理" />

    <el-row :gutter="20">
      <!-- 存储概览 -->
      <el-col :span="8">
        <el-card shadow="never">
          <template #header><span class="card-title">存储概览</span></template>
          <PieChart
            height="250px"
            :data="storagePieData"
            :show-legend="true"
          />
          <div class="storage-stats">
            <div class="stat-item">
              <span class="stat-label">总文件数</span>
              <span class="stat-value">3,256</span>
            </div>
            <div class="stat-item">
              <span class="stat-label">存储使用</span>
              <span class="stat-value">12.8 GB</span>
            </div>
            <div class="stat-item">
              <span class="stat-label">总容量</span>
              <span class="stat-value">50 GB</span>
            </div>
          </div>
        </el-card>
      </el-col>

      <!-- Bucket 列表 + 文件浏览器 -->
      <el-col :span="16">
        <el-card shadow="never">
          <el-tabs v-model="activeTab">
            <el-tab-pane label="Bucket 列表" name="buckets">
              <el-table :data="buckets" stripe border size="small">
                <el-table-column prop="name" label="Bucket 名称" min-width="200" />
                <el-table-column prop="created_at" label="创建时间" width="170">
                  <template #default="{ row }">{{ formatDate(row.created_at) }}</template>
                </el-table-column>
                <el-table-column prop="file_count" label="文件数" width="100" align="center" />
                <el-table-column prop="size" label="大小" width="120" />
                <el-table-column label="操作" width="140">
                  <template #default="{ row }">
                    <el-button type="primary" link size="small" @click="browseBucket(row)">浏览</el-button>
                    <el-popconfirm title="确定删除此Bucket？" @confirm="handleDeleteBucket(row)">
                      <template #reference>
                        <el-button type="danger" link size="small">删除</el-button>
                      </template>
                    </el-popconfirm>
                  </template>
                </el-table-column>
              </el-table>
            </el-tab-pane>

            <el-tab-pane label="文件浏览器" name="files">
              <div class="file-breadcrumb">
                <el-breadcrumb separator="/">
                  <el-breadcrumb-item
                    v-for="(part, index) in currentPathParts"
                    :key="index"
                  >
                    <el-button link type="primary" size="small" @click="navigateTo(index)">
                      {{ part || '根目录' }}
                    </el-button>
                  </el-breadcrumb-item>
                </el-breadcrumb>
              </div>
              <el-table :data="files" stripe border size="small" v-loading="filesLoading">
                <el-table-column label="名称" min-width="300">
                  <template #default="{ row }">
                    <div class="file-name" @click="row.is_dir ? navigateInto(row.name) : null">
                      <el-icon :size="16" style="margin-right: 6px">
                        <Folder v-if="row.is_dir" style="color: #E6A23C" />
                        <Document v-else style="color: #409EFF" />
                      </el-icon>
                      <span :class="{ 'dir-name': row.is_dir }">{{ row.name }}</span>
                    </div>
                  </template>
                </el-table-column>
                <el-table-column label="大小" width="120">
                  <template #default="{ row }">
                    {{ row.is_dir ? '-' : formatFileSize(row.size) }}
                  </template>
                </el-table-column>
                <el-table-column prop="modified_at" label="修改时间" width="170">
                  <template #default="{ row }">{{ formatDate(row.modified_at) }}</template>
                </el-table-column>
                <el-table-column label="操作" width="100">
                  <template #default="{ row }">
                    <el-popconfirm title="确定删除？" @confirm="handleDeleteFile(row)">
                      <template #reference>
                        <el-button type="danger" link size="small" :disabled="row.is_dir">删除</el-button>
                      </template>
                    </el-popconfirm>
                  </template>
                </el-table-column>
              </el-table>
            </el-tab-pane>
          </el-tabs>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { Folder, Document } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import PageHeader from '@/components/common/PageHeader.vue'
import PieChart from '@/components/charts/PieChart.vue'
import { formatDate, formatFileSize } from '@/utils/format'

const activeTab = ref('buckets')

const storagePieData = ref([
  { name: '文档文件', value: 8200 },
  { name: '用户头像', value: 1200 },
  { name: '系统文件', value: 3400 },
  { name: '其他', value: 1000 }
])

const buckets = ref([
  { name: 'rag-documents', created_at: '2024-01-15T10:00:00', file_count: 1843, size: '8.2 GB' },
  { name: 'rag-avatars', created_at: '2024-01-15T10:00:00', file_count: 256, size: '1.2 GB' },
  { name: 'rag-system', created_at: '2024-01-15T10:00:00', file_count: 120, size: '3.4 GB' }
])

const currentPath = ref('')
const currentPathParts = ref<string[]>([''])
const filesLoading = ref(false)
const files = ref([
  { name: 'chapters', is_dir: true, size: 0, modified_at: '2024-03-10T14:30:00' },
  { name: 'uploads', is_dir: true, size: 0, modified_at: '2024-03-10T14:30:00' },
  { name: 'templates', is_dir: true, size: 0, modified_at: '2024-03-08T10:00:00' },
  { name: 'config.json', is_dir: false, size: 2048, modified_at: '2024-03-09T16:20:00' }
])

function browseBucket(bucket: { name: string }) {
  activeTab.value = 'files'
  currentPath.value = bucket.name
  currentPathParts.value = [bucket.name]
}

function navigateInto(dir: string) {
  currentPath.value = currentPath.value ? `${currentPath.value}/${dir}` : dir
  currentPathParts.value.push(dir)
}

function navigateTo(index: number) {
  currentPathParts.value = currentPathParts.value.slice(0, index + 1)
  currentPath.value = currentPathParts.value.join('/')
}

function handleDeleteBucket(bucket: { name: string }) {
  ElMessage.success(`Bucket ${bucket.name} 已删除`)
}

function handleDeleteFile(file: { name: string }) {
  ElMessage.success(`文件 ${file.name} 已删除`)
}

onMounted(() => {})
</script>

<style scoped>
.card-title { font-size: 16px; font-weight: 600; color: #303133; }

.storage-stats {
  margin-top: 16px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.stat-item {
  display: flex;
  justify-content: space-between;
  font-size: 14px;
}

.stat-label { color: #909399; }
.stat-value { font-weight: 600; color: #303133; }

.file-breadcrumb {
  margin-bottom: 12px;
}

.file-name {
  display: flex;
  align-items: center;
  cursor: pointer;
}

.dir-name {
  color: #409EFF;
  font-weight: 500;
}
</style>
