<template>
  <div class="session-list">
    <div class="session-list-header">
      <h3 class="session-list-title">会话列表</h3>
      <el-button type="primary" :icon="Plus" size="small" @click="$emit('new-session')">
        新建
      </el-button>
    </div>

    <div class="session-list-body" v-loading="loading">
      <div v-if="sessions.length === 0" class="session-empty">
        <el-empty description="暂无会话" :image-size="80" />
      </div>

      <div
        v-for="session in sessions"
        :key="session.id"
        class="session-item"
        :class="{ 'is-active': session.id === activeSessionId }"
        @click="$emit('select', session)"
      >
        <div class="session-info">
          <div class="session-title">{{ session.title || '新会话' }}</div>
          <div class="session-meta">
            <span class="session-course">{{ getCourseName(session.course_id) }}</span>
            <span class="session-time">{{ formatRelativeTime(session.updated_at) }}</span>
          </div>
        </div>

        <el-dropdown trigger="click" @command="(cmd: string) => handleCommand(cmd, session)" @click.stop>
          <el-icon class="session-more"><MoreFilled /></el-icon>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item command="delete" class="danger-item">
                <el-icon><Delete /></el-icon>删除会话
              </el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { Plus, MoreFilled, Delete } from '@element-plus/icons-vue'
import { ElMessageBox } from 'element-plus'
import type { ChatSession } from '@/types/chat'
import { formatRelativeTime } from '@/utils/format'

const props = defineProps<{
  sessions: ChatSession[]
  activeSessionId?: number | null
  loading?: boolean
  courseMap?: Record<number, string>
}>()

const emit = defineEmits<{
  select: [session: ChatSession]
  'new-session': []
  delete: [session: ChatSession]
}>()

function getCourseName(courseId: number): string {
  return props.courseMap?.[courseId] || `课程 ${courseId}`
}

function handleCommand(command: string, session: ChatSession) {
  if (command === 'delete') {
    ElMessageBox.confirm('确定要删除该会话吗？删除后不可恢复。', '删除会话', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }).then(() => {
      emit('delete', session)
    }).catch(() => {})
  }
}
</script>

<style scoped>
.session-list {
  display: flex;
  flex-direction: column;
  height: 100%;
}

.session-list-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px;
  border-bottom: 1px solid #ebeef5;
}

.session-list-title {
  font-size: 16px;
  font-weight: 600;
  margin: 0;
  color: #303133;
}

.session-list-body {
  flex: 1;
  overflow-y: auto;
}

.session-empty {
  padding: 20px 0;
}

.session-item {
  display: flex;
  align-items: center;
  padding: 12px 16px;
  cursor: pointer;
  border-bottom: 1px solid #f2f3f5;
  transition: background 0.2s;
}

.session-item:hover {
  background: #f5f7fa;
}

.session-item.is-active {
  background: #ecf5ff;
  border-left: 3px solid #409eff;
}

.session-info {
  flex: 1;
  min-width: 0;
}

.session-title {
  font-size: 14px;
  color: #303133;
  font-weight: 500;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.session-meta {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 4px;
  font-size: 12px;
  color: #909399;
}

.session-more {
  color: #909399;
  padding: 4px;
  border-radius: 4px;
  flex-shrink: 0;
}

.session-more:hover {
  color: #409eff;
  background: #ecf5ff;
}

.danger-item {
  color: #f56c6c !important;
}
</style>
