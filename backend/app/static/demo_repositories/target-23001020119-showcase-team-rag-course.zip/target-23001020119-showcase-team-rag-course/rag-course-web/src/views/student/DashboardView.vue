<template>
  <div class="dashboard-view">
    <!-- 欢迎卡片 -->
    <div class="welcome-card">
      <div class="welcome-info">
        <h2 class="welcome-title">你好，{{ authStore.nickname }}!</h2>
        <p class="welcome-subtitle">欢迎回到 RAG 教学系统，今天也是学习的好日子</p>
      </div>
      <div class="welcome-stats">
        <div class="stat-icon">
          <el-icon :size="28"><DataAnalysis /></el-icon>
        </div>
        <div class="stat-detail">
          <span class="stat-number">{{ stats.todayQuestions }}</span>
          <span class="stat-text">今日提问</span>
        </div>
      </div>
    </div>

    <!-- 统计卡片 -->
    <el-row :gutter="20" class="stats-row">
      <el-col :xs="12" :sm="6">
        <div class="stat-card stat-card--course">
          <el-icon class="stat-card-icon"><Reading /></el-icon>
          <div class="stat-card-info">
            <span class="stat-card-value">{{ stats.courseCount }}</span>
            <span class="stat-card-label">已加入课程</span>
          </div>
        </div>
      </el-col>
      <el-col :xs="12" :sm="6">
        <div class="stat-card stat-card--question">
          <el-icon class="stat-card-icon"><ChatDotRound /></el-icon>
          <div class="stat-card-info">
            <span class="stat-card-value">{{ stats.questionCount }}</span>
            <span class="stat-card-label">提问数</span>
          </div>
        </div>
      </el-col>
      <el-col :xs="12" :sm="6">
        <div class="stat-card stat-card--solved">
          <el-icon class="stat-card-icon"><CircleCheck /></el-icon>
          <div class="stat-card-info">
            <span class="stat-card-value">{{ stats.solvedCount }}</span>
            <span class="stat-card-label">已解决问题</span>
          </div>
        </div>
      </el-col>
      <el-col :xs="12" :sm="6">
        <div class="stat-card stat-card--favorite">
          <el-icon class="stat-card-icon"><Star /></el-icon>
          <div class="stat-card-info">
            <span class="stat-card-value">{{ stats.favoriteCount }}</span>
            <span class="stat-card-label">收藏数</span>
          </div>
        </div>
      </el-col>
    </el-row>

    <!-- 最近课程 -->
    <div class="section-card">
      <div class="section-header">
        <h3 class="section-title">最近课程</h3>
        <el-button text type="primary" @click="router.push('/student/courses')">查看全部</el-button>
      </div>
      <el-row :gutter="20" v-loading="loadingCourses">
        <el-col
          :xs="24" :sm="12" :md="8"
          v-for="course in recentCourses"
          :key="course.id"
        >
          <div class="course-card" @click="router.push(`/student/courses/${course.id}`)">
            <div class="course-cover">
              <img
                :src="`https://picsum.photos/seed/${course.id}/400/200`"
                :alt="course.name"
              />
              <div class="course-semester">{{ course.semester }}</div>
            </div>
            <div class="course-info">
              <h4 class="course-name">{{ course.name }}</h4>
              <div class="course-teacher">
                <el-avatar :size="18">{{ course.teacher?.nickname?.charAt(0) }}</el-avatar>
                <span>{{ course.teacher?.nickname }}</span>
              </div>
              <div class="course-progress">
                <span class="progress-text">文档 {{ course.document_count }} 篇</span>
                <span class="progress-text">{{ course.member_count }} 名同学</span>
              </div>
            </div>
          </div>
        </el-col>
      </el-row>
      <el-empty v-if="!loadingCourses && recentCourses.length === 0" description="还没有加入任何课程">
        <el-button type="primary" @click="router.push('/student/courses')">浏览课程</el-button>
      </el-empty>
    </div>

    <!-- 最近问答 -->
    <div class="section-card">
      <div class="section-header">
        <h3 class="section-title">最近问答</h3>
      </div>
      <el-table :data="recentSessions" v-loading="loadingSessions" stripe>
        <el-table-column label="问题" min-width="300" show-overflow-tooltip>
          <template #default="{ row }">
            <span class="link-text" @click="router.push(`/student/chat/${row.id}`)">
              {{ row.title || '新会话' }}
            </span>
          </template>
        </el-table-column>
        <el-table-column label="消息数" width="100" align="center">
          <template #default="{ row }">
            {{ row.message_count }}
          </template>
        </el-table-column>
        <el-table-column label="最近更新" width="160">
          <template #default="{ row }">
            {{ formatDate(row.updated_at) }}
          </template>
        </el-table-column>
      </el-table>
      <el-empty v-if="!loadingSessions && recentSessions.length === 0" description="暂无问答记录" :image-size="80" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import {
  Reading,
  ChatDotRound,
  CircleCheck,
  Star,
  DataAnalysis
} from '@element-plus/icons-vue'
import { useAuthStore } from '@/stores/auth'
import { getCourses } from '@/api/course'
import { formatDate } from '@/utils/format'
import request from '@/api/request'
import type { ApiResponse, PageResponse } from '@/types/common'
import type { Course } from '@/types/course'
import type { ChatSession } from '@/types/chat'

const router = useRouter()
const authStore = useAuthStore()

const loadingCourses = ref(false)
const loadingSessions = ref(false)
const recentCourses = ref<Course[]>([])
const recentSessions = ref<ChatSession[]>([])

const stats = reactive({
  courseCount: 0,
  questionCount: 0,
  solvedCount: 0,
  favoriteCount: 0,
  todayQuestions: 0
})

async function fetchCourses() {
  loadingCourses.value = true
  try {
    const res = await getCourses({ page: 1, page_size: 6 })
    recentCourses.value = res.data.items || []
    stats.courseCount = res.data.total || 0
  } catch {
    // 忽略错误
  } finally {
    loadingCourses.value = false
  }
}

async function fetchSessions() {
  loadingSessions.value = true
  try {
    const res = await request.get<ApiResponse<PageResponse<ChatSession>>>('/chat/sessions', {
      params: { page: 1, size: 5 }
    })
    recentSessions.value = res.data.items || []
  } catch {
    // 忽略错误
  } finally {
    loadingSessions.value = false
  }
}

onMounted(() => {
  fetchCourses()
  fetchSessions()
})
</script>

<style scoped>
.dashboard-view {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

/* 欢迎卡片 */
.welcome-card {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 24px 32px;
  background: linear-gradient(135deg, #409eff 0%, #66b1ff 100%);
  border-radius: 12px;
  color: #fff;
}

.welcome-title {
  font-size: 22px;
  font-weight: 600;
  margin: 0 0 4px;
}

.welcome-subtitle {
  font-size: 14px;
  opacity: 0.85;
  margin: 0;
}

.welcome-stats {
  display: flex;
  align-items: center;
  gap: 12px;
  background: rgba(255, 255, 255, 0.2);
  padding: 12px 20px;
  border-radius: 10px;
}

.stat-icon {
  opacity: 0.9;
}

.stat-detail {
  display: flex;
  flex-direction: column;
}

.stat-number {
  font-size: 24px;
  font-weight: 700;
}

.stat-text {
  font-size: 12px;
  opacity: 0.85;
}

/* 统计卡片 */
.stats-row {
  margin: 0;
}

.stat-card {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 20px;
  background: #fff;
  border-radius: 10px;
  border-left: 4px solid;
  transition: box-shadow 0.2s;
}

.stat-card:hover {
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
}

.stat-card--course { border-color: #409eff; }
.stat-card--question { border-color: #e6a23c; }
.stat-card--solved { border-color: #67c23a; }
.stat-card--favorite { border-color: #f56c6c; }

.stat-card-icon {
  font-size: 28px;
  color: #909399;
}

.stat-card-info {
  display: flex;
  flex-direction: column;
}

.stat-card-value {
  font-size: 22px;
  font-weight: 700;
  color: #303133;
}

.stat-card-label {
  font-size: 13px;
  color: #909399;
}

/* 通用区块 */
.section-card {
  background: #fff;
  border-radius: 10px;
  padding: 20px;
}

.section-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 16px;
}

.section-title {
  font-size: 16px;
  font-weight: 600;
  margin: 0;
  color: #303133;
}

/* 课程卡片 */
.course-card {
  border: 1px solid #ebeef5;
  border-radius: 10px;
  overflow: hidden;
  cursor: pointer;
  transition: all 0.2s;
  margin-bottom: 16px;
}

.course-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
}

.course-cover {
  position: relative;
  height: 120px;
  overflow: hidden;
}

.course-cover img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.course-semester {
  position: absolute;
  top: 8px;
  right: 8px;
  background: rgba(0, 0, 0, 0.5);
  color: #fff;
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 12px;
}

.course-info {
  padding: 12px;
}

.course-name {
  font-size: 14px;
  font-weight: 600;
  margin: 0 0 8px;
  color: #303133;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.course-teacher {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  color: #606266;
  margin-bottom: 8px;
}

.course-progress {
  display: flex;
  justify-content: space-between;
}

.progress-text {
  font-size: 12px;
  color: #909399;
}

/* 问答链接 */
.link-text {
  color: #409eff;
  cursor: pointer;
}

.link-text:hover {
  text-decoration: underline;
}
</style>
