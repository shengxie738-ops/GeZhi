﻿<template>
  <div class="forum-view">
    <PageHeader title="课程论坛">
      <template #default>
        <el-input
          v-model="searchKeyword"
          placeholder="搜索问题..."
          :prefix-icon="Search"
          clearable
          style="width: 220px"
        />
        <el-button type="primary" :icon="Edit" @click="showPublishDialog = true">
          发布问题
        </el-button>
      </template>
    </PageHeader>

    <div class="forum-content">
      <!-- 课程选择 + 状态筛选 -->
      <div class="filter-bar">
        <el-select v-model="selectedCourseId" placeholder="选择课程" clearable style="width: 200px">
          <el-option
            v-for="course in courses"
            :key="course.id"
            :label="course.name"
            :value="course.id"
          />
        </el-select>

        <el-tabs v-model="activeTab" class="status-tabs">
          <el-tab-pane label="全部" name="all" />
          <el-tab-pane label="待回答" name="open" />
          <el-tab-pane label="已解决" name="answered" />
          <el-tab-pane label="我的提问" name="mine" />
        </el-tabs>
      </div>

      <!-- 问题列表 -->
      <div class="question-list" v-loading="loading">
        <QuestionCard
          v-for="question in filteredQuestions"
          :key="question.id"
          :question="question"
          @click="router.push(`/student/forum/${question.id}`)"
        />
        <el-empty v-if="!loading && filteredQuestions.length === 0" description="暂无问题" />
      </div>

      <Pagination
        v-if="total > 0"
        :total="total"
        :page="page"
        :page-size="pageSize"
        @change="handlePageChange"
      />
    </div>

    <!-- 发布问题对话框 -->
    <el-dialog
      v-model="showPublishDialog"
      title="发布问题"
      width="600px"
      :close-on-click-modal="false"
    >
      <el-form :model="publishForm" label-position="top">
        <el-form-item label="标题" required>
          <el-input
            v-model="publishForm.title"
            placeholder="简明扼要地描述你的问题"
            maxlength="100"
            show-word-limit
          />
        </el-form-item>
        <el-form-item label="内容" required>
          <el-input
            v-model="publishForm.content"
            type="textarea"
            :rows="8"
            placeholder="详细描述你的问题，支持Markdown格式..."
          />
        </el-form-item>
        <el-form-item label="标签">
          <div class="tags-input">
            <el-tag
              v-for="tag in publishForm.tags"
              :key="tag"
              closable
              @close="removeTag(tag)"
            >
              {{ tag }}
            </el-tag>
            <el-input
              v-model="newTag"
              size="small"
              style="width: 120px"
              placeholder="添加标签"
              @keydown.enter.prevent="addTag"
            />
          </div>
        </el-form-item>
        <el-form-item>
          <el-checkbox v-model="publishForm.isAnonymous">匿名发布</el-checkbox>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showPublishDialog = false">取消</el-button>
        <el-button type="primary" :loading="publishing" :disabled="!canPublish" @click="handlePublish">
          发布
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, watch, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { Search, Edit } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import { getCourses } from '@/api/course'
import { getQuestions, createQuestion } from '@/api/forum'
import { useAuthStore } from '@/stores/auth'
import type { Course } from '@/types/course'
import type { ForumQuestion } from '@/types/forum'
import PageHeader from '@/components/common/PageHeader.vue'
import Pagination from '@/components/common/Pagination.vue'
import QuestionCard from '@/components/forum/QuestionCard.vue'

const router = useRouter()
const authStore = useAuthStore()

const loading = ref(false)
const publishing = ref(false)
const courses = ref<Course[]>([])
const questions = ref<ForumQuestion[]>([])
const total = ref(0)
const page = ref(1)
const pageSize = ref(20)

const selectedCourseId = ref<number | undefined>()
const activeTab = ref('all')
const searchKeyword = ref('')
const showPublishDialog = ref(false)
const newTag = ref('')

const publishForm = reactive({
  title: '',
  content: '',
  tags: [] as string[],
  isAnonymous: false
})

const canPublish = computed(() => publishForm.title.trim() && publishForm.content.trim() && !!selectedCourseId.value)

const filteredQuestions = computed(() => {
  let list = questions.value
  if (searchKeyword.value.trim()) {
    const kw = searchKeyword.value.toLowerCase()
    list = list.filter(q => q.title.toLowerCase().includes(kw))
  }
  if (activeTab.value === 'mine') {
    list = list.filter(q => q.user_id === authStore.user?.id)
  }
  return list
})

async function fetchCourses() {
  try {
    const res = await getCourses({ page: 1, page_size: 100 })
    courses.value = res.data.items || []
    if (courses.value.length > 0) {
      selectedCourseId.value = courses.value[0].id
    }
  } catch { /* 忽略 */ }
}

async function fetchQuestions() {
  if (!selectedCourseId.value) {
    questions.value = []
    total.value = 0
    return
  }
  loading.value = true
  try {
    const statusFilter = activeTab.value === 'all' || activeTab.value === 'mine' ? undefined : activeTab.value
    const res = await getQuestions(selectedCourseId.value, {
      page: page.value,
      page_size: pageSize.value,
      status: statusFilter
    })
    questions.value = res.data.items || []
    total.value = res.data.total || 0
  } catch {
    // 错误已处理
  } finally {
    loading.value = false
  }
}

function handlePageChange(newPage: number, newPageSize: number) {
  page.value = newPage
  pageSize.value = newPageSize
  fetchQuestions()
}

function addTag() {
  const tag = newTag.value.trim()
  if (tag && !publishForm.tags.includes(tag)) {
    publishForm.tags.push(tag)
  }
  newTag.value = ''
}

function removeTag(tag: string) {
  publishForm.tags = publishForm.tags.filter(t => t !== tag)
}

async function handlePublish() {
  if (!canPublish.value) return
  publishing.value = true
  try {
    await createQuestion(selectedCourseId.value!, {
      title: publishForm.title.trim(),
      content: publishForm.content.trim(),
      tags: publishForm.tags,
      is_anonymous: publishForm.isAnonymous
    })
    ElMessage.success('发布成功！')
    showPublishDialog.value = false
    publishForm.title = ''
    publishForm.content = ''
    publishForm.tags = []
    publishForm.isAnonymous = false
    await fetchQuestions()
  } catch {
    // 错误已处理
  } finally {
    publishing.value = false
  }
}

watch([selectedCourseId, activeTab], () => {
  page.value = 1
  fetchQuestions()
})

onMounted(() => {
  fetchCourses()
})
</script>

<style scoped>
.forum-view {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.forum-content {
  background: #fff;
  border-radius: 10px;
  padding: 20px;
}

.filter-bar {
  display: flex;
  align-items: center;
  gap: 16px;
  margin-bottom: 16px;
  flex-wrap: wrap;
}

.status-tabs {
  flex: 1;
}

.status-tabs :deep(.el-tabs__header) {
  margin: 0;
}

.status-tabs :deep(.el-tabs__nav-wrap::after) {
  display: none;
}

.question-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.tags-input {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  align-items: center;
}
</style>
