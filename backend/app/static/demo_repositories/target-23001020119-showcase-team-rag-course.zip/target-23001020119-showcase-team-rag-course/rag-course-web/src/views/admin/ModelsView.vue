﻿<template>
  <div class="page-container">
    <PageHeader title="模型配置管理" description="管理系统级AI模型配置">
      <el-button type="primary" @click="openModelDialog()">
        <el-icon><Plus /></el-icon> 新增配置
      </el-button>
    </PageHeader>

    <el-card shadow="never">
      <div class="toolbar">
        <el-input
          v-model="searchKeyword"
          placeholder="搜索配置名或模型名"
          clearable
          style="width: 280px"
          @clear="fetchModels"
          @keyup.enter="fetchModels"
        />
      </div>

      <el-table :data="modelConfigs" v-loading="loading" stripe border>
        <el-table-column prop="name" label="配置名" width="180" />
        <el-table-column prop="provider" label="提供商" width="120">
          <template #default="{ row }">
            <el-tag size="small">{{ row.provider }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="model_id" label="模型名" width="200" />
        <el-table-column prop="api_key" label="API Key" width="180">
          <template #default="{ row }">
            <span class="api-key-masked">{{ maskApiKey(row.api_key) }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="base_url" label="Base URL" min-width="220" show-overflow-tooltip />
        <el-table-column label="Temperature" width="110" align="center">
          <template #default="{ row }">{{ row.temperature }}</template>
        </el-table-column>
        <el-table-column label="Max Tokens" width="110" align="center">
          <template #default="{ row }">{{ row.max_tokens }}</template>
        </el-table-column>
        <el-table-column label="启用" width="80" align="center">
          <template #default="{ row }">
            <el-switch :model-value="row.is_active" size="small" @change="(val: boolean) => toggleModel(row, val)" />
          </template>
        </el-table-column>
        <el-table-column label="默认" width="80" align="center">
          <template #default="{ row }">
            <el-tag v-if="row.is_default" size="small" type="success">默认</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="220" fixed="right">
          <template #default="{ row }">
            <el-button type="primary" link size="small" @click="openModelDialog(row)">编辑</el-button>
            <el-button type="success" link size="small" @click="handleTest(row)" :loading="testingId === row.id">
              测试
            </el-button>
            <el-popconfirm title="确定删除？" @confirm="handleDelete(row)">
              <template #reference>
                <el-button type="danger" link size="small">删除</el-button>
              </template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>

      <Pagination
        v-model:page="pagination.page"
        v-model:page-size="pagination.pageSize"
        :total="pagination.total"
        @change="fetchModels"
      />

      <el-alert
        v-if="testResult"
        :title="testResult.success ? '测试成功' : '测试失败'"
        :type="testResult.success ? 'success' : 'error'"
        show-icon
        :description="testResult.success
          ? `延迟: ${testResult.latency_ms}ms, Token: ${testResult.token_count}, 回复: ${testResult.response}`
          : testResult.error"
        style="margin-top: 16px"
        closable
        @close="testResult = null"
      />
    </el-card>

    <!-- 模型配置对话框 -->
    <el-dialog
      v-model="dialogVisible"
      :title="editingModel ? '编辑模型配置' : '新增模型配置'"
      width="600px"
      :close-on-click-modal="false"
    >
      <el-alert
        title="API Key 将加密存储在数据库中"
        type="info"
        show-icon
        :closable="false"
        style="margin-bottom: 16px"
      />
      <el-form :model="modelForm" label-width="100px">
        <el-form-item label="配置名" required>
          <el-input v-model="modelForm.name" placeholder="配置名称" />
        </el-form-item>
        <el-form-item label="提供商" required>
          <el-select v-model="modelForm.provider" style="width: 100%">
            <el-option label="OpenAI" value="openai" />
            <el-option label="Azure OpenAI" value="azure" />
            <el-option label="百度文心" value="baidu" />
            <el-option label="阿里通义" value="alibaba" />
            <el-option label="本地模型" value="local" />
            <el-option label="其他" value="other" />
          </el-select>
        </el-form-item>
        <el-form-item label="模型名" required>
          <el-input v-model="modelForm.model_id" placeholder="如：gpt-4o" />
        </el-form-item>
        <el-form-item label="API Key" required>
          <el-input v-model="modelForm.api_key" show-password placeholder="sk-..." />
        </el-form-item>
        <el-form-item label="Base URL">
          <el-input v-model="modelForm.base_url" placeholder="https://api.openai.com/v1" />
        </el-form-item>
        <el-form-item label="Temperature">
          <el-slider v-model="modelForm.temperature" :min="0" :max="2" :step="0.1" show-input />
        </el-form-item>
        <el-form-item label="Max Tokens">
          <el-input-number v-model="modelForm.max_tokens" :min="256" :max="16384" :step="256" />
        </el-form-item>
        <el-form-item label="设为默认">
          <el-switch v-model="modelForm.is_default" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="submitLoading" @click="handleSubmit">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { Plus } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import PageHeader from '@/components/common/PageHeader.vue'
import Pagination from '@/components/common/Pagination.vue'
import * as modelConfigApi from '@/api/modelConfig'
import type { ModelConfig, ModelTestResponse } from '@/types/model'

const loading = ref(false)
const modelConfigs = ref<ModelConfig[]>([])
const searchKeyword = ref('')
const pagination = reactive({ page: 1, pageSize: 15, total: 0 })

const dialogVisible = ref(false)
const editingModel = ref<ModelConfig | null>(null)
const submitLoading = ref(false)
const testingId = ref<number | null>(null)
const testResult = ref<ModelTestResponse | null>(null)

const modelForm = reactive({
  name: '', provider: '', model_id: '', api_key: '', base_url: '',
  temperature: 0.7, max_tokens: 4096, is_default: false
})

function maskApiKey(key: string) {
  if (!key || key.length < 8) return '****'
  return key.slice(0, 4) + '****' + key.slice(-4)
}

async function fetchModels() {
  loading.value = true
  try {
    const res = await modelConfigApi.getModelConfigs({
      page: pagination.page, page_size: pagination.pageSize,
      keyword: searchKeyword.value || undefined
    })
    modelConfigs.value = res.data.items
    pagination.total = res.data.total
  } catch { /* handled */ }
  finally { loading.value = false }
}

function openModelDialog(model?: ModelConfig) {
  testResult.value = null
  if (model) {
    editingModel.value = model
    Object.assign(modelForm, {
      name: model.name, provider: model.provider, model_id: model.model_id,
      api_key: model.api_key, base_url: model.base_url, temperature: model.temperature,
      max_tokens: model.max_tokens, is_default: model.is_default
    })
  } else {
    editingModel.value = null
    Object.assign(modelForm, {
      name: '', provider: '', model_id: '', api_key: '', base_url: '',
      temperature: 0.7, max_tokens: 4096, is_default: false
    })
  }
  dialogVisible.value = true
}

async function handleSubmit() {
  if (!modelForm.name || !modelForm.provider || !modelForm.model_id) {
    ElMessage.warning('请填写必要字段')
    return
  }
  submitLoading.value = true
  try {
    if (editingModel.value) {
      await modelConfigApi.updateModelConfig(editingModel.value.id, { ...modelForm })
      ElMessage.success('已更新')
    } else {
      await modelConfigApi.createModelConfig({ ...modelForm })
      ElMessage.success('已创建')
    }
    dialogVisible.value = false
    fetchModels()
  } finally { submitLoading.value = false }
}

async function handleDelete(model: ModelConfig) {
  await modelConfigApi.deleteModelConfig(model.id)
  ElMessage.success('已删除')
  fetchModels()
}

async function toggleModel(model: ModelConfig, active: boolean) {
  await modelConfigApi.updateModelConfig(model.id, { is_active: active })
  model.is_active = active
  ElMessage.success(active ? '已启用' : '已停用')
}

async function handleTest(model: ModelConfig) {
  testingId.value = model.id
  testResult.value = null
  try {
    const res = await modelConfigApi.testModel({ model_id: model.id, prompt: '请回复OK' })
    testResult.value = res.data
  } catch {
    testResult.value = { success: false, response: '', latency_ms: 0, token_count: 0, error: '测试失败' }
  } finally { testingId.value = null }
}

onMounted(() => { fetchModels() })
</script>

<style scoped>
.toolbar { display: flex; gap: 12px; margin-bottom: 16px; }
.api-key-masked { font-family: monospace; color: #909399; font-size: 13px; }
</style>
