<template>
  <div class="answer-card" :class="{ 'is-accepted': answer.is_accepted, 'is-verified': answer.is_verified }">
    <div v-if="answer.is_accepted" class="accepted-badge">
      <el-icon><CircleCheck /></el-icon>
      最佳答案
    </div>

    <div class="answer-header">
      <div class="answer-author">
        <el-avatar :size="32" :src="answer.user?.avatar">
          {{ answer.user?.nickname?.charAt(0) }}
        </el-avatar>
        <div class="author-info">
          <span class="author-name">{{ answer.user?.nickname }}</span>
          <span class="answer-time">{{ formatRelativeTime(answer.created_at) }}</span>
        </div>
        <el-tag v-if="answer.is_verified" type="success" size="small" effect="dark">
          教师认证
        </el-tag>
      </div>
    </div>

    <div class="answer-content">
      <MarkdownRenderer :content="answer.content" />
    </div>

    <div class="answer-footer">
      <el-button
        text
        :type="liked ? 'primary' : ''"
        @click="$emit('like')"
      >
        <el-icon><Star /></el-icon>
        <span>{{ answer.like_count }} 点赞</span>
      </el-button>

      <el-button
        v-if="showAccept"
        text
        type="success"
        @click="$emit('accept')"
      >
        <el-icon><CircleCheck /></el-icon>
        <span>采纳</span>
      </el-button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { CircleCheck, Star } from '@element-plus/icons-vue'
import type { ForumAnswer } from '@/types/forum'
import { formatRelativeTime } from '@/utils/format'
import MarkdownRenderer from '@/components/common/MarkdownRenderer.vue'

defineProps<{
  answer: ForumAnswer
  showAccept?: boolean
  liked?: boolean
}>()

defineEmits<{
  like: []
  accept: []
}>()
</script>

<style scoped>
.answer-card {
  padding: 16px;
  border: 1px solid #ebeef5;
  border-radius: 8px;
  background: #fff;
  transition: box-shadow 0.2s;
}

.answer-card:hover {
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
}

.answer-card.is-accepted {
  border-color: #67c23a;
  background: #f0f9eb;
}

.answer-card.is-verified {
  border-color: #409eff;
  background: #f0f7ff;
}

.accepted-badge {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 13px;
  font-weight: 600;
  color: #67c23a;
  margin-bottom: 10px;
}

.answer-header {
  margin-bottom: 12px;
}

.answer-author {
  display: flex;
  align-items: center;
  gap: 10px;
}

.author-info {
  display: flex;
  flex-direction: column;
}

.author-name {
  font-size: 14px;
  font-weight: 600;
  color: #303133;
}

.answer-time {
  font-size: 12px;
  color: #909399;
}

.answer-content {
  line-height: 1.7;
  margin-bottom: 12px;
}

.answer-footer {
  display: flex;
  align-items: center;
  gap: 8px;
  padding-top: 10px;
  border-top: 1px solid #f2f3f5;
}
</style>
