﻿<template>
  <div class="chat-view">
    <!-- 左侧会话列表 -->
    <div class="chat-sidebar">
      <SessionList
        :sessions="chatStore.sortedSessions"
        :active-session-id="chatStore.currentSessionId"
        :loading="loadingSessions"
        @select="handleSelectSession"
        @new-session="handleNewSession"
        @delete="handleDeleteSession"
      />
    </div>

    <!-- 右侧对话区域 -->
    <div class="chat-main">
      <!-- 无会话时的引导 -->
      <div v-if="!chatStore.currentSessionId" class="chat-empty">
        <el-empty description="选择或新建一个会话开始对话">
          <el-button type="primary" @click="handleNewSession">新建会话</el-button>
        </el-empty>
      </div>

      <!-- 对话区域 -->
      <template v-else>
        <!-- 消息列表 -->
        <div class="messages-wrapper" ref="messagesWrapper">
          <div class="messages-list">
            <ChatMessage
              v-for="msg in chatStore.messages"
              :key="msg.id"
              :message="msg"
              @feedback="handleFeedback(msg, $event)"
            />

            <!-- 流式消息 -->
            <ChatMessage
              v-if="chatStore.currentStatus === 'streaming'"
              :message="streamingMessage"
              :streaming-content="chatStore.streamingContent"
              :is-streaming="true"
            />

            <!-- 空会话提示 -->
            <div v-if="chatStore.messages.length === 0 && chatStore.currentStatus !== 'streaming'" class="empty-chat">
              <div class="empty-icon">
                <el-icon :size="48"><ChatDotRound /></el-icon>
              </div>
              <p>输入你的问题，AI助教会基于课程知识库为你解答</p>
            </div>
          </div>
        </div>

        <!-- 输入区 -->
        <ChatInput
          ref="chatInputRef"
          :disabled="chatStore.currentStatus === 'streaming'"
          @send="handleSend"
        />
      </template>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, watch, nextTick } from 'vue'
import { useRoute } from 'vue-router'
import { ChatDotRound } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import { useChatStore } from '@/stores/chat'
import { getCourses } from '@/api/course'
import { askStream } from '@/api/rag'
import type { ChatSession, ChatMessage as ChatMsgType, FeedbackType } from '@/types/chat'
import type { Course } from '@/types/course'
import SessionList from '@/components/chat/SessionList.vue'
import ChatMessage from '@/components/chat/ChatMessage.vue'
import ChatInput from '@/components/chat/ChatInput.vue'

const route = useRoute()
const chatStore = useChatStore()

const loadingSessions = ref(false)
const messagesWrapper = ref<HTMLElement>()
const chatInputRef = ref<InstanceType<typeof ChatInput>>()
const courses = ref<Course[]>([])

const streamingMessage = computed<ChatMsgType>(() => ({
  id: 0,
  session_id: chatStore.currentSessionId || 0,
  role: 'assistant',
  content: '',
  citations: [],
  feedback: null,
  status: 'streaming',
  token_count: 0,
  model_used: '',
  latency_ms: 0,
  created_at: new Date().toISOString()
}))

async function fetchCourses() {
  try {
    const res = await getCourses({ page: 1, page_size: 100 })
    courses.value = res.data.items || []
  } catch { /* 忽略 */ }
}

function scrollToBottom() {
  nextTick(() => {
    if (messagesWrapper.value) {
      messagesWrapper.value.scrollTop = messagesWrapper.value.scrollHeight
    }
  })
}

function handleSelectSession(session: ChatSession) {
  chatStore.setCurrentSession(session.id)
  chatStore.clearMessages()
}

function handleNewSession() {
  chatStore.setCurrentSession(null)
  chatStore.clearMessages()
}

function handleDeleteSession(session: ChatSession) {
  chatStore.removeSession(session.id)
  ElMessage.success('会话已删除')
}

async function handleSend(text: string) {
  // 添加用户消息
  const userMsg: ChatMsgType = {
    id: Date.now(),
    session_id: chatStore.currentSessionId || 0,
    role: 'user',
    content: text,
    citations: [],
    feedback: null,
    status: 'completed',
    token_count: 0,
    model_used: '',
    latency_ms: 0,
    created_at: new Date().toISOString()
  }
  chatStore.appendMessage(userMsg)
  scrollToBottom()

  // 开始流式回答
  chatStore.startStreaming()
  scrollToBottom()

  const courseId = courses.value.length > 0 ? courses.value[0].id : 1

  askStream(
    {
      question: text,
      course_id: courseId,
      session_id: chatStore.currentSessionId || undefined,
      top_k: 5
    },
    {
      onToken(token) {
        chatStore.appendStreamToken(token)
        scrollToBottom()
      },
      onCitation(citations) {
        chatStore.setStreamCitations(citations)
      },
      onDone(response) {
        const assistantMsg: ChatMsgType = {
          id: response.message_id,
          session_id: response.session_id,
          role: 'assistant',
          content: response.answer,
          citations: response.citations,
          feedback: null,
          status: 'completed',
          token_count: response.token_count,
          model_used: response.model_used,
          latency_ms: response.latency_ms,
          created_at: new Date().toISOString()
        }
        chatStore.finishStreaming(assistantMsg)
        scrollToBottom()
      },
      onError(error) {
        chatStore.setError()
        ElMessage.error(error || '回答生成失败')
      }
    }
  )
}

function handleFeedback(msg: ChatMsgType, type: string) {
  chatStore.updateMessage(msg.id, { feedback: type as FeedbackType })
}

// 监听路由变化
watch(() => route.params.sessionId, (sessionId) => {
  if (sessionId) {
    chatStore.setCurrentSession(Number(sessionId))
  }
}, { immediate: true })

onMounted(() => {
  fetchCourses()
  if (route.params.sessionId) {
    chatStore.setCurrentSession(Number(route.params.sessionId))
  }
})
</script>

<style scoped>
.chat-view {
  display: flex;
  height: calc(100vh - 100px);
  background: #fff;
  border-radius: 10px;
  overflow: hidden;
}

/* 左侧边栏 */
.chat-sidebar {
  width: 280px;
  border-right: 1px solid #ebeef5;
  flex-shrink: 0;
}

/* 右侧对话 */
.chat-main {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-width: 0;
}

.chat-empty {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
}

.messages-wrapper {
  flex: 1;
  overflow-y: auto;
  padding: 20px;
}

.messages-list {
  max-width: 800px;
  margin: 0 auto;
}

.empty-chat {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 80px 0;
  color: #909399;
}

.empty-icon {
  margin-bottom: 16px;
  color: #dcdfe6;
}

.empty-chat p {
  font-size: 14px;
}
</style>
