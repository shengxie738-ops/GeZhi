﻿<template>
  <div class="page-container">
    <PageHeader title="系统管理仪表板" description="系统运行概览与状态监控" />

    <!-- 系统概览卡片 -->
    <el-row :gutter="20" class="stat-row">
      <el-col :xs="12" :sm="6">
        <div class="stat-card stat-card--blue">
          <div class="stat-card-value">{{ systemStats.userCount }}</div>
          <div class="stat-card-label">总用户数</div>
        </div>
      </el-col>
      <el-col :xs="12" :sm="6">
        <div class="stat-card stat-card--green">
          <div class="stat-card-value">{{ systemStats.courseCount }}</div>
          <div class="stat-card-label">总课程数</div>
        </div>
      </el-col>
      <el-col :xs="12" :sm="6">
        <div class="stat-card stat-card--orange">
          <div class="stat-card-value">{{ systemStats.docCount }}</div>
          <div class="stat-card-label">总文档数</div>
        </div>
      </el-col>
      <el-col :xs="12" :sm="6">
        <div class="stat-card stat-card--red">
          <div class="stat-card-value">{{ systemStats.questionCount }}</div>
          <div class="stat-card-label">总问答数</div>
        </div>
      </el-col>
    </el-row>

    <el-row :gutter="20" class="main-row">
      <!-- 资源使用概览 -->
      <el-col :xs="24" :sm="8">
        <el-card shadow="never" class="section-card">
          <template #header><span class="card-title">资源使用概览</span></template>
          <div class="resource-list">
            <div class="resource-item">
              <div class="resource-header">
                <span>存储使用量</span>
                <span class="resource-value">{{ storageUsed }}</span>
              </div>
              <el-progress :percentage="storagePercent" :stroke-width="8" />
            </div>
            <div class="resource-item">
              <div class="resource-header">
                <span>向量库大小</span>
                <span class="resource-value">{{ vectorDbSize }}</span>
              </div>
              <el-progress :percentage="vectorPercent" :stroke-width="8" status="warning" />
            </div>
            <div class="resource-item">
              <div class="resource-header">
                <span>CPU 使用率</span>
                <span class="resource-value">35%</span>
              </div>
              <el-progress :percentage="35" :stroke-width="8" status="success" />
            </div>
            <div class="resource-item">
              <div class="resource-header">
                <span>内存使用率</span>
                <span class="resource-value">62%</span>
              </div>
              <el-progress :percentage="62" :stroke-width="8" status="warning" />
            </div>
          </div>
        </el-card>
      </el-col>

      <!-- 系统服务状态 -->
      <el-col :xs="24" :sm="8">
        <el-card shadow="never" class="section-card">
          <template #header><span class="card-title">系统服务状态</span></template>
          <el-table :data="services" size="small" stripe>
            <el-table-column prop="name" label="服务" min-width="120" />
            <el-table-column prop="description" label="说明" min-width="140" show-overflow-tooltip />
            <el-table-column label="状态" width="80" align="center">
              <template #default="{ row }">
                <el-tag
                  :type="row.status === 'healthy' ? 'success' : row.status === 'warning' ? 'warning' : 'danger'"
                  size="small"
                >
                  {{ row.status === 'healthy' ? '正常' : row.status === 'warning' ? '警告' : '异常' }}
                </el-tag>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>

      <!-- 最近活动日志 -->
      <el-col :xs="24" :sm="8">
        <el-card shadow="never" class="section-card">
          <template #header>
            <div class="card-header">
              <span class="card-title">最近活动日志</span>
              <el-button type="primary" link @click="$router.push('/admin/logs')">查看全部</el-button>
            </div>
          </template>
          <el-table :data="recentLogs" size="small" stripe>
            <el-table-column prop="action" label="操作" min-width="200" show-overflow-tooltip />
            <el-table-column prop="user" label="用户" width="80" />
            <el-table-column prop="time" label="时间" width="100" />
          </el-table>
          <el-empty v-if="recentLogs.length === 0" description="暂无日志" :image-size="60" />
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue'
import PageHeader from '@/components/common/PageHeader.vue'

const systemStats = reactive({
  userCount: 256,
  courseCount: 12,
  docCount: 1843,
  questionCount: 8934
})

const storageUsed = ref('12.8 GB / 50 GB')
const storagePercent = ref(25.6)
const vectorDbSize = ref('3.2 GB')
const vectorPercent = ref(64)

const services = ref([
  { name: 'API 服务', description: '后端 RESTful API', status: 'healthy' },
  { name: 'MinIO 存储', description: '对象存储服务', status: 'healthy' },
  { name: 'Qdrant 向量库', description: '向量检索引擎', status: 'healthy' },
  { name: 'PostgreSQL', description: '关系型数据库', status: 'healthy' },
  { name: 'Redis 缓存', description: '缓存与会话存储', status: 'warning' },
  { name: 'Celery Worker', description: '异步任务队列', status: 'healthy' }
])

const recentLogs = ref([
  { id: 1, action: '用户 张三 登录系统', user: '张三', time: '2分钟前' },
  { id: 2, action: '文档 "AI基础课件" 上传成功', user: '李老师', time: '10分钟前' },
  { id: 3, action: '模型配置 GPT-4o 测试通过', user: '管理员', time: '30分钟前' },
  { id: 4, action: '文档 "习题集3" 解析失败', user: '系统', time: '1小时前' },
  { id: 5, action: '用户 王五 加入课程', user: '王五', time: '2小时前' }
])
</script>

<style scoped>
.stat-row {
  margin-bottom: 20px;
}

.main-row {
  margin-bottom: 20px;
}

.section-card {
  border-radius: 8px;
  height: 100%;
}

.card-title {
  font-size: 16px;
  font-weight: 600;
  color: #303133;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

/* 统计卡片 */
.stat-card {
  padding: 20px;
  background: #fff;
  border-radius: 10px;
  border-left: 4px solid;
  transition: box-shadow 0.2s;
}

.stat-card:hover {
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
}

.stat-card--blue { border-color: #409eff; }
.stat-card--green { border-color: #67c23a; }
.stat-card--orange { border-color: #e6a23c; }
.stat-card--red { border-color: #f56c6c; }

.stat-card-value {
  font-size: 24px;
  font-weight: 700;
  color: #303133;
}

.stat-card-label {
  font-size: 13px;
  color: #909399;
  margin-top: 4px;
}

/* 资源列表 */
.resource-list {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.resource-item {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.resource-header {
  display: flex;
  justify-content: space-between;
  font-size: 14px;
  color: #606266;
}

.resource-value {
  font-weight: 600;
  color: #303133;
}
</style>
