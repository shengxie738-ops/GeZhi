import type { User } from './user'

/** 文档解析状态 */
export type ParseStatus = 'pending' | 'parsing' | 'parsed' | 'failed' | 'indexing' | 'indexed' | 'reindexing'

/** 文档信息 */
export interface Document {
  id: number
  course_id: number
  title: string
  filename: string
  file_path: string
  file_size: number
  file_type: string
  mime_type: string
  parse_status: ParseStatus
  parse_error: string | null
  chunk_count: number
  content_hash: string
  metadata: Record<string, any>
  uploaded_by: number
  uploader: User
  created_at: string
  updated_at: string
  parsed_at: string | null
  indexed_at: string | null
}

/** 文档分块 */
export interface Chunk {
  id: number
  document_id: number
  content: string
  chunk_index: number
  start_page: number | null
  end_page: number | null
  token_count: number
  enabled: boolean
  metadata: Record<string, any>
  embedding_id: string | null
  created_at: string
  updated_at: string
}

/** 向量化任务 */
export interface IngestJob {
  id: number
  document_id: number
  document: Document
  status: 'pending' | 'running' | 'completed' | 'failed'
  progress: number
  total_chunks: number
  processed_chunks: number
  error_message: string | null
  started_at: string | null
  completed_at: string | null
  created_at: string
}

/** 更新分块请求 */
export interface UpdateChunkRequest {
  content?: string
  enabled?: boolean
  metadata?: Record<string, any>
}
