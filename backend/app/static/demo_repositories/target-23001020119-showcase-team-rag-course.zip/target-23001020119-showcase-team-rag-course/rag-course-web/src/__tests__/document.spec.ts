import { describe, it, expect, vi, beforeEach } from 'vitest'
import { mount } from '@vue/test-utils'
import { createTestingPinia } from '@pinia/testing'
import { createRouter, createWebHistory } from 'vue-router'
import ElementPlus from 'element-plus'
import DocumentStatusBadge from '@/components/knowledge/DocumentStatusBadge.vue'
import ChunkTable from '@/components/document/ChunkTable.vue'
import FileUpload from '@/components/common/FileUpload.vue'
import type { Document, Chunk, ParseStatus } from '@/types/document'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/', component: { template: '<div />' } }
  ]
})

describe('DocumentStatusBadge 组件', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  it('渲染待上传状态', () => {
    const wrapper = mount(DocumentStatusBadge, {
      props: { status: 'pending' as ParseStatus },
      global: { plugins: [ElementPlus] }
    })

    expect(wrapper.text()).toContain('待上传')
  })

  it('渲染解析中状态', () => {
    const wrapper = mount(DocumentStatusBadge, {
      props: { status: 'parsing' as ParseStatus, progress: 45 },
      global: { plugins: [ElementPlus] }
    })

    expect(wrapper.text()).toContain('解析中')
    // 应该显示进度条
    expect(wrapper.find('.el-progress').exists()).toBe(true)
  })

  it('渲染已索引状态', () => {
    const wrapper = mount(DocumentStatusBadge, {
      props: { status: 'indexed' as ParseStatus },
      global: { plugins: [ElementPlus] }
    })

    expect(wrapper.text()).toContain('已索引')
  })

  it('渲染失败状态', () => {
    const wrapper = mount(DocumentStatusBadge, {
      props: { status: 'failed' as ParseStatus },
      global: { plugins: [ElementPlus] }
    })

    expect(wrapper.text()).toContain('解析失败')
  })

  it('非处理中状态不显示进度条', () => {
    const wrapper = mount(DocumentStatusBadge, {
      props: { status: 'indexed' as ParseStatus, progress: 100 },
      global: { plugins: [ElementPlus] }
    })

    expect(wrapper.find('.el-progress').exists()).toBe(false)
  })
})

describe('文档列表结构', () => {
  it('文档列表页面结构', () => {
    const mockDocuments: Document[] = [
      {
        id: 1,
        course_id: 1001,
        title: 'RAG 课程讲义',
        filename: 'rag-lecture.pdf',
        file_path: '/uploads/rag-lecture.pdf',
        file_size: 1024000,
        file_type: 'pdf',
        mime_type: 'application/pdf',
        parse_status: 'indexed',
        parse_error: null,
        chunk_count: 45,
        content_hash: 'abc123',
        metadata: {},
        uploaded_by: 1,
        uploader: { id: 1, username: 'teacher', nickname: '张老师', role: 'teacher' } as any,
        created_at: '2025-01-15 10:00:00',
        updated_at: '2025-01-15 12:00:00',
        parsed_at: '2025-01-15 10:05:00',
        indexed_at: '2025-01-15 10:06:00'
      }
    ]

    // 验证文档对象结构
    expect(mockDocuments[0].title).toBe('RAG 课程讲义')
    expect(mockDocuments[0].parse_status).toBe('indexed')
    expect(mockDocuments[0].chunk_count).toBe(45)
    expect(mockDocuments[0].file_type).toBe('pdf')
  })
})

describe('上传对话框结构', () => {
  it('文件上传组件结构', () => {
    const wrapper = mount(
      {
        template: `
          <el-dialog v-model="visible" title="上传文档" width="500px">
            <el-upload
              drag
              :auto-upload="false"
              accept=".pdf,.docx,.md,.txt"
            >
              <el-icon class="el-icon--upload"><UploadFilled /></el-icon>
              <div class="el-upload__text">
                拖拽文件到此或 <em>点击上传</em>
              </div>
              <template #tip>
                <div class="el-upload__tip">
                  支持 PDF、DOCX、Markdown、TXT 格式，单文件最大 50MB
                </div>
              </template>
            </el-upload>
            <template #footer>
              <el-button @click="visible = false">取消</el-button>
              <el-button type="primary">开始上传</el-button>
            </template>
          </el-dialog>
        `,
        setup() {
          const visible = ref(true)
          return { visible }
        }
      },
      {
        global: {
          plugins: [ElementPlus, router]
        }
      }
    )

    // 检查上传对话框
    expect(wrapper.find('.el-dialog').exists()).toBe(true)
    expect(wrapper.text()).toContain('上传文档')
    expect(wrapper.text()).toContain('拖拽文件到此')
    expect(wrapper.text()).toContain('点击上传')
    expect(wrapper.text()).toContain('支持 PDF、DOCX、Markdown、TXT 格式')
  })
})
