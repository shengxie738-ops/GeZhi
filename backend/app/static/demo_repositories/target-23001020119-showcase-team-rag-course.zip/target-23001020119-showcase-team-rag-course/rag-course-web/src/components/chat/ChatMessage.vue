<template>
  <div class="chat-message" :class="[`chat-message--${message.role}`, { 'chat-message--streaming': isStreaming }]">
    <div class="message-avatar">
      <el-avatar v-if="message.role === 'user'" :size="36" :src="authStore.avatar">
        {{ authStore.nickname?.charAt(0) }}
      </el-avatar>
      <el-avatar v-else :size="36" class="ai-avatar">
        <el-icon :size="20"><Monitor /></el-icon>
      </el-avatar>
    </div>

    <div class="message-body">
      <div class="message-header">
        <span class="message-role">{{ message.role === 'user' ? authStore.nickname : 'AI 助教' }}</span>
        <span class="message-time">{{ formatRelativeTime(message.created_at) }}</span>
      </div>

      <div class="message-content">
        <MarkdownRenderer v-if="message.role === 'assistant'" :content="displayContent" />
        <div v-else class="plain-text">{{ displayContent }}</div>

        <!-- 流式打字光标 -->
        <span v-if="isStreaming" class="typing-cursor">|</span>
      </div>

      <!-- 引用来源 -->
      <div v-if="message.role === 'assistant' && message.citations?.length" class="message-citations">
        <div class="citations-header">
          <el-icon><Link /></el-icon>
          <span>引用来源 ({{ message.citations.length }})</span>
        </div>
        <div class="citations-list">
          <CitationCard
            v-for="(citation, index) in message.citations"
            :key="index"
            :citation="citation"
          />
        </div>
      </div>

      <!-- 证据不足提示 -->
      <div v-if="message.role === 'assistant' && showInsufficientEvidence" class="insufficient-evidence">
        <el-alert
          title="证据不足提示"
          description="当前回答可能缺乏足够的知识库支撑，建议通过论坛向教师提问获取更准确的答案。"
          type="warning"
          :closable="false"
          show-icon
        />
      </div>

      <!-- 反馈按钮 -->
      <div v-if="message.role === 'assistant' && !isStreaming && message.id" class="message-actions">
        <el-tooltip content="有用" placement="top">
          <el-button
            :type="message.feedback === 'like' ? 'primary' : ''"
            :icon="Check"
            circle
            size="small"
            @click="$emit('feedback', 'like')"
          />
        </el-tooltip>
        <el-tooltip content="没用" placement="top">
          <el-button
            :type="message.feedback === 'dislike' ? 'danger' : ''"
            :icon="Close"
            circle
            size="small"
            @click="$emit('feedback', 'dislike')"
          />
        </el-tooltip>
        <el-tooltip content="标记未解决" placement="top">
          <el-button
            :type="message.feedback === 'not_helpful' ? 'warning' : ''"
            :icon="Warning"
            circle
            size="small"
            @click="$emit('feedback', 'not_helpful')"
          />
        </el-tooltip>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { Monitor, Link, Check, Close, Warning } from '@element-plus/icons-vue'
import type { ChatMessage } from '@/types/chat'
import { useAuthStore } from '@/stores/auth'
import { formatRelativeTime } from '@/utils/format'
import MarkdownRenderer from '@/components/common/MarkdownRenderer.vue'
import CitationCard from './CitationCard.vue'

const props = defineProps<{
  message: ChatMessage
  streamingContent?: string
  isStreaming?: boolean
}>()

defineEmits<{
  feedback: [type: string]
}>()

const authStore = useAuthStore()

const displayContent = computed(() => {
  if (props.isStreaming && props.streamingContent) {
    return props.streamingContent
  }
  return props.message.content
})

const showInsufficientEvidence = computed(() => {
  if (props.isStreaming || !props.streamingContent) return false
  const content = props.message.content || ''
  return content.includes('证据不足') || content.includes('无法找到') || content.includes('建议咨询')
})
</script>

<style scoped>
.chat-message {
  display: flex;
  gap: 12px;
  padding: 16px 0;
}

.chat-message--user {
  flex-direction: row-reverse;
}

.message-avatar {
  flex-shrink: 0;
}

.ai-avatar {
  background: linear-gradient(135deg, #409eff, #66b1ff);
  color: #fff;
}

.chat-message--user .message-body {
  align-items: flex-end;
}

.message-body {
  max-width: 70%;
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.message-header {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
}

.chat-message--user .message-header {
  flex-direction: row-reverse;
}

.message-role {
  font-weight: 600;
  color: #303133;
}

.message-time {
  color: #909399;
}

.message-content {
  background: #f4f4f5;
  padding: 12px 16px;
  border-radius: 12px;
  line-height: 1.6;
  position: relative;
}

.chat-message--user .message-content {
  background: #409eff;
  color: #fff;
  border-top-right-radius: 4px;
}

.chat-message--assistant .message-content {
  border-top-left-radius: 4px;
}

.plain-text {
  white-space: pre-wrap;
  word-break: break-word;
}

.typing-cursor {
  display: inline-block;
  animation: blink 1s infinite;
  font-weight: bold;
  margin-left: 2px;
}

@keyframes blink {
  0%, 50% { opacity: 1; }
  51%, 100% { opacity: 0; }
}

.message-citations {
  margin-top: 8px;
}

.citations-header {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  color: #909399;
  margin-bottom: 6px;
}

.citations-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.insufficient-evidence {
  margin-top: 8px;
}

.message-actions {
  display: flex;
  gap: 4px;
  margin-top: 4px;
}

.chat-message--user .message-actions {
  justify-content: flex-end;
}
</style>
