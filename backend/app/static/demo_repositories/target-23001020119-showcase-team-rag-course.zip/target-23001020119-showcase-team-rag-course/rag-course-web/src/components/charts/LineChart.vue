<template>
  <div ref="chartRef" class="line-chart"></div>
</template>

<script setup lang="ts">
import { ref, watch, onMounted, onBeforeUnmount, shallowRef } from 'vue'
import * as echarts from 'echarts'
import type { EChartsOption } from 'echarts'

interface SeriesData {
  name: string
  data: number[]
  color?: string
  smooth?: boolean
  areaStyle?: boolean
}

const props = withDefaults(
  defineProps<{
    title?: string
    xAxis: string[]
    series: SeriesData[]
    smooth?: boolean
    areaStyle?: boolean
    height?: string
  }>(),
  {
    title: '',
    smooth: true,
    areaStyle: false,
    height: '300px'
  }
)

const chartRef = ref<HTMLElement>()
const chart = shallowRef<echarts.ECharts>()

function initChart() {
  if (!chartRef.value) return
  chart.value = echarts.init(chartRef.value)
  updateChart()

  const observer = new ResizeObserver(() => {
    chart.value?.resize()
  })
  observer.observe(chartRef.value)
}

function updateChart() {
  if (!chart.value) return

  const option: EChartsOption = {
    title: props.title ? { text: props.title, left: 'center' } : undefined,
    tooltip: {
      trigger: 'axis'
    },
    xAxis: {
      type: 'category',
      data: props.xAxis,
      axisLabel: {
        rotate: props.xAxis.length > 7 ? 30 : 0
      }
    },
    yAxis: {
      type: 'value'
    },
    series: props.series.map((s) => ({
      name: s.name,
      type: 'line' as const,
      data: s.data,
      smooth: s.smooth ?? props.smooth,
      areaStyle: (s.areaStyle ?? props.areaStyle) ? {} : undefined,
      itemStyle: s.color ? { color: s.color } : undefined
    })),
    legend: props.series.length > 1 ? { bottom: 0 } : undefined,
    grid: {
      left: 40,
      right: 20,
      top: props.title ? 50 : 20,
      bottom: props.series.length > 1 ? 40 : 20
    }
  }

  chart.value.setOption(option, true)
}

watch(
  () => [props.xAxis, props.series],
  () => updateChart(),
  { deep: true }
)

onMounted(() => initChart())

onBeforeUnmount(() => {
  chart.value?.dispose()
})
</script>

<style scoped>
.line-chart {
  width: 100%;
  height: v-bind(height);
}
</style>
