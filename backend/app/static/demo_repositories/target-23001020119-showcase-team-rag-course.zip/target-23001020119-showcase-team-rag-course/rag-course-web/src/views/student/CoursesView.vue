﻿<template>
  <div class="courses-view">
    <PageHeader title="我的课程">
      <template #default>
        <el-input
          v-model="searchKeyword"
          placeholder="搜索课程..."
          :prefix-icon="Search"
          clearable
          class="search-input"
        />
        <el-button type="primary" :icon="Plus" @click="showJoinDialog = true">
          加入课程
        </el-button>
      </template>
    </PageHeader>

    <!-- 课程网格 -->
    <div class="courses-grid" v-loading="loading">
      <el-row :gutter="20">
        <el-col
          :xs="24" :sm="12" :md="8"
          v-for="course in filteredCourses"
          :key="course.id"
        >
          <div class="course-card" @click="router.push(`/student/courses/${course.id}`)">
            <div class="course-cover">
              <img
                :src="`https://picsum.photos/seed/${course.id}/400/200`"
                :alt="course.name"
              />
              <div class="course-semester">{{ course.semester }}</div>
            </div>
            <div class="course-body">
              <h3 class="course-name">{{ course.name }}</h3>
              <div class="course-teacher">
                <el-avatar :size="20">{{ course.teacher?.nickname?.charAt(0) }}</el-avatar>
                <span>{{ course.teacher?.nickname }}</span>
              </div>
              <div class="course-meta">
                <span><el-icon><Document /></el-icon> {{ course.document_count }} 篇文档</span>
                <span><el-icon><User /></el-icon> {{ course.member_count }} 名同学</span>
              </div>
              <el-divider />
              <div class="course-footer">
                <span class="course-joined">加入于 {{ formatDate(course.created_at, 'YYYY-MM-DD') }}</span>
                <el-button text type="primary" size="small">查看详情</el-button>
              </div>
            </div>
          </div>
        </el-col>
      </el-row>

      <el-empty v-if="!loading && filteredCourses.length === 0" description="暂无课程">
        <el-button type="primary" @click="showJoinDialog = true">加入课程</el-button>
      </el-empty>
    </div>

    <!-- 加入课程对话框 -->
    <el-dialog
      v-model="showJoinDialog"
      title="加入课程"
      width="420px"
      :close-on-click-modal="false"
    >
      <el-form :model="joinForm" label-position="top">
        <el-form-item label="邀请码" required>
          <el-input
            v-model="joinForm.inviteCode"
            placeholder="请输入教师提供的课程邀请码"
            maxlength="20"
            clearable
          />
          <div class="form-tip">向教师获取课程邀请码后输入</div>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showJoinDialog = false">取消</el-button>
        <el-button type="primary" :loading="joining" :disabled="!joinForm.inviteCode.trim()" @click="handleJoin">
          加入
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { Search, Plus, Document, User } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import { getCourses, joinCourse } from '@/api/course'
import { formatDate } from '@/utils/format'
import type { Course } from '@/types/course'
import PageHeader from '@/components/common/PageHeader.vue'

const router = useRouter()

const loading = ref(false)
const joining = ref(false)
const courses = ref<Course[]>([])
const searchKeyword = ref('')
const showJoinDialog = ref(false)

const joinForm = reactive({
  inviteCode: ''
})

const filteredCourses = computed(() => {
  if (!searchKeyword.value.trim()) return courses.value
  const kw = searchKeyword.value.toLowerCase()
  return courses.value.filter(
    c => c.name.toLowerCase().includes(kw) || c.teacher?.nickname?.toLowerCase().includes(kw)
  )
})

async function fetchCourses() {
  loading.value = true
  try {
    const res = await getCourses({ page: 1, page_size: 100 })
    courses.value = res.data.items || []
  } catch {
    // 错误已由拦截器处理
  } finally {
    loading.value = false
  }
}

async function handleJoin() {
  if (!joinForm.inviteCode.trim()) return
  joining.value = true
  try {
    // 使用邀请码加入课程
    // 需要先通过邀请码查找课程ID，这里简化处理
    const trimmedCode = joinForm.inviteCode.trim()
    await joinCourse(0, { invite_code: trimmedCode })
    ElMessage.success('加入课程成功！')
    showJoinDialog.value = false
    joinForm.inviteCode = ''
    await fetchCourses()
  } catch {
    // 错误已由拦截器处理
  } finally {
    joining.value = false
  }
}

onMounted(() => {
  fetchCourses()
})
</script>

<style scoped>
.courses-view {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.search-input {
  width: 240px;
}

/* 课程卡片 */
.course-card {
  border: 1px solid #ebeef5;
  border-radius: 10px;
  overflow: hidden;
  cursor: pointer;
  transition: all 0.25s;
  margin-bottom: 20px;
  background: #fff;
}

.course-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
}

.course-cover {
  position: relative;
  height: 140px;
  overflow: hidden;
}

.course-cover img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.3s;
}

.course-card:hover .course-cover img {
  transform: scale(1.05);
}

.course-semester {
  position: absolute;
  top: 10px;
  right: 10px;
  background: rgba(0, 0, 0, 0.55);
  color: #fff;
  padding: 3px 10px;
  border-radius: 4px;
  font-size: 12px;
}

.course-body {
  padding: 16px;
}

.course-name {
  font-size: 15px;
  font-weight: 600;
  margin: 0 0 10px;
  color: #303133;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.course-teacher {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  color: #606266;
  margin-bottom: 10px;
}

.course-meta {
  display: flex;
  gap: 16px;
  font-size: 12px;
  color: #909399;
}

.course-meta .el-icon {
  margin-right: 2px;
}

.course-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.course-joined {
  font-size: 12px;
  color: #c0c4cc;
}

.form-tip {
  font-size: 12px;
  color: #909399;
  margin-top: 4px;
}
</style>
