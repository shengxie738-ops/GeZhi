<template>
  <el-breadcrumb separator="/" class="app-breadcrumb" v-if="breadcrumbs.length > 1">
    <el-breadcrumb-item v-for="(item, index) in breadcrumbs" :key="item.path">
      <span
        v-if="index === breadcrumbs.length - 1"
        class="no-link"
      >
        {{ item.title }}
      </span>
      <router-link v-else :to="item.path">
        {{ item.title }}
      </router-link>
    </el-breadcrumb-item>
  </el-breadcrumb>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from 'vue-router'

interface BreadcrumbItem {
  title: string
  path: string
}

const route = useRoute()

const breadcrumbs = computed<BreadcrumbItem[]>(() => {
  const matched = route.matched.filter((item) => item.meta?.title)
  const result: BreadcrumbItem[] = []

  // 根据角色添加首页
  const role = route.path.split('/')[1]
  const roleNames: Record<string, string> = {
    student: '学生端',
    teacher: '教师端',
    admin: '管理端'
  }
  if (role && roleNames[role]) {
    result.push({
      title: roleNames[role],
      path: `/${role}/dashboard`
    })
  }

  matched.forEach((item) => {
    const title = item.meta.title as string
    if (title && !result.some((r) => r.title === title)) {
      result.push({
        title,
        path: item.path || route.path
      })
    }
  })

  return result
})
</script>

<style scoped>
.app-breadcrumb {
  font-size: 14px;
}

.no-link {
  color: #999;
  font-weight: 500;
}
</style>
