import request from './request'
import type { ApiResponse } from '@/types/common'
import type {
  LoginRequest,
  LoginResponse,
  RegisterRequest,
  User,
  RefreshTokenResponse
} from '@/types/user'

/** 用户登录 */
export function login(data: LoginRequest) {
  return request.post<ApiResponse<LoginResponse>>('/auth/login', data)
}

/** 用户注册 */
export function register(data: RegisterRequest) {
  return request.post<ApiResponse<User>>('/auth/register', data)
}

/** 用户登出 */
export function logout() {
  return request.post<ApiResponse<null>>('/auth/logout')
}

/** 获取当前用户信息 */
export function getProfile() {
  return request.get<ApiResponse<User>>('/auth/profile')
}

/** 刷新Token */
export function refreshToken(refreshToken: string) {
  return request.post<ApiResponse<RefreshTokenResponse>>('/auth/refresh', {
    refresh_token: refreshToken
  })
}

/** 更新用户信息 */
export function updateProfile(data: Partial<User>) {
  return request.put<ApiResponse<User>>('/auth/profile', data)
}

/** 修改密码 */
export function changePassword(data: { old_password: string; new_password: string }) {
  return request.put<ApiResponse<null>>('/auth/password', data)
}
