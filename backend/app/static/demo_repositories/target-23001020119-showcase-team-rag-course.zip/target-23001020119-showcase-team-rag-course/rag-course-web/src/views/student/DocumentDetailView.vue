﻿<template>
  <div class="doc-detail-view" v-loading="loading">
    <PageHeader :title="document?.title || '文档详情'" :description="document?.file_type?.toUpperCase()">
      <template #default>
        <el-button @click="router.back()">返回</el-button>
      </template>
    </PageHeader>

    <template v-if="document">
      <!-- 文档元信息 -->
      <div class="meta-card">
        <el-descriptions :column="4" border size="small">
          <el-descriptions-item label="标题">{{ document.title }}</el-descriptions-item>
          <el-descriptions-item label="类型">
            <el-tag size="small">{{ document.file_type?.toUpperCase() }}</el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="大小">{{ formatFileSize(document.file_size) }}</el-descriptions-item>
          <el-descriptions-item label="状态">
            <StatusTag :value="document.parse_status" type="parse" />
          </el-descriptions-item>
          <el-descriptions-item label="上传者">{{ document.uploader?.nickname }}</el-descriptions-item>
          <el-descriptions-item label="分块数">{{ document.chunk_count }}</el-descriptions-item>
          <el-descriptions-item label="上传时间">{{ formatDate(document.created_at) }}</el-descriptions-item>
          <el-descriptions-item label="解析时间">{{ document.parsed_at ? formatDate(document.parsed_at) : '-' }}</el-descriptions-item>
        </el-descriptions>
      </div>

      <!-- 双栏布局 -->
      <div class="detail-layout">
        <!-- PDF预览 -->
        <div class="pdf-panel">
          <h3 class="panel-title">文档预览</h3>
          <PdfViewer
            v-if="document.file_type === 'pdf'"
            :url="pdfUrl"
            :page-number="targetPage"
            @page-change="handlePageChange"
          />
          <div v-else class="non-pdf-placeholder">
            <el-empty description="暂不支持在线预览该类型文件" :image-size="100" />
          </div>
        </div>

        <!-- 知识块列表 -->
        <div class="chunks-panel">
          <h3 class="panel-title">知识块列表</h3>
          <ChunkTable
            :chunks="chunks"
            :total="chunksTotal"
            :loading="loadingChunks"
            :active-chunk-id="activeChunkId"
            @select="handleChunkSelect"
            @toggle="handleChunkToggle"
            @page-change="handleChunkPageChange"
          />
        </div>
      </div>
    </template>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { getDocument, getDocumentChunks, toggleChunkEnabled } from '@/api/document'
import { formatDate, formatFileSize } from '@/utils/format'
import type { Document as DocType, Chunk } from '@/types/document'
import PageHeader from '@/components/common/PageHeader.vue'
import StatusTag from '@/components/common/StatusTag.vue'
import PdfViewer from '@/components/document/PdfViewer.vue'
import ChunkTable from '@/components/document/ChunkTable.vue'

const router = useRouter()
const route = useRoute()
const documentId = Number(route.params.documentId)

const loading = ref(false)
const loadingChunks = ref(false)
const document = ref<DocType | null>(null)
const chunks = ref<Chunk[]>([])
const chunksTotal = ref(0)
const activeChunkId = ref<number | null>(null)
const targetPage = ref<number | undefined>()

const pdfUrl = computed(() => {
  if (!document.value) return ''
  return `/api/documents/${document.value.id}/file`
})

async function fetchDocument() {
  loading.value = true
  try {
    const res = await getDocument(documentId)
    document.value = res.data
  } catch {
    // 错误已处理
  } finally {
    loading.value = false
  }
}

async function fetchChunks(pageNum = 1, size = 10) {
  loadingChunks.value = true
  try {
    const res = await getDocumentChunks(documentId, { page: pageNum, page_size: size })
    chunks.value = res.data.items || []
    chunksTotal.value = res.data.total || 0
  } catch {
    // 错误已处理
  } finally {
    loadingChunks.value = false
  }
}

function handleChunkSelect(chunk: Chunk) {
  activeChunkId.value = chunk.id
  if (chunk.start_page) {
    targetPage.value = chunk.start_page
  }
}

async function handleChunkToggle(chunk: Chunk) {
  try {
    await toggleChunkEnabled(chunk.id, chunk.enabled)
  } catch {
    // 回滚
    chunk.enabled = !chunk.enabled
  }
}

function handleChunkPageChange(query: { page: number; pageSize: number }) {
  fetchChunks(query.page, query.pageSize)
}

function handlePageChange(page: number) {
  // PDF页码变化，可以高亮对应的知识块
  const found = chunks.value.find(c => c.start_page === page)
  if (found) {
    activeChunkId.value = found.id
  }
}

onMounted(() => {
  fetchDocument()
  fetchChunks()
})
</script>

<style scoped>
.doc-detail-view {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.meta-card {
  background: #fff;
  border-radius: 10px;
  padding: 20px;
}

.detail-layout {
  display: flex;
  gap: 20px;
}

.pdf-panel {
  flex: 1;
  min-width: 0;
  background: #fff;
  border-radius: 10px;
  padding: 20px;
}

.chunks-panel {
  width: 400px;
  flex-shrink: 0;
  background: #fff;
  border-radius: 10px;
  padding: 20px;
  max-height: calc(100vh - 200px);
  overflow-y: auto;
}

.panel-title {
  font-size: 15px;
  font-weight: 600;
  margin: 0 0 16px;
  color: #303133;
}

.non-pdf-placeholder {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 400px;
}
</style>
