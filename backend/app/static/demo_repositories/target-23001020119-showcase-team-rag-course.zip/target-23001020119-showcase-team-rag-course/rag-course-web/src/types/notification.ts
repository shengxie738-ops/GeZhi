/** 通知类型 */
export type NotificationType =
  | 'system'
  | 'course_invite'
  | 'question_answered'
  | 'answer_accepted'
  | 'document_parsed'
  | 'document_failed'
  | 'job_completed'
  | 'job_failed'

/** 通知信息 */
export interface Notification {
  id: number
  user_id: number
  type: NotificationType
  title: string
  content: string
  is_read: boolean
  link: string | null
  metadata: Record<string, any>
  created_at: string
}
