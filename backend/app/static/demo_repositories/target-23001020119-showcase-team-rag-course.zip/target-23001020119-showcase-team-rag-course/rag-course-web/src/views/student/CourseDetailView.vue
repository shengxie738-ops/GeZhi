﻿﻿<template>
  <div class="course-detail-view" v-loading="loading">
    <!-- 课程信息头部 -->
    <div class="course-header" v-if="course">
      <div class="header-cover">
        <img :src="`https://picsum.photos/seed/${course.id}/600/250`" :alt="course.name" />
      </div>
      <div class="header-info">
        <div class="header-main">
          <h1 class="course-name">{{ course.name }}</h1>
          <div class="course-meta-row">
            <el-avatar :size="24">{{ course.teacher?.nickname?.charAt(0) }}</el-avatar>
            <span class="teacher-name">{{ course.teacher?.nickname }}</span>
            <el-tag size="small">{{ course.semester }}</el-tag>
            <el-tag size="small" type="info">成员 {{ course.member_count }}</el-tag>
            <el-tag size="small" type="info">文档 {{ course.document_count }}</el-tag>
          </div>
          <p class="course-desc">{{ course.description || '暂无课程描述' }}</p>
        </div>
        <div class="header-actions">
          <el-button type="primary" :icon="ChatDotRound" @click="handleQuickAsk">快速提问</el-button>
          <el-button @click="handleLeave">退出课程</el-button>
        </div>
      </div>
    </div>

    <!-- Tab切换 -->
    <div class="course-tabs">
      <el-tabs v-model="activeTab" @tab-change="handleTabChange">
        <!-- 章节列表 -->
        <el-tab-pane label="章节列表" name="chapters">
          <div class="chapters-panel" v-loading="loadingChapters">
            <el-tree
              v-if="chapters.length > 0"
              :data="chapters"
              :props="{ children: 'children', label: 'title' }"
              node-key="id"
              default-expand-all
              highlight-current
            >
              <template #default="{ node, data }">
                <div class="chapter-node">
                  <el-icon class="chapter-icon"><Document /></el-icon>
                  <span>{{ data.title }}</span>
                  <span class="chapter-order">#{{ data.order }}</span>
                </div>
              </template>
            </el-tree>
            <el-empty v-else description="暂无章节内容" />
          </div>
        </el-tab-pane>

        <!-- 知识库文档 -->
        <el-tab-pane label="知识库文档" name="documents">
          <div class="documents-panel">
            <el-table :data="documents" v-loading="loadingDocuments" stripe>
              <el-table-column label="标题" min-width="200" show-overflow-tooltip>
                <template #default="{ row }">
                  <span class="link-text" @click="router.push(`/student/documents/${row.id}`)">
                    {{ row.title }}
                  </span>
                </template>
              </el-table-column>
              <el-table-column label="类型" width="100" align="center">
                <template #default="{ row }">
                  <el-tag size="small">{{ row.file_type?.toUpperCase() }}</el-tag>
                </template>
              </el-table-column>
              <el-table-column label="大小" width="100" align="center">
                <template #default="{ row }">
                  {{ formatFileSize(row.file_size) }}
                </template>
              </el-table-column>
              <el-table-column label="状态" width="100" align="center">
                <template #default="{ row }">
                  <StatusTag :value="row.parse_status" type="parse" />
                </template>
              </el-table-column>
              <el-table-column label="上传时间" width="160">
                <template #default="{ row }">
                  {{ formatDate(row.created_at) }}
                </template>
              </el-table-column>
            </el-table>
            <el-empty v-if="!loadingDocuments && documents.length === 0" description="暂无文档" />
          </div>
        </el-tab-pane>

        <!-- 课程问答 -->
        <el-tab-pane label="课程问答" name="forum">
          <div class="forum-panel">
            <div class="forum-actions">
              <el-button type="primary" @click="showAskDialog = true">我要提问</el-button>
            </div>
            <div class="question-list">
              <QuestionCard
                v-for="question in questions"
                :key="question.id"
                :question="question"
                @click="router.push(`/student/forum/${question.id}`)"
              />
            </div>
            <el-empty v-if="!loadingQuestions && questions.length === 0" description="暂无问题" />
            <Pagination
              v-if="questionsTotal > 0"
              :total="questionsTotal"
              :page="questionPage"
              :page-size="10"
              @change="handleQuestionPageChange"
            />
          </div>
        </el-tab-pane>
      </el-tabs>
    </div>

    <!-- 快速提问对话框 -->
    <el-dialog v-model="showAskDialog" title="提问" width="560px">
      <el-form :model="askForm" label-position="top">
        <el-form-item label="问题内容" required>
          <el-input
            v-model="askForm.content"
            type="textarea"
            :rows="4"
            placeholder="请输入你的问题..."
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showAskDialog = false">取消</el-button>
        <el-button type="primary" :loading="submittingAsk" @click="handleSubmitAsk">提交</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ChatDotRound, Document } from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getCourse, leaveCourse } from '@/api/course'
import { getDocuments } from '@/api/document'
import { getQuestions, createQuestion } from '@/api/forum'
import { formatDate, formatFileSize } from '@/utils/format'
import type { Course, Chapter } from '@/types/course'
import type { Document as DocType } from '@/types/document'
import type { ForumQuestion } from '@/types/forum'
import PageHeader from '@/components/common/PageHeader.vue'
import StatusTag from '@/components/common/StatusTag.vue'
import Pagination from '@/components/common/Pagination.vue'
import QuestionCard from '@/components/forum/QuestionCard.vue'

const router = useRouter()
const route = useRoute()
const courseId = Number(route.params.courseId)

const loading = ref(false)
const loadingChapters = ref(false)
const loadingDocuments = ref(false)
const loadingQuestions = ref(false)

const course = ref<Course | null>(null)
const chapters = ref<Chapter[]>([])
const documents = ref<DocType[]>([])
const questions = ref<ForumQuestion[]>([])
const questionsTotal = ref(0)
const questionPage = ref(1)

const activeTab = ref('chapters')
const showAskDialog = ref(false)
const submittingAsk = ref(false)
const askForm = reactive({ content: '' })

async function fetchCourse() {
  loading.value = true
  try {
    const res = await getCourse(courseId)
    course.value = res.data
  } catch {
    // 错误已处理
  } finally {
    loading.value = false
  }
}

async function fetchDocuments() {
  loadingDocuments.value = true
  try {
    const res = await getDocuments(courseId, { page: 1, page_size: 50 })
    documents.value = res.data.items || []
  } catch {
    // 错误已处理
  } finally {
    loadingDocuments.value = false
  }
}

async function fetchQuestions() {
  loadingQuestions.value = true
  try {
    const res = await getQuestions(courseId, { page: questionPage.value, page_size: 10 })
    questions.value = res.data.items || []
    questionsTotal.value = res.data.total || 0
  } catch {
    // 错误已处理
  } finally {
    loadingQuestions.value = false
  }
}

function handleTabChange(tab: string) {
  if (tab === 'documents' && documents.value.length === 0) {
    fetchDocuments()
  }
  if (tab === 'forum' && questions.value.length === 0) {
    fetchQuestions()
  }
}

function handleQuickAsk() {
  router.push('/student/ask')
}

async function handleLeave() {
  try {
    await ElMessageBox.confirm('确定要退出该课程吗？退出后需要重新加入。', '退出课程', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    await leaveCourse(courseId)
    ElMessage.success('已退出课程')
    router.push('/student/courses')
  } catch {
    // 用户取消或错误
  }
}

function handleQuestionPageChange(page: number) {
  questionPage.value = page
  fetchQuestions()
}

async function handleSubmitAsk() {
  if (!askForm.content.trim()) {
    ElMessage.warning('请输入问题内容')
    return
  }
  submittingAsk.value = true
  try {
    const res = await createQuestion(courseId, {
      title: askForm.content.slice(0, 50),
      content: askForm.content
    })
    ElMessage.success('提问成功！')
    showAskDialog.value = false
    askForm.content = ''
    router.push(`/student/forum/${res.data.id}`)
  } catch {
    // 错误已处理
  } finally {
    submittingAsk.value = false
  }
}

onMounted(() => {
  fetchCourse()
})
</script>

<style scoped>
.course-detail-view {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

/* 课程头部 */
.course-header {
  background: #fff;
  border-radius: 12px;
  overflow: hidden;
}

.header-cover {
  height: 200px;
  overflow: hidden;
}

.header-cover img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.header-info {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  padding: 20px 24px;
}

.course-name {
  font-size: 22px;
  font-weight: 700;
  margin: 0 0 10px;
  color: #303133;
}

.course-meta-row {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 10px;
}

.teacher-name {
  font-size: 14px;
  color: #606266;
}

.course-desc {
  font-size: 14px;
  color: #909399;
  margin: 0;
  line-height: 1.6;
}

.header-actions {
  display: flex;
  gap: 8px;
  flex-shrink: 0;
}

/* Tabs */
.course-tabs {
  background: #fff;
  border-radius: 10px;
  padding: 0 20px 20px;
}

/* 章节 */
.chapter-node {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
}

.chapter-icon {
  color: #409eff;
}

.chapter-order {
  color: #c0c4cc;
  font-size: 12px;
  margin-left: auto;
}

/* 文档 */
.link-text {
  color: #409eff;
  cursor: pointer;
}

.link-text:hover {
  text-decoration: underline;
}

/* 论坛 */
.forum-actions {
  margin-bottom: 16px;
}

.question-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}
</style>
