<template>
  <div class="pdf-viewer" ref="viewerRef">
    <div v-if="loading" class="pdf-loading" v-loading="true">
      <span>加载PDF文档中...</span>
    </div>

    <div v-else-if="error" class="pdf-error">
      <el-alert :title="error" type="error" :closable="false" show-icon />
    </div>

    <div v-else class="pdf-content">
      <!-- PDF工具栏 -->
      <div class="pdf-toolbar">
        <el-button-group>
          <el-button :icon="ZoomOut" @click="zoomOut" size="small" />
          <el-button size="small" disabled>{{ Math.round(scale * 100) }}%</el-button>
          <el-button :icon="ZoomIn" @click="zoomIn" size="small" />
        </el-button-group>
        <span class="pdf-page-info">
          第 {{ currentPage }} / {{ totalPages }} 页
        </span>
        <el-button-group>
          <el-button :icon="ArrowUp" @click="prevPage" size="small" :disabled="currentPage <= 1" />
          <el-button :icon="ArrowDown" @click="nextPage" size="small" :disabled="currentPage >= totalPages" />
        </el-button-group>
      </div>

      <!-- PDF画布 -->
      <div class="pdf-canvas-wrapper" ref="canvasWrapper">
        <canvas ref="canvasRef" />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onBeforeUnmount, watch } from 'vue'
import { ZoomIn, ZoomOut, ArrowUp, ArrowDown } from '@element-plus/icons-vue'

const props = defineProps<{
  url?: string
  pageNumber?: number
}>()

const emit = defineEmits<{
  'page-change': [page: number]
  loaded: [pages: number]
}>()

const viewerRef = ref<HTMLElement>()
const canvasRef = ref<HTMLCanvasElement>()
const canvasWrapper = ref<HTMLElement>()

const loading = ref(true)
const error = ref('')
const currentPage = ref(1)
const totalPages = ref(0)
const scale = ref(1.2)

let pdfDoc: any = null

async function loadPdf(url: string) {
  if (!url) {
    error.value = 'PDF地址为空'
    loading.value = false
    return
  }

  try {
    loading.value = true
    error.value = ''

    // 动态导入 pdfjs-dist
    const pdfjsLib = await import('pdfjs-dist')
    pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`

    const loadingTask = pdfjsLib.getDocument(url)
    pdfDoc = await loadingTask.promise
    totalPages.value = pdfDoc.numPages
    currentPage.value = 1

    emit('loaded', totalPages.value)
    await renderPage(currentPage.value)
  } catch (e: any) {
    error.value = `PDF加载失败: ${e.message || '未知错误'}`
  } finally {
    loading.value = false
  }
}

async function renderPage(pageNum: number) {
  if (!pdfDoc || !canvasRef.value) return

  const page = await pdfDoc.getPage(pageNum)
  const viewport = page.getViewport({ scale: scale.value })
  const canvas = canvasRef.value
  const context = canvas.getContext('2d')!

  canvas.height = viewport.height
  canvas.width = viewport.width

  await page.render({ canvasContext: context, viewport }).promise
}

function zoomIn() {
  scale.value = Math.min(scale.value + 0.2, 3)
  renderPage(currentPage.value)
}

function zoomOut() {
  scale.value = Math.max(scale.value - 0.2, 0.5)
  renderPage(currentPage.value)
}

async function prevPage() {
  if (currentPage.value > 1) {
    currentPage.value--
    emit('page-change', currentPage.value)
    await renderPage(currentPage.value)
  }
}

async function nextPage() {
  if (currentPage.value < totalPages.value) {
    currentPage.value++
    emit('page-change', currentPage.value)
    await renderPage(currentPage.value)
  }
}

async function goToPage(page: number) {
  if (page >= 1 && page <= totalPages.value) {
    currentPage.value = page
    emit('page-change', currentPage.value)
    await renderPage(currentPage.value)
  }
}

watch(() => props.url, (newUrl) => {
  if (newUrl) loadPdf(newUrl)
})

watch(() => props.pageNumber, (newPage) => {
  if (newPage) goToPage(newPage)
})

onMounted(() => {
  if (props.url) loadPdf(props.url)
})

onBeforeUnmount(() => {
  pdfDoc?.destroy()
})

defineExpose({ goToPage, zoomIn, zoomOut })
</script>

<style scoped>
.pdf-viewer {
  border: 1px solid #ebeef5;
  border-radius: 8px;
  overflow: hidden;
  background: #f5f5f5;
}

.pdf-loading {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 400px;
}

.pdf-error {
  padding: 20px;
}

.pdf-toolbar {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 16px;
  padding: 8px 16px;
  background: #fff;
  border-bottom: 1px solid #ebeef5;
}

.pdf-page-info {
  font-size: 13px;
  color: #606266;
  min-width: 100px;
  text-align: center;
}

.pdf-canvas-wrapper {
  display: flex;
  justify-content: center;
  padding: 16px;
  max-height: 600px;
  overflow-y: auto;
}

.pdf-canvas-wrapper canvas {
  max-width: 100%;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}
</style>
