<template>
  <div class="chat-input">
    <div class="input-wrapper">
      <el-input
        v-model="inputText"
        type="textarea"
        :autosize="{ minRows: 1, maxRows: 6 }"
        placeholder="输入你的问题... (Shift+Enter 换行，Enter 发送)"
        :disabled="disabled"
        resize="none"
        @keydown="handleKeydown"
        ref="textareaRef"
      />
      <el-button
        class="send-btn"
        type="primary"
        :icon="Promotion"
        :disabled="!canSend || disabled"
        circle
        size="large"
        @click="handleSend"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { Promotion } from '@element-plus/icons-vue'
import type { InputInstance } from 'element-plus'

const props = defineProps<{
  disabled?: boolean
}>()

const emit = defineEmits<{
  send: [text: string]
}>()

const inputText = ref('')
const textareaRef = ref<InputInstance>()

const canSend = computed(() => inputText.value.trim().length > 0)

function handleKeydown(e: KeyboardEvent) {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault()
    handleSend()
  }
}

function handleSend() {
  if (!canSend.value || props.disabled) return
  const text = inputText.value.trim()
  inputText.value = ''
  emit('send', text)
}

function focus() {
  textareaRef.value?.focus()
}

defineExpose({ focus })
</script>

<style scoped>
.chat-input {
  padding: 16px 20px;
  border-top: 1px solid #ebeef5;
  background: #fff;
}

.input-wrapper {
  display: flex;
  align-items: flex-end;
  gap: 12px;
  background: #f5f7fa;
  border: 1px solid #dcdfe6;
  border-radius: 12px;
  padding: 8px 8px 8px 16px;
  transition: border-color 0.2s;
}

.input-wrapper:focus-within {
  border-color: #409eff;
  box-shadow: 0 0 0 2px rgba(64, 158, 255, 0.1);
}

.input-wrapper :deep(.el-textarea__inner) {
  background: transparent;
  border: none;
  box-shadow: none;
  padding: 4px 0;
  font-size: 14px;
  line-height: 1.5;
  color: #303133;
}

.input-wrapper :deep(.el-textarea__inner)::-webkit-scrollbar {
  width: 0;
}

.send-btn {
  flex-shrink: 0;
  width: 40px;
  height: 40px;
}
</style>
