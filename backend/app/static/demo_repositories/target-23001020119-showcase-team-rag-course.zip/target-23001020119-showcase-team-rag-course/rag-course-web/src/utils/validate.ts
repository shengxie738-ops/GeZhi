import type { FormItemRule } from 'element-plus'

/** 必填字段验证规则 */
export const required = (message: string): FormItemRule => ({
  required: true,
  message,
  trigger: 'blur'
})

/** 必填字段验证规则（change触发） */
export const requiredChange = (message: string): FormItemRule => ({
  required: true,
  message,
  trigger: 'change'
})

/** 邮箱验证规则 */
export const emailRule: FormItemRule = {
  type: 'email',
  message: '请输入正确的邮箱地址',
  trigger: 'blur'
}

/** 手机号验证规则 */
export const phoneRule: FormItemRule = {
  pattern: /^1[3-9]\d{9}$/,
  message: '请输入正确的手机号码',
  trigger: 'blur'
}

/** 密码验证规则（至少6位） */
export const passwordRule: FormItemRule = {
  min: 6,
  max: 32,
  message: '密码长度需要在 6 到 32 个字符之间',
  trigger: 'blur'
}

/** 用户名验证规则（字母开头，允许字母数字下划线） */
export const usernameRule: FormItemRule = {
  pattern: /^[a-zA-Z][a-zA-Z0-9_]{2,31}$/,
  message: '用户名需要以字母开头，3-32位，只允许字母、数字和下划线',
  trigger: 'blur'
}

/** 课程代码验证规则 */
export const courseCodeRule: FormItemRule = {
  pattern: /^[A-Z]{2,4}\d{3,6}$/,
  message: '课程代码格式不正确，如 CS101',
  trigger: 'blur'
}

/** 通用最大长度验证 */
export const maxLength = (max: number, message?: string): FormItemRule => ({
  max,
  message: message || `不能超过 ${max} 个字符`,
  trigger: 'blur'
})

/** 自定义验证器工厂 */
export function createValidator(
  validator: (rule: FormItemRule, value: any, callback: (error?: string) => void) => void
): FormItemRule {
  return { validator, trigger: 'blur' }
}
