import { createRouter, createWebHistory, type RouteRecordRaw } from 'vue-router'
import { setupRouterGuards } from './guards/auth'

// 懒加载布局组件
const StudentLayout = () => import('@/layouts/StudentLayout.vue')
const TeacherLayout = () => import('@/layouts/TeacherLayout.vue')
const AdminLayout = () => import('@/layouts/AdminLayout.vue')

const routes: RouteRecordRaw[] = [
  // ==================== 公共路由 ====================
  {
    path: '/login',
    name: 'Login',
    component: () => import('@/views/auth/LoginView.vue'),
    meta: { title: '登录', public: true }
  },
  {
    path: '/register',
    name: 'Register',
    component: () => import('@/views/auth/RegisterView.vue'),
    meta: { title: '注册', public: true }
  },
  {
    path: '/403',
    name: 'Forbidden',
    component: () => import('@/views/error/ForbiddenView.vue'),
    meta: { title: '无权限', public: true }
  },
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    component: () => import('@/views/error/NotFoundView.vue'),
    meta: { title: '页面不存在', public: true }
  },

  // ==================== 学生路由 ====================
  {
    path: '/student',
    component: StudentLayout,
    meta: { role: 'student' },
    redirect: '/student/dashboard',
    children: [
      {
        path: 'dashboard',
        name: 'StudentDashboard',
        component: () => import('@/views/student/DashboardView.vue'),
        meta: { title: '仪表板' }
      },
      {
        path: 'courses',
        name: 'StudentCourses',
        component: () => import('@/views/student/CoursesView.vue'),
        meta: { title: '我的课程' }
      },
      {
        path: 'courses/:courseId',
        name: 'StudentCourseDetail',
        component: () => import('@/views/student/CourseDetailView.vue'),
        meta: { title: '课程详情' }
      },
      {
        path: 'ask',
        name: 'StudentAsk',
        component: () => import('@/views/student/AskView.vue'),
        meta: { title: '提问' }
      },
      {
        path: 'chat/:sessionId',
        name: 'StudentChat',
        component: () => import('@/views/student/ChatView.vue'),
        meta: { title: '对话' }
      },
      {
        path: 'search',
        name: 'StudentSearch',
        component: () => import('@/views/student/SearchView.vue'),
        meta: { title: '搜索' }
      },
      {
        path: 'documents',
        name: 'StudentDocuments',
        component: () => import('@/views/student/DocumentsView.vue'),
        meta: { title: '文档' }
      },
      {
        path: 'documents/:documentId',
        name: 'StudentDocumentDetail',
        component: () => import('@/views/student/DocumentDetailView.vue'),
        meta: { title: '文档详情' }
      },
      {
        path: 'forum',
        name: 'StudentForum',
        component: () => import('@/views/student/ForumView.vue'),
        meta: { title: '论坛' }
      },
      {
        path: 'forum/:questionId',
        name: 'StudentForumDetail',
        component: () => import('@/views/student/ForumDetailView.vue'),
        meta: { title: '问题详情' }
      },
      {
        path: 'wrong-questions',
        name: 'StudentWrongQuestions',
        component: () => import('@/views/student/WrongQuestionsView.vue'),
        meta: { title: '错题本' }
      },
      {
        path: 'favorites',
        name: 'StudentFavorites',
        component: () => import('@/views/student/FavoritesView.vue'),
        meta: { title: '收藏' }
      },
      {
        path: 'history',
        name: 'StudentHistory',
        component: () => import('@/views/student/HistoryView.vue'),
        meta: { title: '历史记录' }
      },
      {
        path: 'notifications',
        name: 'StudentNotifications',
        component: () => import('@/views/student/NotificationsView.vue'),
        meta: { title: '通知' }
      }
    ]
  },

  // ==================== 教师路由 ====================
  {
    path: '/teacher',
    component: TeacherLayout,
    meta: { role: 'teacher' },
    redirect: '/teacher/dashboard',
    children: [
      {
        path: 'dashboard',
        name: 'TeacherDashboard',
        component: () => import('@/views/teacher/DashboardView.vue'),
        meta: { title: '仪表板' }
      },
      {
        path: 'courses',
        name: 'TeacherCourses',
        component: () => import('@/views/teacher/CoursesView.vue'),
        meta: { title: '课程管理' }
      },
      {
        path: 'courses/:courseId',
        name: 'TeacherCourseDetail',
        component: () => import('@/views/teacher/CourseDetailView.vue'),
        meta: { title: '课程详情' }
      },
      {
        path: 'knowledge/documents',
        name: 'TeacherKnowledgeDocuments',
        component: () => import('@/views/teacher/knowledge/DocumentsView.vue'),
        meta: { title: '知识库文档' }
      },
      {
        path: 'knowledge/documents/:documentId',
        name: 'TeacherDocumentDetail',
        component: () => import('@/views/teacher/knowledge/DocumentDetailView.vue'),
        meta: { title: '文档详情' }
      },
      {
        path: 'knowledge/chunks',
        name: 'TeacherKnowledgeChunks',
        component: () => import('@/views/teacher/knowledge/ChunksView.vue'),
        meta: { title: '分块管理' }
      },
      {
        path: 'knowledge/forum-review',
        name: 'TeacherForumReview',
        component: () => import('@/views/teacher/knowledge/ForumReviewView.vue'),
        meta: { title: '论坛审核' }
      },
      {
        path: 'questions/unresolved',
        name: 'TeacherUnresolved',
        component: () => import('@/views/teacher/UnresolvedView.vue'),
        meta: { title: '未解决问题' }
      },
      {
        path: 'analytics',
        name: 'TeacherAnalytics',
        component: () => import('@/views/teacher/AnalyticsView.vue'),
        meta: { title: '教学分析' }
      },
      {
        path: 'model-settings',
        name: 'TeacherModelSettings',
        component: () => import('@/views/teacher/ModelSettingsView.vue'),
        meta: { title: '模型设置' }
      },
      {
        path: 'jobs',
        name: 'TeacherJobs',
        component: () => import('@/views/teacher/JobsView.vue'),
        meta: { title: '任务队列' }
      },
      {
        path: 'notifications',
        name: 'TeacherNotifications',
        component: () => import('@/views/teacher/NotificationsView.vue'),
        meta: { title: '通知' }
      }
    ]
  },

  // ==================== 管理员路由 ====================
  {
    path: '/admin',
    component: AdminLayout,
    meta: { role: 'admin' },
    redirect: '/admin/dashboard',
    children: [
      {
        path: 'dashboard',
        name: 'AdminDashboard',
        component: () => import('@/views/admin/DashboardView.vue'),
        meta: { title: '仪表板' }
      },
      {
        path: 'users',
        name: 'AdminUsers',
        component: () => import('@/views/admin/UsersView.vue'),
        meta: { title: '用户管理' }
      },
      {
        path: 'models',
        name: 'AdminModels',
        component: () => import('@/views/admin/ModelsView.vue'),
        meta: { title: '模型配置' }
      },
      {
        path: 'storage',
        name: 'AdminStorage',
        component: () => import('@/views/admin/StorageView.vue'),
        meta: { title: '存储管理' }
      },
      {
        path: 'vector-db',
        name: 'AdminVectorDb',
        component: () => import('@/views/admin/VectorDbView.vue'),
        meta: { title: '向量库管理' }
      },
      {
        path: 'jobs',
        name: 'AdminJobs',
        component: () => import('@/views/admin/JobsView.vue'),
        meta: { title: '任务队列' }
      },
      {
        path: 'logs',
        name: 'AdminLogs',
        component: () => import('@/views/admin/LogsView.vue'),
        meta: { title: '日志审计' }
      },
      {
        path: 'settings',
        name: 'AdminSettings',
        component: () => import('@/views/admin/SettingsView.vue'),
        meta: { title: '系统设置' }
      }
    ]
  },

  // 根路径重定向
  {
    path: '/',
    redirect: '/login'
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior(_to, _from, savedPosition) {
    if (savedPosition) {
      return savedPosition
    }
    return { top: 0 }
  }
})

// 设置路由守卫
setupRouterGuards(router)

// 路由后置守卫 - 设置页面标题
router.afterEach((to) => {
  const title = to.meta.title as string
  if (title) {
    document.title = `${title} - RAG Course`
  }
})

export default router
