﻿<template>
  <div class="wrong-questions-view">
    <PageHeader title="错题本" description="管理和复习你的错题记录">
      <template #default>
        <el-input
          v-model="searchKeyword"
          placeholder="搜索错题..."
          :prefix-icon="Search"
          clearable
          style="width: 200px"
        />
        <el-button type="primary" :icon="Plus" @click="openCreateDialog">
          新增错题
        </el-button>
        <el-button :icon="Upload" @click="showImportDialog = true">
          批量导入
        </el-button>
      </template>
    </PageHeader>

    <div class="wrong-questions-content">
      <!-- 状态筛选 -->
      <div class="filter-bar">
        <el-radio-group v-model="filterStatus" size="default">
          <el-radio-button label="">全部</el-radio-button>
          <el-radio-button label="pending">未解决</el-radio-button>
          <el-radio-button label="reviewing">复习中</el-radio-button>
          <el-radio-button label="mastered">已掌握</el-radio-button>
        </el-radio-group>
      </div>

      <!-- 错题列表 -->
      <div class="table-card">
        <el-table :data="filteredQuestions" v-loading="loading" stripe>
          <el-table-column label="题目" min-width="300" show-overflow-tooltip>
            <template #default="{ row }">
              <span class="link-text" @click="openDetail(row)">{{ row.question }}</span>
            </template>
          </el-table-column>

          <el-table-column label="知识点" min-width="200">
            <template #default="{ row }">
              <div class="tags-cell">
                <el-tag
                  v-for="tag in row.knowledge_tags"
                  :key="tag"
                  size="small"
                  type="info"
                  effect="plain"
                >
                  {{ tag }}
                </el-tag>
              </div>
            </template>
          </el-table-column>

          <el-table-column label="状态" width="100" align="center">
            <template #default="{ row }">
              <StatusTag :value="row.status" type="wrong-question" />
            </template>
          </el-table-column>

          <el-table-column label="复习次数" width="90" align="center">
            <template #default="{ row }">
              {{ row.review_count }}
            </template>
          </el-table-column>

          <el-table-column label="创建时间" width="160">
            <template #default="{ row }">
              {{ formatDate(row.created_at) }}
            </template>
          </el-table-column>

          <el-table-column label="操作" width="160" fixed="right">
            <template #default="{ row }">
              <el-button text type="primary" size="small" @click="openEditDialog(row)">编辑</el-button>
              <el-button
                text
                :type="row.status === 'mastered' ? 'success' : 'primary'"
                size="small"
                @click="handleToggleStatus(row)"
              >
                {{ row.status === 'mastered' ? '标记未掌握' : '标记已掌握' }}
              </el-button>
              <el-popconfirm title="确定删除该错题？" @confirm="handleDelete(row.id)">
                <template #reference>
                  <el-button text type="danger" size="small">删除</el-button>
                </template>
              </el-popconfirm>
            </template>
          </el-table-column>
        </el-table>

        <Pagination
          v-if="total > 0"
          :total="total"
          :page="page"
          :page-size="pageSize"
          @change="handlePageChange"
        />

        <el-empty v-if="!loading && filteredQuestions.length === 0" description="暂无错题记录" />
      </div>
    </div>

    <!-- 新增/编辑错题对话框 -->
    <el-dialog
      v-model="showFormDialog"
      :title="editingId ? '编辑错题' : '新增错题'"
      width="600px"
      :close-on-click-modal="false"
    >
      <el-form :model="form" label-position="top">
        <el-form-item label="题目内容" required>
          <el-input v-model="form.question" type="textarea" :rows="3" placeholder="输入题目内容..." />
        </el-form-item>
        <el-form-item label="学生答案" required>
          <el-input v-model="form.user_answer" type="textarea" :rows="2" placeholder="你当时的答案..." />
        </el-form-item>
        <el-form-item label="正确答案" required>
          <el-input v-model="form.answer" type="textarea" :rows="2" placeholder="正确答案..." />
        </el-form-item>
        <el-form-item label="错误原因">
          <el-input v-model="form.error_reason" type="textarea" :rows="2" placeholder="分析错误原因..." />
        </el-form-item>
        <el-form-item label="知识点标签">
          <div class="tags-input">
            <el-tag v-for="tag in form.knowledge_tags" :key="tag" closable @close="removeTag(tag)">
              {{ tag }}
            </el-tag>
            <el-input
              v-model="newTag"
              size="small"
              style="width: 140px"
              placeholder="添加知识点"
              @keydown.enter.prevent="addTag"
            />
          </div>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showFormDialog = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="handleSave">保存</el-button>
      </template>
    </el-dialog>

    <!-- 批量导入对话框 -->
    <el-dialog v-model="showImportDialog" title="批量导入错题" width="600px">
      <el-form label-position="top">
        <el-form-item label="选择课程" required>
          <el-select v-model="importCourseId" placeholder="选择课程" style="width: 100%">
            <el-option v-for="c in courses" :key="c.id" :label="c.name" :value="c.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="粘贴JSON格式的错题数据">
          <el-input
            v-model="importData"
            type="textarea"
            :rows="10"
            placeholder='[{"question":"题目","answer":"答案","user_answer":"你的答案","knowledge_tags":["标签"]}]'
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showImportDialog = false">取消</el-button>
        <el-button type="primary" :loading="importing" @click="handleImport">导入</el-button>
      </template>
    </el-dialog>

    <!-- 错题详情抽屉 -->
    <el-drawer v-model="showDetailDrawer" title="错题详情" size="500px">
      <template v-if="detailQuestion">
        <el-descriptions :column="1" border>
          <el-descriptions-item label="题目">{{ detailQuestion.question }}</el-descriptions-item>
          <el-descriptions-item label="学生答案">{{ detailQuestion.user_answer }}</el-descriptions-item>
          <el-descriptions-item label="正确答案">{{ detailQuestion.answer }}</el-descriptions-item>
          <el-descriptions-item label="来源">{{ detailQuestion.source || '-' }}</el-descriptions-item>
          <el-descriptions-item label="状态">
            <StatusTag :value="detailQuestion.status" type="wrong-question" />
          </el-descriptions-item>
          <el-descriptions-item label="复习次数">{{ detailQuestion.review_count }}</el-descriptions-item>
          <el-descriptions-item label="知识点">
            <el-tag v-for="t in detailQuestion.knowledge_tags" :key="t" size="small" style="margin-right: 4px">{{ t }}</el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="创建时间">{{ formatDate(detailQuestion.created_at) }}</el-descriptions-item>
        </el-descriptions>
      </template>
    </el-drawer>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, watch, onMounted } from 'vue'
import { Search, Plus, Upload } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import { getCourses } from '@/api/course'
import {
  getWrongQuestions,
  createWrongQuestion,
  updateWrongQuestion,
  deleteWrongQuestion,
  importWrongQuestions
} from '@/api/wrongQuestion'
import { formatDate } from '@/utils/format'
import type { Course } from '@/types/course'
import type { WrongQuestion } from '@/types/wrongQuestion'
import PageHeader from '@/components/common/PageHeader.vue'
import StatusTag from '@/components/common/StatusTag.vue'
import Pagination from '@/components/common/Pagination.vue'

const loading = ref(false)
const saving = ref(false)
const importing = ref(false)
const courses = ref<Course[]>([])
const questions = ref<WrongQuestion[]>([])
const total = ref(0)
const page = ref(1)
const pageSize = ref(20)

const searchKeyword = ref('')
const filterStatus = ref('')
const selectedCourseId = ref<number | undefined>()

// 表单相关
const showFormDialog = ref(false)
const editingId = ref<number | null>(null)
const newTag = ref('')
const form = reactive({
  course_id: 0,
  question: '',
  answer: '',
  user_answer: '',
  error_reason: '',
  knowledge_tags: [] as string[]
})

// 详情抽屉
const showDetailDrawer = ref(false)
const detailQuestion = ref<WrongQuestion | null>(null)

// 导入相关
const showImportDialog = ref(false)
const importCourseId = ref<number | undefined>()
const importData = ref('')

const filteredQuestions = computed(() => {
  if (!searchKeyword.value.trim()) return questions.value
  const kw = searchKeyword.value.toLowerCase()
  return questions.value.filter(q =>
    q.question.toLowerCase().includes(kw) || q.knowledge_tags?.some(t => t.toLowerCase().includes(kw))
  )
})

async function fetchCourses() {
  try {
    const res = await getCourses({ page: 1, page_size: 100 })
    courses.value = res.data.items || []
    if (courses.value.length > 0) {
      selectedCourseId.value = courses.value[0].id
    }
  } catch { /* 忽略 */ }
}

async function fetchQuestions() {
  if (!selectedCourseId.value) return
  loading.value = true
  try {
    const res = await getWrongQuestions(selectedCourseId.value, {
      page: page.value,
      page_size: pageSize.value,
      status: filterStatus.value || undefined
    })
    questions.value = res.data.items || []
    total.value = res.data.total || 0
  } catch {
    // 错误已处理
  } finally {
    loading.value = false
  }
}

function handlePageChange(newPage: number, newPageSize: number) {
  page.value = newPage
  pageSize.value = newPageSize
  fetchQuestions()
}

function openCreateDialog() {
  editingId.value = null
  form.course_id = selectedCourseId.value || 0
  form.question = ''
  form.answer = ''
  form.user_answer = ''
  form.error_reason = ''
  form.knowledge_tags = []
  showFormDialog.value = true
}

function openEditDialog(row: WrongQuestion) {
  editingId.value = row.id
  form.course_id = row.course_id
  form.question = row.question
  form.answer = row.answer
  form.user_answer = row.user_answer
  form.error_reason = ''
  form.knowledge_tags = [...(row.knowledge_tags || [])]
  showFormDialog.value = true
}

function openDetail(row: WrongQuestion) {
  detailQuestion.value = row
  showDetailDrawer.value = true
}

function addTag() {
  const tag = newTag.value.trim()
  if (tag && !form.knowledge_tags.includes(tag)) {
    form.knowledge_tags.push(tag)
  }
  newTag.value = ''
}

function removeTag(tag: string) {
  form.knowledge_tags = form.knowledge_tags.filter(t => t !== tag)
}

async function handleSave() {
  if (!form.question.trim() || !form.answer.trim() || !form.user_answer.trim()) {
    ElMessage.warning('请填写必填项')
    return
  }
  saving.value = true
  try {
    if (editingId.value) {
      await updateWrongQuestion(editingId.value, {
        question: form.question,
        answer: form.answer,
        user_answer: form.user_answer,
        knowledge_tags: form.knowledge_tags
      })
      ElMessage.success('更新成功')
    } else {
      await createWrongQuestion({
        course_id: form.course_id,
        question: form.question,
        answer: form.answer,
        user_answer: form.user_answer,
        knowledge_tags: form.knowledge_tags
      })
      ElMessage.success('创建成功')
    }
    showFormDialog.value = false
    await fetchQuestions()
  } catch {
    // 错误已处理
  } finally {
    saving.value = false
  }
}

async function handleDelete(id: number) {
  try {
    await deleteWrongQuestion(id)
    ElMessage.success('已删除')
    await fetchQuestions()
  } catch { /* 忽略 */ }
}

async function handleToggleStatus(row: WrongQuestion) {
  try {
    const newStatus = row.status === 'mastered' ? 'pending' : 'mastered'
    await updateWrongQuestion(row.id, { status: newStatus })
    row.status = newStatus as any
    ElMessage.success(row.status === 'mastered' ? '已标记为掌握' : '已标记为未掌握')
  } catch { /* 忽略 */ }
}

async function handleImport() {
  if (!importCourseId.value || !importData.value.trim()) {
    ElMessage.warning('请填写完整信息')
    return
  }
  importing.value = true
  try {
    const parsed = JSON.parse(importData.value)
    const questions = Array.isArray(parsed) ? parsed : [parsed]
    await importWrongQuestions({
      course_id: importCourseId.value,
      questions: questions.map((q: any) => ({
        course_id: importCourseId.value!,
        question: q.question,
        answer: q.answer,
        user_answer: q.user_answer,
        knowledge_tags: q.knowledge_tags || []
      }))
    })
    ElMessage.success('导入成功')
    showImportDialog.value = false
    importData.value = ''
    await fetchQuestions()
  } catch (e: any) {
    ElMessage.error('JSON格式错误：' + e.message)
  } finally {
    importing.value = false
  }
}

watch(selectedCourseId, () => {
  page.value = 1
  fetchQuestions()
})

watch(filterStatus, () => {
  page.value = 1
  fetchQuestions()
})

onMounted(() => {
  fetchCourses()
})
</script>

<style scoped>
.wrong-questions-view {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.filter-bar {
  display: flex;
  align-items: center;
  gap: 16px;
}

.table-card {
  background: #fff;
  border-radius: 10px;
  padding: 20px;
}

.tags-cell {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}

.tags-input {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  align-items: center;
}

.link-text {
  color: #409eff;
  cursor: pointer;
}

.link-text:hover {
  text-decoration: underline;
}
</style>
