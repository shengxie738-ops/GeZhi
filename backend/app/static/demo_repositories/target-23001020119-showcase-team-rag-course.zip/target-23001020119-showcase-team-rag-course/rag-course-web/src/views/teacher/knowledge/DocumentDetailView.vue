﻿<template>
  <div class="page-container">
    <PageHeader :title="document.title || '文档详情'">
      <el-button @click="$router.back()">返回列表</el-button>
    </PageHeader>

    <!-- 文档信息卡片 -->
    <el-card shadow="never" class="info-card">
      <el-descriptions :column="3" border>
        <el-descriptions-item label="文档标题">{{ document.title }}</el-descriptions-item>
        <el-descriptions-item label="文件名">{{ document.filename }}</el-descriptions-item>
        <el-descriptions-item label="文件类型">
          <el-tag size="small">{{ document.file_type?.toUpperCase() }}</el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="文件大小">{{ formatFileSize(document.file_size) }}</el-descriptions-item>
        <el-descriptions-item label="知识块数">{{ document.chunk_count }}</el-descriptions-item>
        <el-descriptions-item label="解析状态">
          <DocumentStatusBadge
            :status="document.parse_status"
            :progress="parseProgress"
          />
        </el-descriptions-item>
        <el-descriptions-item label="上传者">{{ document.uploader?.nickname || '-' }}</el-descriptions-item>
        <el-descriptions-item label="上传时间">{{ formatDate(document.created_at) }}</el-descriptions-item>
        <el-descriptions-item label="解析时间">{{ formatDate(document.parsed_at) }}</el-descriptions-item>
      </el-descriptions>
      <div class="doc-actions" v-if="document.parse_status === 'failed'">
        <el-alert :title="document.parse_error || '文档解析失败'" type="error" show-icon :closable="false" style="margin-bottom: 12px" />
        <el-button type="warning" @click="handleReparse">重新解析</el-button>
      </div>
    </el-card>

    <!-- 知识块管理 -->
    <el-card shadow="never" style="margin-top: 20px">
      <template #header>
        <div class="card-header">
          <span class="card-title">知识块管理</span>
          <div class="batch-actions" v-if="selectedChunks.length > 0">
            <span class="selected-count">已选 {{ selectedChunks.length }} 项</span>
            <el-button size="small" type="success" @click="handleBatchEnable">批量启用</el-button>
            <el-button size="small" type="info" @click="handleBatchDisable">批量禁用</el-button>
          </div>
        </div>
      </template>

      <el-table
        :data="chunks"
        v-loading="chunksLoading"
        stripe
        border
        @selection-change="handleSelectionChange"
      >
        <el-table-column type="selection" width="50" />
        <el-table-column type="index" label="编号" width="70" />
        <el-table-column prop="content" label="标题路径" min-width="300">
          <template #default="{ row }">
            <span class="chunk-content">{{ truncate(row.content, 80) }}</span>
          </template>
        </el-table-column>
        <el-table-column label="页码" width="90" align="center">
          <template #default="{ row }">
            {{ row.start_page != null ? `${row.start_page}-${row.end_page ?? row.start_page}` : '-' }}
          </template>
        </el-table-column>
        <el-table-column prop="token_count" label="Token数" width="90" align="center" />
        <el-table-column label="启用" width="80" align="center">
          <template #default="{ row }">
            <el-switch
              :model-value="row.enabled"
              @change="(val: boolean) => handleToggleChunk(row, val)"
              size="small"
            />
          </template>
        </el-table-column>
        <el-table-column label="操作" width="180" fixed="right">
          <template #default="{ row }">
            <el-button type="primary" link size="small" @click="openEditDialog(row)">编辑</el-button>
            <el-button type="info" link size="small" @click="openPreviewDialog(row)">预览</el-button>
          </template>
        </el-table-column>
      </el-table>

      <Pagination
        v-model:page="chunkPagination.page"
        v-model:page-size="chunkPagination.pageSize"
        :total="chunkPagination.total"
        @change="fetchChunks"
      />
    </el-card>

    <!-- 编辑知识块对话框 -->
    <ChunkEditor
      v-model="editDialogVisible"
      :chunk="editingChunk"
      @save="handleSaveChunk"
    />

    <!-- 预览对话框 -->
    <el-dialog v-model="previewDialogVisible" title="知识块预览" width="600px">
      <div class="preview-content">
        <el-descriptions :column="2" border size="small" style="margin-bottom: 16px">
          <el-descriptions-item label="编号">#{{ previewChunk.chunk_index + 1 }}</el-descriptions-item>
          <el-descriptions-item label="Token">{{ previewChunk.token_count }}</el-descriptions-item>
          <el-descriptions-item label="页码">
            {{ previewChunk.start_page != null ? `${previewChunk.start_page}-${previewChunk.end_page}` : '-' }}
          </el-descriptions-item>
          <el-descriptions-item label="状态">
            <el-tag size="small" :type="previewChunk.enabled ? 'success' : 'info'">
              {{ previewChunk.enabled ? '已启用' : '已禁用' }}
            </el-tag>
          </el-descriptions-item>
        </el-descriptions>
        <div class="preview-text">{{ previewChunk.content }}</div>
      </div>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import PageHeader from '@/components/common/PageHeader.vue'
import Pagination from '@/components/common/Pagination.vue'
import DocumentStatusBadge from '@/components/knowledge/DocumentStatusBadge.vue'
import ChunkEditor from '@/components/knowledge/ChunkEditor.vue'
import * as documentApi from '@/api/document'
import { formatDate, formatFileSize, truncate } from '@/utils/format'
import type { Document, Chunk } from '@/types/document'

const route = useRoute()
const documentId = Number(route.params.documentId)

const document = reactive<Document>({
  id: 0, course_id: 0, title: '', filename: '', file_path: '',
  file_size: 0, file_type: '', mime_type: '', parse_status: 'pending',
  parse_error: null, chunk_count: 0, content_hash: '', metadata: {},
  uploaded_by: 0, uploader: {} as any, created_at: '', updated_at: '',
  parsed_at: null, indexed_at: null
})
const parseProgress = ref(0)

const chunks = ref<Chunk[]>([])
const chunksLoading = ref(false)
const selectedChunks = ref<Chunk[]>([])
const chunkPagination = reactive({ page: 1, pageSize: 20, total: 0 })

// 编辑
const editDialogVisible = ref(false)
const editingChunk = ref<Chunk>({} as Chunk)

// 预览
const previewDialogVisible = ref(false)
const previewChunk = ref<Chunk>({} as Chunk)

async function fetchDocument() {
  try {
    const res = await documentApi.getDocument(documentId)
    Object.assign(document, res.data)
  } catch { /* handled */ }
}

async function fetchChunks() {
  chunksLoading.value = true
  try {
    const res = await documentApi.getDocumentChunks(documentId, {
      page: chunkPagination.page,
      page_size: chunkPagination.pageSize
    })
    chunks.value = res.data.items
    chunkPagination.total = res.data.total
  } catch { /* handled */ }
  finally { chunksLoading.value = false }
}

async function handleReparse() {
  try {
    await documentApi.parseDocument(documentId)
    ElMessage.success('已触发重新解析')
    fetchDocument()
  } catch { /* handled */ }
}

function handleSelectionChange(selection: Chunk[]) {
  selectedChunks.value = selection
}

async function handleToggleChunk(chunk: Chunk, enabled: boolean) {
  try {
    await documentApi.toggleChunkEnabled(chunk.id, enabled)
    chunk.enabled = enabled
    ElMessage.success(enabled ? '已启用' : '已禁用')
  } catch { /* handled */ }
}

async function handleBatchEnable() {
  for (const chunk of selectedChunks.value) {
    await documentApi.toggleChunkEnabled(chunk.id, true)
    chunk.enabled = true
  }
  ElMessage.success(`已批量启用 ${selectedChunks.value.length} 个知识块`)
}

async function handleBatchDisable() {
  for (const chunk of selectedChunks.value) {
    await documentApi.toggleChunkEnabled(chunk.id, false)
    chunk.enabled = false
  }
  ElMessage.success(`已批量禁用 ${selectedChunks.value.length} 个知识块`)
}

function openEditDialog(chunk: Chunk) {
  editingChunk.value = { ...chunk }
  editDialogVisible.value = true
}

async function handleSaveChunk(chunkId: number, content: string) {
  try {
    await documentApi.updateChunk(chunkId, { content })
    ElMessage.success('知识块已更新，向量正在重新生成')
    fetchChunks()
  } catch { /* handled */ }
}

function openPreviewDialog(chunk: Chunk) {
  previewChunk.value = chunk
  previewDialogVisible.value = true
}

onMounted(() => {
  fetchDocument()
  fetchChunks()
})
</script>

<style scoped>
.info-card {
  border-radius: 8px;
}

.doc-actions {
  margin-top: 12px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.card-title {
  font-size: 16px;
  font-weight: 600;
  color: #303133;
}

.batch-actions {
  display: flex;
  align-items: center;
  gap: 8px;
}

.selected-count {
  font-size: 13px;
  color: #909399;
}

.chunk-content {
  font-size: 13px;
  color: #606266;
  line-height: 1.5;
}

.preview-content {
  max-height: 500px;
  overflow-y: auto;
}

.preview-text {
  font-size: 14px;
  line-height: 1.8;
  color: #303133;
  white-space: pre-wrap;
  background: #FAFAFA;
  padding: 16px;
  border-radius: 6px;
}
</style>
