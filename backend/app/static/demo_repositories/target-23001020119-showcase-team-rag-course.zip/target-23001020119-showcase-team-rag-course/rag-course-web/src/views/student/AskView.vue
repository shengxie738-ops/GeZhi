<template>
  <div class="ask-view">
    <PageHeader title="智能提问" description="基于知识库的AI助教为你解答疑问" />

    <div class="ask-layout">
      <!-- 左侧提问区 -->
      <div class="ask-main">
        <div class="ask-form-card">
          <!-- 课程选择 -->
          <el-row :gutter="16" class="ask-filters">
            <el-col :span="12">
              <el-select v-model="selectedCourseId" placeholder="选择课程" clearable style="width: 100%">
                <el-option
                  v-for="course in courses"
                  :key="course.id"
                  :label="course.name"
                  :value="course.id"
                />
              </el-select>
            </el-col>
            <el-col :span="12">
              <el-select v-model="selectedChapterId" placeholder="选择章节（可选）" clearable style="width: 100%">
                <el-option
                  v-for="chapter in chapters"
                  :key="chapter.id"
                  :label="chapter.title"
                  :value="chapter.id"
                />
              </el-select>
            </el-col>
          </el-row>

          <!-- 来源类型筛选 -->
          <div class="source-filters">
            <span class="filter-label">知识来源：</span>
            <el-checkbox-group v-model="selectedSources" size="small">
              <el-checkbox label="course_file">课程文件</el-checkbox>
              <el-checkbox label="certified_qa">认证问答</el-checkbox>
              <el-checkbox label="wrong_questions">错题</el-checkbox>
            </el-checkbox-group>
          </div>

          <!-- 提问输入 -->
          <div class="ask-input-area">
            <el-input
              v-model="question"
              type="textarea"
              :autosize="{ minRows: 4, maxRows: 10 }"
              placeholder="请输入你的问题..."
              @keydown.enter.ctrl="handleAsk"
            />
            <div class="ask-actions">
              <span class="ask-tip">Ctrl + Enter 发送</span>
              <el-button
                type="primary"
                :icon="Promotion"
                :loading="asking"
                :disabled="!canAsk"
                @click="handleAsk"
              >
                发送
              </el-button>
            </div>
          </div>

          <!-- 快捷问题标签 -->
          <div class="quick-questions" v-if="quickQuestions.length">
            <span class="quick-label">常见问题：</span>
            <div class="quick-tags">
              <el-tag
                v-for="(q, i) in quickQuestions"
                :key="i"
                class="quick-tag"
                effect="plain"
                @click="question = q"
              >
                {{ q }}
              </el-tag>
            </div>
          </div>
        </div>

        <!-- 提问结果 -->
        <div class="ask-result" v-if="result">
          <div class="result-card">
            <div class="result-header">
              <el-icon class="result-icon"><CircleCheck /></el-icon>
              <span>AI 回答</span>
              <span class="result-meta">耗时 {{ result.latency_ms }}ms · {{ result.token_count }} tokens</span>
            </div>
            <div class="result-content">
              <MarkdownRenderer :content="result.answer" />
            </div>
            <div class="result-citations" v-if="result.citations?.length">
              <div class="citations-title">
                <el-icon><Link /></el-icon>
                引用来源 ({{ result.citations.length }})
              </div>
              <div class="citations-grid">
                <div v-for="(c, i) in result.citations" :key="i" class="citation-item">
                  <span class="citation-doc">{{ c.document_title }}</span>
                  <el-tag v-if="c.page_number" size="small">P.{{ c.page_number }}</el-tag>
                  <span class="citation-score">{{ (c.score * 100).toFixed(0) }}%</span>
                </div>
              </div>
            </div>
            <div class="result-actions">
              <el-button text @click="goToChat">继续对话</el-button>
            </div>
          </div>
        </div>
      </div>

      <!-- 右侧历史 -->
      <div class="ask-sidebar">
        <div class="sidebar-header">
          <h4>最近提问</h4>
        </div>
        <div class="history-list" v-loading="loadingHistory">
          <div
            v-for="session in recentSessions"
            :key="session.id"
            class="history-item"
            @click="router.push(`/student/chat/${session.id}`)"
          >
            <div class="history-title">{{ session.title || '新会话' }}</div>
            <div class="history-time">{{ formatRelativeTime(session.updated_at) }}</div>
          </div>
          <el-empty v-if="!loadingHistory && recentSessions.length === 0" description="暂无记录" :image-size="60" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, watch } from 'vue'
import { useRouter } from 'vue-router'
import { Promotion, CircleCheck, Link } from '@element-plus/icons-vue'
import { getCourses } from '@/api/course'
import { ask } from '@/api/rag'
import { formatRelativeTime } from '@/utils/format'
import type { Course } from '@/types/course'
import type { ChatSession } from '@/types/chat'
import type { AskResponse } from '@/types/rag'
import PageHeader from '@/components/common/PageHeader.vue'
import MarkdownRenderer from '@/components/common/MarkdownRenderer.vue'

const router = useRouter()

const courses = ref<Course[]>([])
const chapters = ref<any[]>([])
const recentSessions = ref<ChatSession[]>([])

const selectedCourseId = ref<number | undefined>()
const selectedChapterId = ref<number | undefined>()
const selectedSources = ref<string[]>(['course_file'])
const question = ref('')
const asking = ref(false)
const loadingHistory = ref(false)
const result = ref<AskResponse | null>(null)
const lastSessionId = ref<number | null>(null)

const quickQuestions = ref([
  '什么是RAG技术？',
  '向量数据库的作用是什么？',
  '如何评估RAG系统的效果？',
  '分块策略有哪些？'
])

const canAsk = computed(() => question.value.trim().length > 0 && !!selectedCourseId.value)

async function fetchCourses() {
  try {
    const res = await getCourses({ page: 1, page_size: 100 })
    courses.value = res.data.items || []
  } catch { /* 忽略 */ }
}

watch(selectedCourseId, async (courseId) => {
  if (!courseId) {
    chapters.value = []
    return
  }
  // 章节可以通过课程详情获取
  chapters.value = []
})

async function handleAsk() {
  if (!canAsk.value) return
  asking.value = true
  result.value = null
  try {
    const res = await ask({
      question: question.value.trim(),
      course_id: selectedCourseId.value!,
      top_k: 5
    })
    result.value = res.data
    lastSessionId.value = res.data.session_id
  } catch {
    // 错误已处理
  } finally {
    asking.value = false
  }
}

function goToChat() {
  if (lastSessionId.value) {
    router.push(`/student/chat/${lastSessionId.value}`)
  }
}

onMounted(() => {
  fetchCourses()
})
</script>

<style scoped>
.ask-view {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.ask-layout {
  display: flex;
  gap: 20px;
}

.ask-main {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.ask-form-card {
  background: #fff;
  border-radius: 10px;
  padding: 20px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.ask-filters {
  margin: 0;
}

.source-filters {
  display: flex;
  align-items: center;
  gap: 8px;
}

.filter-label {
  font-size: 13px;
  color: #606266;
  white-space: nowrap;
}

.ask-input-area {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.ask-actions {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.ask-tip {
  font-size: 12px;
  color: #c0c4cc;
}

.quick-questions {
  padding-top: 8px;
  border-top: 1px solid #f2f3f5;
}

.quick-label {
  font-size: 13px;
  color: #909399;
  margin-bottom: 6px;
  display: block;
}

.quick-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.quick-tag {
  cursor: pointer;
}

.quick-tag:hover {
  color: #409eff;
  border-color: #409eff;
}

/* 结果区域 */
.ask-result {
  display: flex;
  flex-direction: column;
}

.result-card {
  background: #fff;
  border-radius: 10px;
  padding: 20px;
}

.result-header {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 15px;
  font-weight: 600;
  color: #303133;
  margin-bottom: 12px;
}

.result-icon {
  color: #67c23a;
}

.result-meta {
  margin-left: auto;
  font-size: 12px;
  font-weight: 400;
  color: #909399;
}

.result-content {
  line-height: 1.7;
  padding: 12px 0;
  border-top: 1px solid #f2f3f5;
}

.result-citations {
  padding-top: 12px;
  border-top: 1px solid #f2f3f5;
}

.citations-title {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 13px;
  font-weight: 600;
  color: #606266;
  margin-bottom: 8px;
}

.citations-grid {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.citation-item {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  padding: 6px 10px;
  background: #fafafa;
  border-radius: 6px;
}

.citation-doc {
  color: #409eff;
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.citation-score {
  color: #67c23a;
  font-size: 12px;
  flex-shrink: 0;
}

.result-actions {
  padding-top: 12px;
  text-align: right;
}

/* 右侧边栏 */
.ask-sidebar {
  width: 300px;
  flex-shrink: 0;
  background: #fff;
  border-radius: 10px;
  overflow: hidden;
}

.sidebar-header {
  padding: 16px;
  border-bottom: 1px solid #ebeef5;
}

.sidebar-header h4 {
  margin: 0;
  font-size: 15px;
  color: #303133;
}

.history-list {
  max-height: calc(100vh - 300px);
  overflow-y: auto;
}

.history-item {
  padding: 12px 16px;
  border-bottom: 1px solid #f2f3f5;
  cursor: pointer;
  transition: background 0.2s;
}

.history-item:hover {
  background: #f5f7fa;
}

.history-title {
  font-size: 13px;
  color: #303133;
  margin-bottom: 4px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.history-time {
  font-size: 12px;
  color: #c0c4cc;
}
</style>
