﻿﻿<template>
  <div class="page-container">
    <PageHeader title="模型设置" description="配置AI模型和RAG检索参数" />

    <el-tabs v-model="activeTab" type="border-card">
      <!-- 模型配置列表 -->
      <el-tab-pane label="模型配置" name="models">
        <el-card shadow="never">
          <div class="toolbar">
            <span class="section-title">模型配置列表</span>
            <el-button type="primary" size="small" @click="openModelDialog()">
              <el-icon><Plus /></el-icon> 新增配置
            </el-button>
          </div>
          <el-table :data="modelConfigs" v-loading="modelsLoading" stripe border>
            <el-table-column prop="name" label="配置名" width="160" />
            <el-table-column prop="provider" label="提供商" width="120">
              <template #default="{ row }">
                <el-tag size="small">{{ row.provider }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="model_id" label="模型名" width="180" />
            <el-table-column prop="type" label="类型" width="100">
              <template #default="{ row }">
                <el-tag size="small" :type="row.is_default ? 'success' : 'info'">
                  {{ row.is_default ? '默认' : '备选' }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column label="启用状态" width="90" align="center">
              <template #default="{ row }">
                <el-switch
                  :model-value="row.is_active"
                  @change="(val: boolean) => handleToggleModel(row, val)"
                  size="small"
                />
              </template>
            </el-table-column>
            <el-table-column label="操作" width="240" fixed="right">
              <template #default="{ row }">
                <el-button type="primary" link size="small" @click="openModelDialog(row)">编辑</el-button>
                <el-button type="success" link size="small" @click="handleTestModel(row)" :loading="testingId === row.id">
                  测试连接
                </el-button>
                <el-popconfirm title="确定删除此配置？" @confirm="handleDeleteModel(row)">
                  <template #reference>
                    <el-button type="danger" link size="small">删除</el-button>
                  </template>
                </el-popconfirm>
              </template>
            </el-table-column>
          </el-table>

          <!-- 测试结果 -->
          <el-alert
            v-if="testResult"
            :title="testResult.success ? '连接测试成功' : '连接测试失败'"
            :type="testResult.success ? 'success' : 'error'"
            show-icon
            :description="testResult.success
              ? `响应时间: ${testResult.latency_ms}ms, Token数: ${testResult.token_count}`
              : testResult.error"
            style="margin-top: 16px"
          />
        </el-card>
      </el-tab-pane>

      <!-- RAG参数配置 -->
      <el-tab-pane label="RAG 检索参数" name="rag">
        <el-card shadow="never" style="max-width: 800px">
          <el-form :model="ragConfig" label-width="160px">
            <el-divider content-position="left">切分参数</el-divider>
            <el-form-item label="chunk_size">
              <el-slider v-model="ragConfig.chunk_size" :min="100" :max="2000" :step="50" show-input />
              <div class="form-tip">文本切分的最大长度（字符数），越大保留上下文越多</div>
            </el-form-item>
            <el-form-item label="chunk_overlap">
              <el-slider v-model="ragConfig.chunk_overlap" :min="0" :max="500" :step="10" show-input />
              <div class="form-tip">相邻分块的重叠字符数，避免上下文断裂</div>
            </el-form-item>

            <el-divider content-position="left">检索参数</el-divider>
            <el-form-item label="top_k">
              <el-input-number v-model="ragConfig.top_k" :min="1" :max="20" />
              <div class="form-tip">检索返回的最相关文档块数量</div>
            </el-form-item>
            <el-form-item label="rerank_top_n">
              <el-input-number v-model="(ragConfig as any).rerank_top_n" :min="1" :max="10" />
              <div class="form-tip">重排序后保留的文档块数量</div>
            </el-form-item>
            <el-form-item label="min_score">
              <el-slider v-model="ragConfig.score_threshold" :min="0" :max="1" :step="0.05" show-input />
              <div class="form-tip">最低相似度阈值，低于此分数的文档块将被过滤</div>
            </el-form-item>

            <el-divider content-position="left">检索策略</el-divider>
            <el-form-item label="检索策略">
              <el-radio-group v-model="ragConfig.retrieval_strategy">
                <el-radio value="similarity">相似度检索</el-radio>
                <el-radio value="mmr">MMR 多样性检索</el-radio>
                <el-radio value="hybrid">混合检索</el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item label="MMR Lambda" v-if="ragConfig.retrieval_strategy === 'mmr'">
              <el-slider v-model="ragConfig.mmr_lambda" :min="0" :max="1" :step="0.1" show-input />
              <div class="form-tip">相似度与多样性之间的权重平衡</div>
            </el-form-item>

            <el-divider content-position="left">权重配置</el-divider>
            <el-form-item label="语义权重">
              <el-slider v-model="(ragConfig as any).semantic_weight" :min="0" :max="1" :step="0.1" show-input />
            </el-form-item>
            <el-form-item label="关键词权重">
              <el-slider v-model="(ragConfig as any).keyword_weight" :min="0" :max="1" :step="0.1" show-input />
            </el-form-item>

            <el-divider content-position="left">系统提示词</el-divider>
            <el-form-item label="系统提示词">
              <el-input
                v-model="ragConfig.system_prompt"
                type="textarea"
                :rows="8"
                placeholder="设定AI助手的角色和行为规范..."
              />
            </el-form-item>

            <el-form-item>
              <el-button type="primary" :loading="ragSaving" @click="handleSaveRagConfig">保存配置</el-button>
            </el-form-item>
          </el-form>
        </el-card>
      </el-tab-pane>
    </el-tabs>

    <!-- 模型配置对话框 -->
    <el-dialog
      v-model="modelDialogVisible"
      :title="editingModel ? '编辑模型配置' : '新增模型配置'"
      width="600px"
      :close-on-click-modal="false"
    >
      <el-form :model="modelForm" label-width="100px">
        <el-form-item label="配置名" required>
          <el-input v-model="modelForm.name" placeholder="如：GPT-4o 教学助手" />
        </el-form-item>
        <el-form-item label="提供商" required>
          <el-select v-model="modelForm.provider" placeholder="选择提供商" style="width: 100%">
            <el-option label="OpenAI" value="openai" />
            <el-option label="Azure OpenAI" value="azure" />
            <el-option label="百度文心" value="baidu" />
            <el-option label="阿里通义" value="alibaba" />
            <el-option label="本地模型" value="local" />
            <el-option label="其他" value="other" />
          </el-select>
        </el-form-item>
        <el-form-item label="模型名" required>
          <el-input v-model="modelForm.model_id" placeholder="如：gpt-4o" />
        </el-form-item>
        <el-form-item label="API Key" required>
          <el-input v-model="modelForm.api_key" placeholder="sk-..." show-password />
        </el-form-item>
        <el-form-item label="Base URL">
          <el-input v-model="modelForm.base_url" placeholder="https://api.openai.com/v1" />
        </el-form-item>
        <el-form-item label="Temperature">
          <el-slider v-model="modelForm.temperature" :min="0" :max="2" :step="0.1" show-input />
        </el-form-item>
        <el-form-item label="Max Tokens">
          <el-input-number v-model="modelForm.max_tokens" :min="256" :max="16384" :step="256" />
        </el-form-item>
        <el-form-item label="设为默认">
          <el-switch v-model="modelForm.is_default" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="modelDialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="modelSaving" @click="handleSaveModel">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { Plus } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import PageHeader from '@/components/common/PageHeader.vue'
import * as modelConfigApi from '@/api/modelConfig'
import type { ModelConfig, RagConfig, ModelTestResponse } from '@/types/model'

const activeTab = ref('models')

// 模型配置
const modelConfigs = ref<ModelConfig[]>([])
const modelsLoading = ref(false)
const modelDialogVisible = ref(false)
const editingModel = ref<ModelConfig | null>(null)
const modelSaving = ref(false)
const testingId = ref<number | null>(null)
const testResult = ref<ModelTestResponse | null>(null)

const modelForm = reactive({
  name: '',
  provider: '',
  model_id: '',
  api_key: '',
  base_url: '',
  temperature: 0.7,
  max_tokens: 4096,
  is_default: false
})

// RAG配置
const ragConfig = reactive<Partial<RagConfig>>({
  chunk_size: 512,
  chunk_overlap: 50,
  top_k: 5,
  score_threshold: 0.3,
  retrieval_strategy: 'similarity',
  mmr_lambda: 0.7,
  rerank_enabled: false,
  system_prompt: ''
})
const ragSaving = ref(false)

async function fetchModels() {
  modelsLoading.value = true
  try {
    const res = await modelConfigApi.getModelConfigs({ page: 1, page_size: 50 })
    modelConfigs.value = res.data.items
  } catch { /* handled */ }
  finally { modelsLoading.value = false }
}

async function fetchRagConfig() {
  try {
    const res = await modelConfigApi.getRagConfig()
    Object.assign(ragConfig, res.data)
  } catch { /* use defaults */ }
}

function openModelDialog(model?: ModelConfig) {
  testResult.value = null
  if (model) {
    editingModel.value = model
    modelForm.name = model.name
    modelForm.provider = model.provider
    modelForm.model_id = model.model_id
    modelForm.api_key = model.api_key
    modelForm.base_url = model.base_url
    modelForm.temperature = model.temperature
    modelForm.max_tokens = model.max_tokens
    modelForm.is_default = model.is_default
  } else {
    editingModel.value = null
    modelForm.name = ''
    modelForm.provider = ''
    modelForm.model_id = ''
    modelForm.api_key = ''
    modelForm.base_url = ''
    modelForm.temperature = 0.7
    modelForm.max_tokens = 4096
    modelForm.is_default = false
  }
  modelDialogVisible.value = true
}

async function handleSaveModel() {
  if (!modelForm.name || !modelForm.provider || !modelForm.model_id) {
    ElMessage.warning('请填写必要字段')
    return
  }
  modelSaving.value = true
  try {
    if (editingModel.value) {
      await modelConfigApi.updateModelConfig(editingModel.value.id, { ...modelForm })
      ElMessage.success('模型配置已更新')
    } else {
      await modelConfigApi.createModelConfig({ ...modelForm })
      ElMessage.success('模型配置已创建')
    }
    modelDialogVisible.value = false
    fetchModels()
  } finally { modelSaving.value = false }
}

async function handleDeleteModel(model: ModelConfig) {
  try {
    await modelConfigApi.deleteModelConfig(model.id)
    ElMessage.success('已删除')
    fetchModels()
  } catch { /* handled */ }
}

async function handleToggleModel(model: ModelConfig, active: boolean) {
  try {
    await modelConfigApi.updateModelConfig(model.id, { is_active: active })
    model.is_active = active
    ElMessage.success(active ? '已启用' : '已停用')
  } catch { /* handled */ }
}

async function handleTestModel(model: ModelConfig) {
  testingId.value = model.id
  testResult.value = null
  try {
    const res = await modelConfigApi.testModel({ model_id: model.id, prompt: '你好，请回复OK' })
    testResult.value = res.data
  } catch {
    testResult.value = { success: false, response: '', latency_ms: 0, token_count: 0, error: '测试请求失败' }
  } finally { testingId.value = null }
}

async function handleSaveRagConfig() {
  ragSaving.value = true
  try {
    await modelConfigApi.updateRagConfig(ragConfig)
    ElMessage.success('RAG 配置已保存')
  } finally { ragSaving.value = false }
}

onMounted(() => {
  fetchModels()
  fetchRagConfig()
})
</script>

<style scoped>
.toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.section-title {
  font-size: 16px;
  font-weight: 600;
  color: #303133;
}

.form-tip {
  font-size: 12px;
  color: #909399;
  margin-top: 4px;
}
</style>
