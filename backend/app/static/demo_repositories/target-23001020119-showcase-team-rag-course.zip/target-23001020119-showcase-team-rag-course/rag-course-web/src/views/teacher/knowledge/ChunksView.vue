﻿<template>
  <div class="page-container">
    <PageHeader title="知识块全局视图" description="浏览和搜索所有知识块" />

    <el-card shadow="never">
      <div class="toolbar">
        <el-input
          v-model="searchKeyword"
          placeholder="搜索知识块内容"
          clearable
          style="width: 320px"
          @clear="handleSearch"
          @keyup.enter="handleSearch"
        >
          <template #prefix><el-icon><Search /></el-icon></template>
        </el-input>
        <el-select v-model="chapterFilter" placeholder="选择章节" clearable style="width: 200px" @change="handleSearch">
          <el-option v-for="ch in chapterList" :key="ch.id" :label="ch.title" :value="ch.id" />
        </el-select>
        <el-select v-model="documentFilter" placeholder="选择文档" clearable filterable style="width: 240px" @change="handleSearch">
          <el-option v-for="d in documentList" :key="d.id" :label="d.title" :value="d.id" />
        </el-select>
      </div>

      <el-table :data="chunks" v-loading="loading" stripe border row-key="id">
        <el-table-column type="expand">
          <template #default="{ row }">
            <div class="chunk-expand-content">
              <p class="chunk-full-text">{{ row.content }}</p>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="所属文档" min-width="200">
          <template #default="{ row }">
            <span class="doc-title">{{ row.document_title || getDocumentName(row.document_id) }}</span>
          </template>
        </el-table-column>
        <el-table-column type="index" label="编号" width="70" />
        <el-table-column prop="content" label="标题" min-width="250">
          <template #default="{ row }">
            <span class="chunk-text">{{ truncate(row.content, 60) }}</span>
          </template>
        </el-table-column>
        <el-table-column label="页码" width="90" align="center">
          <template #default="{ row }">
            {{ row.start_page != null ? `${row.start_page}` : '-' }}
          </template>
        </el-table-column>
        <el-table-column prop="token_count" label="Token" width="80" align="center" />
        <el-table-column label="状态" width="90" align="center">
          <template #default="{ row }">
            <el-tag :type="row.enabled ? 'success' : 'info'" size="small">
              {{ row.enabled ? '启用' : '禁用' }}
            </el-tag>
          </template>
        </el-table-column>
      </el-table>

      <Pagination
        v-model:page="pagination.page"
        v-model:page-size="pagination.pageSize"
        :total="pagination.total"
        @change="fetchChunks"
      />
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { Search } from '@element-plus/icons-vue'
import PageHeader from '@/components/common/PageHeader.vue'
import Pagination from '@/components/common/Pagination.vue'
import * as documentApi from '@/api/document'
import * as courseApi from '@/api/course'
import { truncate } from '@/utils/format'
import type { Chunk, Document } from '@/types/document'
import type { Chapter } from '@/types/course'

const loading = ref(false)
const chunks = ref<Chunk[]>([])
const chapterList = ref<Chapter[]>([])
const documentList = ref<Document[]>([])
const searchKeyword = ref('')
const chapterFilter = ref<number | ''>('')
const documentFilter = ref<number | ''>('')
const pagination = reactive({ page: 1, pageSize: 20, total: 0 })

function getDocumentName(id: number) {
  return documentList.value.find((d) => d.id === id)?.title || `文档#${id}`
}

async function fetchChunks() {
  loading.value = true
  try {
    // 使用已有API获取全局视图
    const courseId = 1 // 默认使用第一门课程
    const res = await documentApi.getDocuments(courseId, {
      page: 1,
      page_size: 100,
      keyword: searchKeyword.value || undefined
    })
    documentList.value = res.data.items

    // 获取每个文档的chunks
    const allChunks: Chunk[] = []
    for (const doc of res.data.items.slice(0, 20)) {
      try {
        const chunkRes = await documentApi.getDocumentChunks(doc.id, {
          page: 1, page_size: 50
        })
        chunkRes.data.items.forEach((c) => {
          ;(c as any).document_title = doc.title
        })
        allChunks.push(...chunkRes.data.items)
      } catch { /* skip */ }
    }

    // 客户端过滤和分页
    let filtered = allChunks
    if (documentFilter.value) {
      filtered = filtered.filter((c) => c.document_id === documentFilter.value)
    }
    if (searchKeyword.value) {
      const kw = searchKeyword.value.toLowerCase()
      filtered = filtered.filter((c) => c.content.toLowerCase().includes(kw))
    }

    pagination.total = filtered.length
    const start = (pagination.page - 1) * pagination.pageSize
    chunks.value = filtered.slice(start, start + pagination.pageSize)
  } catch { /* handled */ }
  finally { loading.value = false }
}

function handleSearch() {
  pagination.page = 1
  fetchChunks()
}

onMounted(() => {
  fetchChunks()
})
</script>

<style scoped>
.toolbar {
  display: flex;
  gap: 12px;
  margin-bottom: 16px;
}

.chunk-text {
  font-size: 13px;
  color: #606266;
}

.doc-title {
  font-size: 13px;
  color: #409EFF;
}

.chunk-expand-content {
  padding: 12px 20px;
  background: #FAFAFA;
  border-radius: 6px;
  margin: 0 20px;
}

.chunk-full-text {
  font-size: 14px;
  line-height: 1.8;
  color: #303133;
  white-space: pre-wrap;
  margin: 0;
}
</style>
