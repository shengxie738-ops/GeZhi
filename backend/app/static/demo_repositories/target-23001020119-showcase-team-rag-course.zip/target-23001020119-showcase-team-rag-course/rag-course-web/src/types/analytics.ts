/** 分析概览 */
export interface AnalyticsOverview {
  total_students: number
  total_documents: number
  total_chunks: number
  total_questions: number
  total_chat_sessions: number
  active_students_today: number
  avg_response_latency: number
  avg_answer_quality: number
  daily_stats: DailyStat[]
}

/** 每日统计 */
export interface DailyStat {
  date: string
  questions: number
  chat_sessions: number
  active_users: number
  avg_latency: number
}

/** 热门问题 */
export interface HotQuestion {
  id: number
  question: string
  count: number
  avg_score: number
  related_documents: string[]
}

/** 未解决问题 */
export interface UnresolvedQuestion {
  id: number
  question: string
  asked_by: string
  asked_at: string
  answer_count: number
  view_count: number
  priority: 'high' | 'medium' | 'low'
}

/** 知识缺口 */
export interface KnowledgeGap {
  topic: string
  gap_score: number
  related_questions: string[]
  related_documents: string[]
  suggestion: string
}

/** 文档使用统计 */
export interface DocumentUsage {
  document_id: number
  document_title: string
  citation_count: number
  avg_relevance_score: number
}

/** 模型使用统计 */
export interface ModelUsage {
  model_name: string
  total_calls: number
  avg_latency: number
  avg_tokens: number
  success_rate: number
  daily_usage: { date: string; count: number }[]
}
