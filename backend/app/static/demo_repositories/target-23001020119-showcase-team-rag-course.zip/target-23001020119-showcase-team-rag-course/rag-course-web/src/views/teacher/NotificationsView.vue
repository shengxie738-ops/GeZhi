﻿<template>
  <div class="page-container">
    <PageHeader title="通知" description="查看系统通知和消息">
      <el-button @click="handleMarkAllRead">全部标记已读</el-button>
    </PageHeader>

    <el-card shadow="never">
      <el-tabs v-model="activeTab" @tab-change="handleTabChange">
        <el-tab-pane label="全部" name="all" />
        <el-tab-pane label="未读" name="unread" />
        <el-tab-pane label="已读" name="read" />
      </el-tabs>

      <div class="notification-list">
        <div
          v-for="notification in notifications"
          :key="notification.id"
          class="notification-item"
          :class="{ unread: !notification.is_read }"
          @click="handleClick(notification)"
        >
          <div class="notification-icon">
            <el-icon :size="20" :style="{ color: getIconColor(notification.type) }">
              <component :is="getIconComponent(notification.type)" />
            </el-icon>
          </div>
          <div class="notification-body">
            <div class="notification-title">{{ notification.title }}</div>
            <div class="notification-content">{{ notification.content }}</div>
            <div class="notification-time">{{ formatRelativeTime(notification.created_at) }}</div>
          </div>
          <div class="notification-actions">
            <el-button
              v-if="!notification.is_read"
              type="primary" link size="small"
              @click.stop="handleMarkRead(notification)"
            >标记已读</el-button>
          </div>
        </div>
        <el-empty v-if="notifications.length === 0 && !loading" description="暂无通知" />
      </div>

      <Pagination
        v-model:page="pagination.page"
        v-model:page-size="pagination.pageSize"
        :total="pagination.total"
        @change="fetchNotifications"
      />
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import {
  Bell, Message, Document, SuccessFilled, WarningFilled, CircleCloseFilled, InfoFilled
} from '@element-plus/icons-vue'
import PageHeader from '@/components/common/PageHeader.vue'
import Pagination from '@/components/common/Pagination.vue'
import * as notificationApi from '@/api/notification'
import { formatRelativeTime } from '@/utils/format'
import type { Notification, NotificationType } from '@/types/notification'

const loading = ref(false)
const notifications = ref<Notification[]>([])
const activeTab = ref('all')
const pagination = reactive({ page: 1, pageSize: 20, total: 0 })

const iconMap: Record<NotificationType, any> = {
  system: InfoFilled,
  course_invite: Bell,
  question_answered: Message,
  answer_accepted: SuccessFilled,
  document_parsed: Document,
  document_failed: CircleCloseFilled,
  job_completed: SuccessFilled,
  job_failed: WarningFilled
}

const colorMap: Record<NotificationType, string> = {
  system: '#409EFF',
  course_invite: '#E6A23C',
  question_answered: '#67C23A',
  answer_accepted: '#67C23A',
  document_parsed: '#409EFF',
  document_failed: '#F56C6C',
  job_completed: '#67C23A',
  job_failed: '#F56C6C'
}

function getIconComponent(type: NotificationType) {
  return iconMap[type] || Bell
}

function getIconColor(type: NotificationType) {
  return colorMap[type] || '#909399'
}

async function fetchNotifications() {
  loading.value = true
  try {
    const params: any = {
      page: pagination.page,
      page_size: pagination.pageSize
    }
    if (activeTab.value === 'unread') params.is_read = false
    if (activeTab.value === 'read') params.is_read = true

    const res = await notificationApi.getNotifications(params)
    notifications.value = res.data.items
    pagination.total = res.data.total
  } catch { /* handled */ }
  finally { loading.value = false }
}

function handleTabChange() {
  pagination.page = 1
  fetchNotifications()
}

async function handleMarkRead(notification: Notification) {
  try {
    await notificationApi.markRead(notification.id)
    notification.is_read = true
  } catch { /* handled */ }
}

async function handleMarkAllRead() {
  try {
    await notificationApi.markAllRead()
    notifications.value.forEach((n) => { n.is_read = true })
  } catch { /* handled */ }
}

function handleClick(notification: Notification) {
  if (!notification.is_read) {
    handleMarkRead(notification)
  }
  if (notification.link) {
    // 可在此跳转
  }
}

onMounted(() => {
  fetchNotifications()
})
</script>

<style scoped>
.notification-list {
  display: flex;
  flex-direction: column;
}

.notification-item {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  padding: 16px;
  border-bottom: 1px solid #F2F6FC;
  cursor: pointer;
  transition: background-color 0.2s;
}

.notification-item:hover {
  background-color: #FAFAFA;
}

.notification-item.unread {
  background-color: #F0F9FF;
}

.notification-icon {
  flex-shrink: 0;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: #F5F7FA;
  display: flex;
  align-items: center;
  justify-content: center;
}

.notification-body {
  flex: 1;
  min-width: 0;
}

.notification-title {
  font-size: 14px;
  font-weight: 500;
  color: #303133;
  margin-bottom: 4px;
}

.notification-content {
  font-size: 13px;
  color: #606266;
  line-height: 1.5;
  margin-bottom: 4px;
}

.notification-time {
  font-size: 12px;
  color: #C0C4CC;
}

.notification-actions {
  flex-shrink: 0;
}
</style>
