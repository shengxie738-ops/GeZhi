﻿﻿<template>
  <div class="documents-view">
    <PageHeader title="文档浏览" description="浏览课程中的知识库文档" />

    <div class="documents-content">
      <!-- 筛选栏 -->
      <div class="filter-bar">
        <el-select v-model="selectedCourseId" placeholder="选择课程" clearable style="width: 200px">
          <el-option
            v-for="course in courses"
            :key="course.id"
            :label="course.name"
            :value="course.id"
          />
        </el-select>
        <el-select v-model="filterType" placeholder="文件类型" clearable style="width: 140px">
          <el-option label="PDF" value="pdf" />
          <el-option label="DOCX" value="docx" />
          <el-option label="Markdown" value="md" />
          <el-option label="TXT" value="txt" />
        </el-select>
        <el-select v-model="filterStatus" placeholder="解析状态" clearable style="width: 140px">
          <el-option label="等待解析" value="pending" />
          <el-option label="解析中" value="parsing" />
          <el-option label="已解析" value="parsed" />
          <el-option label="已索引" value="indexed" />
          <el-option label="解析失败" value="failed" />
        </el-select>
      </div>

      <!-- 文档表格 -->
      <div class="table-card">
        <el-table :data="documents" v-loading="loading" stripe>
          <el-table-column label="标题" min-width="240" show-overflow-tooltip>
            <template #default="{ row }">
              <div class="doc-title-cell">
                <el-icon class="doc-icon" :class="getTypeClass(row.file_type)">
                  <Document />
                </el-icon>
                <span class="doc-title link-text" @click="router.push(`/student/documents/${row.id}`)">
                  {{ row.title }}
                </span>
              </div>
            </template>
          </el-table-column>

          <el-table-column label="类型" width="90" align="center">
            <template #default="{ row }">
              <el-tag size="small" :type="getTypeTagType(row.file_type)">
                {{ row.file_type?.toUpperCase() }}
              </el-tag>
            </template>
          </el-table-column>

          <el-table-column label="所属章节" width="140" show-overflow-tooltip>
            <template #default="{ row }">
              {{ row.metadata?.chapter || '-' }}
            </template>
          </el-table-column>

          <el-table-column label="页数" width="70" align="center">
            <template #default="{ row }">
              {{ row.metadata?.pages || '-' }}
            </template>
          </el-table-column>

          <el-table-column label="分块数" width="80" align="center">
            <template #default="{ row }">
              {{ row.chunk_count }}
            </template>
          </el-table-column>

          <el-table-column label="状态" width="100" align="center">
            <template #default="{ row }">
              <StatusTag :value="row.parse_status" type="parse" />
            </template>
          </el-table-column>

          <el-table-column label="大小" width="100" align="center">
            <template #default="{ row }">
              {{ formatFileSize(row.file_size) }}
            </template>
          </el-table-column>

          <el-table-column label="上传时间" width="160">
            <template #default="{ row }">
              {{ formatDate(row.created_at) }}
            </template>
          </el-table-column>
        </el-table>

        <Pagination
          v-if="total > 0"
          :total="total"
          :page="page"
          :page-size="pageSize"
          @change="handlePageChange"
        />

        <el-empty v-if="!loading && documents.length === 0" description="暂无文档" />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, watch, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { Document } from '@element-plus/icons-vue'
import { getCourses } from '@/api/course'
import { getDocuments } from '@/api/document'
import { formatDate, formatFileSize } from '@/utils/format'
import type { Course } from '@/types/course'
import type { Document as DocType } from '@/types/document'
import PageHeader from '@/components/common/PageHeader.vue'
import StatusTag from '@/components/common/StatusTag.vue'
import Pagination from '@/components/common/Pagination.vue'

const router = useRouter()

const loading = ref(false)
const courses = ref<Course[]>([])
const documents = ref<DocType[]>([])
const total = ref(0)
const page = ref(1)
const pageSize = ref(20)

const selectedCourseId = ref<number | undefined>()
const filterType = ref('')
const filterStatus = ref('')

async function fetchCourses() {
  try {
    const res = await getCourses({ page: 1, page_size: 100 })
    courses.value = res.data.items || []
    if (courses.value.length > 0) {
      selectedCourseId.value = courses.value[0].id
    }
  } catch { /* 忽略 */ }
}

async function fetchDocuments() {
  if (!selectedCourseId.value) {
    documents.value = []
    total.value = 0
    return
  }
  loading.value = true
  try {
    const res = await getDocuments(selectedCourseId.value, {
      page: page.value,
      page_size: pageSize.value,
      status: filterStatus.value || undefined
    })
    documents.value = res.data.items || []
    total.value = res.data.total || 0
  } catch {
    // 错误已处理
  } finally {
    loading.value = false
  }
}

function handlePageChange(newPage: number, newPageSize: number) {
  page.value = newPage
  pageSize.value = newPageSize
  fetchDocuments()
}

function getTypeClass(fileType: string): string {
  const map: Record<string, string> = { pdf: 'icon-pdf', docx: 'icon-doc', md: 'icon-md', txt: 'icon-txt' }
  return map[fileType?.toLowerCase()] || ''
}

function getTypeTagType(fileType: string): string {
  const map: Record<string, string> = { pdf: 'danger', docx: 'primary', md: 'success', txt: 'info' }
  return map[fileType?.toLowerCase()] || 'info'
}

watch(selectedCourseId, () => {
  page.value = 1
  fetchDocuments()
})

watch([filterType, filterStatus], () => {
  page.value = 1
  fetchDocuments()
})

onMounted(() => {
  fetchCourses()
})
</script>

<style scoped>
.documents-view {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.filter-bar {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
}

.table-card {
  background: #fff;
  border-radius: 10px;
  padding: 20px;
}

.doc-title-cell {
  display: flex;
  align-items: center;
  gap: 8px;
}

.doc-icon {
  font-size: 18px;
  flex-shrink: 0;
}

.icon-pdf { color: #f56c6c; }
.icon-doc { color: #409eff; }
.icon-md { color: #67c23a; }
.icon-txt { color: #909399; }

.doc-title {
  font-size: 14px;
  font-weight: 500;
}

.link-text {
  color: #409eff;
  cursor: pointer;
}

.link-text:hover {
  text-decoration: underline;
}
</style>
