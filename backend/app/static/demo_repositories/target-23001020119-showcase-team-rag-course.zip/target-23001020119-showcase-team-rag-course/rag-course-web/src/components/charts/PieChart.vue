<template>
  <div ref="chartRef" class="pie-chart"></div>
</template>

<script setup lang="ts">
import { ref, watch, onMounted, onBeforeUnmount, shallowRef } from 'vue'
import * as echarts from 'echarts'
import type { EChartsOption } from 'echarts'

const props = withDefaults(
  defineProps<{
    title?: string
    data: { name: string; value: number }[]
    roseType?: string
    radius?: string | string[]
    height?: string
  }>(),
  {
    title: '',
    roseType: '',
    radius: () => ['40%', '70%'],
    height: '300px'
  }
)

const chartRef = ref<HTMLElement>()
const chart = shallowRef<echarts.ECharts>()

function initChart() {
  if (!chartRef.value) return
  chart.value = echarts.init(chartRef.value)
  updateChart()

  const observer = new ResizeObserver(() => {
    chart.value?.resize()
  })
  observer.observe(chartRef.value)
}

function updateChart() {
  if (!chart.value) return

  const option: EChartsOption = {
    title: props.title ? { text: props.title, left: 'center' } : undefined,
    tooltip: {
      trigger: 'item',
      formatter: '{b}: {c} ({d}%)'
    },
    legend: {
      bottom: 0,
      type: 'scroll'
    },
    series: [
      {
        type: 'pie',
        radius: props.radius,
        center: props.title ? ['50%', '55%'] : ['50%', '50%'],
        roseType: props.roseType || undefined,
        data: props.data,
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.3)'
          }
        },
        label: {
          formatter: '{b}\n{d}%'
        }
      }
    ]
  }

  chart.value.setOption(option, true)
}

watch(
  () => props.data,
  () => updateChart(),
  { deep: true }
)

onMounted(() => initChart())

onBeforeUnmount(() => {
  chart.value?.dispose()
})
</script>

<style scoped>
.pie-chart {
  width: 100%;
  height: v-bind(height);
}
</style>
