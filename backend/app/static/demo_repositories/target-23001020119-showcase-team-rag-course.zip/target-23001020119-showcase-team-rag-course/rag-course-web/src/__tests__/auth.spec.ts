import { describe, it, expect, vi, beforeEach } from 'vitest'
import { mount } from '@vue/test-utils'
import { createTestingPinia } from '@pinia/testing'
import { createRouter, createWebHistory } from 'vue-router'
import ElementPlus from 'element-plus'
import LoginView from '@/views/auth/LoginView.vue'
import { useAuthStore } from '@/stores/auth'

// Mock the auth API
vi.mock('@/api/auth', () => ({
  login: vi.fn(),
  register: vi.fn(),
  logout: vi.fn(),
  getProfile: vi.fn(),
  refreshToken: vi.fn(),
  updateProfile: vi.fn(),
  changePassword: vi.fn()
}))

const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/login', name: 'Login', component: LoginView },
    { path: '/student/dashboard', name: 'StudentDashboard', component: { template: '<div>Dashboard</div>' } },
    { path: '/teacher/dashboard', name: 'TeacherDashboard', component: { template: '<div>Dashboard</div>' } },
    { path: '/admin/dashboard', name: 'AdminDashboard', component: { template: '<div>Dashboard</div>' } }
  ]
})

describe('LoginView', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    localStorage.clear()
  })

  it('渲染登录表单', () => {
    const wrapper = mount(LoginView, {
      global: {
        plugins: [
          router,
          ElementPlus,
          createTestingPinia({ createSpy: vi.fn })
        ]
      }
    })

    // 检查标题
    expect(wrapper.text()).toContain('RAG Course')
    expect(wrapper.text()).toContain('人工智能技术基础课程')

    // 检查表单元素
    const inputs = wrapper.findAll('input')
    expect(inputs.length).toBeGreaterThanOrEqual(2)

    // 检查登录按钮
    const loginBtn = wrapper.find('.login-btn')
    expect(loginBtn.exists()).toBe(true)
    expect(loginBtn.text()).toContain('登录')

    // 检查注册链接
    expect(wrapper.text()).toContain('还没有账号')
    expect(wrapper.text()).toContain('立即注册')
  })

  it('空表单提交验证', async () => {
    const wrapper = mount(LoginView, {
      global: {
        plugins: [
          router,
          ElementPlus,
          createTestingPinia({ createSpy: vi.fn })
        ]
      }
    })

    // 尝试点击登录按钮（空表单）
    const loginBtn = wrapper.find('.login-btn')
    await loginBtn.trigger('click')

    // 表单不应被提交（因为有验证规则）
    const authStore = useAuthStore()
    expect(authStore.login).not.toHaveBeenCalled()
  })

  it('填写表单后成功登录跳转', async () => {
    const { login } = await import('@/api/auth')
    const mockLogin = vi.mocked(login)
    mockLogin.mockResolvedValue({
      code: 0,
      message: 'success',
      data: {
        access_token: 'mock-token',
        refresh_token: 'mock-refresh-token',
        token_type: 'Bearer',
        expires_in: 3600,
        user: {
          id: 1,
          username: 'teacher',
          real_name: '张老师',
          role: 'teacher',
          avatar_url: null
        }
      }
    })

    const wrapper = mount(LoginView, {
      global: {
        plugins: [
          router,
          ElementPlus,
          createTestingPinia({ createSpy: vi.fn })
        ]
      }
    })

    // 填写表单
    const inputs = wrapper.findAll('input')
    await inputs[0].setValue('teacher')
    await inputs[1].setValue('Teacher@123')

    // 点击登录
    const loginBtn = wrapper.find('.login-btn')
    await loginBtn.trigger('click')

    // 等待异步操作
    await vi.dynamicImportSettled()
    await wrapper.vm.$nextTick()

    // 验证 API 被调用
    expect(mockLogin).toHaveBeenCalledWith({
      username: 'teacher',
      password: 'Teacher@123'
    })
  })
})
