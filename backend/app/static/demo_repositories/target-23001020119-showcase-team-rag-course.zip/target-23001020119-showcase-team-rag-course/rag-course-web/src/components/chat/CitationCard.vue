<template>
  <div class="citation-card" @click="expanded = !expanded">
    <div class="citation-header">
      <el-icon class="citation-icon"><Document /></el-icon>
      <span class="citation-title">{{ citation.document_title }}</span>
      <el-tag size="small" type="info" v-if="citation.page_number">
        P.{{ citation.page_number }}
      </el-tag>
      <span class="citation-score">
        相关度 {{ (citation.score * 100).toFixed(0) }}%
      </span>
      <el-icon class="expand-icon" :class="{ 'is-expanded': expanded }">
        <ArrowDown />
      </el-icon>
    </div>

    <transition name="el-zoom-in-top">
      <div v-if="expanded" class="citation-detail">
        <div class="citation-content">{{ citation.chunk_content }}</div>
        <div class="citation-actions">
          <el-button size="small" text type="primary" @click.stop="$emit('view-pdf', citation)">
            查看原文
          </el-button>
        </div>
      </div>
    </transition>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { Document, ArrowDown } from '@element-plus/icons-vue'
import type { Citation } from '@/types/chat'

defineProps<{
  citation: Citation
}>()

defineEmits<{
  'view-pdf': [citation: Citation]
}>()

const expanded = ref(false)
</script>

<style scoped>
.citation-card {
  background: #fafafa;
  border: 1px solid #ebeef5;
  border-radius: 8px;
  padding: 8px 12px;
  cursor: pointer;
  transition: all 0.2s;
}

.citation-card:hover {
  border-color: #409eff;
  background: #f0f7ff;
}

.citation-header {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
}

.citation-icon {
  color: #409eff;
  flex-shrink: 0;
}

.citation-title {
  color: #303133;
  font-weight: 500;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.citation-score {
  margin-left: auto;
  color: #67c23a;
  font-size: 12px;
  flex-shrink: 0;
}

.expand-icon {
  color: #909399;
  transition: transform 0.3s;
  flex-shrink: 0;
}

.expand-icon.is-expanded {
  transform: rotate(180deg);
}

.citation-detail {
  margin-top: 8px;
  padding-top: 8px;
  border-top: 1px solid #ebeef5;
}

.citation-content {
  font-size: 13px;
  color: #606266;
  line-height: 1.6;
  max-height: 120px;
  overflow-y: auto;
  white-space: pre-wrap;
}

.citation-actions {
  margin-top: 6px;
  display: flex;
  justify-content: flex-end;
}
</style>
