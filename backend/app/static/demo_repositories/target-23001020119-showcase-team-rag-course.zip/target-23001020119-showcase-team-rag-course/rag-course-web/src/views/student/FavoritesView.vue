﻿<template>
  <div class="favorites-view">
    <PageHeader title="我的收藏" />

    <div class="favorites-content">
      <el-tabs v-model="activeTab">
        <!-- 收藏问答 -->
        <el-tab-pane label="收藏问答" name="qa">
          <div class="favorites-list" v-loading="loadingQA">
            <div
              v-for="item in qaFavorites"
              :key="item.id"
              class="favorite-card"
            >
              <div class="fav-info">
                <div class="fav-title" @click="handleQAItemClick(item)">
                  {{ item.title }}
                </div>
                <div class="fav-meta">
                  <el-tag size="small" type="info">{{ item.source || '问答' }}</el-tag>
                  <span class="fav-time">{{ formatRelativeTime(item.created_at) }}</span>
                </div>
              </div>
              <el-button
                text
                type="danger"
                size="small"
                @click="handleRemoveFavorite('qa', item.id)"
              >
                取消收藏
              </el-button>
            </div>
            <el-empty v-if="!loadingQA && qaFavorites.length === 0" description="暂无收藏的问答" />
          </div>
        </el-tab-pane>

        <!-- 收藏文档 -->
        <el-tab-pane label="收藏文档" name="doc">
          <div class="table-card" v-loading="loadingDoc">
            <el-table :data="docFavorites" stripe>
              <el-table-column label="标题" min-width="240" show-overflow-tooltip>
                <template #default="{ row }">
                  <span class="link-text" @click="handleDocItemClick(row)">
                    {{ row.title }}
                  </span>
                </template>
              </el-table-column>
              <el-table-column label="类型" width="100" align="center">
                <template #default="{ row }">
                  <el-tag size="small">{{ row.file_type?.toUpperCase() }}</el-tag>
                </template>
              </el-table-column>
              <el-table-column label="收藏时间" width="160">
                <template #default="{ row }">
                  {{ formatDate(row.created_at) }}
                </template>
              </el-table-column>
              <el-table-column label="操作" width="120" align="center">
                <template #default="{ row }">
                  <el-button text type="danger" size="small" @click="handleRemoveFavorite('doc', row.id)">
                    取消收藏
                  </el-button>
                </template>
              </el-table-column>
            </el-table>
            <el-empty v-if="!loadingDoc && docFavorites.length === 0" description="暂无收藏的文档" />
          </div>
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { formatDate, formatRelativeTime } from '@/utils/format'
import PageHeader from '@/components/common/PageHeader.vue'

const router = useRouter()
const activeTab = ref('qa')

const loadingQA = ref(false)
const loadingDoc = ref(false)

// 收藏的问答和文档数据（需要后端API支持，这里使用模拟数据结构）
const qaFavorites = ref<any[]>([])
const docFavorites = ref<any[]>([])

// 这里模拟加载，实际需要对应的收藏API
async function fetchQAFavorites() {
  loadingQA.value = true
  try {
    // TODO: 需要收藏API支持
    qaFavorites.value = []
  } catch {
    // 忽略
  } finally {
    loadingQA.value = false
  }
}

async function fetchDocFavorites() {
  loadingDoc.value = true
  try {
    // TODO: 需要收藏API支持
    docFavorites.value = []
  } catch {
    // 忽略
  } finally {
    loadingDoc.value = false
  }
}

function handleQAItemClick(item: any) {
  if (item.question_id) {
    router.push(`/student/forum/${item.question_id}`)
  }
}

function handleDocItemClick(item: any) {
  if (item.document_id) {
    router.push(`/student/documents/${item.document_id}`)
  }
}

async function handleRemoveFavorite(type: string, id: number) {
  try {
    // TODO: 需要取消收藏API
    if (type === 'qa') {
      qaFavorites.value = qaFavorites.value.filter(i => i.id !== id)
    } else {
      docFavorites.value = docFavorites.value.filter(i => i.id !== id)
    }
    ElMessage.success('已取消收藏')
  } catch { /* 忽略 */ }
}

onMounted(() => {
  fetchQAFavorites()
  fetchDocFavorites()
})
</script>

<style scoped>
.favorites-view {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.favorites-content {
  background: #fff;
  border-radius: 10px;
  padding: 20px;
}

.favorites-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.favorite-card {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 16px;
  border: 1px solid #ebeef5;
  border-radius: 8px;
  transition: all 0.2s;
}

.favorite-card:hover {
  border-color: #409eff;
  background: #f0f7ff;
}

.fav-info {
  flex: 1;
  min-width: 0;
}

.fav-title {
  font-size: 14px;
  font-weight: 500;
  color: #303133;
  cursor: pointer;
  margin-bottom: 6px;
}

.fav-title:hover {
  color: #409eff;
}

.fav-meta {
  display: flex;
  align-items: center;
  gap: 8px;
}

.fav-time {
  font-size: 12px;
  color: #c0c4cc;
}

.table-card {
  background: transparent;
}

.link-text {
  color: #409eff;
  cursor: pointer;
}

.link-text:hover {
  text-decoration: underline;
}
</style>
