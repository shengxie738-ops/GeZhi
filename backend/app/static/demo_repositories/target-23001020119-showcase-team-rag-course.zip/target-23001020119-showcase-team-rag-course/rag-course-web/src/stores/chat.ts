import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import type { ChatSession, ChatMessage, AnswerStatus } from '@/types/chat'

export const useChatStore = defineStore('chat', () => {
  const sessions = ref<ChatSession[]>([])
  const currentSessionId = ref<number | null>(null)
  const messages = ref<ChatMessage[]>([])
  const streamingContent = ref('')
  const streamingCitations = ref<any[]>([])
  const currentStatus = ref<AnswerStatus>('completed')
  const loading = ref(false)

  const currentSession = computed(() =>
    sessions.value.find((s) => s.id === currentSessionId.value) || null
  )

  const sortedSessions = computed(() =>
    [...sessions.value].sort(
      (a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime()
    )
  )

  function setSessions(list: ChatSession[]) {
    sessions.value = list
  }

  function addSession(session: ChatSession) {
    sessions.value.unshift(session)
  }

  function setCurrentSession(sessionId: number | null) {
    currentSessionId.value = sessionId
  }

  function setMessages(list: ChatMessage[]) {
    messages.value = list
  }

  function appendMessage(message: ChatMessage) {
    messages.value.push(message)
  }

  function updateMessage(messageId: number, data: Partial<ChatMessage>) {
    const msg = messages.value.find((m) => m.id === messageId)
    if (msg) {
      Object.assign(msg, data)
    }
  }

  function startStreaming() {
    streamingContent.value = ''
    streamingCitations.value = []
    currentStatus.value = 'streaming'
  }

  function appendStreamToken(token: string) {
    streamingContent.value += token
  }

  function setStreamCitations(citations: any[]) {
    streamingCitations.value = citations
  }

  function finishStreaming(finalMessage?: ChatMessage) {
    if (finalMessage && currentSessionId.value) {
      messages.value.push(finalMessage)
    }
    streamingContent.value = ''
    streamingCitations.value = []
    currentStatus.value = 'completed'
  }

  function setError() {
    currentStatus.value = 'error'
  }

  function removeSession(sessionId: number) {
    sessions.value = sessions.value.filter((s) => s.id !== sessionId)
    if (currentSessionId.value === sessionId) {
      currentSessionId.value = sessions.value[0]?.id ?? null
    }
  }

  function clearMessages() {
    messages.value = []
    streamingContent.value = ''
    streamingCitations.value = []
  }

  return {
    sessions,
    currentSessionId,
    currentSession,
    sortedSessions,
    messages,
    streamingContent,
    streamingCitations,
    currentStatus,
    loading,
    setSessions,
    addSession,
    setCurrentSession,
    setMessages,
    appendMessage,
    updateMessage,
    startStreaming,
    appendStreamToken,
    setStreamCitations,
    finishStreaming,
    setError,
    removeSession,
    clearMessages
  }
})
