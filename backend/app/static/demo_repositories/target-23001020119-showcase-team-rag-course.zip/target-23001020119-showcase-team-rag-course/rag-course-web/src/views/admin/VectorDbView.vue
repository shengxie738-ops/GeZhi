﻿<template>
  <div class="page-container">
    <PageHeader title="向量库管理" description="Qdrant 向量数据库管理" />

    <el-row :gutter="20">
      <!-- 集合信息 -->
      <el-col :span="16">
        <el-card shadow="never">
          <template #header>
            <div class="card-header">
              <span class="card-title">集合信息</span>
              <div>
                <el-button type="primary" size="small" @click="handleRebuild">重建索引</el-button>
                <el-button type="warning" size="small" @click="handleOptimize">优化</el-button>
              </div>
            </div>
          </template>
          <el-table :data="collections" stripe border>
            <el-table-column prop="name" label="集合名称" width="200" />
            <el-table-column prop="vector_count" label="向量数量" width="120" align="center">
              <template #default="{ row }">{{ formatNumber(row.vector_count) }}</template>
            </el-table-column>
            <el-table-column prop="vector_dimensions" label="向量维度" width="120" align="center" />
            <el-table-column prop="storage_size" label="存储大小" width="120" />
            <el-table-column prop="status" label="状态" width="100">
              <template #default="{ row }">
                <el-tag :type="row.status === 'green' ? 'success' : 'warning'" size="small">
                  {{ row.status === 'green' ? '健康' : '维护中' }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="created_at" label="创建时间" width="170">
              <template #default="{ row }">{{ formatDate(row.created_at) }}</template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>

      <!-- 向量库统计 -->
      <el-col :span="8">
        <el-card shadow="never">
          <template #header><span class="card-title">统计概览</span></template>
          <div class="vector-stats">
            <StatCard title="总向量数" :value="24680" icon="data" color="#409EFF" />
            <StatCard title="今日新增" :value="156" icon="trend" color="#67C23A" style="margin-top: 16px" />
            <StatCard title="索引大小" value="3.2 GB" icon="files" color="#E6A23C" style="margin-top: 16px" />
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 最近写入记录 -->
    <el-card shadow="never" style="margin-top: 20px">
      <template #header><span class="card-title">最近向量写入记录</span></template>
      <el-table :data="recentWrites" stripe border size="small">
        <el-table-column prop="time" label="时间" width="170" />
        <el-table-column prop="document" label="文档" min-width="200" />
        <el-table-column prop="operation" label="操作" width="100">
          <template #default="{ row }">
            <el-tag size="small" :type="row.operation === '插入' ? 'success' : row.operation === '更新' ? 'warning' : 'danger'">
              {{ row.operation }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="count" label="向量数" width="100" align="center" />
        <el-table-column prop="status" label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="row.status === '成功' ? 'success' : 'danger'" size="small">
              {{ row.status }}
            </el-tag>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { ElMessage } from 'element-plus'
import PageHeader from '@/components/common/PageHeader.vue'
import StatCard from '@/components/charts/StatCard.vue'
import { formatDate, formatNumber } from '@/utils/format'

const collections = ref([
  {
    name: 'rag_chunks',
    vector_count: 24680,
    vector_dimensions: 1536,
    storage_size: '3.2 GB',
    status: 'green',
    created_at: '2024-01-15T10:00:00'
  }
])

const recentWrites = ref([
  { time: '2024-03-10 14:30:00', document: 'AI基础课件-第3章', operation: '插入', count: 45, status: '成功' },
  { time: '2024-03-10 14:15:00', document: '习题集-期中考试', operation: '插入', count: 32, status: '成功' },
  { time: '2024-03-10 13:50:00', document: 'AI基础课件-第2章', operation: '更新', count: 38, status: '成功' },
  { time: '2024-03-10 12:20:00', document: '论坛优质问答-合集', operation: '插入', count: 15, status: '成功' },
  { time: '2024-03-10 11:00:00', document: '错误的文档', operation: '删除', count: 0, status: '失败' }
])

function handleRebuild() {
  ElMessage.success('索引重建任务已提交')
}

function handleOptimize() {
  ElMessage.success('优化任务已提交')
}
</script>

<style scoped>
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.card-title {
  font-size: 16px;
  font-weight: 600;
  color: #303133;
}

.vector-stats {
  display: flex;
  flex-direction: column;
  gap: 0;
}
</style>
