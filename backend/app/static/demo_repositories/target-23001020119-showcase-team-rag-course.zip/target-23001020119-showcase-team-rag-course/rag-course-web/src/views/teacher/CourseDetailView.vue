﻿﻿<template>
  <div class="page-container">
    <PageHeader :title="course.name || '课程详情'" :description="course.description">
      <el-button @click="$router.back()">返回列表</el-button>
    </PageHeader>

    <el-tabs v-model="activeTab" type="border-card">
      <!-- 课程信息 -->
      <el-tab-pane label="课程信息" name="info">
        <el-card shadow="never">
          <el-form :model="course" label-width="100px" style="max-width: 600px">
            <el-form-item label="课程名称">
              <el-input v-model="course.name" />
            </el-form-item>
            <el-form-item label="课程代码">
              <el-input v-model="course.code" />
            </el-form-item>
            <el-form-item label="学期">
              <el-input v-model="course.semester" />
            </el-form-item>
            <el-form-item label="课程描述">
              <el-input v-model="course.description" type="textarea" :rows="3" />
            </el-form-item>
            <el-form-item label="状态">
              <el-select v-model="course.status" style="width: 100%">
                <el-option label="进行中" value="active" />
                <el-option label="已停用" value="inactive" />
                <el-option label="已归档" value="archived" />
              </el-select>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" :loading="saving" @click="handleSaveCourse">保存修改</el-button>
            </el-form-item>
          </el-form>
        </el-card>
      </el-tab-pane>

      <!-- 章节管理 -->
      <el-tab-pane label="章节管理" name="chapters">
        <el-card shadow="never">
          <div class="toolbar">
            <span class="section-title">章节列表</span>
            <el-button type="primary" size="small" @click="openChapterDialog()">
              <el-icon><Plus /></el-icon> 新增章节
            </el-button>
          </div>
          <el-table :data="chapters" row-key="id" stripe border>
            <el-table-column type="index" label="序号" width="70" />
            <el-table-column prop="title" label="章节标题" min-width="200" />
            <el-table-column prop="description" label="描述" min-width="250" show-overflow-tooltip />
            <el-table-column label="操作" width="160">
              <template #default="{ row }">
                <el-button type="primary" link size="small" @click="openChapterDialog(row)">编辑</el-button>
                <el-popconfirm title="确定删除此章节？" @confirm="handleDeleteChapter(row.id)">
                  <template #reference>
                    <el-button type="danger" link size="small">删除</el-button>
                  </template>
                </el-popconfirm>
              </template>
            </el-table-column>
          </el-table>
          <el-empty v-if="chapters.length === 0" description="暂无章节" />
        </el-card>
      </el-tab-pane>

      <!-- 成员管理 -->
      <el-tab-pane label="成员管理" name="members">
        <el-card shadow="never">
          <div class="toolbar">
            <el-input
              v-model="memberSearch"
              placeholder="搜索成员"
              clearable
              style="width: 240px"
              @clear="fetchMembers"
              @keyup.enter="fetchMembers"
            />
            <div class="invite-section">
              <el-tag v-if="inviteCode" type="success" effect="plain">
                邀请码：{{ inviteCode }}
              </el-tag>
              <el-button size="small" @click="refreshInviteCode">刷新邀请码</el-button>
            </div>
          </div>
          <el-table :data="members" v-loading="membersLoading" stripe border>
            <el-table-column label="头像" width="70">
              <template #default="{ row }">
                <el-avatar :size="32" :src="row.user.avatar">
                  {{ row.user.nickname?.[0] || 'U' }}
                </el-avatar>
              </template>
            </el-table-column>
            <el-table-column prop="user.nickname" label="姓名" width="120" />
            <el-table-column label="学号/工号" width="130">
              <template #default="{ row }">{{ row.user.student_no || '-' }}</template>
            </el-table-column>
            <el-table-column prop="role" label="角色" width="100">
              <template #default="{ row }">
                <el-tag size="small" :type="row.role === 'teaching_assistant' ? 'warning' : 'info'">
                  {{ row.role === 'teaching_assistant' ? '助教' : '学生' }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="joined_at" label="加入时间" width="170">
              <template #default="{ row }">{{ formatDate(row.joined_at) }}</template>
            </el-table-column>
            <el-table-column label="操作" width="160">
              <template #default="{ row }">
                <el-select
                  :model-value="row.role"
                  size="small"
                  style="width: 80px; margin-right: 8px"
                  @change="(val: string) => handleChangeRole(row.user_id, val)"
                >
                  <el-option label="学生" value="student" />
                  <el-option label="助教" value="teaching_assistant" />
                </el-select>
                <el-popconfirm title="确定移除该成员？" @confirm="handleRemoveMember(row.user_id)">
                  <template #reference>
                    <el-button type="danger" link size="small">移除</el-button>
                  </template>
                </el-popconfirm>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-tab-pane>

      <!-- RAG 配置 -->
      <el-tab-pane label="RAG 配置" name="rag">
        <el-card shadow="never">
          <el-form :model="ragConfig" label-width="140px" style="max-width: 700px">
            <el-divider content-position="left">检索参数</el-divider>
            <el-form-item label="chunk_size">
              <el-slider
                v-model="ragConfig.chunk_size"
                :min="100"
                :max="2000"
                :step="50"
                show-input
              />
            </el-form-item>
            <el-form-item label="chunk_overlap">
              <el-slider
                v-model="ragConfig.chunk_overlap"
                :min="0"
                :max="500"
                :step="10"
                show-input
              />
            </el-form-item>
            <el-form-item label="top_k">
              <el-input-number v-model="ragConfig.top_k" :min="1" :max="20" />
            </el-form-item>
            <el-form-item label="score_threshold">
              <el-slider
                v-model="ragConfig.score_threshold"
                :min="0"
                :max="1"
                :step="0.05"
                show-input
              />
            </el-form-item>
            <el-form-item label="检索策略">
              <el-select v-model="ragConfig.retrieval_strategy" style="width: 100%">
                <el-option label="相似度检索" value="similarity" />
                <el-option label="MMR 多样性检索" value="mmr" />
                <el-option label="混合检索" value="hybrid" />
              </el-select>
            </el-form-item>
            <el-form-item label="rerank 启用">
              <el-switch v-model="ragConfig.rerank_enabled" />
            </el-form-item>
            <el-form-item label="系统提示词">
              <el-input
                v-model="ragConfig.system_prompt"
                type="textarea"
                :rows="6"
                placeholder="设置系统角色提示词"
              />
            </el-form-item>
            <el-form-item>
              <el-button type="primary" :loading="ragSaving" @click="handleSaveRagConfig">
                保存配置
              </el-button>
            </el-form-item>
          </el-form>
        </el-card>
      </el-tab-pane>
    </el-tabs>

    <!-- 章节编辑对话框 -->
    <el-dialog
      v-model="chapterDialogVisible"
      :title="editingChapter ? '编辑章节' : '新增章节'"
      width="500px"
      :close-on-click-modal="false"
    >
      <el-form :model="chapterForm" label-width="80px">
        <el-form-item label="标题" required>
          <el-input v-model="chapterForm.title" placeholder="请输入章节标题" />
        </el-form-item>
        <el-form-item label="描述">
          <el-input v-model="chapterForm.description" type="textarea" :rows="3" placeholder="章节描述" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="chapterDialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="chapterSaving" @click="handleSaveChapter">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { Plus } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import PageHeader from '@/components/common/PageHeader.vue'
import * as courseApi from '@/api/course'
import * as modelConfigApi from '@/api/modelConfig'
import { formatDate } from '@/utils/format'
import type { Course, Chapter, CourseMember } from '@/types/course'
import type { RagConfig } from '@/types/model'

const route = useRoute()
const courseId = Number(route.params.courseId)

const activeTab = ref('info')
const course = reactive<Course>({
  id: 0, name: '', code: '', description: '', teacher_id: 0,
  teacher: {} as any, semester: '', status: 'active',
  member_count: 0, document_count: 0, created_at: '', updated_at: ''
})
const saving = ref(false)

// 章节
const chapters = ref<Chapter[]>([])
const chapterDialogVisible = ref(false)
const editingChapter = ref<Chapter | null>(null)
const chapterSaving = ref(false)
const chapterForm = reactive({ title: '', description: '' })

// 成员
const members = ref<CourseMember[]>([])
const membersLoading = ref(false)
const memberSearch = ref('')
const inviteCode = ref('')

// RAG配置
const ragConfig = reactive<Partial<RagConfig>>({
  chunk_size: 512,
  chunk_overlap: 50,
  top_k: 5,
  score_threshold: 0.3,
  retrieval_strategy: 'similarity',
  rerank_enabled: false,
  system_prompt: ''
})
const ragSaving = ref(false)

async function fetchCourse() {
  try {
    const res = await courseApi.getCourse(courseId)
    Object.assign(course, res.data)
  } catch { /* handled */ }
}

async function fetchChapters() {
  try {
    const res = await courseApi.getCourse(courseId)
    chapters.value = (res.data as any).chapters || []
  } catch { /* handled */ }
}

async function fetchMembers() {
  membersLoading.value = true
  try {
    const res = await courseApi.getMembers(courseId, {
      page: 1, page_size: 100, keyword: memberSearch.value || undefined
    })
    members.value = res.data.items
  } catch { /* handled */ }
  finally { membersLoading.value = false }
}

function refreshInviteCode() {
  inviteCode.value = Math.random().toString(36).slice(2, 10).toUpperCase()
  ElMessage.success(`邀请码已刷新：${inviteCode.value}`)
}

function openChapterDialog(chapter?: Chapter) {
  if (chapter) {
    editingChapter.value = chapter
    chapterForm.title = chapter.title
    chapterForm.description = chapter.description
  } else {
    editingChapter.value = null
    chapterForm.title = ''
    chapterForm.description = ''
  }
  chapterDialogVisible.value = true
}

async function handleSaveChapter() {
  if (!chapterForm.title.trim()) {
    ElMessage.warning('请输入章节标题')
    return
  }
  chapterSaving.value = true
  try {
    chapterDialogVisible.value = false
    fetchChapters()
  } finally {
    chapterSaving.value = false
  }
}

async function handleDeleteChapter(id: number) {
  try {
    fetchChapters()
    ElMessage.success('章节已删除')
  } catch { /* handled */ }
}

async function handleRemoveMember(userId: number) {
  try {
    await courseApi.removeMember(courseId, userId)
    ElMessage.success('成员已移除')
    fetchMembers()
  } catch { /* handled */ }
}

async function handleChangeRole(userId: number, role: string) {
  try {
    await courseApi.updateMemberRole(courseId, userId, role)
    ElMessage.success('角色已更新')
    fetchMembers()
  } catch { /* handled */ }
}

async function handleSaveCourse() {
  saving.value = true
  try {
    await courseApi.updateCourse(courseId, {
      name: course.name,
      code: course.code,
      description: course.description,
      semester: course.semester,
      status: course.status
    })
    ElMessage.success('课程信息已更新')
  } finally {
    saving.value = false
  }
}

async function handleSaveRagConfig() {
  ragSaving.value = true
  try {
    await modelConfigApi.updateRagConfig(ragConfig)
    ElMessage.success('RAG 配置已保存')
  } finally {
    ragSaving.value = false
  }
}

async function fetchRagConfig() {
  try {
    const res = await modelConfigApi.getRagConfig()
    Object.assign(ragConfig, res.data)
  } catch { /* use defaults */ }
}

onMounted(() => {
  fetchCourse()
  fetchChapters()
  fetchMembers()
  fetchRagConfig()
})
</script>

<style scoped>
.toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.section-title {
  font-size: 16px;
  font-weight: 600;
  color: #303133;
}

.invite-section {
  display: flex;
  align-items: center;
  gap: 12px;
}
</style>
