﻿<template>
  <div class="page-container">
    <PageHeader title="知识库文档管理" description="管理课程知识库文档">
      <el-button type="primary" @click="openUploadDialog">
        <el-icon><Upload /></el-icon> 上传文档
      </el-button>
    </PageHeader>

    <el-card shadow="never">
      <div class="toolbar">
        <el-input
          v-model="searchKeyword"
          placeholder="搜索文档标题"
          clearable
          style="width: 260px"
          @clear="handleSearch"
          @keyup.enter="handleSearch"
        />
        <el-select v-model="statusFilter" placeholder="状态筛选" clearable style="width: 140px" @change="handleSearch">
          <el-option label="等待解析" value="pending" />
          <el-option label="解析中" value="parsing" />
          <el-option label="已解析" value="parsed" />
          <el-option label="已索引" value="indexed" />
          <el-option label="解析失败" value="failed" />
        </el-select>
        <el-select v-model="courseFilter" placeholder="选择课程" clearable style="width: 200px" @change="handleSearch">
          <el-option v-for="c in courseList" :key="c.id" :label="c.name" :value="c.id" />
        </el-select>
      </div>

      <el-table :data="documents" v-loading="loading" stripe border>
        <el-table-column prop="title" label="文档标题" min-width="200" show-overflow-tooltip />
        <el-table-column prop="file_type" label="类型" width="80">
          <template #default="{ row }">
            <el-tag size="small" type="info">{{ row.file_type?.toUpperCase() }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="file_size" label="大小" width="100">
          <template #default="{ row }">{{ formatFileSize(row.file_size) }}</template>
        </el-table-column>
        <el-table-column prop="chunk_count" label="知识块" width="80" align="center" />
        <el-table-column prop="parse_status" label="解析状态" width="180">
          <template #default="{ row }">
            <DocumentStatusBadge
              :status="row.parse_status"
              :progress="parseProgressMap[row.id] || 0"
            />
          </template>
        </el-table-column>
        <el-table-column label="上传者" width="100">
          <template #default="{ row }">{{ row.uploader?.nickname || '-' }}</template>
        </el-table-column>
        <el-table-column prop="created_at" label="上传时间" width="170">
          <template #default="{ row }">{{ formatDate(row.created_at) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="220" fixed="right">
          <template #default="{ row }">
            <el-button type="primary" link size="small" @click="goToDetail(row.id)">查看</el-button>
            <el-button
              type="warning" link size="small"
              :disabled="row.parse_status === 'parsing' || row.parse_status === 'indexing'"
              @click="handleReparse(row)"
            >重新解析</el-button>
            <el-popconfirm title="确定删除此文档？" @confirm="handleDelete(row)">
              <template #reference>
                <el-button type="danger" link size="small">删除</el-button>
              </template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>

      <Pagination
        v-model:page="pagination.page"
        v-model:page-size="pagination.pageSize"
        :total="pagination.total"
        @change="fetchDocuments"
      />
    </el-card>

    <!-- 上传对话框 -->
    <el-dialog
      v-model="uploadDialogVisible"
      title="上传文档"
      width="560px"
      :close-on-click-modal="false"
    >
      <el-form label-width="80px">
        <el-form-item label="选择课程" required>
          <el-select v-model="uploadForm.courseId" placeholder="选择课程" style="width: 100%">
            <el-option v-for="c in courseList" :key="c.id" :label="c.name" :value="c.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="选择章节">
          <el-select v-model="uploadForm.chapterId" placeholder="选择章节（可选）" clearable style="width: 100%">
            <el-option v-for="ch in chapterList" :key="ch.id" :label="ch.title" :value="ch.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="上传文件">
          <el-upload
            ref="uploadRef"
            drag
            :auto-upload="false"
            :limit="1"
            accept=".pdf,.docx,.doc,.txt,.md"
            :on-change="handleFileChange"
            :on-exceed="handleExceed"
          >
            <el-icon :size="40" class="upload-icon"><Upload /></el-icon>
            <div class="el-upload__text">拖拽文件到此区域，或<em>点击上传</em></div>
            <template #tip>
              <div class="el-upload__tip">支持 PDF、Word、TXT、Markdown，最大 50MB</div>
            </template>
          </el-upload>
        </el-form-item>
      </el-form>
      <div v-if="uploading" style="margin-top: 12px">
        <el-progress :percentage="uploadProgress" :stroke-width="8" />
      </div>
      <template #footer>
        <el-button @click="uploadDialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="uploading" :disabled="!selectedFile" @click="handleUpload">
          上传
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { Upload } from '@element-plus/icons-vue'
import { ElMessage, type UploadFile, type UploadInstance } from 'element-plus'
import PageHeader from '@/components/common/PageHeader.vue'
import Pagination from '@/components/common/Pagination.vue'
import DocumentStatusBadge from '@/components/knowledge/DocumentStatusBadge.vue'
import * as documentApi from '@/api/document'
import * as courseApi from '@/api/course'
import { formatDate, formatFileSize } from '@/utils/format'
import type { Document } from '@/types/document'
import type { Course, Chapter } from '@/types/course'

const router = useRouter()
const loading = ref(false)
const documents = ref<Document[]>([])
const courseList = ref<Course[]>([])
const chapterList = ref<Chapter[]>([])
const searchKeyword = ref('')
const statusFilter = ref('')
const courseFilter = ref<number | ''>('')
const parseProgressMap = ref<Record<number, number>>({})

const pagination = reactive({ page: 1, pageSize: 10, total: 0 })

// 上传
const uploadDialogVisible = ref(false)
const uploading = ref(false)
const uploadProgress = ref(0)
const selectedFile = ref<File | null>(null)
const uploadRef = ref<UploadInstance>()
const uploadForm = reactive({ courseId: 0, chapterId: 0 })

async function fetchDocuments() {
  loading.value = true
  try {
    const params: any = {
      page: pagination.page,
      page_size: pagination.pageSize,
      keyword: searchKeyword.value || undefined,
      status: statusFilter.value || undefined
    }
    const courseId = courseFilter.value || uploadForm.courseId
    const res = courseId
      ? await documentApi.getDocuments(courseId, params)
      : await documentApi.getDocuments(courseList.value[0]?.id || 1, params)
    documents.value = res.data.items
    pagination.total = res.data.total
  } catch { /* handled */ }
  finally { loading.value = false }
}

async function fetchCourses() {
  try {
    const res = await courseApi.getCourses({ page: 1, page_size: 50 })
    courseList.value = res.data.items
  } catch { /* handled */ }
}

function handleSearch() {
  pagination.page = 1
  fetchDocuments()
}

function openUploadDialog() {
  selectedFile.value = null
  uploadForm.courseId = courseList.value[0]?.id || 0
  uploadForm.chapterId = 0
  uploadProgress.value = 0
  uploadDialogVisible.value = true
}

function handleFileChange(file: UploadFile) {
  selectedFile.value = file.raw || null
}

function handleExceed() {
  ElMessage.warning('只能上传一个文件')
}

async function handleUpload() {
  if (!selectedFile.value || !uploadForm.courseId) {
    ElMessage.warning('请选择课程和文件')
    return
  }
  uploading.value = true
  uploadProgress.value = 0
  try {
    await documentApi.uploadDocument(uploadForm.courseId, selectedFile.value, (percent) => {
      uploadProgress.value = percent
    })
    ElMessage.success('文档上传成功')
    uploadDialogVisible.value = false
    fetchDocuments()
  } finally {
    uploading.value = false
  }
}

async function handleReparse(doc: Document) {
  try {
    await documentApi.parseDocument(doc.id)
    ElMessage.success('已触发重新解析')
    fetchDocuments()
  } catch { /* handled */ }
}

async function handleDelete(doc: Document) {
  try {
    await documentApi.deleteDocument(doc.id)
    ElMessage.success('文档已删除')
    fetchDocuments()
  } catch { /* handled */ }
}

function goToDetail(id: number) {
  router.push(`/teacher/knowledge/documents/${id}`)
}

onMounted(() => {
  fetchCourses().then(() => fetchDocuments())
})
</script>

<style scoped>
.toolbar {
  display: flex;
  gap: 12px;
  margin-bottom: 16px;
}

.upload-icon {
  color: #909399;
}
</style>
