<template>
  <div class="file-upload">
    <el-upload
      ref="uploadRef"
      :action="uploadUrl"
      :headers="uploadHeaders"
      :accept="accept"
      :multiple="multiple"
      :limit="limit"
      :drag="drag"
      :auto-upload="autoUpload"
      :before-upload="handleBeforeUpload"
      :on-success="handleSuccess"
      :on-error="handleError"
      :on-remove="handleRemove"
      :on-change="handleChange"
      :on-exceed="handleExceed"
      :file-list="fileList"
      v-model:file-list="fileList"
    >
      <template v-if="drag">
        <el-icon class="el-icon--upload"><UploadFilled /></el-icon>
        <div class="el-upload__text">
          将文件拖到此处，或<em>点击上传</em>
        </div>
        <template #tip>
          <div class="el-upload__tip" v-if="tip">
            {{ tip }}
          </div>
        </template>
      </template>
      <template v-else>
        <el-button type="primary" :icon="Upload">
          {{ buttonText }}
        </el-button>
        <template #tip>
          <div class="el-upload__tip" v-if="tip">
            {{ tip }}
          </div>
        </template>
      </template>
    </el-upload>

    <!-- 上传进度 -->
    <div class="upload-progress" v-if="showProgress && uploading">
      <el-progress :percentage="progress" :status="progressStatus" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { ElMessage } from 'element-plus'
import { Upload, UploadFilled } from '@element-plus/icons-vue'
import { getToken } from '@/utils/auth'
import type { UploadFile, UploadRawFile, UploadProps } from 'element-plus'

const props = withDefaults(
  defineProps<{
    action?: string
    accept?: string
    multiple?: boolean
    limit?: number
    drag?: boolean
    autoUpload?: boolean
    maxSize?: number
    buttonText?: string
    tip?: string
    showProgress?: boolean
  }>(),
  {
    action: '',
    accept: '.pdf,.doc,.docx,.txt,.md',
    multiple: true,
    limit: 10,
    drag: true,
    autoUpload: true,
    maxSize: 50,
    buttonText: '选择文件',
    tip: '',
    showProgress: true
  }
)

const emit = defineEmits<{
  success: [response: any, file: UploadFile]
  error: [error: any, file: UploadFile]
  change: [fileList: UploadFile[]]
  'exceed': [files: File[]]
}>()

const uploadRef = ref()
const fileList = ref<UploadFile[]>([])
const uploading = ref(false)
const progress = ref(0)

const uploadUrl = computed(() => {
  return props.action || `${import.meta.env.VITE_API_BASE_URL}/upload`
})

const uploadHeaders = computed(() => ({
  Authorization: `Bearer ${getToken() || ''}`
}))

const progressStatus = computed(() => {
  if (progress.value === 100) return 'success'
  return undefined
})

function handleBeforeUpload(rawFile: UploadRawFile) {
  const sizeMB = rawFile.size / 1024 / 1024
  if (sizeMB > props.maxSize) {
    ElMessage.error(`文件大小不能超过 ${props.maxSize}MB`)
    return false
  }
  uploading.value = true
  progress.value = 0
  return true
}

function handleSuccess(response: any, file: UploadFile) {
  uploading.value = false
  progress.value = 100
  emit('success', response, file)
  ElMessage.success('上传成功')
}

function handleError(error: any, file: UploadFile) {
  uploading.value = false
  emit('error', error, file)
  ElMessage.error('上传失败')
}

function handleRemove(file: UploadFile) {
  emit('change', fileList.value)
}

function handleChange(file: UploadFile) {
  emit('change', fileList.value)
}

function handleExceed(files: File[]) {
  ElMessage.warning(`最多只能上传 ${props.limit} 个文件`)
  emit('exceed', files)
}

function clearFiles() {
  uploadRef.value?.clearFiles()
  fileList.value = []
}

defineExpose({ clearFiles })
</script>

<style scoped>
.file-upload {
  width: 100%;
}

.upload-progress {
  margin-top: 12px;
}

.el-upload__tip {
  color: #999;
  font-size: 12px;
  margin-top: 8px;
}
</style>
