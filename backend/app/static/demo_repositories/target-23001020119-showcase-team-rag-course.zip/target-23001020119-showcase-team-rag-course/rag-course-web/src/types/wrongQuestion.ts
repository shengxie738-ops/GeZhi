/** 错题状态 */
export type WrongQuestionStatus = 'pending' | 'mastered' | 'reviewing'

/** 错题信息 */
export interface WrongQuestion {
  id: number
  user_id: number
  course_id: number
  question: string
  answer: string
  user_answer: string
  source: string
  source_type: 'exam' | 'homework' | 'practice' | 'import'
  knowledge_tags: string[]
  status: WrongQuestionStatus
  review_count: number
  last_reviewed_at: string | null
  created_at: string
  updated_at: string
}

/** 创建错题请求 */
export interface CreateWrongQuestionRequest {
  course_id: number
  question: string
  answer: string
  user_answer: string
  source?: string
  source_type?: 'exam' | 'homework' | 'practice' | 'import'
  knowledge_tags?: string[]
}

/** 导入错题请求 */
export interface ImportWrongQuestionsRequest {
  course_id: number
  questions: CreateWrongQuestionRequest[]
}
