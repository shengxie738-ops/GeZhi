<template>
  <div class="empty-state">
    <el-empty :description="description" :image-size="imageSize">
      <template #default v-if="$slots.default">
        <slot />
      </template>
    </el-empty>
  </div>
</template>

<script setup lang="ts">
withDefaults(
  defineProps<{
    description?: string
    imageSize?: number
  }>(),
  {
    description: '暂无数据',
    imageSize: 160
  }
)
</script>

<style scoped>
.empty-state {
  padding: 40px 0;
  display: flex;
  justify-content: center;
}
</style>
