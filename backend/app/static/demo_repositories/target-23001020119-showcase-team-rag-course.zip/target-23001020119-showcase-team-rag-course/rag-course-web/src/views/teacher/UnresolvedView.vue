﻿<template>
  <div class="page-container">
    <PageHeader title="未解决问题" description="查看和处理学生未解决的提问" />

    <el-card shadow="never">
      <div class="toolbar">
        <el-input
          v-model="searchKeyword"
          placeholder="搜索问题"
          clearable
          style="width: 280px"
          @clear="handleSearch"
          @keyup.enter="handleSearch"
        />
        <div class="toolbar-right">
          <el-button
            v-if="selectedRows.length > 0"
            type="success"
            size="small"
            @click="handleBatchResolve"
          >
            批量标记已解决 ({{ selectedRows.length }})
          </el-button>
        </div>
      </div>

      <el-table
        :data="questions"
        v-loading="loading"
        stripe
        border
        @selection-change="handleSelectionChange"
      >
        <el-table-column type="selection" width="50" />
        <el-table-column prop="question" label="问题标题" min-width="300" show-overflow-tooltip />
        <el-table-column prop="asked_by" label="提问者" width="120" />
        <el-table-column prop="asked_at" label="提问时间" width="170">
          <template #default="{ row }">{{ formatDate(row.asked_at) }}</template>
        </el-table-column>
        <el-table-column prop="view_count" label="浏览" width="80" align="center" />
        <el-table-column prop="answer_count" label="回答" width="80" align="center" />
        <el-table-column prop="priority" label="优先级" width="90">
          <template #default="{ row }">
            <el-tag
              :type="row.priority === 'high' ? 'danger' : row.priority === 'medium' ? 'warning' : 'info'"
              size="small"
            >
              {{ { high: '高', medium: '中', low: '低' }[row.priority] }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="180" fixed="right">
          <template #default="{ row }">
            <el-button type="primary" link size="small" @click="quickReply(row)">快捷回答</el-button>
            <el-button type="success" link size="small" @click="handleResolve(row)">标记已解决</el-button>
          </template>
        </el-table-column>
      </el-table>

      <Pagination
        v-model:page="pagination.page"
        v-model:page-size="pagination.pageSize"
        :total="pagination.total"
        @change="fetchQuestions"
      />
    </el-card>

    <!-- 快捷回答对话框 -->
    <el-dialog
      v-model="replyDialogVisible"
      title="快捷回答"
      width="600px"
      :close-on-click-modal="false"
    >
      <div class="reply-question">
        <label>问题：</label>
        <p>{{ currentQuestion?.question }}</p>
      </div>
      <el-input
        v-model="replyContent"
        type="textarea"
        :rows="6"
        placeholder="输入您的回答..."
      />
      <template #footer>
        <el-button @click="replyDialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="replyLoading" @click="handleReply">提交回答</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import PageHeader from '@/components/common/PageHeader.vue'
import Pagination from '@/components/common/Pagination.vue'
import * as analyticsApi from '@/api/analytics'
import { formatDate } from '@/utils/format'
import type { UnresolvedQuestion } from '@/types/analytics'

const loading = ref(false)
const questions = ref<UnresolvedQuestion[]>([])
const searchKeyword = ref('')
const selectedRows = ref<UnresolvedQuestion[]>([])
const pagination = reactive({ page: 1, pageSize: 10, total: 0 })

// 快捷回答
const replyDialogVisible = ref(false)
const currentQuestion = ref<UnresolvedQuestion | null>(null)
const replyContent = ref('')
const replyLoading = ref(false)

async function fetchQuestions() {
  loading.value = true
  try {
    const res = await analyticsApi.getUnresolved(1, {
      page: pagination.page,
      page_size: pagination.pageSize,
      keyword: searchKeyword.value || undefined
    })
    questions.value = res.data.items
    pagination.total = res.data.total
  } catch { /* handled */ }
  finally { loading.value = false }
}

function handleSearch() {
  pagination.page = 1
  fetchQuestions()
}

function handleSelectionChange(selection: UnresolvedQuestion[]) {
  selectedRows.value = selection
}

function quickReply(question: UnresolvedQuestion) {
  currentQuestion.value = question
  replyContent.value = ''
  replyDialogVisible.value = true
}

async function handleReply() {
  if (!replyContent.value.trim()) {
    ElMessage.warning('请输入回答内容')
    return
  }
  replyLoading.value = true
  try {
    ElMessage.success('回答已提交')
    replyDialogVisible.value = false
    fetchQuestions()
  } finally { replyLoading.value = false }
}

async function handleResolve(question: UnresolvedQuestion) {
  ElMessage.success('已标记为已解决')
  fetchQuestions()
}

async function handleBatchResolve() {
  ElMessage.success(`已批量标记 ${selectedRows.value.length} 个问题为已解决`)
  fetchQuestions()
}

onMounted(() => {
  fetchQuestions()
})
</script>

<style scoped>
.toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.toolbar-right {
  display: flex;
  gap: 8px;
}

.reply-question {
  margin-bottom: 16px;
}

.reply-question label {
  font-size: 13px;
  color: #909399;
}

.reply-question p {
  font-size: 14px;
  color: #303133;
  margin: 4px 0 0;
  line-height: 1.6;
}
</style>
