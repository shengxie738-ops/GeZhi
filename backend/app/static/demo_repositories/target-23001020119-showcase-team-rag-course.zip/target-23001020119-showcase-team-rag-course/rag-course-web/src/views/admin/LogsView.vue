﻿<template>
  <div class="page-container">
    <PageHeader title="日志审计" description="系统操作审计日志" />

    <el-card shadow="never">
      <div class="toolbar">
        <el-date-picker
          v-model="dateRange"
          type="daterange"
          range-separator="至"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          value-format="YYYY-MM-DD"
          style="width: 280px"
          @change="fetchLogs"
        />
        <el-select v-model="userFilter" placeholder="操作用户" clearable filterable style="width: 160px" @change="fetchLogs">
          <el-option label="全部用户" value="" />
          <el-option v-for="u in userOptions" :key="u" :label="u" :value="u" />
        </el-select>
        <el-select v-model="moduleFilter" placeholder="模块" clearable style="width: 140px" @change="fetchLogs">
          <el-option label="全部" value="" />
          <el-option label="认证" value="auth" />
          <el-option label="课程" value="course" />
          <el-option label="文档" value="document" />
          <el-option label="模型" value="model" />
          <el-option label="系统" value="system" />
        </el-select>
        <el-select v-model="operationFilter" placeholder="操作类型" clearable style="width: 140px" @change="fetchLogs">
          <el-option label="全部" value="" />
          <el-option label="登录" value="login" />
          <el-option label="创建" value="create" />
          <el-option label="修改" value="update" />
          <el-option label="删除" value="delete" />
          <el-option label="上传" value="upload" />
        </el-select>
        <el-input
          v-model="keyword"
          placeholder="搜索IP或详情"
          clearable
          style="width: 220px"
          @clear="fetchLogs"
          @keyup.enter="fetchLogs"
        />
      </div>

      <el-table :data="logs" v-loading="loading" stripe border>
        <el-table-column prop="created_at" label="时间" width="170" />
        <el-table-column prop="user" label="用户" width="100" />
        <el-table-column prop="module" label="模块" width="100">
          <template #default="{ row }">
            <el-tag size="small" :type="moduleTagType[row.module] || 'info'">{{ moduleLabel[row.module] || row.module }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="operation" label="操作" width="100">
          <template #default="{ row }">
            <el-tag size="small" :type="operationTagType[row.operation] || 'info'">{{ operationLabel[row.operation] || row.operation }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="ip" label="IP 地址" width="140" />
        <el-table-column prop="detail" label="详情" min-width="300" show-overflow-tooltip />
        <el-table-column label="操作" width="80">
          <template #default="{ row }">
            <el-button type="primary" link size="small" @click="openDetail(row)">详情</el-button>
          </template>
        </el-table-column>
      </el-table>

      <Pagination
        v-model:page="pagination.page"
        v-model:page-size="pagination.pageSize"
        :total="pagination.total"
        @change="fetchLogs"
      />
    </el-card>

    <!-- 日志详情对话框 -->
    <el-dialog v-model="detailDialogVisible" title="日志详情" width="600px">
      <el-descriptions :column="1" border v-if="currentLog">
        <el-descriptions-item label="时间">{{ currentLog.created_at }}</el-descriptions-item>
        <el-descriptions-item label="用户">{{ currentLog.user }}</el-descriptions-item>
        <el-descriptions-item label="模块">{{ currentLog.module }}</el-descriptions-item>
        <el-descriptions-item label="操作">{{ currentLog.operation }}</el-descriptions-item>
        <el-descriptions-item label="IP 地址">{{ currentLog.ip }}</el-descriptions-item>
        <el-descriptions-item label="User Agent">{{ currentLog.userAgent || '-' }}</el-descriptions-item>
        <el-descriptions-item label="请求方法">{{ currentLog.method || '-' }}</el-descriptions-item>
        <el-descriptions-item label="请求路径">{{ currentLog.path || '-' }}</el-descriptions-item>
        <el-descriptions-item label="详情">{{ currentLog.detail }}</el-descriptions-item>
      </el-descriptions>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import PageHeader from '@/components/common/PageHeader.vue'
import Pagination from '@/components/common/Pagination.vue'
import { formatDate } from '@/utils/format'

interface LogEntry {
  id: number
  created_at: string
  user: string
  module: string
  operation: string
  ip: string
  detail: string
  userAgent?: string
  method?: string
  path?: string
}

const loading = ref(false)
const logs = ref<LogEntry[]>([])
const dateRange = ref<[string, string] | null>(null)
const userFilter = ref('')
const moduleFilter = ref('')
const operationFilter = ref('')
const keyword = ref('')
const userOptions = ref(['张三', '李老师', '管理员', '王五', '系统'])
const pagination = reactive({ page: 1, pageSize: 20, total: 0 })

const detailDialogVisible = ref(false)
const currentLog = ref<LogEntry | null>(null)

const moduleLabel: Record<string, string> = { auth: '认证', course: '课程', document: '文档', model: '模型', system: '系统' }
const moduleTagType: Record<string, string> = { auth: 'primary', course: 'success', document: 'warning', model: 'info', system: 'danger' }
const operationLabel: Record<string, string> = { login: '登录', create: '创建', update: '修改', delete: '删除', upload: '上传' }
const operationTagType: Record<string, string> = { login: 'primary', create: 'success', update: 'warning', delete: 'danger', upload: 'info' }

// Mock数据
const mockLogs: LogEntry[] = [
  { id: 1, created_at: '2024-03-10 14:30:00', user: '张三', module: 'auth', operation: 'login', ip: '192.168.1.100', detail: '用户张三登录系统', userAgent: 'Mozilla/5.0', method: 'POST', path: '/api/auth/login' },
  { id: 2, created_at: '2024-03-10 14:15:00', user: '李老师', module: 'document', operation: 'upload', ip: '192.168.1.101', detail: '上传文档《AI基础课件-第3章》', method: 'POST', path: '/api/documents/upload' },
  { id: 3, created_at: '2024-03-10 13:50:00', user: '管理员', module: 'model', operation: 'create', ip: '192.168.1.1', detail: '新增模型配置 GPT-4o', method: 'POST', path: '/api/models' },
  { id: 4, created_at: '2024-03-10 12:20:00', user: '王五', module: 'course', operation: 'create', ip: '192.168.1.102', detail: '创建课程《机器学习实践》', method: 'POST', path: '/api/courses' },
  { id: 5, created_at: '2024-03-10 11:00:00', user: '系统', module: 'system', operation: 'update', ip: '127.0.0.1', detail: '自动清理过期缓存' },
  { id: 6, created_at: '2024-03-10 10:30:00', user: '张三', module: 'document', operation: 'delete', ip: '192.168.1.100', detail: '删除文档《过期资料》', method: 'DELETE', path: '/api/documents/42' }
]

async function fetchLogs() {
  loading.value = true
  try {
    // 使用mock数据
    let filtered = [...mockLogs]
    if (moduleFilter.value) filtered = filtered.filter((l) => l.module === moduleFilter.value)
    if (operationFilter.value) filtered = filtered.filter((l) => l.operation === operationFilter.value)
    if (userFilter.value) filtered = filtered.filter((l) => l.user === userFilter.value)
    if (keyword.value) {
      const kw = keyword.value.toLowerCase()
      filtered = filtered.filter((l) => l.ip.includes(kw) || l.detail.toLowerCase().includes(kw))
    }
    pagination.total = filtered.length
    const start = (pagination.page - 1) * pagination.pageSize
    logs.value = filtered.slice(start, start + pagination.pageSize)
  } finally { loading.value = false }
}

function openDetail(log: LogEntry) {
  currentLog.value = log
  detailDialogVisible.value = true
}

onMounted(() => { fetchLogs() })
</script>

<style scoped>
.toolbar {
  display: flex;
  gap: 12px;
  margin-bottom: 16px;
  flex-wrap: wrap;
}
</style>
