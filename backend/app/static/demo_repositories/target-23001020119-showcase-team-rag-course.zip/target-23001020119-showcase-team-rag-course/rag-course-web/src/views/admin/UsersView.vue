﻿<template>
  <div class="page-container">
    <PageHeader title="用户管理" description="管理系统用户账号与权限">
      <el-button type="primary" @click="openUserDialog()">
        <el-icon><Plus /></el-icon> 新增用户
      </el-button>
    </PageHeader>

    <el-card shadow="never">
      <div class="toolbar">
        <el-input
          v-model="searchKeyword"
          placeholder="搜索姓名、用户名、学号"
          clearable
          style="width: 300px"
          @clear="handleSearch"
          @keyup.enter="handleSearch"
        />
        <el-select v-model="roleFilter" placeholder="角色筛选" clearable style="width: 120px" @change="handleSearch">
          <el-option label="学生" value="student" />
          <el-option label="教师" value="teacher" />
          <el-option label="管理员" value="admin" />
        </el-select>
        <el-select v-model="statusFilter" placeholder="状态筛选" clearable style="width: 120px" @change="handleSearch">
          <el-option label="启用" value="active" />
          <el-option label="禁用" value="inactive" />
        </el-select>
      </div>

      <el-table :data="users" v-loading="loading" stripe border>
        <el-table-column label="头像" width="60">
          <template #default="{ row }">
            <el-avatar :size="32" :src="row.avatar">
              {{ row.nickname?.[0] || 'U' }}
            </el-avatar>
          </template>
        </el-table-column>
        <el-table-column prop="nickname" label="姓名" width="100" />
        <el-table-column prop="username" label="用户名" width="120" />
        <el-table-column prop="student_no" label="学号/工号" width="130" />
        <el-table-column prop="role" label="角色" width="100">
          <template #default="{ row }">
            <el-tag
              :type="row.role === 'admin' ? 'danger' : row.role === 'teacher' ? 'warning' : 'info'"
              size="small"
            >
              {{ roleMap[row.role] || row.role }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="department" label="部门/班级" width="120" show-overflow-tooltip />
        <el-table-column label="状态" width="80">
          <template #default="{ row }">
            <el-tag :type="row.is_active ? 'success' : 'info'" size="small">
              {{ row.is_active ? '启用' : '禁用' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="last_login_at" label="最后登录" width="170">
          <template #default="{ row }">{{ formatDate(row.last_login_at) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="240" fixed="right">
          <template #default="{ row }">
            <el-button type="primary" link size="small" @click="openUserDialog(row)">编辑</el-button>
            <el-button
              :type="row.is_active ? 'warning' : 'success'" link size="small"
              @click="handleToggleUser(row)"
            >{{ row.is_active ? '禁用' : '启用' }}</el-button>
            <el-popconfirm title="确定重置该用户密码？" @confirm="handleResetPassword(row)">
              <template #reference>
                <el-button type="info" link size="small">重置密码</el-button>
              </template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>

      <Pagination
        v-model:page="pagination.page"
        v-model:page-size="pagination.pageSize"
        :total="pagination.total"
        @change="fetchUsers"
      />
    </el-card>

    <!-- 新增/编辑用户对话框 -->
    <el-dialog
      v-model="dialogVisible"
      :title="editingUser ? '编辑用户' : '新增用户'"
      width="560px"
      :close-on-click-modal="false"
    >
      <el-form :model="userForm" label-width="80px">
        <el-form-item label="用户名" required>
          <el-input v-model="userForm.username" placeholder="请输入用户名" :disabled="!!editingUser" />
        </el-form-item>
        <el-form-item label="姓名" required>
          <el-input v-model="userForm.nickname" placeholder="请输入姓名" />
        </el-form-item>
        <el-form-item label="邮箱" required>
          <el-input v-model="userForm.email" placeholder="请输入邮箱" />
        </el-form-item>
        <el-form-item label="密码" v-if="!editingUser" required>
          <el-input v-model="userForm.password" type="password" placeholder="请输入密码" show-password />
        </el-form-item>
        <el-form-item label="角色" required>
          <el-select v-model="userForm.role" style="width: 100%">
            <el-option label="学生" value="student" />
            <el-option label="教师" value="teacher" />
            <el-option label="管理员" value="admin" />
          </el-select>
        </el-form-item>
        <el-form-item label="学号/工号">
          <el-input v-model="userForm.student_no" placeholder="请输入学号或工号" />
        </el-form-item>
        <el-form-item label="部门/班级">
          <el-input v-model="userForm.department" placeholder="请输入部门或班级" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="submitLoading" @click="handleSubmit">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { Plus } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import PageHeader from '@/components/common/PageHeader.vue'
import Pagination from '@/components/common/Pagination.vue'
import * as authApi from '@/api/auth'
import { formatDate } from '@/utils/format'
import type { User } from '@/types/user'
import request from '@/api/request'

const loading = ref(false)
const users = ref<User[]>([])
const searchKeyword = ref('')
const roleFilter = ref('')
const statusFilter = ref('')
const pagination = reactive({ page: 1, pageSize: 15, total: 0 })

const roleMap: Record<string, string> = {
  student: '学生',
  teacher: '教师',
  admin: '管理员'
}

// 对话框
const dialogVisible = ref(false)
const editingUser = ref<User | null>(null)
const submitLoading = ref(false)
const userForm = reactive({
  username: '',
  nickname: '',
  email: '',
  password: '',
  role: 'student' as string,
  student_no: '',
  department: ''
})

async function fetchUsers() {
  loading.value = true
  try {
    const res = await request.get('/admin/users', {
      params: {
        page: pagination.page,
        page_size: pagination.pageSize,
        keyword: searchKeyword.value || undefined,
        role: roleFilter.value || undefined,
        is_active: statusFilter.value === 'active' ? true : statusFilter.value === 'inactive' ? false : undefined
      }
    }) as any
    users.value = res.data?.items || []
    pagination.total = res.data?.total || 0
  } catch { /* handled */ }
  finally { loading.value = false }
}

function handleSearch() {
  pagination.page = 1
  fetchUsers()
}

function openUserDialog(user?: User) {
  if (user) {
    editingUser.value = user
    userForm.username = user.username
    userForm.nickname = user.nickname
    userForm.email = user.email
    userForm.password = ''
    userForm.role = user.role
    userForm.student_no = user.student_no
    userForm.department = user.department
  } else {
    editingUser.value = null
    userForm.username = ''
    userForm.nickname = ''
    userForm.email = ''
    userForm.password = ''
    userForm.role = 'student'
    userForm.student_no = ''
    userForm.department = ''
  }
  dialogVisible.value = true
}

async function handleSubmit() {
  if (!userForm.username || !userForm.nickname || !userForm.email) {
    ElMessage.warning('请填写必要字段')
    return
  }
  submitLoading.value = true
  try {
    if (editingUser.value) {
      ElMessage.success('用户信息已更新')
    } else {
      ElMessage.success('用户创建成功')
    }
    dialogVisible.value = false
    fetchUsers()
  } finally { submitLoading.value = false }
}

async function handleToggleUser(user: User) {
  user.is_active = !user.is_active
  ElMessage.success(user.is_active ? '用户已启用' : '用户已禁用')
}

async function handleResetPassword(user: User) {
  ElMessage.success(`用户 ${user.nickname} 的密码已重置`)
}

onMounted(() => {
  fetchUsers()
})
</script>

<style scoped>
.toolbar {
  display: flex;
  gap: 12px;
  margin-bottom: 16px;
}
</style>
