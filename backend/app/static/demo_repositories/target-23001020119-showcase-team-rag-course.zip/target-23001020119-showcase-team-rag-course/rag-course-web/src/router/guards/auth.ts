import type { Router } from 'vue-router'
import { getToken } from '@/utils/auth'

const whiteList = ['/login', '/register']

export function setupRouterGuards(router: Router) {
  router.beforeEach(async (to, _from, next) => {
    const token = getToken()

    if (token) {
      if (to.path === '/login') {
        // 已登录，跳转到首页
        next({ path: '/' })
        return
      }

      // 检查路由权限
      const requiredRole = to.meta.role as string | undefined
      if (requiredRole) {
        // 简单的路由权限检查 - 实际中会从 store 获取用户角色
        // 这里做基础检查，具体权限在各路由守卫中处理
      }

      next()
    } else {
      if (whiteList.includes(to.path)) {
        next()
      } else {
        // 未登录，跳转登录页
        next({ path: '/login', query: { redirect: to.fullPath } })
      }
    }
  })
}
