import request from './request'
import type { ApiResponse, PageRequest, PageResponse } from '@/types/common'
import type {
  AnalyticsOverview,
  HotQuestion,
  UnresolvedQuestion,
  KnowledgeGap,
  DocumentUsage,
  ModelUsage
} from '@/types/analytics'

/** 获取分析概览 */
export function getOverview(courseId?: number) {
  return request.get<ApiResponse<AnalyticsOverview>>('/analytics/overview', {
    params: courseId ? { course_id: courseId } : {}
  })
}

/** 获取热门问题 */
export function getHotQuestions(courseId?: number, limit = 10) {
  return request.get<ApiResponse<HotQuestion[]>>('/analytics/hot-questions', {
    params: { course_id: courseId, limit }
  })
}

/** 获取未解决问题 */
export function getUnresolved(courseId?: number, params?: PageRequest) {
  return request.get<ApiResponse<PageResponse<UnresolvedQuestion>>>('/analytics/unresolved', {
    params: { ...params, course_id: courseId }
  })
}

/** 获取知识缺口 */
export function getKnowledgeGaps(courseId?: number, limit = 10) {
  return request.get<ApiResponse<KnowledgeGap[]>>('/analytics/knowledge-gaps', {
    params: { course_id: courseId, limit }
  })
}

/** 获取文档使用统计 */
export function getDocuments(courseId?: number, limit = 10) {
  return request.get<ApiResponse<DocumentUsage[]>>('/analytics/documents', {
    params: { course_id: courseId, limit }
  })
}

/** 获取模型使用统计 */
export function getModelUsage(courseId?: number) {
  return request.get<ApiResponse<ModelUsage[]>>('/analytics/model-usage', {
    params: courseId ? { course_id: courseId } : {}
  })
}
