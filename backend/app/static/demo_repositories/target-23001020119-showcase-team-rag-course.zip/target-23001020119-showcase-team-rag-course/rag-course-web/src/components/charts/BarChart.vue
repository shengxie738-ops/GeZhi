<template>
  <div ref="chartRef" class="bar-chart"></div>
</template>

<script setup lang="ts">
import { ref, watch, onMounted, onBeforeUnmount, shallowRef } from 'vue'
import * as echarts from 'echarts'
import type { EChartsOption } from 'echarts'

const props = withDefaults(
  defineProps<{
    title?: string
    xAxis: string[]
    series: { name: string; data: number[]; color?: string }[]
    horizontal?: boolean
    height?: string
  }>(),
  {
    title: '',
    horizontal: false,
    height: '300px'
  }
)

const chartRef = ref<HTMLElement>()
const chart = shallowRef<echarts.ECharts>()

function initChart() {
  if (!chartRef.value) return
  chart.value = echarts.init(chartRef.value)
  updateChart()

  const observer = new ResizeObserver(() => {
    chart.value?.resize()
  })
  observer.observe(chartRef.value)
}

function updateChart() {
  if (!chart.value) return

  const xAxisConfig = props.horizontal
    ? { type: 'value' as const }
    : {
        type: 'category' as const,
        data: props.xAxis,
        axisLabel: {
          rotate: props.xAxis.length > 7 ? 30 : 0
        }
      }

  const yAxisConfig = props.horizontal
    ? {
        type: 'category' as const,
        data: props.xAxis,
        inverse: true
      }
    : { type: 'value' as const }

  const option: EChartsOption = {
    title: props.title ? { text: props.title, left: 'center' } : undefined,
    tooltip: {
      trigger: 'axis'
    },
    xAxis: xAxisConfig,
    yAxis: yAxisConfig,
    series: props.series.map((s) => ({
      name: s.name,
      type: 'bar' as const,
      data: s.data,
      itemStyle: s.color ? { color: s.color } : undefined,
      barMaxWidth: 40
    })),
    legend: props.series.length > 1 ? { bottom: 0 } : undefined,
    grid: {
      left: props.horizontal ? 100 : 40,
      right: 20,
      top: props.title ? 50 : 20,
      bottom: props.series.length > 1 ? 40 : 20
    }
  }

  chart.value.setOption(option, true)
}

watch(
  () => [props.xAxis, props.series],
  () => updateChart(),
  { deep: true }
)

onMounted(() => initChart())

onBeforeUnmount(() => {
  chart.value?.dispose()
})
</script>

<style scoped>
.bar-chart {
  width: 100%;
  height: v-bind(height);
}
</style>
