<template>
  <div class="document-status-badge">
    <el-tag :type="statusInfo.type" :effect="effect" :size="size">
      {{ statusInfo.label }}
    </el-tag>
    <el-progress
      v-if="showProgress && statusInfo.inProgress"
      :percentage="progress"
      :stroke-width="4"
      :show-text="false"
      :status="progressStatus"
      class="status-progress"
    />
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import type { ParseStatus } from '@/types/document'

const props = withDefaults(
  defineProps<{
    status: ParseStatus
    progress?: number
    showProgress?: boolean
    effect?: 'dark' | 'light' | 'plain'
    size?: 'large' | 'default' | 'small'
  }>(),
  {
    progress: 0,
    showProgress: true,
    effect: 'light',
    size: 'small'
  }
)

const statusMap: Record<ParseStatus, { label: string; type: '' | 'success' | 'warning' | 'danger' | 'info'; inProgress: boolean }> = {
  pending: { label: '待上传', type: 'info', inProgress: false },
  parsing: { label: '解析中', type: '', inProgress: true },
  parsed: { label: '已解析', type: '', inProgress: false },
  failed: { label: '解析失败', type: 'danger', inProgress: false },
  indexing: { label: '索引中', type: '', inProgress: true },
  indexed: { label: '已索引', type: 'success', inProgress: false },
  reindexing: { label: '重建索引', type: 'warning', inProgress: true }
}

const statusInfo = computed(() => statusMap[props.status] || statusMap.pending)

const progressStatus = computed(() => {
  if (props.status === 'failed') return 'exception'
  if (props.progress >= 100) return 'success'
  return undefined
})
</script>

<style scoped>
.document-status-badge {
  display: inline-flex;
  align-items: center;
  gap: 8px;
}

.status-progress {
  width: 60px;
}
</style>
