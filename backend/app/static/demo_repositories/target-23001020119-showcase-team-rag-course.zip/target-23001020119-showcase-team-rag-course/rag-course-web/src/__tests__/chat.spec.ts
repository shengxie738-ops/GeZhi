import { describe, it, expect, vi, beforeEach } from 'vitest'
import { mount } from '@vue/test-utils'
import { createTestingPinia } from '@pinia/testing'
import ElementPlus from 'element-plus'
import ChatMessage from '@/components/chat/ChatMessage.vue'
import ChatInput from '@/components/chat/ChatInput.vue'
import { useChatStore } from '@/stores/chat'
import { useAuthStore } from '@/stores/auth'
import type { ChatMessage as ChatMessageType } from '@/types/chat'

// Mock the auth store
vi.mock('@/stores/auth', () => ({
  useAuthStore: vi.fn()
}))

// Mock markdown renderer to avoid DOM issues
vi.mock('@/components/common/MarkdownRenderer.vue', () => ({
  default: {
    name: 'MarkdownRenderer',
    template: '<div class="markdown-renderer">{{ content }}</div>',
    props: ['content']
  }
}))

vi.mock('@/components/chat/CitationCard.vue', () => ({
  default: {
    name: 'CitationCard',
    template: '<div class="citation-card"></div>',
    props: ['citation']
  }
}))

vi.mock('@/utils/format', () => ({
  formatRelativeTime: vi.fn(() => '刚刚')
}))

const mockAuthStore = {
  nickname: '测试用户',
  avatar: '',
  user: { id: 1, username: 'student', role: 'student' }
}

const mockUserMessage: ChatMessageType = {
  id: 1,
  session_id: 1,
  role: 'user',
  content: '什么是 RAG？',
  created_at: '2025-01-15 10:00:00'
}

const mockAssistantMessage: ChatMessageType = {
  id: 2,
  session_id: 1,
  role: 'assistant',
  content: 'RAG 是检索增强生成的缩写，它通过外部检索补充模型上下文 [1]。',
  created_at: '2025-01-15 10:00:01',
  citations: [
    {
      source_type: 'COURSE_FILE',
      document_id: 1,
      document_title: 'RAG 课程讲义',
      page_no: 5,
      chunk_id: 1,
      score: 0.85,
      quote: 'RAG 通过检索模块获取相关文档...'
    }
  ]
}

describe('ChatMessage 组件', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    vi.mocked(useAuthStore).mockReturnValue(mockAuthStore as any)
  })

  it('渲染用户消息', () => {
    const wrapper = mount(ChatMessage, {
      props: { message: mockUserMessage },
      global: {
        plugins: [ElementPlus]
      }
    })

    expect(wrapper.text()).toContain('什么是 RAG？')
    expect(wrapper.text()).toContain('测试用户')
    expect(wrapper.classes()).toContain('chat-message--user')
  })

  it('渲染 AI 助教消息', () => {
    const wrapper = mount(ChatMessage, {
      props: { message: mockAssistantMessage },
      global: {
        plugins: [ElementPlus]
      }
    })

    expect(wrapper.text()).toContain('AI 助教')
    expect(wrapper.classes()).toContain('chat-message--assistant')
  })

  it('渲染引用来源', () => {
    const wrapper = mount(ChatMessage, {
      props: { message: mockAssistantMessage },
      global: {
        plugins: [ElementPlus]
      }
    })

    expect(wrapper.text()).toContain('引用来源')
  })
})

describe('ChatInput 组件', () => {
  it('渲染消息输入框', () => {
    const wrapper = mount(ChatInput, {
      global: {
        plugins: [ElementPlus]
      }
    })

    const textarea = wrapper.find('textarea')
    expect(textarea.exists()).toBe(true)
  })

  it('发送按钮默认禁用', () => {
    const wrapper = mount(ChatInput, {
      global: {
        plugins: [ElementPlus]
      }
    })

    const sendBtn = wrapper.find('.send-btn')
    expect(sendBtn.attributes('disabled')).toBeDefined()
  })

  it('输入内容后发送按钮可用', async () => {
    const wrapper = mount(ChatInput, {
      global: {
        plugins: [ElementPlus]
      }
    })

    const textarea = wrapper.find('textarea')
    await textarea.setValue('测试消息')

    await wrapper.vm.$nextTick()

    const sendBtn = wrapper.find('.send-btn')
    expect(sendBtn.attributes('disabled')).toBeUndefined()
  })

  it('点击发送按钮触发 send 事件', async () => {
    const wrapper = mount(ChatInput, {
      global: {
        plugins: [ElementPlus]
      }
    })

    const textarea = wrapper.find('textarea')
    await textarea.setValue('测试消息')

    const sendBtn = wrapper.find('.send-btn')
    await sendBtn.trigger('click')

    expect(wrapper.emitted('send')).toBeTruthy()
    expect(wrapper.emitted('send')![0]).toEqual(['测试消息'])
  })

  it('发送后清空输入框', async () => {
    const wrapper = mount(ChatInput, {
      global: {
        plugins: [ElementPlus]
      }
    })

    const textarea = wrapper.find('textarea')
    await textarea.setValue('测试消息')

    const sendBtn = wrapper.find('.send-btn')
    await sendBtn.trigger('click')

    await wrapper.vm.$nextTick()
    expect((textarea.element as HTMLTextAreaElement).value).toBe('')
  })
})
