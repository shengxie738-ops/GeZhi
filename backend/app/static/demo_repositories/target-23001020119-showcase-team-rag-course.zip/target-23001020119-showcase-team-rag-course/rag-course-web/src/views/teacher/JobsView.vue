﻿<template>
  <div class="page-container">
    <PageHeader title="任务队列" description="查看和管理文档解析与索引任务">
      <el-button @click="fetchJobs" :loading="loading">
        <el-icon><Refresh /></el-icon> 刷新
      </el-button>
    </PageHeader>

    <el-card shadow="never">
      <div class="toolbar">
        <el-select v-model="statusFilter" placeholder="任务状态" clearable style="width: 140px" @change="handleSearch">
          <el-option label="等待中" value="pending" />
          <el-option label="运行中" value="running" />
          <el-option label="已完成" value="completed" />
          <el-option label="失败" value="failed" />
        </el-select>
      </div>

      <el-table :data="jobs" v-loading="loading" stripe border>
        <el-table-column prop="id" label="任务号" width="80" />
        <el-table-column label="文档" min-width="200">
          <template #default="{ row }">
            <span class="doc-name">{{ row.document?.title || `文档#${row.document_id}` }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100">
          <template #default="{ row }">
            <StatusTag :value="row.status" type="job" />
          </template>
        </el-table-column>
        <el-table-column label="进度" width="200">
          <template #default="{ row }">
            <el-progress
              :percentage="row.progress"
              :status="row.status === 'failed' ? 'exception' : row.status === 'completed' ? 'success' : undefined"
              :stroke-width="10"
            />
          </template>
        </el-table-column>
        <el-table-column label="当前步骤" width="120">
          <template #default="{ row }">
            <span class="step-text">
              {{ row.processed_chunks }}/{{ row.total_chunks }}
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="started_at" label="开始时间" width="170">
          <template #default="{ row }">{{ formatDate(row.started_at) }}</template>
        </el-table-column>
        <el-table-column label="耗时" width="100">
          <template #default="{ row }">
            {{ calcDuration(row.started_at, row.completed_at) }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="160" fixed="right">
          <template #default="{ row }">
            <el-button
              v-if="row.status === 'failed'"
              type="warning" link size="small"
              @click="handleRetry(row)"
            >重试</el-button>
            <el-button
              v-if="row.status === 'running' || row.status === 'pending'"
              type="danger" link size="small"
              @click="handleCancel(row)"
            >取消</el-button>
          </template>
        </el-table-column>
      </el-table>

      <Pagination
        v-model:page="pagination.page"
        v-model:page-size="pagination.pageSize"
        :total="pagination.total"
        @change="fetchJobs"
      />
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, onBeforeUnmount } from 'vue'
import { Refresh } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import PageHeader from '@/components/common/PageHeader.vue'
import Pagination from '@/components/common/Pagination.vue'
import StatusTag from '@/components/common/StatusTag.vue'
import * as modelConfigApi from '@/api/modelConfig'
import { formatDate } from '@/utils/format'
import type { IngestJob } from '@/types/document'

const loading = ref(false)
const jobs = ref<IngestJob[]>([])
const statusFilter = ref('')
const pagination = reactive({ page: 1, pageSize: 15, total: 0 })
let pollingTimer: ReturnType<typeof setInterval> | null = null

async function fetchJobs() {
  loading.value = true
  try {
    const res = await modelConfigApi.getJobs({
      page: pagination.page,
      page_size: pagination.pageSize,
      status: statusFilter.value || undefined
    })
    jobs.value = res.data.items
    pagination.total = res.data.total
  } catch { /* handled */ }
  finally { loading.value = false }
}

function handleSearch() {
  pagination.page = 1
  fetchJobs()
}

function calcDuration(start?: string | null, end?: string | null) {
  if (!start) return '-'
  const startTime = new Date(start).getTime()
  const endTime = end ? new Date(end).getTime() : Date.now()
  const diff = Math.floor((endTime - startTime) / 1000)
  if (diff < 60) return `${diff}s`
  return `${Math.floor(diff / 60)}m ${diff % 60}s`
}

async function handleRetry(job: IngestJob) {
  try {
    await modelConfigApi.retryJob(job.id)
    ElMessage.success('任务已重新提交')
    fetchJobs()
  } catch { /* handled */ }
}

async function handleCancel(job: IngestJob) {
  try {
    await modelConfigApi.cancelJob(job.id)
    ElMessage.success('任务已取消')
    fetchJobs()
  } catch { /* handled */ }
}

onMounted(() => {
  fetchJobs()
  // 实时轮询
  pollingTimer = setInterval(() => {
    const hasRunning = jobs.value.some((j) => j.status === 'running' || j.status === 'pending')
    if (hasRunning) fetchJobs()
  }, 5000)
})

onBeforeUnmount(() => {
  if (pollingTimer) clearInterval(pollingTimer)
})
</script>

<style scoped>
.toolbar {
  display: flex;
  gap: 12px;
  margin-bottom: 16px;
}

.doc-name {
  font-size: 13px;
  color: #409EFF;
}

.step-text {
  font-size: 13px;
  color: #606266;
}
</style>
