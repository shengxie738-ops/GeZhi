import request from './request'
import type { ApiResponse, PageRequest, PageResponse } from '@/types/common'
import type { Document, Chunk, IngestJob, UpdateChunkRequest } from '@/types/document'

/** 上传文档 */
export function uploadDocument(courseId: number, file: File, onProgress?: (percent: number) => void) {
  const formData = new FormData()
  formData.append('file', file)
  formData.append('course_id', String(courseId))

  return request.post<ApiResponse<Document>>('/documents/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
    timeout: 300000,
    onUploadProgress: (progressEvent) => {
      if (onProgress && progressEvent.total) {
        onProgress(Math.round((progressEvent.loaded * 100) / progressEvent.total))
      }
    }
  })
}

/** 获取文档列表 */
export function getDocuments(courseId: number, params?: PageRequest & { status?: string }) {
  return request.get<ApiResponse<PageResponse<Document>>>(`/courses/${courseId}/documents`, {
    params
  })
}

/** 获取文档详情 */
export function getDocument(documentId: number) {
  return request.get<ApiResponse<Document>>(`/documents/${documentId}`)
}

/** 删除文档 */
export function deleteDocument(documentId: number) {
  return request.delete<ApiResponse<null>>(`/documents/${documentId}`)
}

/** 触发文档解析 */
export function parseDocument(documentId: number) {
  return request.post<ApiResponse<IngestJob>>(`/documents/${documentId}/parse`)
}

/** 重新索引文档 */
export function reindexDocument(documentId: number) {
  return request.post<ApiResponse<IngestJob>>(`/documents/${documentId}/reindex`)
}

/** 获取文档分块列表 */
export function getDocumentChunks(documentId: number, params?: PageRequest) {
  return request.get<ApiResponse<PageResponse<Chunk>>>(`/documents/${documentId}/chunks`, {
    params
  })
}

/** 更新分块内容 */
export function updateChunk(chunkId: number, data: UpdateChunkRequest) {
  return request.put<ApiResponse<Chunk>>(`/chunks/${chunkId}`, data)
}

/** 启用/禁用分块 */
export function toggleChunkEnabled(chunkId: number, enabled: boolean) {
  return request.put<ApiResponse<Chunk>>(`/chunks/${chunkId}`, { enabled })
}

/** 获取解析状态（轮询） */
export function getParseStatus(documentId: number) {
  return request.get<ApiResponse<{ parse_status: string; progress: number }>>(
    `/documents/${documentId}/status`
  )
}
