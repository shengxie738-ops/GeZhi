import type { User } from './user'

/** 课程信息 */
export interface Course {
  id: number
  name: string
  code: string
  description: string
  teacher_id: number
  teacher: User
  semester: string
  status: 'active' | 'inactive' | 'archived'
  member_count: number
  document_count: number
  created_at: string
  updated_at: string
}

/** 课程成员 */
export interface CourseMember {
  id: number
  course_id: number
  user_id: number
  user: User
  role: 'student' | 'teaching_assistant'
  joined_at: string
}

/** 章节信息 */
export interface Chapter {
  id: number
  course_id: number
  title: string
  description: string
  order: number
  parent_id: number | null
  children: Chapter[]
  created_at: string
}

/** 创建课程请求 */
export interface CreateCourseRequest {
  name: string
  code: string
  description: string
  semester: string
}

/** 更新课程请求 */
export interface UpdateCourseRequest {
  name?: string
  code?: string
  description?: string
  semester?: string
  status?: 'active' | 'inactive' | 'archived'
}
