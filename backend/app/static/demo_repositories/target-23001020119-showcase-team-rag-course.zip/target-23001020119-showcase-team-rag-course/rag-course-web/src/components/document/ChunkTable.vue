<template>
  <div class="chunk-table">
    <el-table
      :data="chunks"
      v-loading="loading"
      stripe
      size="small"
      highlight-current-row
      @current-change="handleCurrentChange"
      :row-class-name="getRowClassName"
    >
      <el-table-column label="#" width="60" align="center">
        <template #default="{ $index }">
          {{ (currentPage - 1) * pageSize + $index + 1 }}
        </template>
      </el-table-column>

      <el-table-column label="标题路径" min-width="200" show-overflow-tooltip>
        <template #default="{ row }">
          <span class="chunk-title">{{ getChunkTitle(row) }}</span>
        </template>
      </el-table-column>

      <el-table-column label="页码范围" width="100" align="center">
        <template #default="{ row }">
          <span v-if="row.start_page != null">
            {{ row.start_page }}{{ row.end_page && row.end_page !== row.start_page ? `-${row.end_page}` : '' }}
          </span>
          <span v-else class="text-muted">-</span>
        </template>
      </el-table-column>

      <el-table-column label="Token数" width="90" align="center">
        <template #default="{ row }">
          {{ row.token_count }}
        </template>
      </el-table-column>

      <el-table-column label="状态" width="80" align="center">
        <template #default="{ row }">
          <el-switch
            v-model="row.enabled"
            size="small"
            @change="$emit('toggle', row)"
          />
        </template>
      </el-table-column>
    </el-table>

    <div class="chunk-pagination" v-if="total > 0">
      <el-pagination
        v-model:current-page="currentPage"
        v-model:page-size="pageSize"
        :total="total"
        :page-sizes="[10, 20, 50]"
        layout="total, sizes, prev, pager, next"
        background
        small
        @size-change="$emit('page-change', { page: 1, pageSize: $event })"
        @current-change="$emit('page-change', { page: $event, pageSize })"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import type { Chunk } from '@/types/document'

const props = defineProps<{
  chunks: Chunk[]
  total?: number
  loading?: boolean
  activeChunkId?: number | null
}>()

const currentPage = ref(1)
const pageSize = ref(10)

const emit = defineEmits<{
  'select': [chunk: Chunk]
  'toggle': [chunk: Chunk]
  'page-change': [query: { page: number; pageSize: number }]
}>()

function getChunkTitle(chunk: Chunk): string {
  const meta = chunk.metadata
  if (meta?.title) return meta.title
  return chunk.content.slice(0, 60) + (chunk.content.length > 60 ? '...' : '')
}

function getRowClassName({ row }: { row: Chunk }) {
  if (row.id === props.activeChunkId) return 'active-row'
  return ''
}

function handleCurrentChange(row: Chunk | null) {
  if (row) emit('select', row)
}
</script>

<style scoped>
.chunk-table {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.chunk-title {
  font-size: 13px;
  color: #303133;
}

.text-muted {
  color: #c0c4cc;
}

.chunk-pagination {
  display: flex;
  justify-content: flex-end;
}

:deep(.el-table .active-row) {
  background: #ecf5ff !important;
}
</style>
