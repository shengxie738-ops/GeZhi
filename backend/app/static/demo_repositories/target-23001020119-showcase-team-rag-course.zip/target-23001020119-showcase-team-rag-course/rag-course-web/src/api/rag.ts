import request from './request'
import { getToken } from '@/utils/auth'
import type { ApiResponse } from '@/types/common'
import type { SearchRequest, SearchResult, AskRequest, AskResponse } from '@/types/rag'
import type { StreamEvent } from '@/types/rag'

/** 知识库搜索 */
export function search(data: SearchRequest) {
  return request.post<ApiResponse<SearchResult[]>>('/rag/search', data)
}

/** RAG提问（非流式） */
export function ask(data: AskRequest) {
  return request.post<ApiResponse<AskResponse>>('/rag/ask', data)
}

/**
 * RAG提问（SSE流式）
 * 返回一个可取消的 EventSource-like 管理对象
 */
export function askStream(
  data: AskRequest,
  callbacks: {
    onToken?: (token: string) => void
    onCitation?: (citations: any[]) => void
    onDone?: (response: AskResponse) => void
    onError?: (error: string) => void
  }
): { abort: () => void } {
  const controller = new AbortController()
  const token = getToken()

  const baseURL = import.meta.env.VITE_API_BASE_URL
  const url = `${baseURL}/rag/ask/stream`

  fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {})
    },
    body: JSON.stringify(data),
    signal: controller.signal
  })
    .then(async (response) => {
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`)
      }

      const reader = response.body?.getReader()
      if (!reader) {
        throw new Error('无法读取响应流')
      }

      const decoder = new TextDecoder()
      let buffer = ''

      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        buffer += decoder.decode(value, { stream: true })
        const lines = buffer.split('\n')
        buffer = lines.pop() || ''

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const jsonStr = line.slice(6).trim()
            if (jsonStr === '[DONE]') {
              continue
            }
            try {
              const event: StreamEvent = JSON.parse(jsonStr)
              switch (event.type) {
                case 'token':
                  callbacks.onToken?.(event.data as string)
                  break
                case 'citation':
                  callbacks.onCitation?.(event.data as any[])
                  break
                case 'done':
                  callbacks.onDone?.(event.data as unknown as AskResponse)
                  break
                case 'error':
                  callbacks.onError?.(event.data as string)
                  break
              }
            } catch {
              // 忽略解析错误
            }
          }
        }
      }
    })
    .catch((error) => {
      if (error.name !== 'AbortError') {
        callbacks.onError?.(error.message)
      }
    })

  return {
    abort: () => controller.abort()
  }
}
