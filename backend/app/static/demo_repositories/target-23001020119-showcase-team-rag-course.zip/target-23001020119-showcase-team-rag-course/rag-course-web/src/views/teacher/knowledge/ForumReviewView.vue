﻿<template>
  <div class="page-container">
    <PageHeader title="论坛问答审核" description="审核学生问答内容，认证优质回答" />

    <el-card shadow="never">
      <el-tabs v-model="activeTab" @tab-change="handleTabChange">
        <!-- 待审核 -->
        <el-tab-pane label="待审核" name="pending">
          <div class="qa-list">
            <el-card
              v-for="question in questions"
              :key="question.id"
              shadow="hover"
              class="qa-card"
            >
              <div class="qa-header">
                <div class="qa-title-row">
                  <el-tag size="small" type="warning">待审核</el-tag>
                  <span class="qa-title">{{ question.title }}</span>
                </div>
                <div class="qa-meta">
                  <span>{{ question.user?.nickname || '匿名' }}</span>
                  <span>{{ formatDate(question.created_at) }}</span>
                  <span>浏览 {{ question.view_count }}</span>
                </div>
              </div>
              <div class="qa-content">{{ truncate(question.content, 200) }}</div>

              <!-- 回答列表 -->
              <el-collapse v-if="question.answer_count > 0">
                <el-collapse-item :title="`查看 ${question.answer_count} 条回答`">
                  <div v-for="answer in (question as any).answers || []" :key="answer.id" class="answer-item">
                    <div class="answer-header">
                      <el-avatar :size="24">{{ answer.user?.nickname?.[0] || 'U' }}</el-avatar>
                      <span class="answer-author">{{ answer.user?.nickname || '匿名' }}</span>
                      <el-tag v-if="answer.is_verified" size="small" type="success">已认证</el-tag>
                      <el-tag v-if="answer.added_to_knowledge" size="small" type="info">已入库</el-tag>
                    </div>
                    <div class="answer-content">{{ answer.content }}</div>
                    <div class="answer-actions">
                      <el-button
                        type="success" size="small" :icon="CircleCheck"
                        :disabled="answer.is_verified"
                        @click="handleVerify(answer.id, true)"
                      >认证回答</el-button>
                      <el-button
                        type="primary" size="small" :icon="FolderAdd"
                        :disabled="answer.added_to_knowledge"
                        @click="openKnowledgeDialog(answer)"
                      >加入知识库</el-button>
                      <el-button
                        size="small" :icon="Star"
                        @click="handleMarkHighQuality(question)"
                      >标记高质量</el-button>
                    </div>
                  </div>
                  <el-empty v-if="!(question as any).answers?.length" description="暂无回答" :image-size="60" />
                </el-collapse-item>
              </el-collapse>
            </el-card>
            <el-empty v-if="questions.length === 0 && !loading" description="暂无待审核内容" />
          </div>
        </el-tab-pane>

        <!-- 已审核 -->
        <el-tab-pane label="已审核" name="verified">
          <div class="qa-list">
            <el-card v-for="q in verifiedQuestions" :key="q.id" shadow="hover" class="qa-card">
              <div class="qa-header">
                <div class="qa-title-row">
                  <el-tag size="small" type="success">已审核</el-tag>
                  <span class="qa-title">{{ q.title }}</span>
                </div>
                <div class="qa-meta">
                  <span>{{ q.user?.nickname }}</span>
                  <span>{{ formatDate(q.created_at) }}</span>
                </div>
              </div>
              <div class="qa-content">{{ truncate(q.content, 150) }}</div>
            </el-card>
            <el-empty v-if="verifiedQuestions.length === 0 && !loading" description="暂无已审核内容" />
          </div>
        </el-tab-pane>

        <!-- 高质量问答 -->
        <el-tab-pane label="高质量问答" name="high_quality">
          <div class="qa-list">
            <el-card v-for="q in highQualityQuestions" :key="q.id" shadow="hover" class="qa-card">
              <div class="qa-header">
                <div class="qa-title-row">
                  <el-tag size="small" effect="dark">高质量</el-tag>
                  <span class="qa-title">{{ q.title }}</span>
                </div>
                <div class="qa-meta">
                  <span>{{ q.user?.nickname }}</span>
                  <span>点赞 {{ q.like_count }}</span>
                </div>
              </div>
              <div class="qa-content">{{ truncate(q.content, 150) }}</div>
            </el-card>
            <el-empty v-if="highQualityQuestions.length === 0 && !loading" description="暂无高质量问答" />
          </div>
        </el-tab-pane>
      </el-tabs>
    </el-card>

    <!-- 加入知识库对话框 -->
    <el-dialog
      v-model="knowledgeDialogVisible"
      title="加入知识库"
      width="500px"
      :close-on-click-modal="false"
    >
      <el-form label-width="100px">
        <el-form-item label="选择目标章节">
          <el-select v-model="knowledgeForm.chapterId" placeholder="选择章节" style="width: 100%">
            <el-option v-for="ch in chapterList" :key="ch.id" :label="ch.title" :value="ch.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="切分参数">
          <el-input-number v-model="knowledgeForm.chunkSize" :min="100" :max="2000" :step="50" />
          <span style="margin-left: 8px; color: #909399; font-size: 12px">chunk_size</span>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="knowledgeDialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="knowledgeSaving" @click="handleAddToKnowledge">确定加入</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { CircleCheck, FolderAdd, Star } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import PageHeader from '@/components/common/PageHeader.vue'
import * as forumApi from '@/api/forum'
import * as courseApi from '@/api/course'
import { formatDate, truncate } from '@/utils/format'
import type { ForumQuestion, ForumAnswer } from '@/types/forum'
import type { Chapter } from '@/types/course'

const activeTab = ref('pending')
const loading = ref(false)
const questions = ref<ForumQuestion[]>([])
const verifiedQuestions = ref<ForumQuestion[]>([])
const highQualityQuestions = ref<ForumQuestion[]>([])
const chapterList = ref<Chapter[]>([])

// 加入知识库
const knowledgeDialogVisible = ref(false)
const knowledgeSaving = ref(false)
const knowledgeForm = reactive({ answerId: 0, chapterId: 0, chunkSize: 512 })

const courseId = 1 // 默认课程

async function fetchQuestions(status: string) {
  loading.value = true
  try {
    const res = await forumApi.getQuestions(courseId, { page: 1, page_size: 50, status })
    return res.data.items
  } catch { return [] }
  finally { loading.value = false }
}

async function fetchAll() {
  const [pending, verified, highQuality] = await Promise.all([
    fetchQuestions('open'),
    fetchQuestions('verified'),
    fetchQuestions('closed')
  ])
  questions.value = pending
  verifiedQuestions.value = verified
  highQualityQuestions.value = highQuality
}

async function fetchChapters() {
  try {
    const res = await courseApi.getCourse(courseId)
    chapterList.value = (res.data as any).chapters || []
  } catch { /* handled */ }
}

function handleTabChange() {
  // 切换tab时刷新对应数据
  fetchAll()
}

async function handleVerify(answerId: number, verified: boolean) {
  try {
    await forumApi.verifyAnswer(answerId, verified)
    ElMessage.success('认证成功')
    fetchAll()
  } catch { /* handled */ }
}

function openKnowledgeDialog(answer: ForumAnswer) {
  knowledgeForm.answerId = answer.id
  knowledgeForm.chapterId = chapterList.value[0]?.id || 0
  knowledgeDialogVisible.value = true
}

async function handleAddToKnowledge() {
  knowledgeSaving.value = true
  try {
    await forumApi.addToKnowledge(knowledgeForm.answerId)
    ElMessage.success('已加入知识库')
    knowledgeDialogVisible.value = false
    fetchAll()
  } finally { knowledgeSaving.value = false }
}

async function handleMarkHighQuality(question: ForumQuestion) {
  ElMessage.success('已标记为高质量')
}

onMounted(() => {
  fetchAll()
  fetchChapters()
})
</script>

<style scoped>
.qa-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.qa-card {
  border-radius: 8px;
}

.qa-header {
  margin-bottom: 12px;
}

.qa-title-row {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
}

.qa-title {
  font-size: 16px;
  font-weight: 600;
  color: #303133;
}

.qa-meta {
  display: flex;
  gap: 16px;
  font-size: 13px;
  color: #909399;
}

.qa-content {
  font-size: 14px;
  color: #606266;
  line-height: 1.6;
  margin-bottom: 12px;
}

.answer-item {
  padding: 12px;
  border: 1px solid #EBEEF5;
  border-radius: 6px;
  margin-bottom: 8px;
}

.answer-item:last-child { margin-bottom: 0; }

.answer-header {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
}

.answer-author {
  font-size: 13px;
  font-weight: 500;
  color: #303133;
}

.answer-content {
  font-size: 14px;
  color: #606266;
  line-height: 1.6;
  margin-bottom: 8px;
}

.answer-actions {
  display: flex;
  gap: 8px;
}
</style>
