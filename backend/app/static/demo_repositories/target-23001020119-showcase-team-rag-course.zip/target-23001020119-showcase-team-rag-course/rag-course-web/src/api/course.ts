import request from './request'
import type { ApiResponse, PageRequest, PageResponse } from '@/types/common'
import type { Course, CourseMember, CreateCourseRequest, UpdateCourseRequest } from '@/types/course'

/** 获取课程列表 */
export function getCourses(params: PageRequest & { status?: string }) {
  return request.get<ApiResponse<PageResponse<Course>>>('/courses', { params })
}

/** 获取课程详情 */
export function getCourse(courseId: number) {
  return request.get<ApiResponse<Course>>(`/courses/${courseId}`)
}

/** 创建课程 */
export function createCourse(data: CreateCourseRequest) {
  return request.post<ApiResponse<Course>>('/courses', data)
}

/** 更新课程 */
export function updateCourse(courseId: number, data: UpdateCourseRequest) {
  return request.put<ApiResponse<Course>>(`/courses/${courseId}`, data)
}

/** 删除课程 */
export function deleteCourse(courseId: number) {
  return request.delete<ApiResponse<null>>(`/courses/${courseId}`)
}

/** 加入课程 */
export function joinCourse(courseId: number, data?: { invite_code?: string }) {
  return request.post<ApiResponse<CourseMember>>(`/courses/${courseId}/join`, data)
}

/** 退出课程 */
export function leaveCourse(courseId: number) {
  return request.delete<ApiResponse<null>>(`/courses/${courseId}/leave`)
}

/** 获取课程成员列表 */
export function getMembers(courseId: number, params?: PageRequest) {
  return request.get<ApiResponse<PageResponse<CourseMember>>>(`/courses/${courseId}/members`, {
    params
  })
}

/** 移除课程成员 */
export function removeMember(courseId: number, userId: number) {
  return request.delete<ApiResponse<null>>(`/courses/${courseId}/members/${userId}`)
}

/** 更新成员角色 */
export function updateMemberRole(courseId: number, userId: number, role: string) {
  return request.put<ApiResponse<CourseMember>>(`/courses/${courseId}/members/${userId}`, {
    role
  })
}
