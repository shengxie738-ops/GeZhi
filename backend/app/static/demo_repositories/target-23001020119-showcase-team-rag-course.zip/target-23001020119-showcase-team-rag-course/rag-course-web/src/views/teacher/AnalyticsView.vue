﻿<template>
  <div class="page-container">
    <PageHeader title="教学分析" description="全面了解教学数据与学生学习情况" />

    <!-- 顶部筛选 -->
    <el-card shadow="never" class="filter-card">
      <el-row :gutter="16" align="middle">
        <el-col :span="6">
          <el-select v-model="selectedCourseId" placeholder="选择课程" style="width: 100%" @change="fetchAllData">
            <el-option label="全部课程" :value="0" />
            <el-option v-for="c in courseList" :key="c.id" :label="c.name" :value="c.id" />
          </el-select>
        </el-col>
        <el-col :span="6">
          <el-date-picker
            v-model="dateRange"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            value-format="YYYY-MM-DD"
            style="width: 100%"
            @change="fetchAllData"
          />
        </el-col>
      </el-row>
    </el-card>

    <!-- 数据概览卡片 -->
    <el-row :gutter="20" class="stat-row">
      <el-col :xs="12" :sm="6">
        <div class="stat-card stat-card--blue">
          <div class="stat-card-value">{{ overview.total_questions }}</div>
          <div class="stat-card-label">总提问</div>
        </div>
      </el-col>
      <el-col :xs="12" :sm="6">
        <div class="stat-card stat-card--green">
          <div class="stat-card-value">{{ avgDailyQuestions }}</div>
          <div class="stat-card-label">日均提问</div>
        </div>
      </el-col>
      <el-col :xs="12" :sm="6">
        <div class="stat-card stat-card--orange">
          <div class="stat-card-value">{{ (resolveRate * 100).toFixed(0) }}%</div>
          <div class="stat-card-label">解决率</div>
        </div>
      </el-col>
      <el-col :xs="12" :sm="6">
        <div class="stat-card stat-card--red">
          <div class="stat-card-value">{{ overview.avg_response_latency }}ms</div>
          <div class="stat-card-label">平均响应时间</div>
        </div>
      </el-col>
    </el-row>

    <!-- 热门知识点 -->
    <el-card shadow="never" class="section-card">
      <template #header><span class="card-title">热门知识点 TOP10</span></template>
      <el-table :data="hotTopics" stripe size="small">
        <el-table-column type="index" label="排名" width="60" />
        <el-table-column prop="question" label="知识点" min-width="300" show-overflow-tooltip />
        <el-table-column prop="count" label="提问次数" width="100" align="center" />
        <el-table-column prop="avg_score" label="平均评分" width="100" align="center">
          <template #default="{ row }">
            <el-rate v-model="row.avg_score" disabled text-color="#ff9900" size="small" />
          </template>
        </el-table-column>
      </el-table>
      <el-empty v-if="hotTopics.length === 0" description="暂无数据" />
    </el-card>

    <!-- 无答案问题 -->
    <el-card shadow="never" class="section-card">
      <template #header><span class="card-title">未解决问题</span></template>
      <el-table :data="unresolvedList" stripe border size="small">
        <el-table-column type="index" label="#" width="50" />
        <el-table-column prop="question" label="问题" min-width="300" show-overflow-tooltip />
        <el-table-column prop="asked_by" label="提问者" width="100" />
        <el-table-column prop="asked_at" label="时间" width="160">
          <template #default="{ row }">{{ formatDate(row.asked_at) }}</template>
        </el-table-column>
        <el-table-column prop="priority" label="优先级" width="80">
          <template #default="{ row }">
            <el-tag size="small" :type="row.priority === 'high' ? 'danger' : 'warning'">
              {{ row.priority === 'high' ? '高' : '中' }}
            </el-tag>
          </template>
        </el-table-column>
      </el-table>
      <el-empty v-if="unresolvedList.length === 0" description="暂无未解决问题" />
    </el-card>

    <!-- 低满意度回答 -->
    <el-card shadow="never" class="section-card">
      <template #header><span class="card-title">低满意度回答</span></template>
      <el-table :data="lowSatisfactionList" stripe border size="small">
        <el-table-column type="index" label="#" width="50" />
        <el-table-column prop="question" label="问题" min-width="300" show-overflow-tooltip />
        <el-table-column prop="score" label="满意度" width="160">
          <template #default="{ row }">
            <el-rate v-model="row.score" disabled text-color="#ff9900" />
          </template>
        </el-table-column>
      </el-table>
      <el-empty v-if="lowSatisfactionList.length === 0" description="暂无低满意度回答" />
    </el-card>

    <!-- 文档使用统计 -->
    <el-card shadow="never" class="section-card">
      <template #header><span class="card-title">文档使用统计</span></template>
      <el-table :data="docUsage" stripe size="small">
        <el-table-column type="index" label="#" width="50" />
        <el-table-column prop="document_title" label="文档" min-width="250" show-overflow-tooltip />
        <el-table-column prop="citation_count" label="引用次数" width="100" align="center" />
        <el-table-column prop="avg_relevance_score" label="平均相关度" width="120" align="center">
          <template #default="{ row }">
            <el-progress :percentage="Math.round(row.avg_relevance_score * 100)" :stroke-width="8" />
          </template>
        </el-table-column>
      </el-table>
      <el-empty v-if="docUsage.length === 0" description="暂无文档使用数据" />
    </el-card>

    <!-- 知识盲区 -->
    <el-card shadow="never" class="section-card">
      <template #header><span class="card-title">知识盲区</span></template>
      <el-table :data="knowledgeGaps" stripe border size="small">
        <el-table-column type="index" label="#" width="50" />
        <el-table-column prop="topic" label="知识点" min-width="200" />
        <el-table-column prop="gap_score" label="缺口分数" width="120" align="center">
          <template #default="{ row }">
            <el-progress
              :percentage="Math.round(row.gap_score * 100)"
              :color="row.gap_score > 0.7 ? '#F56C6C' : row.gap_score > 0.4 ? '#E6A23C' : '#67C23A'"
              :stroke-width="12"
            />
          </template>
        </el-table-column>
        <el-table-column prop="suggestion" label="建议" min-width="300" show-overflow-tooltip />
      </el-table>
      <el-empty v-if="knowledgeGaps.length === 0" description="暂无知识盲区数据" />
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import PageHeader from '@/components/common/PageHeader.vue'
import * as analyticsApi from '@/api/analytics'
import * as courseApi from '@/api/course'
import { formatDate } from '@/utils/format'
import type { AnalyticsOverview, HotQuestion, UnresolvedQuestion, KnowledgeGap, DocumentUsage, ModelUsage } from '@/types/analytics'
import type { Course } from '@/types/course'

const selectedCourseId = ref(0)
const dateRange = ref<[string, string] | null>(null)
const courseList = ref<Course[]>([])

const overview = reactive<AnalyticsOverview>({
  total_students: 0, total_documents: 0, total_chunks: 0,
  total_questions: 0, total_chat_sessions: 0, active_students_today: 0,
  avg_response_latency: 0, avg_answer_quality: 0, daily_stats: []
})

const hotTopics = ref<HotQuestion[]>([])
const unresolvedList = ref<UnresolvedQuestion[]>([])
const knowledgeGaps = ref<KnowledgeGap[]>([])
const docUsage = ref<DocumentUsage[]>([])
const modelUsageData = ref<ModelUsage[]>([])

const avgDailyQuestions = computed(() => {
  const days = overview.daily_stats.length || 1
  return Math.round(overview.total_questions / days)
})

const resolveRate = computed(() => 0.78)

const lowSatisfactionList = ref<{ question: string; score: number }[]>([])

async function fetchAllData() {
  const courseId = selectedCourseId.value || undefined

  try {
    const [overviewRes, hotRes, gapsRes, docRes] = await Promise.all([
      analyticsApi.getOverview(courseId),
      analyticsApi.getHotQuestions(courseId, 10),
      analyticsApi.getKnowledgeGaps(courseId, 10),
      analyticsApi.getDocuments(courseId, 10)
    ])

    Object.assign(overview, overviewRes.data)
    hotTopics.value = hotRes.data || []
    knowledgeGaps.value = gapsRes.data || []
    docUsage.value = docRes.data || []

    // 未解决问题
    const unresolvedRes = await analyticsApi.getUnresolved(courseId, { page: 1, page_size: 10 })
    unresolvedList.value = unresolvedRes.data.items

    // 低满意度
    lowSatisfactionList.value = hotRes.data?.slice(0, 5).map((q) => ({
      question: q.question,
      score: Math.max(1, Math.round(q.avg_score))
    })) || []
  } catch {
    // 使用默认数据
  }
}

async function fetchCourses() {
  try {
    const res = await courseApi.getCourses({ page: 1, page_size: 50 })
    courseList.value = res.data.items
  } catch { /* handled */ }
}

onMounted(() => {
  fetchCourses().then(() => fetchAllData())
})
</script>

<style scoped>
.filter-card {
  margin-bottom: 20px;
  border-radius: 8px;
}

.stat-row {
  margin-bottom: 20px;
}

.section-card {
  margin-bottom: 20px;
  border-radius: 8px;
}

.card-title {
  font-size: 16px;
  font-weight: 600;
  color: #303133;
}

/* 统计卡片 */
.stat-card {
  padding: 20px;
  background: #fff;
  border-radius: 10px;
  border-left: 4px solid;
  transition: box-shadow 0.2s;
}

.stat-card:hover {
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
}

.stat-card--blue { border-color: #409eff; }
.stat-card--green { border-color: #67c23a; }
.stat-card--orange { border-color: #e6a23c; }
.stat-card--red { border-color: #f56c6c; }

.stat-card-value {
  font-size: 24px;
  font-weight: 700;
  color: #303133;
}

.stat-card-label {
  font-size: 13px;
  color: #909399;
  margin-top: 4px;
}
</style>
