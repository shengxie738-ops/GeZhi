#!/bin/bash
# ============================================================
# Qdrant 向量数据库初始化脚本
# 通过 REST API 创建集合和索引
# ============================================================

set -e

# 配置项（可通过环境变量覆盖）
QDRANT_URL="${QDRANT_URL:-http://localhost:6333}"
COLLECTION_NAME="course_knowledge_chunks"
VECTOR_DIM="${VECTOR_DIM:-1024}"

echo "============================================"
echo " Qdrant 初始化脚本"
echo "============================================"
echo "Qdrant URL:   ${QDRANT_URL}"
echo "集合名称:     ${COLLECTION_NAME}"
echo "向量维度:     ${VECTOR_DIM}"
echo "============================================"

# 等待Qdrant服务就绪
echo ""
echo "[1/4] 等待Qdrant服务就绪..."
MAX_RETRIES=30
RETRY_COUNT=0
until curl -sf "${QDRANT_URL}/healthz" > /dev/null 2>&1; do
  RETRY_COUNT=$((RETRY_COUNT + 1))
  if [ ${RETRY_COUNT} -ge ${MAX_RETRIES} ]; then
    echo "错误：Qdrant服务在 ${MAX_RETRIES} 次重试后仍不可用"
    exit 1
  fi
  echo "  等待Qdrant就绪... (${RETRY_COUNT}/${MAX_RETRIES})"
  sleep 2
done
echo "  ✓ Qdrant服务已就绪"

# 检查集合是否已存在
echo ""
echo "[2/4] 检查集合 '${COLLECTION_NAME}' 是否存在..."
COLLECTION_EXISTS=$(curl -sf "${QDRANT_URL}/collections/${COLLECTION_NAME}" | python3 -c "import sys,json; d=json.load(sys.stdin); print('true' if d.get('result') else 'false')" 2>/dev/null || echo "false")

if [ "${COLLECTION_EXISTS}" = "true" ]; then
  echo "  ⚠ 集合已存在，跳过创建"
else
  echo "  创建集合 '${COLLECTION_NAME}'..."
  # 创建集合：1024维向量，余弦距离
  CREATE_RESPONSE=$(curl -sf -X PUT "${QDRANT_URL}/collections/${COLLECTION_NAME}" \
    -H "Content-Type: application/json" \
    -d "{
      \"vectors\": {
        \"size\": ${VECTOR_DIM},
        \"distance\": \"Cosine\"
      },
      \"optimizers_config\": {
        \"default_segment_number\": 2
      },
      \"replication_factor\": 1
    }")

  if echo "${CREATE_RESPONSE}" | grep -q '"status":"ok"'; then
    echo "  ✓ 集合创建成功"
  else
    echo "  ✗ 集合创建失败: ${CREATE_RESPONSE}"
    exit 1
  fi
fi

# 创建Payload索引（加速过滤查询）
echo ""
echo "[3/4] 创建Payload索引..."

# course_id 索引（整数类型）
echo "  创建索引: course_id (integer)..."
curl -sf -X PUT "${QDRANT_URL}/collections/${COLLECTION_NAME}/indexes/payload/course_id" \
  -H "Content-Type: application/json" \
  -d '{"type": "integer"}' > /dev/null 2>&1 && echo "  ✓ course_id 索引已创建" || echo "  ⚠ course_id 索引可能已存在"

# document_id 索引（整数类型）
echo "  创建索引: document_id (integer)..."
curl -sf -X PUT "${QDRANT_URL}/collections/${COLLECTION_NAME}/indexes/payload/document_id" \
  -H "Content-Type: application/json" \
  -d '{"type": "integer"}' > /dev/null 2>&1 && echo "  ✓ document_id 索引已创建" || echo "  ⚠ document_id 索引可能已存在"

# enabled 索引（布尔类型）
echo "  创建索引: enabled (bool)..."
curl -sf -X PUT "${QDRANT_URL}/collections/${COLLECTION_NAME}/indexes/payload/enabled" \
  -H "Content-Type: application/json" \
  -d '{"type": "bool"}' > /dev/null 2>&1 && echo "  ✓ enabled 索引已创建" || echo "  ⚠ enabled 索引可能已存在"

# 验证集合信息
echo ""
echo "[4/4] 验证集合配置..."
COLLECTION_INFO=$(curl -sf "${QDRANT_URL}/collections/${COLLECTION_NAME}")
echo "${COLLECTION_INFO}" | python3 -c "
import sys, json
data = json.load(sys.stdin)
result = data.get('result', {})
vectors = result.get('config', {}).get('params', {}).get('vectors', {})
optimizer = result.get('optimizer_status', 'unknown')
points = result.get('points_count', 0)
print(f\"  集合名称:   ${COLLECTION_NAME}\")
print(f\"  向量维度:   {vectors.get('size', 'unknown')}\")
print(f\"  距离度量:   {vectors.get('distance', 'unknown')}\")
print(f\"  优化状态:   {optimizer}\")
print(f\"  向量数量:   {points}\")
" 2>/dev/null || echo "  ⚠ 无法解析集合信息"

echo ""
echo "============================================"
echo " ✓ Qdrant初始化完成"
echo "============================================"
