-- ============================================================
-- RAG Course 数据库初始化脚本
-- MySQL 8.0+ | InnoDB | utf8mb4
-- ============================================================

-- 创建数据库
CREATE DATABASE IF NOT EXISTS `rag_course`
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_general_ci;

USE `rag_course`;

-- ============================================================
-- 1. sys_user - 用户表
-- ============================================================
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user` (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT,
  `username`    VARCHAR(64)  NOT NULL COMMENT '用户名',
  `password`    VARCHAR(128) NOT NULL COMMENT '密码（BCrypt加密）',
  `real_name`   VARCHAR(64)  DEFAULT NULL COMMENT '真实姓名',
  `student_no`  VARCHAR(32)  DEFAULT NULL COMMENT '学号',
  `employee_no` VARCHAR(32)  DEFAULT NULL COMMENT '工号',
  `email`       VARCHAR(128) DEFAULT NULL COMMENT '邮箱',
  `role`        VARCHAR(20)  NOT NULL DEFAULT 'STUDENT' COMMENT '角色: STUDENT/TEACHER/ADMIN',
  `avatar`      VARCHAR(512) DEFAULT NULL COMMENT '头像URL',
  `enabled`     TINYINT(1)   NOT NULL DEFAULT 1 COMMENT '是否启用',
  `deleted`     TINYINT(1)   NOT NULL DEFAULT 0 COMMENT '逻辑删除: 0正常 1删除',
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  UNIQUE KEY `uk_student_no` (`student_no`),
  UNIQUE KEY `uk_employee_no` (`employee_no`),
  KEY `idx_role` (`role`),
  KEY `idx_deleted` (`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统用户表';

-- ============================================================
-- 2. course - 课程表
-- ============================================================
DROP TABLE IF EXISTS `course`;
CREATE TABLE `course` (
  `id`            BIGINT       NOT NULL AUTO_INCREMENT,
  `name`          VARCHAR(128) NOT NULL COMMENT '课程名称',
  `description`   TEXT         DEFAULT NULL COMMENT '课程描述',
  `cover_image`   VARCHAR(512) DEFAULT NULL COMMENT '课程封面图片URL',
  `course_code`   VARCHAR(64)  NOT NULL COMMENT '课程编码',
  `invite_code`   VARCHAR(32)  DEFAULT NULL COMMENT '邀请码',
  `academic_year` VARCHAR(20)  DEFAULT NULL COMMENT '学年',
  `semester`      VARCHAR(10)  DEFAULT NULL COMMENT '学期',
  `teacher_id`    BIGINT       NOT NULL COMMENT '教师用户ID',
  `is_public`     TINYINT(1)   NOT NULL DEFAULT 1 COMMENT '是否公开',
  `deleted`       TINYINT(1)   NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_course_code` (`course_code`),
  KEY `uk_invite_code` (`invite_code`),
  KEY `idx_teacher_id` (`teacher_id`),
  KEY `idx_deleted` (`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='课程表';

-- ============================================================
-- 3. course_member - 课程成员表
-- ============================================================
DROP TABLE IF EXISTS `course_member`;
CREATE TABLE `course_member` (
  `id`          BIGINT   NOT NULL AUTO_INCREMENT,
  `course_id`   BIGINT   NOT NULL COMMENT '课程ID',
  `user_id`     BIGINT   NOT NULL COMMENT '用户ID',
  `member_role` VARCHAR(20) NOT NULL DEFAULT 'STUDENT' COMMENT '成员角色: OWNER/TEACHER/STUDENT',
  `deleted`     TINYINT(1) NOT NULL DEFAULT 0,
  `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_course_user` (`course_id`, `user_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_deleted` (`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='课程成员表';

-- ============================================================
-- 4. course_chapter - 课程章节表
-- ============================================================
DROP TABLE IF EXISTS `course_chapter`;
CREATE TABLE `course_chapter` (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT,
  `course_id`   BIGINT       NOT NULL COMMENT '课程ID',
  `title`       VARCHAR(128) NOT NULL COMMENT '章节标题',
  `description` TEXT         DEFAULT NULL COMMENT '章节描述',
  `sort_order`  INT          NOT NULL DEFAULT 0 COMMENT '排序序号',
  `parent_id`   BIGINT       DEFAULT NULL COMMENT '父章节ID（支持多级章节）',
  `deleted`     TINYINT(1)   NOT NULL DEFAULT 0,
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_course_id` (`course_id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_sort_order` (`sort_order`),
  KEY `idx_deleted` (`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='课程章节表';

-- ============================================================
-- 5. knowledge_document - 知识文档表
-- ============================================================
DROP TABLE IF EXISTS `knowledge_document`;
CREATE TABLE `knowledge_document` (
  `id`           BIGINT       NOT NULL AUTO_INCREMENT,
  `course_id`    BIGINT       NOT NULL COMMENT '课程ID',
  `chapter_id`   BIGINT       DEFAULT NULL COMMENT '章节ID',
  `title`        VARCHAR(256) NOT NULL COMMENT '文档标题',
  `filename`     VARCHAR(256) DEFAULT NULL COMMENT '文件名',
  `doc_type`     VARCHAR(20)  NOT NULL DEFAULT 'PDF' COMMENT '文档类型: PDF/DOCX/TXT/MD/PPT/IMAGE',
  `file_path`    VARCHAR(512) DEFAULT NULL COMMENT '文件存储路径',
  `file_size`    BIGINT       DEFAULT 0 COMMENT '文件大小(字节)',
  `file_type`    VARCHAR(32)  DEFAULT NULL COMMENT '文件MIME类型',
  `mime_type`    VARCHAR(128) DEFAULT NULL COMMENT 'MIME类型',
  `parse_status` VARCHAR(20)  NOT NULL DEFAULT 'PENDING' COMMENT '解析状态: PENDING/PARSING/COMPLETED/FAILED',
  `parse_error`  TEXT         DEFAULT NULL COMMENT '解析错误信息',
  `uploaded_by`  BIGINT       DEFAULT NULL COMMENT '上传用户ID',
  `chunk_count`  INT          NOT NULL DEFAULT 0 COMMENT 'chunk数量',
  `content_hash` VARCHAR(64)  DEFAULT NULL COMMENT '内容哈希',
  `metadata`     JSON         DEFAULT NULL COMMENT '元数据JSON',
  `parsed_at`    DATETIME     DEFAULT NULL COMMENT '解析完成时间',
  `indexed_at`   DATETIME     DEFAULT NULL COMMENT '索引完成时间',
  `deleted`      TINYINT(1)   NOT NULL DEFAULT 0,
  `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_course_id` (`course_id`),
  KEY `idx_chapter_id` (`chapter_id`),
  KEY `idx_uploaded_by` (`uploaded_by`),
  KEY `idx_parse_status` (`parse_status`),
  KEY `idx_deleted` (`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='知识文档表';

-- ============================================================
-- 6. knowledge_chunk - 知识块表
-- ============================================================
DROP TABLE IF EXISTS `knowledge_chunk`;
CREATE TABLE `knowledge_chunk` (
  `id`          BIGINT    NOT NULL AUTO_INCREMENT,
  `document_id` BIGINT    NOT NULL COMMENT '文档ID',
  `course_id`   BIGINT    NOT NULL COMMENT '课程ID',
  `chapter_id`  BIGINT    DEFAULT NULL COMMENT '章节ID',
  `content`     TEXT      NOT NULL COMMENT '分块内容',
  `chunk_index` INT       NOT NULL DEFAULT 0 COMMENT '分块序号',
  `token_count` INT       NOT NULL DEFAULT 0 COMMENT 'Token数量',
  `start_page`  INT       DEFAULT NULL COMMENT '起始页码',
  `end_page`    INT       DEFAULT NULL COMMENT '结束页码',
  `vector_id`   VARCHAR(128) DEFAULT NULL COMMENT '向量ID（向量数据库中的ID）',
  `source_type` VARCHAR(50)  NOT NULL DEFAULT 'KNOWLEDGE' COMMENT '来源类型: KNOWLEDGE/FORUM/WRONG_QUESTION/TEXTBOOK',
  `enabled`     TINYINT(1)   NOT NULL DEFAULT 1 COMMENT '是否启用',
  `metadata`    JSON         DEFAULT NULL COMMENT '元数据JSON',
  `deleted`     TINYINT(1)   NOT NULL DEFAULT 0,
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_document_id` (`document_id`),
  KEY `idx_course_id` (`course_id`),
  KEY `idx_chapter_id` (`chapter_id`),
  KEY `idx_source_type` (`source_type`),
  KEY `idx_enabled` (`enabled`),
  KEY `idx_deleted` (`deleted`),
  FULLTEXT KEY `ft_content` (`content`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='知识块表';

-- ============================================================
-- 7. ingest_job - 解析任务表
-- ============================================================
DROP TABLE IF EXISTS `ingest_job`;
CREATE TABLE `ingest_job` (
  `id`               BIGINT   NOT NULL AUTO_INCREMENT,
  `document_id`      BIGINT   NOT NULL COMMENT '文档ID',
  `status`           VARCHAR(20) NOT NULL DEFAULT 'PENDING' COMMENT '任务状态: PENDING/PARSING/COMPLETED/FAILED',
  `progress`         INT      NOT NULL DEFAULT 0 COMMENT '处理进度百分比',
  `total_chunks`     INT      DEFAULT 0 COMMENT '总chunk数',
  `processed_chunks` INT      DEFAULT 0 COMMENT '已处理chunk数',
  `error_message`    TEXT     DEFAULT NULL COMMENT '错误信息',
  `started_at`       DATETIME DEFAULT NULL COMMENT '开始时间',
  `completed_at`     DATETIME DEFAULT NULL COMMENT '完成时间',
  `created_at`       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_document_id` (`document_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='文档解析任务表';

-- ============================================================
-- 8. forum_question - 论坛问题表
-- ============================================================
DROP TABLE IF EXISTS `forum_question`;
CREATE TABLE `forum_question` (
  `id`                 BIGINT       NOT NULL AUTO_INCREMENT,
  `course_id`          BIGINT       NOT NULL COMMENT '课程ID',
  `chapter_id`         BIGINT       DEFAULT NULL COMMENT '关联章节ID',
  `user_id`            BIGINT       NOT NULL COMMENT '提问用户ID',
  `title`              VARCHAR(256) NOT NULL COMMENT '问题标题',
  `content`            TEXT         NOT NULL COMMENT '问题内容',
  `tags`               JSON         DEFAULT NULL COMMENT '标签列表JSON',
  `status`             VARCHAR(20)  NOT NULL DEFAULT 'OPEN' COMMENT '状态: OPEN/CLOSED/RESOLVED/DELETED',
  `view_count`         INT          NOT NULL DEFAULT 0 COMMENT '浏览次数',
  `like_count`         INT          NOT NULL DEFAULT 0 COMMENT '点赞数',
  `answer_count`       INT          NOT NULL DEFAULT 0 COMMENT '回答数',
  `accepted_answer_id` BIGINT       DEFAULT NULL COMMENT '最佳答案ID',
  `is_anonymous`       TINYINT(1)   NOT NULL DEFAULT 0 COMMENT '是否匿名',
  `deleted`            TINYINT(1)   NOT NULL DEFAULT 0,
  `created_at`         DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`         DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_course_id` (`course_id`),
  KEY `idx_chapter_id` (`chapter_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_deleted` (`deleted`),
  FULLTEXT KEY `ft_title_content` (`title`, `content`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='论坛问题表';

-- ============================================================
-- 9. forum_answer - 论坛回答表
-- ============================================================
DROP TABLE IF EXISTS `forum_answer`;
CREATE TABLE `forum_answer` (
  `id`                  BIGINT   NOT NULL AUTO_INCREMENT,
  `question_id`         BIGINT   NOT NULL COMMENT '问题ID',
  `user_id`             BIGINT   NOT NULL COMMENT '回答用户ID',
  `content`             TEXT     NOT NULL COMMENT '回答内容',
  `like_count`          INT      NOT NULL DEFAULT 0 COMMENT '点赞数',
  `is_accepted`         TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否被采纳',
  `is_verified`         TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否经过教师认证',
  `verified_by`         BIGINT   DEFAULT NULL COMMENT '认证教师ID',
  `verified_at`         DATETIME DEFAULT NULL COMMENT '认证时间',
  `added_to_knowledge`  TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否已加入知识库',
  `deleted`             TINYINT(1) NOT NULL DEFAULT 0,
  `created_at`          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_question_id` (`question_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_is_accepted` (`is_accepted`),
  KEY `idx_is_verified` (`is_verified`),
  KEY `idx_deleted` (`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='论坛回答表';

-- ============================================================
-- 10. chat_session - 会话表
-- ============================================================
DROP TABLE IF EXISTS `chat_session`;
CREATE TABLE `chat_session` (
  `id`             BIGINT       NOT NULL AUTO_INCREMENT,
  `user_id`        BIGINT       NOT NULL COMMENT '用户ID',
  `course_id`      BIGINT       NOT NULL COMMENT '课程ID',
  `title`          VARCHAR(256) DEFAULT NULL COMMENT '会话标题',
  `is_rag_enabled` TINYINT(1)   NOT NULL DEFAULT 1 COMMENT '是否为RAG增强会话',
  `deleted`        TINYINT(1)   NOT NULL DEFAULT 0,
  `created_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_course_id` (`course_id`),
  KEY `idx_deleted` (`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='聊天会话表';

-- ============================================================
-- 11. chat_message - 消息表
-- ============================================================
DROP TABLE IF EXISTS `chat_message`;
CREATE TABLE `chat_message` (
  `id`             BIGINT   NOT NULL AUTO_INCREMENT,
  `session_id`     BIGINT   NOT NULL COMMENT '会话ID',
  `role`           VARCHAR(20) NOT NULL COMMENT '角色: user/assistant/system',
  `content`        LONGTEXT NOT NULL COMMENT '消息内容',
  `token_count`    INT      DEFAULT 0 COMMENT 'Token消耗数',
  `rag_enabled`    TINYINT(1) DEFAULT NULL COMMENT '是否启用RAG',
  `evidence_status` VARCHAR(30) DEFAULT NULL COMMENT '证据状态: SUPPORTED/PARTIAL/INSUFFICIENT',
  `model_used`     VARCHAR(64)  DEFAULT NULL COMMENT '使用的模型',
  `latency_ms`     INT          DEFAULT NULL COMMENT '响应延迟(毫秒)',
  `created_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_session_id` (`session_id`),
  KEY `idx_role` (`role`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='聊天消息表';

-- ============================================================
-- 12. message_citation - 引用表
-- ============================================================
DROP TABLE IF EXISTS `message_citation`;
CREATE TABLE `message_citation` (
  `id`              BIGINT       NOT NULL AUTO_INCREMENT,
  `message_id`      BIGINT       NOT NULL COMMENT '消息ID',
  `chunk_id`        BIGINT       DEFAULT NULL COMMENT '引用的chunk ID',
  `content_preview` TEXT         DEFAULT NULL COMMENT '引用内容摘要',
  `score`           DOUBLE       DEFAULT 0 COMMENT '相似度分数',
  `document_id`     BIGINT       DEFAULT NULL COMMENT '来源文档ID',
  `document_title`  VARCHAR(256) DEFAULT NULL COMMENT '来源文档标题',
  `page_number`     INT          DEFAULT NULL COMMENT '引用所在页码',
  `created_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_message_id` (`message_id`),
  KEY `idx_chunk_id` (`chunk_id`),
  KEY `idx_document_id` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='消息引用表';

-- ============================================================
-- 13. answer_feedback - 回答反馈表
-- ============================================================
DROP TABLE IF EXISTS `answer_feedback`;
CREATE TABLE `answer_feedback` (
  `id`            BIGINT   NOT NULL AUTO_INCREMENT,
  `message_id`    BIGINT   NOT NULL COMMENT '消息ID',
  `user_id`       BIGINT   NOT NULL COMMENT '用户ID',
  `feedback_type` VARCHAR(30) NOT NULL COMMENT '反馈类型: POSITIVE/NEGATIVE/UNRESOLVED',
  `content`       TEXT     DEFAULT NULL COMMENT '反馈内容',
  `created_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_message_user` (`message_id`, `user_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_feedback_type` (`feedback_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='回答反馈表';

-- ============================================================
-- 14. wrong_question - 错题表
-- ============================================================
DROP TABLE IF EXISTS `wrong_question`;
CREATE TABLE `wrong_question` (
  `id`              BIGINT   NOT NULL AUTO_INCREMENT,
  `user_id`         BIGINT   NOT NULL COMMENT '用户ID',
  `course_id`       BIGINT   NOT NULL COMMENT '课程ID',
  `question`        TEXT     NOT NULL COMMENT '题目内容',
  `answer`          TEXT     DEFAULT NULL COMMENT '正确答案',
  `user_answer`     TEXT     DEFAULT NULL COMMENT '用户答案',
  `source`          VARCHAR(128) DEFAULT NULL COMMENT '来源',
  `source_type`     VARCHAR(20)  DEFAULT 'practice' COMMENT '来源类型: exam/homework/practice/import',
  `knowledge_tags`  JSON     DEFAULT NULL COMMENT '知识点标签JSON',
  `status`          VARCHAR(20)  NOT NULL DEFAULT 'pending' COMMENT '状态: pending/mastered/reviewing',
  `review_count`    INT      NOT NULL DEFAULT 0 COMMENT '复习次数',
  `last_reviewed_at` DATETIME DEFAULT NULL COMMENT '最后复习时间',
  `deleted`         TINYINT(1) NOT NULL DEFAULT 0,
  `created_at`      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_course_id` (`course_id`),
  KEY `idx_status` (`status`),
  KEY `idx_deleted` (`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='错题表';

-- ============================================================
-- 15. favorite - 收藏表
-- ============================================================
DROP TABLE IF EXISTS `favorite`;
CREATE TABLE `favorite` (
  `id`          BIGINT   NOT NULL AUTO_INCREMENT,
  `user_id`     BIGINT   NOT NULL COMMENT '用户ID',
  `course_id`   BIGINT   NOT NULL COMMENT '课程ID',
  `source_type` VARCHAR(50)  NOT NULL COMMENT '收藏类型: ANSWER/DOCUMENT/QUESTION',
  `source_id`   BIGINT   NOT NULL COMMENT '收藏对象ID',
  `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_source` (`user_id`, `source_type`, `source_id`),
  KEY `idx_course_id` (`course_id`),
  KEY `idx_source_type_id` (`source_type`, `source_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='收藏表';

-- ============================================================
-- 16. model_config - 模型配置表
-- ============================================================
DROP TABLE IF EXISTS `model_config`;
CREATE TABLE `model_config` (
  `id`           BIGINT       NOT NULL AUTO_INCREMENT,
  `name`         VARCHAR(128) NOT NULL COMMENT '配置名称',
  `provider`     VARCHAR(50)  NOT NULL COMMENT '提供商: qwen/openai/zhupu',
  `model_type`   VARCHAR(30)  NOT NULL COMMENT '模型类型: EMBEDDING/CHAT',
  `model_id`     VARCHAR(128) NOT NULL COMMENT '模型标识',
  `api_key`      VARCHAR(512) DEFAULT NULL COMMENT 'API密钥',
  `base_url`     VARCHAR(512) DEFAULT NULL COMMENT 'API基础URL',
  `max_tokens`   INT          DEFAULT 4096 COMMENT '最大Token数',
  `temperature`  DOUBLE       DEFAULT 0.7 COMMENT '温度参数',
  `top_p`        DOUBLE       DEFAULT 0.9 COMMENT 'Top-P参数',
  `is_active`    TINYINT(1)   NOT NULL DEFAULT 1 COMMENT '是否启用',
  `is_default`   TINYINT(1)   NOT NULL DEFAULT 0 COMMENT '是否默认',
  `usage_count`  BIGINT       NOT NULL DEFAULT 0 COMMENT '使用次数',
  `config`       JSON         DEFAULT NULL COMMENT '扩展配置JSON',
  `deleted`      TINYINT(1)   NOT NULL DEFAULT 0,
  `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_provider` (`provider`),
  KEY `idx_model_type` (`model_type`),
  KEY `idx_is_default` (`is_default`),
  KEY `idx_deleted` (`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='模型配置表';

-- ============================================================
-- 17. rag_config - RAG配置表
-- ============================================================
DROP TABLE IF EXISTS `rag_config`;
CREATE TABLE `rag_config` (
  `id`                  BIGINT   NOT NULL AUTO_INCREMENT,
  `course_id`           BIGINT   DEFAULT NULL COMMENT '课程ID（NULL为全局配置）',
  `embedding_model`     VARCHAR(128) DEFAULT NULL COMMENT 'Embedding模型',
  `embedding_dimensions` INT     DEFAULT 1024 COMMENT 'Embedding维度',
  `chunk_size`          INT      DEFAULT 512 COMMENT '分块大小',
  `chunk_overlap`       INT      DEFAULT 128 COMMENT '分块重叠',
  `top_k`               INT      DEFAULT 10 COMMENT '检索Top-K',
  `score_threshold`     DOUBLE   DEFAULT 0.3 COMMENT '相关性阈值',
  `rerank_enabled`      TINYINT(1) DEFAULT 0 COMMENT '是否启用重排序',
  `rerank_model`        VARCHAR(128) DEFAULT NULL COMMENT '重排序模型',
  `retrieval_strategy`  VARCHAR(30) DEFAULT 'hybrid' COMMENT '检索策略: similarity/mmr/hybrid',
  `mmr_lambda`          DOUBLE   DEFAULT 0.5 COMMENT 'MMR Lambda参数',
  `keyword_weight`      DOUBLE   DEFAULT 0.3 COMMENT '关键词权重',
  `vector_weight`       DOUBLE   DEFAULT 0.7 COMMENT '向量权重',
  `prompt_template`     TEXT     DEFAULT NULL COMMENT '提示词模板',
  `system_prompt`       TEXT     DEFAULT NULL COMMENT '系统提示词',
  `created_at`          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_course_id` (`course_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='RAG配置表';

-- ============================================================
-- 18. notification - 通知表
-- ============================================================
DROP TABLE IF EXISTS `notification`;
CREATE TABLE `notification` (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT,
  `user_id`     BIGINT       NOT NULL COMMENT '用户ID',
  `type`        VARCHAR(30)  NOT NULL COMMENT '通知类型: system/course_invite/question_answered/answer_accepted/document_parsed/document_failed/job_completed/job_failed',
  `title`       VARCHAR(128) NOT NULL COMMENT '通知标题',
  `content`     TEXT         DEFAULT NULL COMMENT '通知内容',
  `is_read`     TINYINT(1)   NOT NULL DEFAULT 0 COMMENT '是否已读',
  `link`        VARCHAR(512) DEFAULT NULL COMMENT '关联链接',
  `metadata`    JSON         DEFAULT NULL COMMENT '元数据JSON',
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_is_read` (`is_read`),
  KEY `idx_type` (`type`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='通知表';

-- ============================================================
-- 19. audit_log - 审计日志表
-- ============================================================
DROP TABLE IF EXISTS `audit_log`;
CREATE TABLE `audit_log` (
  `id`          BIGINT        NOT NULL AUTO_INCREMENT,
  `user_id`     BIGINT        DEFAULT NULL COMMENT '操作用户ID',
  `action`      VARCHAR(64)   NOT NULL COMMENT '操作动作',
  `target_type` VARCHAR(64)   DEFAULT NULL COMMENT '操作对象类型',
  `target_id`   BIGINT        DEFAULT NULL COMMENT '操作对象ID',
  `ip_address`  VARCHAR(45)   DEFAULT NULL COMMENT 'IP地址',
  `user_agent`  VARCHAR(512)  DEFAULT NULL COMMENT 'User-Agent',
  `details`     JSON          DEFAULT NULL COMMENT '操作详情JSON',
  `created_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_action` (`action`),
  KEY `idx_target_type_id` (`target_type`, `target_id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='审计日志表';
