#!/bin/bash
# ============================================================
# RAG Course 项目初始化脚本
# 仅创建目录结构，不下载依赖、不运行命令
# ============================================================

set -e

PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"

echo "============================================"
echo " RAG Course 项目初始化"
echo "============================================"
echo " 项目根目录: ${PROJECT_ROOT}"
echo "============================================"
echo ""

# 创建核心目录结构
echo "[1/7] 创建后端目录结构..."
mkdir -p "${PROJECT_ROOT}/rag-course-server/src/main/resources/mapper"
mkdir -p "${PROJECT_ROOT}/rag-course-server/src/main/resources/static"
mkdir -p "${PROJECT_ROOT}/rag-course-server/src/test/java/com/gezi/ragcourse"

echo "[2/7] 创建前端目录结构..."
mkdir -p "${PROJECT_ROOT}/rag-course-web/public"
mkdir -p "${PROJECT_ROOT}/rag-course-web/src/assets"
mkdir -p "${PROJECT_ROOT}/rag-course-web/dist"

echo "[3/7] 创建RAG服务目录结构..."
mkdir -p "${PROJECT_ROOT}/rag-course-rag-service/app"
mkdir -p "${PROJECT_ROOT}/rag-course-rag-service/tests"

echo "[4/7] 创建运维目录结构..."
mkdir -p "${PROJECT_ROOT}/scripts"
mkdir -p "${PROJECT_ROOT}/nginx"
mkdir -p "${PROJECT_ROOT}/docs"
mkdir -p "${PROJECT_ROOT}/.github/workflows"

echo "[5/7] 创建数据目录..."
mkdir -p "${PROJECT_ROOT}/data/mysql"
mkdir -p "${PROJECT_ROOT}/data/redis"
mkdir -p "${PROJECT_ROOT}/data/qdrant"
mkdir -p "${PROJECT_ROOT}/data/minio"
mkdir -p "${PROJECT_ROOT}/uploads"
mkdir -p "${PROJECT_ROOT}/logs"

echo "[6/7] 创建配置文件..."
# 创建 .env 文件（如果不存在）
if [ ! -f "${PROJECT_ROOT}/.env" ]; then
  if [ -f "${PROJECT_ROOT}/.env.example" ]; then
    cp "${PROJECT_ROOT}/.env.example" "${PROJECT_ROOT}/.env"
    echo "  ✓ 已从 .env.example 创建 .env 文件"
  else
    echo "  ⚠ .env.example 不存在，跳过"
  fi
fi

# 创建 .gitkeep 文件（确保空目录被Git跟踪）
for DIR in data/mysql data/redis data/qdrant data/minio uploads logs; do
  touch "${PROJECT_ROOT}/${DIR}/.gitkeep"
done

echo "[7/7] 设置脚本执行权限..."
chmod +x "${PROJECT_ROOT}/scripts/"*.sh 2>/dev/null || true

echo ""
echo "============================================"
echo " ✓ 项目初始化完成"
echo "============================================"
echo ""
echo " 项目目录结构："
echo ""
echo "  ${PROJECT_ROOT}/"
echo "  ├── rag-course-server/       # Java后端"
echo "  ├── rag-course-web/          # Vue前端"
echo "  ├── rag-course-rag-service/  # Python RAG服务"
echo "  ├── scripts/                 # 运维脚本"
echo "  │   ├── init-db.sql"
echo "  │   ├── seed-data.sql"
echo "  │   ├── init-qdrant.sh"
echo "  │   ├── health-check.sh"
echo "  │   └── init-project.sh"
echo "  ├── nginx/                   # Nginx配置"
echo "  ├── data/                    # 数据持久化目录"
echo "  ├── uploads/                 # 上传文件目录"
echo "  ├── logs/                    # 日志目录"
echo "  ├── docker-compose.yml"
echo "  ├── .env.example"
echo "  └── .env"
echo ""
echo "  下一步操作："
echo "  1. 编辑 .env 文件，填入实际配置值"
echo "  2. docker-compose up -d 启动所有服务"
echo "  3. 访问 http://localhost 查看前端"
echo "  4. 访问 http://localhost:9001 查看MinIO控制台"
echo ""
