#!/bin/bash
# ============================================================
# RAG Course 服务健康检查脚本
# 检查所有 Docker 服务的健康状态
# ============================================================

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 服务列表及健康检查端点
declare -A SERVICES
SERVICES=(
  ["rag-nginx"]="http://localhost:80/health"
  ["rag-web"]="http://localhost:5173"
  ["rag-server"]="http://localhost:8080/api/actuator/health"
  ["rag-service"]="http://localhost:8091/health"
  ["rag-mysql"]="mysql://localhost:3306"
  ["rag-redis"]="redis://localhost:6379"
  ["rag-qdrant"]="http://localhost:6333/healthz"
  ["rag-minio"]="http://localhost:9000/minio/health/live"
)

echo ""
echo "============================================"
echo " RAG Course 服务健康检查"
echo "============================================"
echo " 检查时间: $(date '+%Y-%m-%d %H:%M:%S')"
echo "============================================"
echo ""

TOTAL=0
HEALTHY=0
UNHEALTHY=0

# 1. 检查 Docker 容器状态
echo -e "${BLUE}[Docker 容器状态]${NC}"
echo "--------------------------------------------"

for SERVICE_NAME in "${!SERVICES[@]}"; do
  TOTAL=$((TOTAL + 1))
  STATUS=$(docker inspect --format='{{.State.Health.Status}}' "${SERVICE_NAME}" 2>/dev/null || echo "not_found")

  case ${STATUS} in
    "healthy")
      echo -e "  ${GREEN}✓${NC} ${SERVICE_NAME}: ${GREEN}healthy${NC}"
      HEALTHY=$((HEALTHY + 1))
      ;;
    "unhealthy")
      echo -e "  ${RED}✗${NC} ${SERVICE_NAME}: ${RED}unhealthy${NC}"
      UNHEALTHY=$((UNHEALTHY + 1))
      ;;
    "starting")
      echo -e "  ${YELLOW}~${NC} ${SERVICE_NAME}: ${YELLOW}starting${NC}"
      ;;
    "not_found")
      echo -e "  ${RED}✗${NC} ${SERVICE_NAME}: ${RED}未运行${NC}"
      UNHEALTHY=$((UNHEALTHY + 1))
      ;;
    *)
      echo -e "  ${YELLOW}?${NC} ${SERVICE_NAME}: ${STATUS}"
      ;;
  esac
done

echo ""

# 2. 检查 HTTP 端点可用性
echo -e "${BLUE}[HTTP 端点检查]${NC}"
echo "--------------------------------------------"

check_http() {
  local name=$1
  local url=$2
  local timeout=${3:-5}

  HTTP_CODE=$(curl -sf -o /dev/null -w "%{http_code}" --max-time "${timeout}" "${url}" 2>/dev/null || echo "000")

  if [ "${HTTP_CODE}" -ge 200 ] && [ "${HTTP_CODE}" -lt 400 ]; then
    echo -e "  ${GREEN}✓${NC} ${name} (${url}): ${GREEN}HTTP ${HTTP_CODE}${NC}"
    return 0
  else
    echo -e "  ${RED}✗${NC} ${name} (${url}): ${RED}HTTP ${HTTP_CODE}${NC}"
    return 1
  fi
}

HTTP_FAIL=0
check_http "Nginx(80)" "http://localhost:80/health" || HTTP_FAIL=$((HTTP_FAIL + 1))
check_http "Frontend(5173)" "http://localhost:5173" 5 || HTTP_FAIL=$((HTTP_FAIL + 1))
check_http "Backend(8080)" "http://localhost:8080/api/actuator/health" 5 || HTTP_FAIL=$((HTTP_FAIL + 1))
check_http "RAG Service(8091)" "http://localhost:8091/health" 5 || HTTP_FAIL=$((HTTP_FAIL + 1))
check_http "Qdrant(6333)" "http://localhost:6333/healthz" 5 || HTTP_FAIL=$((HTTP_FAIL + 1))
check_http "MinIO(9000)" "http://localhost:9000/minio/health/live" 5 || HTTP_FAIL=$((HTTP_FAIL + 1))

echo ""

# 3. 检查关键连接
echo -e "${BLUE}[服务连接检查]${NC}"
echo "--------------------------------------------"

# MySQL
if command -v mysql &> /dev/null; then
  MYSQL_STATUS=$(mysql -h 127.0.0.1 -P 3306 -u root -ppassword -e "SELECT 1" 2>/dev/null && echo "ok" || echo "fail")
  if [ "${MYSQL_STATUS}" = "ok" ]; then
    echo -e "  ${GREEN}✓${NC} MySQL连接: ${GREEN}正常${NC}"

    # 检查表数量
    TABLE_COUNT=$(mysql -h 127.0.0.1 -P 3306 -u root -ppassword -N -e "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='rag_course'" 2>/dev/null || echo "?")
    echo -e "    数据库表数量: ${TABLE_COUNT}"
  else
    echo -e "  ${RED}✗${NC} MySQL连接: ${RED}失败${NC}"
  fi
else
  echo -e "  ${YELLOW}~${NC} MySQL: mysql客户端未安装，跳过连接检查"
fi

# Redis
if command -v redis-cli &> /dev/null; then
  REDIS_PONG=$(redis-cli -h 127.0.0.1 -p 6379 ping 2>/dev/null || echo "FAIL")
  if [ "${REDIS_PONG}" = "PONG" ]; then
    echo -e "  ${GREEN}✓${NC} Redis连接: ${GREEN}正常${NC}"
  else
    echo -e "  ${RED}✗${NC} Redis连接: ${RED}失败${NC}"
  fi
else
  echo -e "  ${YELLOW}~${NC} Redis: redis-cli未安装，跳过连接检查"
fi

echo ""

# 4. 磁盘空间
echo -e "${BLUE}[磁盘空间]${NC}"
echo "--------------------------------------------"
df -h / | tail -1 | awk '{printf "  总容量: %s, 已用: %s (%s), 可用: %s\n", $2, $3, $5, $4}'

echo ""

# 5. Docker 卷空间
echo -e "${BLUE}[Docker 数据卷]${NC}"
echo "--------------------------------------------"
for VOL in rag-mysql-data rag-redis-data rag-qdrant-data rag-minio-data rag-uploads-data; do
  SIZE=$(docker system df -v 2>/dev/null | grep "${VOL}" | awk '{print $3}' || echo "?")
  if [ -n "${SIZE}" ] && [ "${SIZE}" != "?" ]; then
    echo -e "  ${VOL}: ${SIZE}"
  else
    echo -e "  ${VOL}: 未找到"
  fi
done

echo ""

# 6. 总结
echo "============================================"
echo -e " 健康检查完成"
echo -e " 容器: ${GREEN}健康 ${HEALTHY}${NC} / ${RED}异常 ${UNHEALTHY}${NC} / 总计 ${TOTAL}"
echo -e " HTTP: ${RED}失败 ${HTTP_FAIL}${NC}"
echo "============================================"
echo ""

# 退出码：有异常则非0
if [ ${UNHEALTHY} -gt 0 ] || [ ${HTTP_FAIL} -gt 0 ]; then
  exit 1
fi
exit 0
