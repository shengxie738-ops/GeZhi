package com.gezi.ragcourse.rag.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gezi.ragcourse.common.exception.BusinessException;
import com.gezi.ragcourse.document.entity.KnowledgeChunk;
import com.gezi.ragcourse.document.entity.KnowledgeDocument;
import com.gezi.ragcourse.document.mapper.KnowledgeChunkMapper;
import com.gezi.ragcourse.document.mapper.KnowledgeDocumentMapper;
import com.gezi.ragcourse.rag.dto.*;
import com.gezi.ragcourse.rag.entity.ChatMessage;
import com.gezi.ragcourse.rag.entity.ChatSession;
import com.gezi.ragcourse.rag.entity.MessageCitation;
import com.gezi.ragcourse.rag.mapper.ChatMessageMapper;
import com.gezi.ragcourse.rag.mapper.ChatSessionMapper;
import com.gezi.ragcourse.rag.mapper.MessageCitationMapper;
import com.gezi.ragcourse.rag.service.RagService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.ArrayList;
import java.util.List;

/**
 * RAG服务实现
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RagServiceImpl implements RagService {

    private final KnowledgeChunkMapper chunkMapper;
    private final KnowledgeDocumentMapper documentMapper;
    private final ChatSessionMapper chatSessionMapper;
    private final ChatMessageMapper chatMessageMapper;
    private final MessageCitationMapper citationMapper;

    @Override
    public SearchResult search(Long userId, SearchRequest request) {
        long startTime = System.currentTimeMillis();

        // 构建查询条件
        LambdaQueryWrapper<KnowledgeChunk> wrapper = new LambdaQueryWrapper<>();
        if (request.getCourseId() != null) {
            wrapper.eq(KnowledgeChunk::getCourseId, request.getCourseId());
        }
        if (request.getChapterId() != null) {
            wrapper.eq(KnowledgeChunk::getChapterId, request.getChapterId());
        }
        // 文本搜索（后续替换为向量搜索）
        wrapper.like(KnowledgeChunk::getContent, request.getQuery());
        Page<KnowledgeChunk> page = new Page<>(1, request.getTopK());
        chunkMapper.selectPage(page, wrapper);

        List<KnowledgeChunk> chunks = page.getRecords();

        // 构建搜索结果
        List<SearchResult.SearchResultItem> items = chunks.stream().map(chunk -> {
            KnowledgeDocument doc = documentMapper.selectById(chunk.getDocumentId());
            return SearchResult.SearchResultItem.builder()
                    .chunkId(chunk.getId())
                    .content(chunk.getContent())
                    .score(0.85) // TODO: 实际应使用向量相似度分数
                    .documentId(chunk.getDocumentId())
                    .documentTitle(doc != null ? doc.getTitle() : "")
                    .courseId(chunk.getCourseId())
                    .chapterId(chunk.getChapterId())
                    .build();
        }).toList();

        long searchTime = System.currentTimeMillis() - startTime;

        return SearchResult.builder()
                .items(items)
                .searchTimeMs(searchTime)
                .totalResults(items.size())
                .build();
    }

    @Override
    public AskResponse ask(Long userId, AskRequest request) {
        // 创建或获取会话
        ChatSession session;
        if (request.getSessionId() != null) {
            session = chatSessionMapper.selectById(request.getSessionId());
            if (session == null) {
                throw new BusinessException(404, "会话不存在");
            }
        } else {
            session = ChatSession.builder()
                    .userId(userId)
                    .courseId(request.getCourseId())
                    .title(request.getQuestion())
                    .isRagEnabled(request.getRagEnabled())
                    .build();
            chatSessionMapper.insert(session);
        }

        // 保存用户消息
        ChatMessage userMessage = ChatMessage.builder()
                .sessionId(session.getId())
                .role("user")
                .content(request.getQuestion())
                .ragEnabled(request.getRagEnabled())
                .build();
        chatMessageMapper.insert(userMessage);

        // RAG检索
        List<MessageCitation> citations = new ArrayList<>();
        String answer = "";

        if (Boolean.TRUE.equals(request.getRagEnabled())) {
            // 执行向量搜索
            SearchRequest searchReq = SearchRequest.builder()
                    .query(request.getQuestion())
                    .courseId(request.getCourseId())
                    .chapterId(request.getChapterId())
                    .sourceTypes(request.getSourceTypes())
                    .topK(5)
                    .build();
            SearchResult searchResult = search(userId, searchReq);

            // TODO: 调用LLM API，将检索到的上下文注入prompt
            answer = "这是基于RAG检索增强的AI回答。检索到的相关知识片段: " +
                    searchResult.getItems().size() + " 条。";

            // 保存引用
            for (SearchResult.SearchResultItem item : searchResult.getItems()) {
                MessageCitation citation = MessageCitation.builder()
                        .chunkId(item.getChunkId())
                        .contentPreview(item.getContent().substring(0, Math.min(200, item.getContent().length())))
                        .score(item.getScore())
                        .documentId(item.getDocumentId())
                        .documentTitle(item.getDocumentTitle())
                        .build();
                citationMapper.insert(citation);
                citations.add(citation);
            }
        } else {
            // 不启用RAG，直接调用LLM
            answer = "这是AI直接回答（未使用RAG检索增强）。";
        }

        // 保存AI回答
        ChatMessage aiMessage = ChatMessage.builder()
                .sessionId(session.getId())
                .role("assistant")
                .content(answer)
                .ragEnabled(request.getRagEnabled())
                .evidenceStatus(!citations.isEmpty() ? "SUPPORTED" : "UNSUPPORTED")
                .build();
        chatMessageMapper.insert(aiMessage);

        // 回填messageId到引用记录
        for (MessageCitation citation : citations) {
            citation.setMessageId(aiMessage.getId());
            citationMapper.updateById(citation);
        }

        // 构建引用DTO
        List<CitationDTO> citationDTOs = citations.stream().map(c ->
                CitationDTO.builder()
                        .id(c.getId())
                        .contentPreview(c.getContentPreview())
                        .score(c.getScore())
                        .documentId(c.getDocumentId())
                        .documentTitle(c.getDocumentTitle())
                        .chunkId(c.getChunkId())
                        .build()
        ).toList();

        return AskResponse.builder()
                .answer(answer)
                .sessionId(session.getId())
                .messageId(aiMessage.getId())
                .evidenceStatus(aiMessage.getEvidenceStatus())
                .citations(citationDTOs)
                .tokenCount(0)
                .build();
    }

    @Override
    @Async
    public SseEmitter askStream(Long userId, AskRequest request) {
        SseEmitter emitter = new SseEmitter(120000L); // 2分钟超时

        try {
            // 获取或创建会话
            ChatSession session;
            if (request.getSessionId() != null) {
                session = chatSessionMapper.selectById(request.getSessionId());
            } else {
                session = ChatSession.builder()
                        .userId(userId)
                        .courseId(request.getCourseId())
                        .title(request.getQuestion())
                        .isRagEnabled(request.getRagEnabled())
                        .build();
                chatSessionMapper.insert(session);
            }

            // 发送会话ID
            emitter.send(SseEmitter.event()
                    .name("session")
                    .data(session.getId()));

            // TODO: 实际的流式LLM调用
            // 模拟流式输出
            String[] words = "这是一个流式回答的示例，模拟AI逐字输出的效果。".split("");
            StringBuilder fullAnswer = new StringBuilder();
            for (String word : words) {
                fullAnswer.append(word);
                emitter.send(SseEmitter.event()
                        .name("chunk")
                        .data(word));
                Thread.sleep(50);
            }

            // 发送完成信号
            emitter.send(SseEmitter.event()
                    .name("done")
                    .data("completed"));

            emitter.complete();
        } catch (Exception e) {
            log.error("SSE流式输出异常", e);
            emitter.completeWithError(e);
        }

        return emitter;
    }
}
