package com.gezi.ragcourse.document.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 文本分块DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "文本分块信息")
public class ChunkDTO {

    @Schema(description = "分块ID")
    private Long id;

    @Schema(description = "分块内容")
    private String content;

    @Schema(description = "分块序号")
    private Integer chunkIndex;

    @Schema(description = "Token数量")
    private Integer tokenCount;

    @Schema(description = "来源文档ID")
    private Long documentId;

    @Schema(description = "来源文档标题")
    private String documentTitle;
}
