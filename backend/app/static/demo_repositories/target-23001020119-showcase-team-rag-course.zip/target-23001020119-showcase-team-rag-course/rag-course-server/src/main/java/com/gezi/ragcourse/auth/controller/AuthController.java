package com.gezi.ragcourse.auth.controller;

import com.gezi.ragcourse.auth.dto.*;
import com.gezi.ragcourse.auth.service.AuthService;
import com.gezi.ragcourse.common.api.ApiResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * 认证控制器
 * 权限说明: login和register公开访问，其他接口需要登录认证
 */
@Tag(name = "认证模块")
@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    /**
     * 用户登录 - 公开接口
     */
    @Operation(summary = "用户登录", description = "用户名密码登录，返回JWT Token")
    @PostMapping("/login")
    public ApiResponse<LoginResponse> login(@Valid @RequestBody LoginRequest request) {
        return ApiResponse.success(authService.login(request));
    }

    /**
     * 用户注册 - 公开接口
     */
    @Operation(summary = "用户注册", description = "新用户注册")
    @PostMapping("/register")
    public ApiResponse<UserDTO> register(@Valid @RequestBody RegisterRequest request) {
        return ApiResponse.success("注册成功", authService.register(request));
    }

    /**
     * 用户登出 - 需要登录
     */
    @Operation(summary = "用户登出", description = "登出当前用户，使Token失效")
    @PostMapping("/logout")
    public ApiResponse<Void> logout(HttpServletRequest request) {
        String token = extractToken(request);
        if (token == null || token.isBlank()) {
            return ApiResponse.error(401, "未提供有效的认证Token");
        }
        authService.logout(token);
        return ApiResponse.success();
    }

    /**
     * 刷新令牌 - 公开接口（使用refreshToken）
     */
    @Operation(summary = "刷新令牌", description = "使用refreshToken获取新的accessToken")
    @PostMapping("/refresh")
    public ApiResponse<LoginResponse> refresh(@RequestBody java.util.Map<String, String> body) {
        String refreshToken = body.get("refreshToken");
        return ApiResponse.success(authService.refreshToken(refreshToken));
    }

    /**
     * 获取当前用户信息 - 需要登录
     */
    @Operation(summary = "获取当前用户信息", description = "获取当前登录用户的基本信息")
    @GetMapping("/me")
    public ApiResponse<UserDTO> getCurrentUser(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute("userId");
        return ApiResponse.success(authService.getCurrentUser(userId));
    }

    /**
     * 从请求头中提取Token
     */
    private String extractToken(HttpServletRequest request) {
        String bearerToken = request.getHeader("Authorization");
        if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7);
        }
        return null;
    }
}
