package com.gezi.ragcourse.forum.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gezi.ragcourse.forum.entity.ForumAnswer;
import org.apache.ibatis.annotations.Mapper;

/**
 * 论坛回答Mapper接口
 */
@Mapper
public interface ForumAnswerMapper extends BaseMapper<ForumAnswer> {
}
