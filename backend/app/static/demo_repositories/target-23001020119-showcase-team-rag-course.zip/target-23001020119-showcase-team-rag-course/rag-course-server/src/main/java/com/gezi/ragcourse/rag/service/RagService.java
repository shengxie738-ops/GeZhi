package com.gezi.ragcourse.rag.service;

import com.gezi.ragcourse.rag.dto.AskRequest;
import com.gezi.ragcourse.rag.dto.AskResponse;
import com.gezi.ragcourse.rag.dto.SearchRequest;
import com.gezi.ragcourse.rag.dto.SearchResult;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.List;

/**
 * RAG服务接口
 */
public interface RagService {

    /**
     * 向量搜索
     */
    SearchResult search(Long userId, SearchRequest request);

    /**
     * RAG问答（同步）
     */
    AskResponse ask(Long userId, AskRequest request);

    /**
     * RAG问答（SSE流式）
     */
    SseEmitter askStream(Long userId, AskRequest request);
}
