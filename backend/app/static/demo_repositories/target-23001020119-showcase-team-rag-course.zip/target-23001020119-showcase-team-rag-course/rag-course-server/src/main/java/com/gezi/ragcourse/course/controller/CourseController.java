package com.gezi.ragcourse.course.controller;

import com.gezi.ragcourse.common.api.ApiResponse;
import com.gezi.ragcourse.common.api.PageResult;
import com.gezi.ragcourse.course.dto.CreateCourseRequest;
import com.gezi.ragcourse.course.entity.Course;
import com.gezi.ragcourse.course.entity.CourseChapter;
import com.gezi.ragcourse.course.service.CourseService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 课程管理控制器
 * 权限说明: 创建/修改/删除课程需要TEACHER或ADMIN角色
 */
@Tag(name = "课程模块")
@RestController
@RequestMapping("/courses")
@RequiredArgsConstructor
public class CourseController {

    private final CourseService courseService;

    /**
     * 创建课程 - 需要TEACHER或ADMIN权限
     */
    @Operation(summary = "创建课程", description = "教师创建新课程")
    @PostMapping
    public ApiResponse<Course> createCourse(@Valid @RequestBody CreateCourseRequest request,
                                            HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        return ApiResponse.success("课程创建成功", courseService.createCourse(userId, request));
    }

    /**
     * 获取课程列表 - 需要登录
     */
    @Operation(summary = "获取课程列表", description = "分页获取课程列表")
    @GetMapping
    public ApiResponse<PageResult<Course>> listCourses(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String keyword) {
        return ApiResponse.success(courseService.listCourses(page, size, keyword));
    }

    /**
     * 获取课程详情 - 需要登录
     */
    @Operation(summary = "获取课程详情", description = "获取指定课程的详细信息")
    @GetMapping("/{courseId}")
    public ApiResponse<Course> getCourse(@PathVariable Long courseId) {
        return ApiResponse.success(courseService.getCourseById(courseId));
    }

    /**
     * 更新课程 - 需要TEACHER或ADMIN权限（仅课程创建者可修改）
     */
    @Operation(summary = "更新课程", description = "更新课程信息")
    @PutMapping("/{courseId}")
    public ApiResponse<Course> updateCourse(@PathVariable Long courseId,
                                            @Valid @RequestBody CreateCourseRequest request,
                                            HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        return ApiResponse.success("更新成功", courseService.updateCourse(courseId, request, userId));
    }

    /**
     * 删除课程 - 需要TEACHER或ADMIN权限（仅课程创建者可删除）
     */
    @Operation(summary = "删除课程", description = "删除指定课程")
    @DeleteMapping("/{courseId}")
    public ApiResponse<Void> deleteCourse(@PathVariable Long courseId,
                                          HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        courseService.deleteCourse(courseId, userId);
        return ApiResponse.success();
    }

    /**
     * 获取课程章节列表 - 需要登录
     */
    @Operation(summary = "获取课程章节列表", description = "获取指定课程的所有章节")
    @GetMapping("/{courseId}/chapters")
    public ApiResponse<List<CourseChapter>> getCourseChapters(@PathVariable Long courseId) {
        return ApiResponse.success(courseService.getCourseChapters(courseId));
    }
}
