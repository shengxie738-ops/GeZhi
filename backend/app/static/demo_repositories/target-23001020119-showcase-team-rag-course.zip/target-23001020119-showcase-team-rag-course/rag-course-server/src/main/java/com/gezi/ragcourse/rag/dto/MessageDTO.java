package com.gezi.ragcourse.rag.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 消息DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "聊天消息")
public class MessageDTO {

    @Schema(description = "消息ID")
    private Long id;

    @Schema(description = "会话ID")
    private Long sessionId;

    @Schema(description = "角色: user, assistant")
    private String role;

    @Schema(description = "消息内容")
    private String content;

    @Schema(description = "Token消耗数")
    private Integer tokenCount;

    @Schema(description = "是否启用RAG")
    private Boolean ragEnabled;

    @Schema(description = "证据状态: SUPPORTED, PARTIAL, UNSUPPORTED")
    private String evidenceStatus;

    @Schema(description = "引用列表")
    private List<CitationDTO> citations;

    @Schema(description = "创建时间")
    private LocalDateTime createdAt;
}
