package com.gezi.ragcourse.rag.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * 创建会话请求
 */
@Data
@Schema(description = "创建会话请求")
public class CreateSessionRequest {

    @NotNull(message = "课程ID不能为空")
    @Schema(description = "课程ID", example = "1")
    private Long courseId;

    @Schema(description = "会话标题")
    private String title;
}
