package com.gezi.ragcourse.document.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 知识库文本分块实体
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("knowledge_chunk")
public class KnowledgeChunk {

    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 文档ID
     */
    private Long documentId;

    /**
     * 课程ID
     */
    private Long courseId;

    /**
     * 章节ID
     */
    private Long chapterId;

    /**
     * 分块内容
     */
    private String content;

    /**
     * 分块序号
     */
    private Integer chunkIndex;

    /**
     * Token数量
     */
    private Integer tokenCount;

    /**
     * 向量ID（向量数据库中的ID）
     */
    private String vectorId;

    /**
     * 来源类型
     */
    private String sourceType;

    @TableLogic
    private Integer deleted;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;
}
