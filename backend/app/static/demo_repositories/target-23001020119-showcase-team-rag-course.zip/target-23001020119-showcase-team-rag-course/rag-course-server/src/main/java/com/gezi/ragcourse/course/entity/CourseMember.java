package com.gezi.ragcourse.course.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 课程成员实体
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("course_member")
public class CourseMember {

    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 课程ID
     */
    private Long courseId;

    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 成员角色: OWNER(课程创建者), TEACHER(助教), STUDENT(学生)
     */
    private String memberRole;

    @TableLogic
    private Integer deleted;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;
}
