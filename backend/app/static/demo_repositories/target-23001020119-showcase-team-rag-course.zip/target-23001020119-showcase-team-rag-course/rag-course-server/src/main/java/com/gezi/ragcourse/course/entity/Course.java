package com.gezi.ragcourse.course.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 课程实体
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("course")
public class Course {

    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 课程名称
     */
    private String name;

    /**
     * 课程描述
     */
    private String description;

    /**
     * 课程封面图片URL
     */
    private String coverImage;

    /**
     * 课程编码
     */
    private String courseCode;

    /**
     * 学年
     */
    private String academicYear;

    /**
     * 学期
     */
    private String semester;

    /**
     * 教师用户ID
     */
    private Long teacherId;

    /**
     * 是否公开
     */
    @Builder.Default
    private Boolean isPublic = true;

    /**
     * 逻辑删除
     */
    @TableLogic
    private Integer deleted;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updatedAt;
}
