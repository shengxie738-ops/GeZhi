package com.gezi.ragcourse.audit.aspect;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gezi.ragcourse.audit.annotation.AuditAnnotation;
import com.gezi.ragcourse.audit.entity.AuditLog;
import com.gezi.ragcourse.audit.mapper.AuditLogMapper;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.lang.reflect.Method;

/**
 * 审计切面 - 拦截带有@AuditAnnotation注解的方法，自动记录审计日志
 */
@Slf4j
@Aspect
@Component
@RequiredArgsConstructor
public class AuditAspect {

    private final AuditLogMapper auditLogMapper;
    private final ObjectMapper objectMapper;

    @Around("@annotation(com.gezi.ragcourse.audit.annotation.AuditAnnotation)")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        long startTime = System.currentTimeMillis();

        // 获取注解信息
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        AuditAnnotation annotation = method.getAnnotation(AuditAnnotation.class);

        // 构建审计日志
        AuditLog auditLog = new AuditLog();
        auditLog.setModule(annotation.module());
        auditLog.setAction(annotation.action());
        auditLog.setDescription(annotation.description());

        // 获取请求信息
        try {
            ServletRequestAttributes attributes =
                    (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if (attributes != null) {
                HttpServletRequest request = attributes.getRequest();
                auditLog.setRequestMethod(request.getMethod());
                auditLog.setRequestUrl(request.getRequestURI());
                auditLog.setIpAddress(getClientIp(request));

                // 从请求属性中获取当前用户信息
                Object userIdAttr = request.getAttribute("userId");
                if (userIdAttr != null) {
                    auditLog.setUserId((Long) userIdAttr);
                }
                Object usernameAttr = request.getAttribute("username");
                if (usernameAttr != null) {
                    auditLog.setUsername((String) usernameAttr);
                }
            }
        } catch (Exception e) {
            log.warn("获取请求信息失败", e);
        }

        // 记录请求参数
        try {
            Object[] args = joinPoint.getArgs();
            if (args != null && args.length > 0) {
                // 过滤掉HttpServletRequest和HttpServletResponse参数
                Object[] serializableArgs = new Object[args.length];
                int idx = 0;
                for (Object arg : args) {
                    if (arg != null && !(arg instanceof jakarta.servlet.http.HttpServletRequest)
                            && !(arg instanceof jakarta.servlet.http.HttpServletResponse)) {
                        serializableArgs[idx++] = arg;
                    }
                }
                String params = objectMapper.writeValueAsString(serializableArgs);
                auditLog.setRequestParams(params.length() > 2000
                        ? params.substring(0, 2000) : params);
            }
        } catch (Exception e) {
            log.warn("序列化请求参数失败", e);
        }

        Object result;
        try {
            // 执行目标方法
            result = joinPoint.proceed();
            auditLog.setResult("SUCCESS");
        } catch (Throwable e) {
            auditLog.setResult("FAILURE");
            auditLog.setErrorMessage(e.getMessage() != null
                    ? e.getMessage().substring(0, Math.min(500, e.getMessage().length()))
                    : "未知错误");
            throw e;
        } finally {
            // 记录耗时
            long duration = System.currentTimeMillis() - startTime;
            auditLog.setDurationMs(duration);

            // 异步保存审计日志（避免影响主流程性能）
            try {
                auditLogMapper.insert(auditLog);
            } catch (Exception e) {
                log.error("保存审计日志失败", e);
            }
        }

        return result;
    }

    /**
     * 获取客户端真实IP
     */
    private String getClientIp(HttpServletRequest request) {
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("X-Real-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        // 多个代理时取第一个
        if (ip != null && ip.contains(",")) {
            ip = ip.substring(0, ip.indexOf(",")).trim();
        }
        return ip;
    }
}
