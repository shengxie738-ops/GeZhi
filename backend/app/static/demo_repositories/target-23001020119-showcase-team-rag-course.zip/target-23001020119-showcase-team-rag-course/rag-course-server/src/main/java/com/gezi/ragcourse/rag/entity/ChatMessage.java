package com.gezi.ragcourse.rag.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 聊天消息实体
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("chat_message")
public class ChatMessage {

    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 会话ID
     */
    private Long sessionId;

    /**
     * 角色: user, assistant
     */
    private String role;

    /**
     * 消息内容
     */
    private String content;

    /**
     * Token消耗数
     */
    private Integer tokenCount;

    /**
     * 是否启用RAG
     */
    private Boolean ragEnabled;

    /**
     * 证据状态: SUPPORTED(有证据), PARTIAL(部分证据), UNSUPPORTED(无证据)
     */
    private String evidenceStatus;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;
}
