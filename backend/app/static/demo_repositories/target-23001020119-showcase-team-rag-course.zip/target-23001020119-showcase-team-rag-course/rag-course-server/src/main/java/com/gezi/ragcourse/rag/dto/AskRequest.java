package com.gezi.ragcourse.rag.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.util.List;

/**
 * RAG问答请求
 */
@Data
@Schema(description = "RAG问答请求")
public class AskRequest {

    @Schema(description = "课程ID", example = "1")
    private Long courseId;

    @Schema(description = "会话ID（可选，不传则创建新会话）")
    private Long sessionId;

    @NotBlank(message = "问题不能为空")
    @Schema(description = "用户问题", example = "什么是向量数据库？")
    private String question;

    @Schema(description = "限定章节ID")
    private Long chapterId;

    @Schema(description = "限定来源类型列表")
    private List<String> sourceTypes;

    @Schema(description = "是否启用RAG增强", defaultValue = "true")
    private Boolean ragEnabled = true;
}
