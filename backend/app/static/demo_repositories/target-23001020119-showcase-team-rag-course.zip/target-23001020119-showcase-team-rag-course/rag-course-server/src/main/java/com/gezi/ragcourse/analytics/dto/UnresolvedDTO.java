package com.gezi.ragcourse.analytics.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 未解决问题DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "未解决问题")
public class UnresolvedDTO {

    @Schema(description = "问题ID")
    private Long id;

    @Schema(description = "问题标题")
    private String question;

    @Schema(description = "提问者")
    private String askedBy;

    @Schema(description = "提问时间")
    private String askedAt;

    @Schema(description = "回答数量")
    private Integer answerCount;

    @Schema(description = "浏览次数")
    private Integer viewCount;

    @Schema(description = "优先级: high, medium, low")
    private String priority;
}
