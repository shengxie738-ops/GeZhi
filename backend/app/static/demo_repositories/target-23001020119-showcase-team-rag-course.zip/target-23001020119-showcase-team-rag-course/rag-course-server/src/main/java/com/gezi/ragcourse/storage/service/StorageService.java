package com.gezi.ragcourse.storage.service;

/**
 * 存储服务接口
 */
public interface StorageService {

    /**
     * 获取文件预签名下载URL
     */
    String getPresignedUrl(String objectName);

    /**
     * 删除文件
     */
    void deleteFile(String objectName);

    /**
     * 获取文件信息（大小、类型等）
     */
    FileInfo getFileInfo(String objectName);

    /**
     * 文件信息DTO
     */
    record FileInfo(String objectName, String contentType, long size, String lastModified) {}
}
