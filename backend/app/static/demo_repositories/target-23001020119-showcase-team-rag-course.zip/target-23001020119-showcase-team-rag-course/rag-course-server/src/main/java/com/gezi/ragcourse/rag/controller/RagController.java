package com.gezi.ragcourse.rag.controller;

import com.gezi.ragcourse.common.api.ApiResponse;
import com.gezi.ragcourse.rag.dto.AskRequest;
import com.gezi.ragcourse.rag.dto.AskResponse;
import com.gezi.ragcourse.rag.dto.SearchRequest;
import com.gezi.ragcourse.rag.dto.SearchResult;
import com.gezi.ragcourse.rag.service.RagService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

/**
 * RAG检索与问答控制器
 */
@Tag(name = "RAG检索问答模块")
@RestController
@RequestMapping("/rag")
@RequiredArgsConstructor
public class RagController {

    private final RagService ragService;

    /**
     * 向量搜索
     */
    @Operation(summary = "向量搜索", description = "基于关键词对知识库进行向量检索，返回相关片段")
    @ApiResponses({
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "搜索成功")
    })
    @PostMapping("/search")
    public ApiResponse<SearchResult> search(
            @Valid @RequestBody SearchRequest request,
            HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        return ApiResponse.success(ragService.search(userId, request));
    }

    /**
     * RAG问答（同步）
     */
    @Operation(summary = "RAG问答", description = "基于知识库检索增强的AI同步问答")
    @ApiResponses({
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "回答成功")
    })
    @PostMapping("/ask")
    public ApiResponse<AskResponse> ask(
            @Valid @RequestBody AskRequest request,
            HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        return ApiResponse.success(ragService.ask(userId, request));
    }

    /**
     * RAG问答（SSE流式）
     */
    @Operation(summary = "RAG流式问答", description = "基于知识库检索增强的AI流式回答（SSE）")
    @PostMapping(value = "/ask/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    @ApiResponses({
            @io.swagger.v3.oas.annotations.responses.ApiResponse(
                    responseCode = "200",
                    description = "SSE流式响应",
                    content = @io.swagger.v3.oas.annotations.media.Content(
                            mediaType = MediaType.TEXT_EVENT_STREAM_VALUE))
    })
    public SseEmitter askStream(
            @Valid @RequestBody AskRequest request,
            HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        return ragService.askStream(userId, request);
    }
}
