package com.gezi.ragcourse.analytics.controller;

import com.gezi.ragcourse.analytics.dto.*;
import com.gezi.ragcourse.analytics.service.AnalyticsService;
import com.gezi.ragcourse.common.api.ApiResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 教学分析控制器
 */
@Tag(name = "教学分析模块")
@RestController
@RequestMapping("/analytics")
@RequiredArgsConstructor
public class AnalyticsController {

    private final AnalyticsService analyticsService;

    /**
     * 获取课程概览数据
     */
    @Operation(summary = "课程概览", description = "获取指定课程的综合概览数据")
    @GetMapping("/overview")
    public ApiResponse<OverviewDTO> getCourseOverview(
            @RequestParam(required = false) Long courseId) {
        return ApiResponse.success(analyticsService.getCourseOverview(courseId));
    }

    /**
     * 获取热门问题
     */
    @Operation(summary = "热门问题", description = "获取指定课程的热门问题排行")
    @GetMapping("/hot-questions")
    public ApiResponse<List<HotQuestionDTO>> getHotQuestions(
            @RequestParam(required = false) Long courseId,
            @RequestParam(defaultValue = "10") int limit) {
        return ApiResponse.success(analyticsService.getHotQuestions(courseId, limit));
    }

    /**
     * 获取未解决问题
     */
    @Operation(summary = "未解决问题", description = "获取指定课程的未解决问题列表")
    @GetMapping("/unresolved")
    public ApiResponse<List<UnresolvedDTO>> getUnresolvedQuestions(
            @RequestParam(required = false) Long courseId) {
        return ApiResponse.success(analyticsService.getUnresolvedQuestions(courseId));
    }

    /**
     * 获取知识点缺口分析
     */
    @Operation(summary = "知识点缺口", description = "分析指定课程各章节的知识点覆盖缺口")
    @GetMapping("/knowledge-gaps")
    public ApiResponse<List<KnowledgeGapDTO>> getKnowledgeGaps(
            @RequestParam(required = false) Long courseId) {
        return ApiResponse.success(analyticsService.getKnowledgeGaps(courseId));
    }

    /**
     * 获取文档使用统计
     */
    @Operation(summary = "文档使用统计", description = "获取指定课程文档的使用情况统计")
    @GetMapping("/documents")
    public ApiResponse<List<DocumentUsageDTO>> getDocumentUsage(
            @RequestParam(required = false) Long courseId) {
        return ApiResponse.success(analyticsService.getDocumentUsage(courseId));
    }

    /**
     * 获取模型使用统计
     */
    @Operation(summary = "模型使用统计", description = "获取指定课程AI模型的使用情况统计")
    @GetMapping("/model-usage")
    public ApiResponse<List<ModelUsageDTO>> getModelUsage(
            @RequestParam(required = false) Long courseId) {
        return ApiResponse.success(analyticsService.getModelUsage(courseId));
    }
}
