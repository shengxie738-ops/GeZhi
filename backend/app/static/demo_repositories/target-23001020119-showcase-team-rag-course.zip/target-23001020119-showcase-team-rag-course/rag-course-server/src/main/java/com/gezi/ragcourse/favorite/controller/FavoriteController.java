package com.gezi.ragcourse.favorite.controller;

import com.gezi.ragcourse.common.api.ApiResponse;
import com.gezi.ragcourse.common.api.PageResult;
import com.gezi.ragcourse.favorite.entity.Favorite;
import com.gezi.ragcourse.favorite.service.FavoriteService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * 收藏管理控制器
 * 权限说明: 所有接口需要登录，用户只能操作自己的收藏
 */
@Tag(name = "收藏模块")
@RestController
@RequestMapping("/favorites")
@RequiredArgsConstructor
public class FavoriteController {

    private final FavoriteService favoriteService;

    /**
     * 获取收藏列表
     */
    @Operation(summary = "获取收藏列表", description = "分页获取用户收藏列表，支持按目标类型过滤")
    @GetMapping
    public ApiResponse<PageResult<Favorite>> listFavorites(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String targetType,
            HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        return ApiResponse.success(favoriteService.listFavorites(page, size, userId, targetType));
    }

    /**
     * 添加收藏
     */
    @Operation(summary = "添加收藏", description = "收藏指定内容（课程、问题、文档、回答）")
    @PostMapping
    public ApiResponse<Favorite> addFavorite(@RequestParam String targetType,
                                             @RequestParam Long targetId,
                                             HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        return ApiResponse.success("收藏成功", favoriteService.addFavorite(userId, targetType, targetId));
    }

    /**
     * 取消收藏
     */
    @Operation(summary = "取消收藏", description = "取消收藏指定内容")
    @DeleteMapping("/{targetType}/{targetId}")
    public ApiResponse<Void> removeFavorite(@PathVariable String targetType,
                                            @PathVariable Long targetId,
                                            HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        favoriteService.removeFavorite(userId, targetType, targetId);
        return ApiResponse.success("取消收藏成功");
    }
}
