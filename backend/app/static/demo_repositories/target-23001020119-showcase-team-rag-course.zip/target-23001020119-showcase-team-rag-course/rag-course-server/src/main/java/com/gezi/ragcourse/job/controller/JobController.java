package com.gezi.ragcourse.job.controller;

import com.gezi.ragcourse.common.api.ApiResponse;
import com.gezi.ragcourse.common.api.PageResult;
import com.gezi.ragcourse.job.service.JobService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * 任务管理控制器
 * 权限说明: 需要教师或管理员角色
 */
@Tag(name = "任务模块")
@RestController
@RequestMapping("/jobs")
@RequiredArgsConstructor
public class JobController {

    private final JobService jobService;

    /**
     * 获取任务列表
     */
    @Operation(summary = "获取任务列表", description = "分页获取异步任务列表，支持按状态筛选")
    @GetMapping
    public ApiResponse<PageResult<Map<String, Object>>> listJobs(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String status) {
        return ApiResponse.success(jobService.listJobs(page, size, status));
    }

    /**
     * 获取任务详情
     */
    @Operation(summary = "获取任务详情", description = "获取指定任务的详细信息")
    @GetMapping("/{jobId}")
    public ApiResponse<Map<String, Object>> getJob(@PathVariable Long jobId) {
        return ApiResponse.success(jobService.getJobById(jobId));
    }

    /**
     * 重试任务
     */
    @Operation(summary = "重试任务", description = "重新执行失败的任务")
    @PostMapping("/{jobId}/retry")
    public ApiResponse<Void> retryJob(@PathVariable Long jobId) {
        jobService.retryJob(jobId);
        return ApiResponse.success("任务已重试");
    }

    /**
     * 取消任务
     */
    @Operation(summary = "取消任务", description = "取消运行中或等待中的任务")
    @PostMapping("/{jobId}/cancel")
    public ApiResponse<Void> cancelJob(@PathVariable Long jobId) {
        jobService.cancelJob(jobId);
        return ApiResponse.success("任务已取消");
    }
}
