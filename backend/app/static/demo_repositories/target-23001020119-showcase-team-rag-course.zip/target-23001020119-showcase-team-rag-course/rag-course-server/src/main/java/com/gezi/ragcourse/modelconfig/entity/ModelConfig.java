package com.gezi.ragcourse.modelconfig.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 模型配置实体
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("model_config")
public class ModelConfig {

    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 模型名称
     */
    private String modelName;

    /**
     * 模型提供商（如openai, zhipu, baichuan等）
     */
    private String provider;

    /**
     * API端点地址
     */
    private String apiEndpoint;

    /**
     * API密钥（加密存储）
     */
    private String apiKey;

    /**
     * 模型参数（JSON格式，如temperature、maxTokens等）
     */
    private String modelParams;

    /**
     * 是否为当前启用的模型
     */
    @Builder.Default
    private Boolean isActive = false;

    /**
     * 描述信息
     */
    private String description;

    @TableLogic
    private Integer deleted;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updatedAt;
}
