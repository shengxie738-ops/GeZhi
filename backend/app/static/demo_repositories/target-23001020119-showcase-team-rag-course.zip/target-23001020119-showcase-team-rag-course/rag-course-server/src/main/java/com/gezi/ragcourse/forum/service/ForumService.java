package com.gezi.ragcourse.forum.service;

import com.gezi.ragcourse.common.api.PageResult;
import com.gezi.ragcourse.forum.dto.CreateAnswerRequest;
import com.gezi.ragcourse.forum.dto.CreateQuestionRequest;
import com.gezi.ragcourse.forum.entity.ForumAnswer;
import com.gezi.ragcourse.forum.entity.ForumQuestion;

/**
 * 论坛服务接口
 */
public interface ForumService {

    /**
     * 创建问题
     */
    ForumQuestion createQuestion(Long userId, CreateQuestionRequest request);

    /**
     * 问题列表（分页，支持按课程/状态过滤、关键词搜索）
     */
    PageResult<ForumQuestion> listQuestions(int page, int size, Long courseId, String status, String keyword);

    /**
     * 获取问题的回答列表
     */
    PageResult<ForumAnswer> listAnswers(Long questionId, int page, int size);

    /**
     * 获取问题详情（自动增加浏览次数）
     */
    ForumQuestion getQuestionById(Long questionId);

    /**
     * 更新问题（仅作者本人可操作）
     */
    ForumQuestion updateQuestion(Long questionId, CreateQuestionRequest request, Long userId);

    /**
     * 删除问题（仅作者本人可操作）
     */
    void deleteQuestion(Long questionId, Long userId);

    /**
     * 创建回答
     */
    ForumAnswer createAnswer(Long userId, Long questionId, CreateAnswerRequest request);

    /**
     * 接受最佳答案
     */
    void acceptAnswer(Long answerId, Long userId);

    /**
     * 教师认证回答
     */
    void verifyAnswer(Long answerId, Long userId);

    /**
     * 将回答加入知识库
     */
    void addToKnowledge(Long answerId, Long userId);

    /**
     * 问题点赞
     */
    void likeQuestion(Long questionId, Long userId);
}
