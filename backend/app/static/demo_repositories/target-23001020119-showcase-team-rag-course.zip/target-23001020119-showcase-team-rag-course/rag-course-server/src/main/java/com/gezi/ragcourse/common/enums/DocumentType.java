package com.gezi.ragcourse.common.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 文档类型枚举
 */
@Getter
@AllArgsConstructor
public enum DocumentType {

    PDF("PDF", "PDF文档"),
    DOCX("DOCX", "Word文档"),
    TXT("TXT", "文本文件"),
    MD("MD", "Markdown文件"),
    PPT("PPT", "PPT演示文稿"),
    IMAGE("IMAGE", "图片");

    @EnumValue
    @JsonValue
    private final String code;
    private final String description;
}
