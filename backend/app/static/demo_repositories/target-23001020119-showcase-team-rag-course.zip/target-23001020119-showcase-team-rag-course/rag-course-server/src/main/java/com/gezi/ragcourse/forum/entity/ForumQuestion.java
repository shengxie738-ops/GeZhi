package com.gezi.ragcourse.forum.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 论坛问题实体
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("forum_question")
public class ForumQuestion {

    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 课程ID
     */
    private Long courseId;

    /**
     * 章节ID
     */
    private Long chapterId;

    /**
     * 作者用户ID
     */
    private Long authorId;

    /**
     * 问题标题
     */
    private String title;

    /**
     * 问题内容
     */
    private String content;

    /**
     * 标签（JSON数组格式）
     */
    private String tags;

    /**
     * 状态: OPEN / CLOSED / RESOLVED
     */
    @Builder.Default
    private String status = "OPEN";

    /**
     * 浏览次数
     */
    @Builder.Default
    private Integer viewCount = 0;

    /**
     * 点赞数
     */
    @Builder.Default
    private Integer likeCount = 0;

    /**
     * 回答数量
     */
    @Builder.Default
    private Integer answerCount = 0;

    /**
     * 被采纳的回答ID
     */
    private Long acceptedAnswerId;

    /**
     * 是否经过教师认证
     */
    @Builder.Default
    private Boolean teacherVerified = false;

    /**
     * 逻辑删除
     */
    @TableLogic
    private Integer deleted;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updatedAt;
}
