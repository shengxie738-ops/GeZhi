package com.gezi.ragcourse.storage.controller;

import com.gezi.ragcourse.common.api.ApiResponse;
import com.gezi.ragcourse.storage.service.StorageService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * 存储管理控制器
 * 权限说明: 需要管理员或教师角色
 */
@Tag(name = "存储模块")
@RestController
@RequestMapping("/storage")
@RequiredArgsConstructor
public class StorageController {

    private final StorageService storageService;

    /**
     * 获取文件信息
     */
    @Operation(summary = "获取文件信息", description = "获取指定文件的元数据信息")
    @GetMapping("/files/{objectName}")
    public ApiResponse<StorageService.FileInfo> getFileInfo(@PathVariable String objectName) {
        return ApiResponse.success(storageService.getFileInfo(objectName));
    }

    /**
     * 删除文件
     */
    @Operation(summary = "删除文件", description = "删除指定存储文件")
    @DeleteMapping("/files/{objectName}")
    public ApiResponse<Void> deleteFile(@PathVariable String objectName) {
        storageService.deleteFile(objectName);
        return ApiResponse.success("文件删除成功");
    }

    /**
     * 获取预签名下载URL
     */
    @Operation(summary = "获取下载链接", description = "获取文件的预签名下载URL（有效期2小时）")
    @GetMapping("/files/{objectName}/presigned-url")
    public ApiResponse<String> getPresignedUrl(@PathVariable String objectName) {
        return ApiResponse.success(storageService.getPresignedUrl(objectName));
    }
}
