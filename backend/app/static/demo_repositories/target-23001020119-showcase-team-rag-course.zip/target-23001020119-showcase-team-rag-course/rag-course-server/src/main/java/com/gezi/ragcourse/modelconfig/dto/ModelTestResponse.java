package com.gezi.ragcourse.modelconfig.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 模型测试响应
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "模型测试响应")
public class ModelTestResponse {

    @Schema(description = "是否连接成功")
    private Boolean success;

    @Schema(description = "模型返回内容")
    private String content;

    @Schema(description = "响应耗时（毫秒）")
    private Long latencyMs;

    @Schema(description = "消耗的Token数")
    private Integer tokenCount;

    @Schema(description = "错误信息（失败时返回）")
    private String errorMessage;
}
