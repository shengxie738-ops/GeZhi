package com.gezi.ragcourse.course.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * 创建课程请求
 */
@Data
@Schema(description = "创建课程请求")
public class CreateCourseRequest {

    @NotBlank(message = "课程名称不能为空")
    @Schema(description = "课程名称", example = "人工智能技术基础")
    private String name;

    @Schema(description = "课程描述")
    private String description;

    @Schema(description = "课程编码", example = "AI101")
    private String courseCode;

    @Schema(description = "学年", example = "2024-2025")
    private String academicYear;

    @Schema(description = "学期", example = "1")
    private String semester;

    @Schema(description = "是否公开", defaultValue = "true")
    private Boolean isPublic = true;
}
