package com.gezi.ragcourse.storage.service.impl;

import com.gezi.ragcourse.common.exception.BusinessException;
import com.gezi.ragcourse.config.MinioConfig;
import com.gezi.ragcourse.storage.service.StorageService;
import io.minio.*;
import io.minio.http.Method;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

/**
 * MinIO存储服务实现
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class MinioStorageServiceImpl implements StorageService {

    private final MinioClient minioClient;
    private final MinioConfig minioConfig;

    @Override
    public String getPresignedUrl(String objectName) {
        try {
            // 生成预签名下载URL，有效期2小时
            return minioClient.getPresignedObjectUrl(
                    GetPresignedObjectUrlArgs.builder()
                            .method(Method.GET)
                            .bucket(minioConfig.getBucketName())
                            .object(objectName)
                            .expiry(2, TimeUnit.HOURS)
                            .build()
            );
        } catch (Exception e) {
            log.error("生成预签名URL失败: objectName={}", objectName, e);
            throw new BusinessException("获取文件下载链接失败");
        }
    }

    @Override
    public void deleteFile(String objectName) {
        try {
            minioClient.removeObject(
                    RemoveObjectArgs.builder()
                            .bucket(minioConfig.getBucketName())
                            .object(objectName)
                            .build()
            );
            log.info("文件删除成功: {}", objectName);
        } catch (Exception e) {
            log.error("删除文件失败: objectName={}", objectName, e);
            throw new BusinessException("删除文件失败");
        }
    }

    @Override
    public FileInfo getFileInfo(String objectName) {
        try {
            StatObjectResponse stat = minioClient.statObject(
                    StatObjectArgs.builder()
                            .bucket(minioConfig.getBucketName())
                            .object(objectName)
                            .build()
            );
            return new FileInfo(
                    objectName,
                    stat.contentType(),
                    stat.size(),
                    stat.lastModified() != null ? stat.lastModified().toString() : ""
            );
        } catch (Exception e) {
            log.error("获取文件信息失败: objectName={}", objectName, e);
            throw new BusinessException(404, "文件不存在");
        }
    }
}
