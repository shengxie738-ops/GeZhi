package com.gezi.ragcourse.common.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 论坛状态枚举
 */
@Getter
@AllArgsConstructor
public enum ForumStatus {

    OPEN("OPEN", "开放"),
    CLOSED("CLOSED", "已关闭"),
    RESOLVED("RESOLVED", "已解决"),
    DELETED("DELETED", "已删除");

    @EnumValue
    @JsonValue
    private final String code;
    private final String description;
}
