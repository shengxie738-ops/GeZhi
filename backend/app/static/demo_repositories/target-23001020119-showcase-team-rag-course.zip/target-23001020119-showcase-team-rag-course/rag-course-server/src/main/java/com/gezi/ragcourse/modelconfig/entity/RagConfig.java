package com.gezi.ragcourse.modelconfig.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * RAG配置实体
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("rag_config")
public class RagConfig {

    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 课程ID（全局配置时为null）
     */
    private Long courseId;

    /**
     * 检索策略: HYBRID / VECTOR / KEYWORD
     */
    @Builder.Default
    private String retrievalStrategy = "HYBRID";

    /**
     * 向量检索Top-K数
     */
    @Builder.Default
    private Integer topK = 5;

    /**
     * 相似度阈值（0-1）
     */
    @Builder.Default
    private Double similarityThreshold = 0.7;

    /**
     * 向量化模型名称
     */
    private String embeddingModel;

    /**
     * Chunk大小（token数）
     */
    @Builder.Default
    private Integer chunkSize = 512;

    /**
     * Chunk重叠大小（token数）
     */
    @Builder.Default
    private Integer chunkOverlap = 50;

    /**
     * 重排序模型（可选）
     */
    private String rerankModel;

    /**
     * 附加配置（JSON格式）
     */
    private String extraConfig;

    @TableLogic
    private Integer deleted;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updatedAt;
}
