package com.gezi.ragcourse.modelconfig.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.util.Map;

/**
 * 创建模型配置请求
 */
@Data
@Schema(description = "创建模型配置请求")
public class CreateModelConfigRequest {

    @NotBlank(message = "模型名称不能为空")
    @Schema(description = "模型名称", example = "gpt-4")
    private String modelName;

    @NotBlank(message = "提供商不能为空")
    @Schema(description = "模型提供商", example = "openai")
    private String provider;

    @Schema(description = "API端点地址")
    private String apiEndpoint;

    @Schema(description = "API密钥")
    private String apiKey;

    @Schema(description = "模型参数")
    private Map<String, Object> modelParams;

    @Schema(description = "描述信息")
    private String description;
}
