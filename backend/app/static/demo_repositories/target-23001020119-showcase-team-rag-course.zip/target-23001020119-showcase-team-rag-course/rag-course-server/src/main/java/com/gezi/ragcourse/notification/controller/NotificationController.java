package com.gezi.ragcourse.notification.controller;

import com.gezi.ragcourse.common.api.ApiResponse;
import com.gezi.ragcourse.common.api.PageResult;
import com.gezi.ragcourse.notification.entity.Notification;
import com.gezi.ragcourse.notification.service.NotificationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * 通知管理控制器
 * 权限说明: 所有接口需要登录，用户只能操作自己的通知
 */
@Tag(name = "通知模块")
@RestController
@RequestMapping("/notifications")
@RequiredArgsConstructor
public class NotificationController {

    private final NotificationService notificationService;

    /**
     * 获取通知列表
     */
    @Operation(summary = "获取通知列表", description = "分页获取用户通知列表")
    @GetMapping
    public ApiResponse<PageResult<Notification>> listNotifications(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) Boolean unreadOnly,
            HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        return ApiResponse.success(notificationService.listNotifications(page, size, userId, unreadOnly));
    }

    /**
     * 获取未读通知数量
     */
    @Operation(summary = "获取未读数", description = "获取当前用户的未读通知数量")
    @GetMapping("/unread-count")
    public ApiResponse<Long> getUnreadCount(HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        return ApiResponse.success(notificationService.getUnreadCount(userId));
    }

    /**
     * 标记单条通知为已读
     */
    @Operation(summary = "标记已读", description = "将指定通知标记为已读")
    @PutMapping("/{notificationId}/read")
    public ApiResponse<Void> markAsRead(@PathVariable Long notificationId,
                                        HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        notificationService.markAsRead(notificationId, userId);
        return ApiResponse.success("已标记为已读");
    }

    /**
     * 标记所有通知为已读
     */
    @Operation(summary = "全部已读", description = "将所有未读通知标记为已读")
    @PutMapping("/read-all")
    public ApiResponse<Void> markAllAsRead(HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        notificationService.markAllAsRead(userId);
        return ApiResponse.success("已全部标记为已读");
    }
}
