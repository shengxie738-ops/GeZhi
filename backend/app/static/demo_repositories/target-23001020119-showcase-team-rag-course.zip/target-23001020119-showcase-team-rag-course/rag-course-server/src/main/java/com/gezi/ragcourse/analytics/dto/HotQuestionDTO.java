package com.gezi.ragcourse.analytics.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 热门问题DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "热门问题")
public class HotQuestionDTO {

    @Schema(description = "问题ID")
    private Long id;

    @Schema(description = "问题标题")
    private String question;

    @Schema(description = "被提问次数")
    private Integer count;

    @Schema(description = "平均相似度分数")
    private Double avgScore;

    @Schema(description = "关联文档标题列表")
    private List<String> relatedDocuments;
}
