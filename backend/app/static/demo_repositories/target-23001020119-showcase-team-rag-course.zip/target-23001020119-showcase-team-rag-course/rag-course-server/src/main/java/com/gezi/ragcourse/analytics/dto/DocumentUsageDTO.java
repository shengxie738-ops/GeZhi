package com.gezi.ragcourse.analytics.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 文档使用统计DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "文档使用统计")
public class DocumentUsageDTO {

    @Schema(description = "文档ID")
    private Long documentId;

    @Schema(description = "文档标题")
    private String documentTitle;

    @Schema(description = "被引用次数")
    private Integer citationCount;

    @Schema(description = "平均相关性分数")
    private Double avgRelevanceScore;
}
