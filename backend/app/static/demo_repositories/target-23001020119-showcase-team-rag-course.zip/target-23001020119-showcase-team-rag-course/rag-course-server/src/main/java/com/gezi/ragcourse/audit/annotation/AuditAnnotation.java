package com.gezi.ragcourse.audit.annotation;

import java.lang.annotation.*;

/**
 * 审计注解 - 标注在需要审计记录的方法上
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface AuditAnnotation {

    /**
     * 操作模块名称
     */
    String module() default "";

    /**
     * 操作类型（如CREATE、UPDATE、DELETE）
     */
    String action() default "";

    /**
     * 操作描述
     */
    String description() default "";
}
