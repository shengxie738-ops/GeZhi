package com.gezi.ragcourse.modelconfig.service;

import com.gezi.ragcourse.modelconfig.dto.CreateModelConfigRequest;
import com.gezi.ragcourse.modelconfig.dto.ModelTestRequest;
import com.gezi.ragcourse.modelconfig.dto.ModelTestResponse;
import com.gezi.ragcourse.modelconfig.entity.ModelConfig;
import com.gezi.ragcourse.modelconfig.entity.RagConfig;

import java.util.List;

/**
 * 模型配置服务接口
 */
public interface ModelConfigService {

    /**
     * 获取模型配置列表
     */
    List<ModelConfig> listModelConfigs();

    /**
     * 获取模型配置详情
     */
    ModelConfig getModelConfigById(Long id);

    /**
     * 创建模型配置
     */
    ModelConfig createModelConfig(CreateModelConfigRequest request);

    /**
     * 更新模型配置
     */
    ModelConfig updateModelConfig(Long id, CreateModelConfigRequest request);

    /**
     * 删除模型配置
     */
    void deleteModelConfig(Long id);

    /**
     * 设置活跃模型
     */
    void setActiveModel(Long id);

    /**
     * 测试模型连接
     */
    ModelTestResponse testModel(ModelTestRequest request);

    /**
     * 获取RAG配置
     */
    RagConfig getRagConfig(Long courseId);

    /**
     * 保存RAG配置
     */
    RagConfig saveRagConfig(Long courseId, RagConfig ragConfig);
}
