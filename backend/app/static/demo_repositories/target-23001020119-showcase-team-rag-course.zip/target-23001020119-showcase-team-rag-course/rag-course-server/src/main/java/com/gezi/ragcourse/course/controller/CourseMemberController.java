package com.gezi.ragcourse.course.controller;

import com.gezi.ragcourse.common.api.ApiResponse;
import com.gezi.ragcourse.course.dto.JoinCourseRequest;
import com.gezi.ragcourse.course.entity.CourseMember;
import com.gezi.ragcourse.course.service.CourseService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 课程成员管理控制器
 * 权限说明: 加入课程需要登录，移除成员需要课程所有者或ADMIN
 */
@Tag(name = "课程模块")
@RestController
@RequestMapping("/courses/{courseId}/members")
@RequiredArgsConstructor
public class CourseMemberController {

    private final CourseService courseService;

    /**
     * 加入课程 - 需要登录
     */
    @Operation(summary = "加入课程", description = "通过课程编码加入课程")
    @PostMapping("/join")
    public ApiResponse<Void> joinCourse(@PathVariable Long courseId,
                                        @Valid @RequestBody JoinCourseRequest request,
                                        HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        courseService.joinCourse(userId, request);
        return ApiResponse.success("加入课程成功");
    }

    /**
     * 获取课程成员列表 - 需要登录
     */
    @Operation(summary = "获取课程成员列表", description = "获取指定课程的所有成员")
    @GetMapping
    public ApiResponse<List<CourseMember>> getMembers(@PathVariable Long courseId) {
        return ApiResponse.success(courseService.getCourseMembers(courseId));
    }

    /**
     * 移除课程成员 - 需要课程所有者或ADMIN权限
     */
    @Operation(summary = "移除课程成员", description = "将成员从课程中移除")
    @DeleteMapping("/{userId}")
    public ApiResponse<Void> removeMember(@PathVariable Long courseId,
                                          @PathVariable Long userId) {
        courseService.removeMember(courseId, userId);
        return ApiResponse.success();
    }
}
