package com.gezi.ragcourse.rag.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gezi.ragcourse.common.api.PageResult;
import com.gezi.ragcourse.common.exception.BusinessException;
import com.gezi.ragcourse.rag.dto.*;
import com.gezi.ragcourse.rag.entity.AnswerFeedback;
import com.gezi.ragcourse.rag.entity.ChatMessage;
import com.gezi.ragcourse.rag.entity.ChatSession;
import com.gezi.ragcourse.rag.entity.MessageCitation;
import com.gezi.ragcourse.rag.mapper.AnswerFeedbackMapper;
import com.gezi.ragcourse.rag.mapper.ChatMessageMapper;
import com.gezi.ragcourse.rag.mapper.ChatSessionMapper;
import com.gezi.ragcourse.rag.mapper.MessageCitationMapper;
import com.gezi.ragcourse.rag.service.ChatService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 聊天会话服务实现
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ChatServiceImpl implements ChatService {

    private final ChatSessionMapper chatSessionMapper;
    private final ChatMessageMapper chatMessageMapper;
    private final MessageCitationMapper citationMapper;
    private final AnswerFeedbackMapper feedbackMapper;

    @Override
    public PageResult<SessionDTO> listSessions(Long userId, int page, int size) {
        LambdaQueryWrapper<ChatSession> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ChatSession::getUserId, userId)
               .orderByDesc(ChatSession::getUpdatedAt);

        Page<ChatSession> pageResult = chatSessionMapper.selectPage(
                new Page<>(page, size), wrapper);

        List<SessionDTO> dtoList = pageResult.getRecords().stream()
                .map(this::toSessionDTO)
                .collect(Collectors.toList());

        return PageResult.of(dtoList, pageResult.getTotal(),
                pageResult.getCurrent(), pageResult.getSize());
    }

    @Override
    public SessionDTO createSession(Long userId, CreateSessionRequest request) {
        ChatSession session = ChatSession.builder()
                .userId(userId)
                .courseId(request.getCourseId())
                .title(request.getTitle())
                .build();
        chatSessionMapper.insert(session);
        return toSessionDTO(session);
    }

    @Override
    public SessionDTO getSessionDetail(Long userId, Long sessionId) {
        ChatSession session = chatSessionMapper.selectById(sessionId);
        if (session == null || !session.getUserId().equals(userId)) {
            throw new BusinessException(404, "会话不存在");
        }

        // 查询该会话下所有消息
        LambdaQueryWrapper<ChatMessage> msgWrapper = new LambdaQueryWrapper<>();
        msgWrapper.eq(ChatMessage::getSessionId, sessionId)
                  .orderByAsc(ChatMessage::getCreatedAt);
        List<ChatMessage> messages = chatMessageMapper.selectList(msgWrapper);

        List<MessageDTO> messageDTOs = messages.stream()
                .map(this::toMessageDTO)
                .collect(Collectors.toList());

        SessionDTO dto = toSessionDTO(session);
        dto.setMessages(messageDTOs);
        return dto;
    }

    @Override
    public void deleteSession(Long userId, Long sessionId) {
        ChatSession session = chatSessionMapper.selectById(sessionId);
        if (session == null || !session.getUserId().equals(userId)) {
            throw new BusinessException(404, "会话不存在");
        }

        // 级联删除关联的citations
        LambdaQueryWrapper<ChatMessage> msgWrapper = new LambdaQueryWrapper<>();
        msgWrapper.eq(ChatMessage::getSessionId, sessionId);
        List<ChatMessage> messages = chatMessageMapper.selectList(msgWrapper);
        for (ChatMessage message : messages) {
            LambdaQueryWrapper<MessageCitation> citWrapper = new LambdaQueryWrapper<>();
            citWrapper.eq(MessageCitation::getMessageId, message.getId());
            citationMapper.delete(citWrapper);
        }

        // 级联删除关联的messages
        chatMessageMapper.delete(msgWrapper);

        chatSessionMapper.deleteById(sessionId);
    }

    @Override
    public void submitFeedback(Long userId, Long messageId, FeedbackRequest request) {
        // 校验消息存在
        ChatMessage message = chatMessageMapper.selectById(messageId);
        if (message == null) {
            throw new BusinessException(404, "消息不存在");
        }

        // 保存反馈
        AnswerFeedback feedback = AnswerFeedback.builder()
                .messageId(messageId)
                .userId(userId)
                .feedbackType(request.getFeedbackType())
                .content(request.getReason() != null ? request.getReason() : request.getComment())
                .build();
        feedbackMapper.insert(feedback);
    }

    // ---- 内部转换方法 ----

    private SessionDTO toSessionDTO(ChatSession session) {
        return SessionDTO.builder()
                .id(session.getId())
                .userId(session.getUserId())
                .courseId(session.getCourseId())
                .title(session.getTitle())
                .isRagEnabled(session.getIsRagEnabled())
                .createdAt(session.getCreatedAt())
                .updatedAt(session.getUpdatedAt())
                .build();
    }

    private MessageDTO toMessageDTO(ChatMessage message) {
        // 查询消息的引用
        LambdaQueryWrapper<MessageCitation> citWrapper = new LambdaQueryWrapper<>();
        citWrapper.eq(MessageCitation::getMessageId, message.getId());
        List<MessageCitation> citations = citationMapper.selectList(citWrapper);

        List<CitationDTO> citationDTOs = citations.stream()
                .map(c -> CitationDTO.builder()
                        .id(c.getId())
                        .contentPreview(c.getContentPreview())
                        .score(c.getScore())
                        .documentId(c.getDocumentId())
                        .documentTitle(c.getDocumentTitle())
                        .chunkId(c.getChunkId())
                        .build())
                .collect(Collectors.toList());

        return MessageDTO.builder()
                .id(message.getId())
                .sessionId(message.getSessionId())
                .role(message.getRole())
                .content(message.getContent())
                .tokenCount(message.getTokenCount())
                .ragEnabled(message.getRagEnabled())
                .evidenceStatus(message.getEvidenceStatus())
                .citations(citationDTOs)
                .createdAt(message.getCreatedAt())
                .build();
    }
}
