package com.gezi.ragcourse.document.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gezi.ragcourse.common.api.PageResult;
import com.gezi.ragcourse.common.enums.DocumentType;
import com.gezi.ragcourse.common.enums.ParseStatus;
import com.gezi.ragcourse.common.enums.Role;
import com.gezi.ragcourse.common.exception.BusinessException;
import com.gezi.ragcourse.document.dto.ChunkDTO;
import com.gezi.ragcourse.document.dto.UploadResponse;
import com.gezi.ragcourse.document.entity.IngestJob;
import com.gezi.ragcourse.document.entity.KnowledgeChunk;
import com.gezi.ragcourse.document.entity.KnowledgeDocument;
import com.gezi.ragcourse.document.mapper.IngestJobMapper;
import com.gezi.ragcourse.document.mapper.KnowledgeChunkMapper;
import com.gezi.ragcourse.document.mapper.KnowledgeDocumentMapper;
import com.gezi.ragcourse.document.service.DocumentService;
import com.gezi.ragcourse.storage.service.StorageService;
import com.gezi.ragcourse.user.entity.SysUser;
import com.gezi.ragcourse.user.mapper.SysUserMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 文档服务实现
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DocumentServiceImpl implements DocumentService {

    private final KnowledgeDocumentMapper documentMapper;
    private final KnowledgeChunkMapper chunkMapper;
    private final IngestJobMapper ingestJobMapper;
    private final StorageService storageService;
    private final SysUserMapper sysUserMapper;

    @Override
    public UploadResponse uploadDocument(Long userId, Long courseId, Long chapterId, MultipartFile file) {
        // 确定文档类型
        DocumentType docType = resolveDocumentType(file.getOriginalFilename());

        // 上传文件到MinIO
        String filePath = storageService.uploadFile(file, "documents/" + courseId);

        // 创建文档记录
        KnowledgeDocument document = KnowledgeDocument.builder()
                .courseId(courseId)
                .chapterId(chapterId)
                .title(file.getOriginalFilename())
                .docType(docType)
                .filePath(filePath)
                .fileSize(file.getSize())
                .parseStatus(ParseStatus.PENDING)
                .uploadedBy(userId)
                .build();
        documentMapper.insert(document);

        return UploadResponse.builder()
                .documentId(document.getId())
                .fileName(file.getOriginalFilename())
                .fileSize(file.getSize())
                .fileUrl(filePath)
                .parseStatus(document.getParseStatus().name())
                .build();
    }

    @Override
    public PageResult<KnowledgeDocument> listDocuments(Long courseId, int page, int size) {
        LambdaQueryWrapper<KnowledgeDocument> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(KnowledgeDocument::getCourseId, courseId)
                .orderByDesc(KnowledgeDocument::getCreatedAt);
        Page<KnowledgeDocument> pageResult = documentMapper.selectPage(new Page<>(page, size), wrapper);
        return PageResult.of(pageResult);
    }

    @Override
    public KnowledgeDocument getDocumentById(Long documentId) {
        KnowledgeDocument document = documentMapper.selectById(documentId);
        if (document == null) {
            throw new BusinessException(404, "文档不存在");
        }
        return document;
    }

    @Override
    public void deleteDocument(Long documentId, Long userId) {
        KnowledgeDocument document = documentMapper.selectById(documentId);
        if (document == null) {
            throw new BusinessException(404, "文档不存在");
        }

        // 权限校验：仅文档上传者或管理员可删除
        SysUser user = sysUserMapper.selectById(userId);
        if (user == null || (!userId.equals(document.getUploadedBy()) && user.getRole() != Role.ADMIN)) {
            throw new BusinessException(403, "无权删除该文档");
        }

        // 删除关联的chunk
        LambdaQueryWrapper<KnowledgeChunk> chunkWrapper = new LambdaQueryWrapper<>();
        chunkWrapper.eq(KnowledgeChunk::getDocumentId, documentId);
        chunkMapper.delete(chunkWrapper);

        // 删除MinIO文件
        try {
            storageService.deleteFile(document.getFilePath());
        } catch (Exception e) {
            log.warn("删除文件异常", e);
        }

        documentMapper.deleteById(documentId);
    }

    @Override
    @Async
    public void parseDocument(Long documentId) {
        KnowledgeDocument document = documentMapper.selectById(documentId);
        if (document == null) {
            throw new BusinessException(404, "文档不存在");
        }

        // 创建解析任务
        IngestJob job = IngestJob.builder()
                .documentId(documentId)
                .status(ParseStatus.PARSING)
                .startedAt(java.time.LocalDateTime.now())
                .build();
        ingestJobMapper.insert(job);

        // 更新文档状态
        document.setParseStatus(ParseStatus.PARSING);
        documentMapper.updateById(document);

        try {
            // TODO: 实际的文档解析逻辑（文本提取、分块、向量化）
            // 这里需要集成LLM API进行文档解析
            // 1. 读取文件内容
            // 2. 文本分块
            // 3. 调用embedding API生成向量
            // 4. 存储到向量数据库
            // 5. 保存chunk到MySQL

            // 模拟解析完成
            document.setParseStatus(ParseStatus.COMPLETED);
            document.setChunkCount(0); // 实际应设置为解析出的chunk数量
            documentMapper.updateById(document);

            job.setStatus(ParseStatus.COMPLETED);
            job.setProgress(100);
            job.setCompletedAt(java.time.LocalDateTime.now());
            ingestJobMapper.updateById(job);

        } catch (Exception e) {
            log.error("文档解析失败: {}", documentId, e);
            document.setParseStatus(ParseStatus.FAILED);
            documentMapper.updateById(document);

            job.setStatus(ParseStatus.FAILED);
            job.setErrorMessage(e.getMessage());
            ingestJobMapper.updateById(job);
        }
    }

    @Override
    public List<ChunkDTO> getDocumentChunks(Long documentId) {
        LambdaQueryWrapper<KnowledgeChunk> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(KnowledgeChunk::getDocumentId, documentId)
                .orderByAsc(KnowledgeChunk::getChunkIndex);
        List<KnowledgeChunk> chunks = chunkMapper.selectList(wrapper);

        return chunks.stream().map(chunk -> ChunkDTO.builder()
                .id(chunk.getId())
                .content(chunk.getContent())
                .chunkIndex(chunk.getChunkIndex())
                .tokenCount(chunk.getTokenCount())
                .documentId(chunk.getDocumentId())
                .build()).toList();
    }

    private DocumentType resolveDocumentType(String filename) {
        if (filename == null) return DocumentType.TXT;
        String lower = filename.toLowerCase();
        if (lower.endsWith(".pdf")) return DocumentType.PDF;
        if (lower.endsWith(".docx") || lower.endsWith(".doc")) return DocumentType.DOCX;
        if (lower.endsWith(".txt")) return DocumentType.TXT;
        if (lower.endsWith(".md")) return DocumentType.MD;
        if (lower.endsWith(".ppt") || lower.endsWith(".pptx")) return DocumentType.PPT;
        if (lower.endsWith(".png") || lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return DocumentType.IMAGE;
        return DocumentType.TXT;
    }
}
