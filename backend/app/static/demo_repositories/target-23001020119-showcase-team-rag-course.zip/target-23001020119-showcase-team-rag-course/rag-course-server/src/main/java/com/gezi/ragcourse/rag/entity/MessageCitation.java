package com.gezi.ragcourse.rag.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 消息引用实体（回答引用的知识库内容）
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("message_citation")
public class MessageCitation {

    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 消息ID
     */
    private Long messageId;

    /**
     * 引用的chunk ID
     */
    private Long chunkId;

    /**
     * 引用内容摘要
     */
    private String contentPreview;

    /**
     * 相似度分数
     */
    private Double score;

    /**
     * 来源文档ID
     */
    private Long documentId;

    /**
     * 来源文档标题
     */
    private String documentTitle;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;
}
