package com.gezi.ragcourse.common.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 文档解析状态枚举
 */
@Getter
@AllArgsConstructor
public enum ParseStatus {

    PENDING("PENDING", "待解析"),
    PARSING("PARSING", "解析中"),
    COMPLETED("COMPLETED", "解析完成"),
    FAILED("FAILED", "解析失败");

    @EnumValue
    @JsonValue
    private final String code;
    private final String description;
}
