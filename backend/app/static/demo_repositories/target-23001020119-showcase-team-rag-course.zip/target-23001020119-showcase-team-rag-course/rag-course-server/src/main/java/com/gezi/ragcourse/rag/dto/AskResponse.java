package com.gezi.ragcourse.rag.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * RAG问答响应
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "RAG问答响应")
public class AskResponse {

    @Schema(description = "回答内容")
    private String answer;

    @Schema(description = "会话ID")
    private Long sessionId;

    @Schema(description = "消息ID")
    private Long messageId;

    @Schema(description = "证据状态: SUPPORTED, PARTIAL, UNSUPPORTED")
    private String evidenceStatus;

    @Schema(description = "引用列表")
    private List<CitationDTO> citations;

    @Schema(description = "Token消耗")
    private Integer tokenCount;
}
