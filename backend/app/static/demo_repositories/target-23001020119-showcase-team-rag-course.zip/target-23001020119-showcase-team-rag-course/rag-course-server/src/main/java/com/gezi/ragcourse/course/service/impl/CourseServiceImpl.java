package com.gezi.ragcourse.course.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gezi.ragcourse.common.api.PageResult;
import com.gezi.ragcourse.common.exception.BusinessException;
import com.gezi.ragcourse.course.dto.CreateCourseRequest;
import com.gezi.ragcourse.course.dto.JoinCourseRequest;
import com.gezi.ragcourse.course.entity.Course;
import com.gezi.ragcourse.course.entity.CourseChapter;
import com.gezi.ragcourse.course.entity.CourseMember;
import com.gezi.ragcourse.course.mapper.CourseChapterMapper;
import com.gezi.ragcourse.course.mapper.CourseMapper;
import com.gezi.ragcourse.course.mapper.CourseMemberMapper;
import com.gezi.ragcourse.course.service.CourseService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

/**
 * 课程服务实现
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CourseServiceImpl implements CourseService {

    private final CourseMapper courseMapper;
    private final CourseMemberMapper courseMemberMapper;
    private final CourseChapterMapper courseChapterMapper;

    @Override
    public Course createCourse(Long teacherId, CreateCourseRequest request) {
        Course course = Course.builder()
                .name(request.getName())
                .description(request.getDescription())
                .courseCode(request.getCourseCode())
                .academicYear(request.getAcademicYear())
                .semester(request.getSemester())
                .teacherId(teacherId)
                .isPublic(request.getIsPublic())
                .build();
        courseMapper.insert(course);

        // 创建者自动成为课程所有者
        CourseMember owner = CourseMember.builder()
                .courseId(course.getId())
                .userId(teacherId)
                .memberRole("OWNER")
                .build();
        courseMemberMapper.insert(owner);

        return course;
    }

    @Override
    public Course getCourseById(Long courseId) {
        Course course = courseMapper.selectById(courseId);
        if (course == null) {
            throw new BusinessException(404, "课程不存在");
        }
        return course;
    }

    @Override
    public PageResult<Course> listCourses(int page, int size, String keyword) {
        LambdaQueryWrapper<Course> wrapper = new LambdaQueryWrapper<>();
        if (StringUtils.hasText(keyword)) {
            wrapper.and(w -> w
                    .like(Course::getName, keyword)
                    .or().like(Course::getCourseCode, keyword)
            );
        }
        wrapper.orderByDesc(Course::getCreatedAt);

        Page<Course> pageResult = courseMapper.selectPage(new Page<>(page, size), wrapper);
        return PageResult.of(pageResult);
    }

    @Override
    public Course updateCourse(Long courseId, CreateCourseRequest request, Long userId) {
        Course course = courseMapper.selectById(courseId);
        if (course == null) {
            throw new BusinessException(404, "课程不存在");
        }
        if (!course.getTeacherId().equals(userId)) {
            throw new BusinessException(403, "无权修改该课程");
        }

        course.setName(request.getName());
        course.setDescription(request.getDescription());
        course.setCourseCode(request.getCourseCode());
        course.setAcademicYear(request.getAcademicYear());
        course.setSemester(request.getSemester());
        course.setIsPublic(request.getIsPublic());
        courseMapper.updateById(course);

        return course;
    }

    @Override
    public void deleteCourse(Long courseId, Long userId) {
        Course course = courseMapper.selectById(courseId);
        if (course == null) {
            throw new BusinessException(404, "课程不存在");
        }
        if (!course.getTeacherId().equals(userId)) {
            throw new BusinessException(403, "无权删除该课程");
        }
        courseMapper.deleteById(courseId);
    }

    @Override
    public void joinCourse(Long userId, JoinCourseRequest request) {
        // 根据课程编码查找课程
        LambdaQueryWrapper<Course> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Course::getCourseCode, request.getCourseCode());
        Course course = courseMapper.selectOne(wrapper);
        if (course == null) {
            throw new BusinessException(404, "课程不存在");
        }

        // 检查是否已加入
        LambdaQueryWrapper<CourseMember> memberWrapper = new LambdaQueryWrapper<>();
        memberWrapper.eq(CourseMember::getCourseId, course.getId())
                .eq(CourseMember::getUserId, userId);
        if (courseMemberMapper.selectCount(memberWrapper) > 0) {
            throw new BusinessException("已加入该课程");
        }

        CourseMember member = CourseMember.builder()
                .courseId(course.getId())
                .userId(userId)
                .memberRole("STUDENT")
                .build();
        courseMemberMapper.insert(member);
    }

    @Override
    public List<CourseMember> getCourseMembers(Long courseId) {
        LambdaQueryWrapper<CourseMember> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(CourseMember::getCourseId, courseId);
        return courseMemberMapper.selectList(wrapper);
    }

    @Override
    public List<CourseChapter> getCourseChapters(Long courseId) {
        LambdaQueryWrapper<CourseChapter> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(CourseChapter::getCourseId, courseId)
                .orderByAsc(CourseChapter::getSortOrder);
        return courseChapterMapper.selectList(wrapper);
    }

    @Override
    public void removeMember(Long courseId, Long userId) {
        LambdaQueryWrapper<CourseMember> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(CourseMember::getCourseId, courseId)
                .eq(CourseMember::getUserId, userId);
        courseMemberMapper.delete(wrapper);
    }
}
