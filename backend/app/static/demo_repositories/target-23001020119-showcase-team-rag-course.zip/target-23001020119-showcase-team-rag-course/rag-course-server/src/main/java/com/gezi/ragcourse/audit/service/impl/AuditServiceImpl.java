package com.gezi.ragcourse.audit.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gezi.ragcourse.audit.entity.AuditLog;
import com.gezi.ragcourse.audit.mapper.AuditLogMapper;
import com.gezi.ragcourse.audit.service.AuditService;
import com.gezi.ragcourse.common.api.PageResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
 * 审计服务实现
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AuditServiceImpl implements AuditService {

    private final AuditLogMapper auditLogMapper;

    @Override
    public PageResult<AuditLog> listAuditLogs(int page, int size, String module, String action, Long userId) {
        LambdaQueryWrapper<AuditLog> wrapper = new LambdaQueryWrapper<>();
        // 按模块筛选
        if (StringUtils.hasText(module)) {
            wrapper.eq(AuditLog::getModule, module);
        }
        // 按操作类型筛选
        if (StringUtils.hasText(action)) {
            wrapper.eq(AuditLog::getAction, action);
        }
        // 按用户ID筛选
        if (userId != null) {
            wrapper.eq(AuditLog::getUserId, userId);
        }
        wrapper.orderByDesc(AuditLog::getCreatedAt);

        Page<AuditLog> pageResult = auditLogMapper.selectPage(new Page<>(page, size), wrapper);
        return PageResult.of(pageResult);
    }
}
