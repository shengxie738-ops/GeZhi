package com.gezi.ragcourse.document.controller;

import com.gezi.ragcourse.common.api.ApiResponse;
import com.gezi.ragcourse.common.api.PageResult;
import com.gezi.ragcourse.document.dto.ChunkDTO;
import com.gezi.ragcourse.document.dto.UploadResponse;
import com.gezi.ragcourse.document.entity.KnowledgeDocument;
import com.gezi.ragcourse.document.service.DocumentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 文档管理控制器
 * 权限说明: 上传/删除需要TEACHER或ADMIN角色，查看需要登录
 */
@Tag(name = "文档模块")
@RestController
@RequestMapping("/documents")
@RequiredArgsConstructor
public class DocumentController {

    private final DocumentService documentService;

    /**
     * 上传文档 - 需要TEACHER或ADMIN权限
     */
    @Operation(summary = "上传文档", description = "上传知识库文档到指定课程")
    @PostMapping("/upload")
    public ApiResponse<UploadResponse> uploadDocument(
            @RequestParam Long courseId,
            @RequestParam(required = false) Long chapterId,
            @RequestParam("file") MultipartFile file,
            HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        return ApiResponse.success("上传成功", documentService.uploadDocument(userId, courseId, chapterId, file));
    }

    /**
     * 获取课程文档列表 - 需要登录
     */
    @Operation(summary = "获取课程文档列表", description = "分页获取指定课程的文档列表")
    @GetMapping("/course/{courseId}")
    public ApiResponse<PageResult<KnowledgeDocument>> listDocuments(
            @PathVariable Long courseId,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size) {
        return ApiResponse.success(documentService.listDocuments(courseId, page, size));
    }

    /**
     * 获取文档详情 - 需要登录
     */
    @Operation(summary = "获取文档详情", description = "获取指定文档的详细信息")
    @GetMapping("/{documentId}")
    public ApiResponse<KnowledgeDocument> getDocument(@PathVariable Long documentId) {
        return ApiResponse.success(documentService.getDocumentById(documentId));
    }

    /**
     * 删除文档 - 需要TEACHER或ADMIN权限
     */
    @Operation(summary = "删除文档", description = "删除指定文档及其关联数据")
    @DeleteMapping("/{documentId}")
    public ApiResponse<Void> deleteDocument(@PathVariable Long documentId,
                                            HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        documentService.deleteDocument(documentId, userId);
        return ApiResponse.success();
    }

    /**
     * 触发文档解析 - 需要TEACHER或ADMIN权限
     */
    @Operation(summary = "触发文档解析", description = "异步触发文档解析（分块、向量化）")
    @PostMapping("/{documentId}/parse")
    public ApiResponse<Void> parseDocument(@PathVariable Long documentId) {
        documentService.parseDocument(documentId);
        return ApiResponse.success("解析任务已提交");
    }

    /**
     * 获取文档分块列表 - 需要登录
     */
    @Operation(summary = "获取文档分块", description = "获取指定文档的所有文本分块")
    @GetMapping("/{documentId}/chunks")
    public ApiResponse<List<ChunkDTO>> getDocumentChunks(@PathVariable Long documentId) {
        return ApiResponse.success(documentService.getDocumentChunks(documentId));
    }
}
