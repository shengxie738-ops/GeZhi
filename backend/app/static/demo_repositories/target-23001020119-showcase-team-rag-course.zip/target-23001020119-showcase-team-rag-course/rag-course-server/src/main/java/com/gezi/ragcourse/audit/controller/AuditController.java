package com.gezi.ragcourse.audit.controller;

import com.gezi.ragcourse.audit.entity.AuditLog;
import com.gezi.ragcourse.audit.service.AuditService;
import com.gezi.ragcourse.common.api.ApiResponse;
import com.gezi.ragcourse.common.api.PageResult;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * 审计日志控制器
 * 权限说明: 所有接口需要管理员角色
 */
@Tag(name = "审计模块")
@RestController
@RequestMapping("/admin/audit")
@RequiredArgsConstructor
public class AuditController {

    private final AuditService auditService;

    /**
     * 获取审计日志列表
     */
    @Operation(summary = "获取审计日志", description = "分页获取审计日志，支持按模块、操作类型、用户ID筛选")
    @GetMapping("/logs")
    public ApiResponse<PageResult<AuditLog>> listAuditLogs(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(required = false) String module,
            @RequestParam(required = false) String action,
            @RequestParam(required = false) Long userId) {
        return ApiResponse.success(auditService.listAuditLogs(page, size, module, action, userId));
    }
}
