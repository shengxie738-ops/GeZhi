package com.gezi.ragcourse.wrongquestion.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.List;

/**
 * 创建错题请求
 */
@Data
@Schema(description = "创建错题请求")
public class CreateWrongQuestionRequest {

    @NotNull(message = "课程ID不能为空")
    @Schema(description = "课程ID", example = "1")
    private Long courseId;

    @NotBlank(message = "标题不能为空")
    @Schema(description = "错题标题", example = "向量检索原理")
    private String title;

    @NotBlank(message = "题目内容不能为空")
    @Schema(description = "题目内容")
    private String questionContent;

    @Schema(description = "学生的错误答案")
    private String studentAnswer;

    @Schema(description = "正确答案")
    private String correctAnswer;

    @Schema(description = "错误原因分析")
    private String errorReason;

    @Schema(description = "知识点标签列表", example = "[\"向量检索\", \"相似度计算\"]")
    private List<String> knowledgeTags;

    @Schema(description = "教师点评")
    private String teacherComment;
}
