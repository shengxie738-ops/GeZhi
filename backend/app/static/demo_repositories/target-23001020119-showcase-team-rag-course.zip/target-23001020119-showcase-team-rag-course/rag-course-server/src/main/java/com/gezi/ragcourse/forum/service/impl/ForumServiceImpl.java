package com.gezi.ragcourse.forum.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gezi.ragcourse.common.api.PageResult;
import com.gezi.ragcourse.common.exception.BusinessException;
import com.gezi.ragcourse.forum.dto.CreateAnswerRequest;
import com.gezi.ragcourse.forum.dto.CreateQuestionRequest;
import com.gezi.ragcourse.forum.entity.ForumAnswer;
import com.gezi.ragcourse.forum.entity.ForumQuestion;
import com.gezi.ragcourse.forum.mapper.ForumAnswerMapper;
import com.gezi.ragcourse.forum.mapper.ForumQuestionMapper;
import com.gezi.ragcourse.forum.service.ForumService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.Arrays;
import java.util.List;

/**
 * 论坛服务实现
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ForumServiceImpl implements ForumService {

    private final ForumQuestionMapper questionMapper;
    private final ForumAnswerMapper answerMapper;
    private final ObjectMapper objectMapper;

    @Override
    public ForumQuestion createQuestion(Long userId, CreateQuestionRequest request) {
        // 将标签列表转为JSON字符串存储
        String tagsJson = null;
        if (request.getTags() != null && !request.getTags().isEmpty()) {
            try {
                tagsJson = objectMapper.writeValueAsString(request.getTags());
            } catch (Exception e) {
                log.error("标签JSON序列化失败", e);
            }
        }

        ForumQuestion question = ForumQuestion.builder()
                .courseId(request.getCourseId())
                .chapterId(request.getChapterId())
                .authorId(userId)
                .title(request.getTitle())
                .content(request.getContent())
                .tags(tagsJson)
                .build();
        questionMapper.insert(question);
        return question;
    }

    @Override
    public PageResult<ForumQuestion> listQuestions(int page, int size, Long courseId, String status, String keyword) {
        LambdaQueryWrapper<ForumQuestion> wrapper = new LambdaQueryWrapper<>();
        // 按课程ID过滤
        if (courseId != null) {
            wrapper.eq(ForumQuestion::getCourseId, courseId);
        }
        // 按状态过滤
        if (StringUtils.hasText(status)) {
            wrapper.eq(ForumQuestion::getStatus, status);
        }
        // 关键词搜索标题或内容
        if (StringUtils.hasText(keyword)) {
            wrapper.and(w -> w
                    .like(ForumQuestion::getTitle, keyword)
                    .or().like(ForumQuestion::getContent, keyword)
            );
        }
        // 按创建时间倒序
        wrapper.orderByDesc(ForumQuestion::getCreatedAt);

        Page<ForumQuestion> pageResult = questionMapper.selectPage(new Page<>(page, size), wrapper);
        return PageResult.of(pageResult);
    }

    @Override
    public PageResult<ForumAnswer> listAnswers(Long questionId, int page, int size) {
        LambdaQueryWrapper<ForumAnswer> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ForumAnswer::getQuestionId, questionId)
               .orderByAsc(ForumAnswer::getCreatedAt);
        Page<ForumAnswer> pageResult = answerMapper.selectPage(new Page<>(page, size), wrapper);
        return PageResult.of(pageResult);
    }

    @Override
    public ForumQuestion getQuestionById(Long questionId) {
        ForumQuestion question = questionMapper.selectById(questionId);
        if (question == null) {
            throw new BusinessException(404, "问题不存在");
        }
        // 自动增加浏览次数
        question.setViewCount(question.getViewCount() + 1);
        questionMapper.updateById(question);
        return question;
    }

    @Override
    public ForumQuestion updateQuestion(Long questionId, CreateQuestionRequest request, Long userId) {
        ForumQuestion question = questionMapper.selectById(questionId);
        if (question == null) {
            throw new BusinessException(404, "问题不存在");
        }
        if (!question.getAuthorId().equals(userId)) {
            throw new BusinessException(403, "无权修改该问题");
        }

        String tagsJson = null;
        if (request.getTags() != null && !request.getTags().isEmpty()) {
            try {
                tagsJson = objectMapper.writeValueAsString(request.getTags());
            } catch (Exception e) {
                log.error("标签JSON序列化失败", e);
            }
        }

        question.setTitle(request.getTitle());
        question.setContent(request.getContent());
        question.setTags(tagsJson);
        if (request.getChapterId() != null) {
            question.setChapterId(request.getChapterId());
        }
        questionMapper.updateById(question);
        return question;
    }

    @Override
    public void deleteQuestion(Long questionId, Long userId) {
        ForumQuestion question = questionMapper.selectById(questionId);
        if (question == null) {
            throw new BusinessException(404, "问题不存在");
        }
        if (!question.getAuthorId().equals(userId)) {
            throw new BusinessException(403, "无权删除该问题");
        }
        questionMapper.deleteById(questionId);
    }

    @Override
    @Transactional
    public ForumAnswer createAnswer(Long userId, Long questionId, CreateAnswerRequest request) {
        ForumQuestion question = questionMapper.selectById(questionId);
        if (question == null) {
            throw new BusinessException(404, "问题不存在");
        }

        ForumAnswer answer = ForumAnswer.builder()
                .questionId(questionId)
                .authorId(userId)
                .content(request.getContent())
                .build();
        answerMapper.insert(answer);

        // 更新问题的回答计数
        question.setAnswerCount(question.getAnswerCount() + 1);
        questionMapper.updateById(question);

        return answer;
    }

    @Override
    @Transactional
    public void acceptAnswer(Long answerId, Long userId) {
        ForumAnswer answer = answerMapper.selectById(answerId);
        if (answer == null) {
            throw new BusinessException(404, "回答不存在");
        }

        ForumQuestion question = questionMapper.selectById(answer.getQuestionId());
        if (question == null) {
            throw new BusinessException(404, "关联问题不存在");
        }

        // 只有问题作者可以采纳最佳答案
        if (!question.getAuthorId().equals(userId)) {
            throw new BusinessException(403, "只有提问者可以采纳最佳答案");
        }

        // 如果之前已有被采纳的答案，取消之前的状态
        if (question.getAcceptedAnswerId() != null) {
            ForumAnswer previousAccepted = answerMapper.selectById(question.getAcceptedAnswerId());
            if (previousAccepted != null) {
                previousAccepted.setIsAccepted(false);
                answerMapper.updateById(previousAccepted);
            }
        }

        // 设置当前回答为最佳答案
        answer.setIsAccepted(true);
        answerMapper.updateById(answer);

        // 更新问题的被采纳答案ID和状态
        question.setAcceptedAnswerId(answerId);
        question.setStatus("RESOLVED");
        questionMapper.updateById(question);
    }

    @Override
    public void verifyAnswer(Long answerId, Long userId) {
        // 业务逻辑：教师认证回答，验证其内容的正确性
        ForumAnswer answer = answerMapper.selectById(answerId);
        if (answer == null) {
            throw new BusinessException(404, "回答不存在");
        }
        // 注意：此处应额外校验用户是否为教师角色（通过UserMapper或SecurityContext）
        answer.setTeacherVerified(true);
        answerMapper.updateById(answer);

        // 同时标记关联问题为教师认证
        ForumQuestion question = questionMapper.selectById(answer.getQuestionId());
        if (question != null) {
            question.setTeacherVerified(true);
            questionMapper.updateById(question);
        }
    }

    @Override
    public void addToKnowledge(Long answerId, Long userId) {
        // 业务逻辑：将优质回答加入课程知识库，供后续RAG检索使用
        ForumAnswer answer = answerMapper.selectById(answerId);
        if (answer == null) {
            throw new BusinessException(404, "回答不存在");
        }
        if (Boolean.TRUE.equals(answer.getAddedToKnowledge())) {
            throw new BusinessException("该回答已加入知识库");
        }

        answer.setAddedToKnowledge(true);
        answerMapper.updateById(answer);

        // TODO: 调用DocumentService将回答内容作为知识文档写入向量库
        log.info("回答[{}]已标记加入知识库，等待异步索引", answerId);
    }

    @Override
    public void likeQuestion(Long questionId, Long userId) {
        ForumQuestion question = questionMapper.selectById(questionId);
        if (question == null) {
            throw new BusinessException(404, "问题不存在");
        }
        // TODO: 实际项目中应记录用户点赞关系（防重复点赞），这里简化为直接计数+1
        question.setLikeCount(question.getLikeCount() + 1);
        questionMapper.updateById(question);
    }
}
