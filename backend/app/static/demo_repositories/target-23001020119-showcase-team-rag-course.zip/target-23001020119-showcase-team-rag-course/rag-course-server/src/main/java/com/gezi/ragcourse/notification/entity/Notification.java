package com.gezi.ragcourse.notification.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 通知实体
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("notification")
public class Notification {

    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 接收用户ID
     */
    private Long userId;

    /**
     * 通知类型: ANSWER / ACCEPTED / VERIFIED / SYSTEM / COURSE
     */
    private String type;

    /**
     * 通知标题
     */
    private String title;

    /**
     * 通知内容
     */
    private String content;

    /**
     * 关联目标类型（如QUESTION、ANSWER、COURSE等）
     */
    private String targetType;

    /**
     * 关联目标ID
     */
    private Long targetId;

    /**
     * 是否已读
     */
    @Builder.Default
    private Boolean isRead = false;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;
}
