package com.gezi.ragcourse.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.tags.Tag;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 * SpringDoc OpenAPI 配置
 */
@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI openAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("RAG教学系统 API")
                        .description("人工智能技术基础课程 - RAG教学系统后端接口文档")
                        .version("1.0.0")
                        .contact(new Contact()
                                .name("Gezi")
                                .email("admin@gezi.com")))
                .addSecurityItem(new SecurityRequirement().addList("Bearer"))
                .components(new Components()
                        .addSecuritySchemes("Bearer",
                                new SecurityScheme()
                                        .type(SecurityScheme.Type.HTTP)
                                        .scheme("bearer")
                                        .bearerFormat("JWT")
                                        .description("JWT Token认证，格式: Bearer {token}")))
                .tags(List.of(
                        new Tag().name("认证模块").description("用户登录、注册、登出"),
                        new Tag().name("用户模块").description("用户管理"),
                        new Tag().name("课程模块").description("课程管理"),
                        new Tag().name("文档模块").description("知识库文档管理"),
                        new Tag().name("RAG问答模块").description("RAG检索增强问答"),
                        new Tag().name("论坛模块").description("论坛问答"),
                        new Tag().name("错题模块").description("错题管理"),
                        new Tag().name("收藏模块").description("收藏管理"),
                        new Tag().name("教学分析模块").description("教学数据分析"),
                        new Tag().name("模型配置模块").description("AI模型与RAG配置"),
                        new Tag().name("通知模块").description("系统通知"),
                        new Tag().name("审计模块").description("操作审计日志"),
                        new Tag().name("存储模块").description("文件存储"),
                        new Tag().name("任务模块").description("异步任务管理")
                ));
    }
}
