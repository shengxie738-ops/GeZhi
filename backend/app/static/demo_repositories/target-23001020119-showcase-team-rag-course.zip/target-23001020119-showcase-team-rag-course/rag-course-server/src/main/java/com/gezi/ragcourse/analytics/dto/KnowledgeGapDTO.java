package com.gezi.ragcourse.analytics.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 知识点缺口DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "知识点缺口")
public class KnowledgeGapDTO {

    @Schema(description = "知识点主题")
    private String topic;

    @Schema(description = "缺口评分")
    private Double gapScore;

    @Schema(description = "相关问题列表")
    private List<String> relatedQuestions;

    @Schema(description = "相关文档列表")
    private List<String> relatedDocuments;

    @Schema(description = "建议补充方向")
    private String suggestion;
}
