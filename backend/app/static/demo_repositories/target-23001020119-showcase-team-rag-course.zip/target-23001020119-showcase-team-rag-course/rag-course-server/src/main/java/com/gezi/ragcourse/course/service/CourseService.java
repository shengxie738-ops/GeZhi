package com.gezi.ragcourse.course.service;

import com.gezi.ragcourse.common.api.PageResult;
import com.gezi.ragcourse.course.dto.CreateCourseRequest;
import com.gezi.ragcourse.course.dto.JoinCourseRequest;
import com.gezi.ragcourse.course.entity.Course;
import com.gezi.ragcourse.course.entity.CourseChapter;
import com.gezi.ragcourse.course.entity.CourseMember;

import java.util.List;

/**
 * 课程服务接口
 */
public interface CourseService {

    /**
     * 创建课程
     */
    Course createCourse(Long teacherId, CreateCourseRequest request);

    /**
     * 获取课程详情
     */
    Course getCourseById(Long courseId);

    /**
     * 课程列表（分页）
     */
    PageResult<Course> listCourses(int page, int size, String keyword);

    /**
     * 更新课程
     */
    Course updateCourse(Long courseId, CreateCourseRequest request, Long userId);

    /**
     * 删除课程
     */
    void deleteCourse(Long courseId, Long userId);

    /**
     * 学生加入课程
     */
    void joinCourse(Long userId, JoinCourseRequest request);

    /**
     * 获取课程成员列表
     */
    List<CourseMember> getCourseMembers(Long courseId);

    /**
     * 获取课程章节列表
     */
    List<CourseChapter> getCourseChapters(Long courseId);

    /**
     * 移除课程成员
     */
    void removeMember(Long courseId, Long userId);
}
