package com.gezi.ragcourse.document.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gezi.ragcourse.document.entity.KnowledgeChunk;
import org.apache.ibatis.annotations.Mapper;

/**
 * 知识库文本分块Mapper接口
 */
@Mapper
public interface KnowledgeChunkMapper extends BaseMapper<KnowledgeChunk> {
}
