package com.gezi.ragcourse.forum.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.List;

/**
 * 创建问题请求
 */
@Data
@Schema(description = "创建问题请求")
public class CreateQuestionRequest {

    @NotNull(message = "课程ID不能为空")
    @Schema(description = "课程ID", example = "1")
    private Long courseId;

    @Schema(description = "章节ID")
    private Long chapterId;

    @NotBlank(message = "标题不能为空")
    @Schema(description = "问题标题", example = "什么是向量数据库？")
    private String title;

    @NotBlank(message = "内容不能为空")
    @Schema(description = "问题内容")
    private String content;

    @Schema(description = "标签列表", example = "[\"向量数据库\", \"RAG\"]")
    private List<String> tags;
}
