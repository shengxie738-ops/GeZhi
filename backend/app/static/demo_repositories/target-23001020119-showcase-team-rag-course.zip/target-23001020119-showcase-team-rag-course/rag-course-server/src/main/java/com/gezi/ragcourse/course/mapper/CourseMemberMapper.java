package com.gezi.ragcourse.course.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gezi.ragcourse.course.entity.CourseMember;
import org.apache.ibatis.annotations.Mapper;

/**
 * 课程成员Mapper接口
 */
@Mapper
public interface CourseMemberMapper extends BaseMapper<CourseMember> {
}
