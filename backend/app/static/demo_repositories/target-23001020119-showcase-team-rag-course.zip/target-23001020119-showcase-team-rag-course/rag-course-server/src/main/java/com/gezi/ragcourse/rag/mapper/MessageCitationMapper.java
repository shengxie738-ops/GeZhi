package com.gezi.ragcourse.rag.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gezi.ragcourse.rag.entity.MessageCitation;
import org.apache.ibatis.annotations.Mapper;

/**
 * 消息引用Mapper接口
 */
@Mapper
public interface MessageCitationMapper extends BaseMapper<MessageCitation> {
}
