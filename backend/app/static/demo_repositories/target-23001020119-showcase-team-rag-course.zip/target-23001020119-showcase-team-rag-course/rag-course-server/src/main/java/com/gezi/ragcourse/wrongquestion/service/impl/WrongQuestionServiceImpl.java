package com.gezi.ragcourse.wrongquestion.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gezi.ragcourse.common.api.PageResult;
import com.gezi.ragcourse.common.exception.BusinessException;
import com.gezi.ragcourse.wrongquestion.dto.CreateWrongQuestionRequest;
import com.gezi.ragcourse.wrongquestion.entity.WrongQuestion;
import com.gezi.ragcourse.wrongquestion.mapper.WrongQuestionMapper;
import com.gezi.ragcourse.wrongquestion.service.WrongQuestionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.List;

/**
 * 错题服务实现
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class WrongQuestionServiceImpl implements WrongQuestionService {

    private final WrongQuestionMapper wrongQuestionMapper;
    private final ObjectMapper objectMapper;

    @Override
    public WrongQuestion createWrongQuestion(Long userId, CreateWrongQuestionRequest request) {
        String tagsJson = serializeTags(request.getKnowledgeTags());

        WrongQuestion wrongQuestion = WrongQuestion.builder()
                .courseId(request.getCourseId())
                .userId(userId)
                .title(request.getTitle())
                .questionContent(request.getQuestionContent())
                .studentAnswer(request.getStudentAnswer())
                .correctAnswer(request.getCorrectAnswer())
                .errorReason(request.getErrorReason())
                .knowledgeTags(tagsJson)
                .teacherComment(request.getTeacherComment())
                .build();
        wrongQuestionMapper.insert(wrongQuestion);
        return wrongQuestion;
    }

    @Override
    public PageResult<WrongQuestion> listWrongQuestions(int page, int size, Long courseId, Long userId, String status) {
        LambdaQueryWrapper<WrongQuestion> wrapper = new LambdaQueryWrapper<>();
        // 按课程ID过滤
        if (courseId != null) {
            wrapper.eq(WrongQuestion::getCourseId, courseId);
        }
        // 按用户ID过滤（学生只看自己的错题）
        if (userId != null) {
            wrapper.eq(WrongQuestion::getUserId, userId);
        }
        // 按状态过滤
        if (StringUtils.hasText(status)) {
            wrapper.eq(WrongQuestion::getStatus, status);
        }
        wrapper.orderByDesc(WrongQuestion::getCreatedAt);

        Page<WrongQuestion> pageResult = wrongQuestionMapper.selectPage(new Page<>(page, size), wrapper);
        return PageResult.of(pageResult);
    }

    @Override
    public WrongQuestion getWrongQuestionById(Long id) {
        WrongQuestion wrongQuestion = wrongQuestionMapper.selectById(id);
        if (wrongQuestion == null) {
            throw new BusinessException(404, "错题不存在");
        }
        return wrongQuestion;
    }

    @Override
    public WrongQuestion updateWrongQuestion(Long id, CreateWrongQuestionRequest request, Long userId) {
        WrongQuestion wrongQuestion = wrongQuestionMapper.selectById(id);
        if (wrongQuestion == null) {
            throw new BusinessException(404, "错题不存在");
        }
        if (!wrongQuestion.getUserId().equals(userId)) {
            throw new BusinessException(403, "无权修改该错题");
        }

        String tagsJson = serializeTags(request.getKnowledgeTags());

        wrongQuestion.setTitle(request.getTitle());
        wrongQuestion.setQuestionContent(request.getQuestionContent());
        wrongQuestion.setStudentAnswer(request.getStudentAnswer());
        wrongQuestion.setCorrectAnswer(request.getCorrectAnswer());
        wrongQuestion.setErrorReason(request.getErrorReason());
        wrongQuestion.setKnowledgeTags(tagsJson);
        if (request.getTeacherComment() != null) {
            wrongQuestion.setTeacherComment(request.getTeacherComment());
        }
        wrongQuestionMapper.updateById(wrongQuestion);
        return wrongQuestion;
    }

    @Override
    public void deleteWrongQuestion(Long id, Long userId) {
        WrongQuestion wrongQuestion = wrongQuestionMapper.selectById(id);
        if (wrongQuestion == null) {
            throw new BusinessException(404, "错题不存在");
        }
        if (!wrongQuestion.getUserId().equals(userId)) {
            throw new BusinessException(403, "无权删除该错题");
        }
        wrongQuestionMapper.deleteById(id);
    }

    @Override
    @Transactional
    public int importWrongQuestions(Long userId, List<CreateWrongQuestionRequest> requests) {
        // 批量导入错题，返回成功导入的数量
        int count = 0;
        for (CreateWrongQuestionRequest request : requests) {
            try {
                createWrongQuestion(userId, request);
                count++;
            } catch (Exception e) {
                log.warn("导入错题失败: {}", e.getMessage());
            }
        }
        return count;
    }

    /**
     * 将标签列表序列化为JSON字符串
     */
    private String serializeTags(List<String> tags) {
        if (tags == null || tags.isEmpty()) {
            return null;
        }
        try {
            return objectMapper.writeValueAsString(tags);
        } catch (Exception e) {
            log.error("知识点标签JSON序列化失败", e);
            return null;
        }
    }
}
