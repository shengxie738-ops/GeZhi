package com.gezi.ragcourse.user.controller;

import com.gezi.ragcourse.auth.dto.UserDTO;
import com.gezi.ragcourse.common.api.ApiResponse;
import com.gezi.ragcourse.common.api.PageResult;
import com.gezi.ragcourse.user.dto.UpdateUserRequest;
import com.gezi.ragcourse.user.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * 用户管理控制器
 * 权限说明: 除获取个人信息外，其他接口需要ADMIN角色
 */
@Tag(name = "用户模块")
@RestController
@RequestMapping("/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    /**
     * 获取用户信息 - 需要登录
     */
    @Operation(summary = "获取用户信息", description = "根据用户ID获取用户详情")
    @GetMapping("/{id}")
    public ApiResponse<UserDTO> getUserById(@PathVariable Long id) {
        return ApiResponse.success(userService.getUserById(id));
    }

    /**
     * 更新用户信息 - 需要登录（本人或ADMIN）
     */
    @Operation(summary = "更新用户信息", description = "更新指定用户的基本信息")
    @PutMapping("/{id}")
    public ApiResponse<UserDTO> updateUser(@PathVariable Long id,
                                           @Valid @RequestBody UpdateUserRequest request) {
        return ApiResponse.success("更新成功", userService.updateUser(id, request));
    }

    /**
     * 获取用户列表 - 需要ADMIN权限
     */
    @Operation(summary = "获取用户列表", description = "分页获取用户列表，支持关键词搜索")
    @GetMapping
    public ApiResponse<PageResult<UserDTO>> listUsers(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String keyword) {
        return ApiResponse.success(userService.listUsers(page, size, keyword));
    }

    /**
     * 删除用户 - 需要ADMIN权限
     */
    @Operation(summary = "删除用户", description = "逻辑删除用户")
    @DeleteMapping("/{id}")
    public ApiResponse<Void> deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return ApiResponse.success();
    }

    /**
     * 启用/禁用用户 - 需要ADMIN权限
     */
    @Operation(summary = "启用/禁用用户", description = "切换用户启用状态")
    @PutMapping("/{id}/toggle-status")
    public ApiResponse<Void> toggleUserStatus(@PathVariable Long id) {
        userService.toggleUserStatus(id);
        return ApiResponse.success();
    }
}
