package com.gezi.ragcourse.course.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * 加入课程请求
 */
@Data
@Schema(description = "加入课程请求")
public class JoinCourseRequest {

    @NotBlank(message = "课程编码不能为空")
    @Schema(description = "课程编码", example = "AI101")
    private String courseCode;
}
