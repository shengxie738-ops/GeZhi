package com.gezi.ragcourse.forum.controller;

import com.gezi.ragcourse.common.api.ApiResponse;
import com.gezi.ragcourse.common.api.PageResult;
import com.gezi.ragcourse.forum.dto.CreateAnswerRequest;
import com.gezi.ragcourse.forum.dto.CreateQuestionRequest;
import com.gezi.ragcourse.forum.entity.ForumAnswer;
import com.gezi.ragcourse.forum.entity.ForumQuestion;
import com.gezi.ragcourse.forum.service.ForumService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * 论坛模块控制器
 */
@Tag(name = "论坛模块")
@RestController
@RequestMapping("/forum")
@RequiredArgsConstructor
public class ForumController {

    private final ForumService forumService;

    /**
     * 获取问题列表（按课程过滤，分页）
     */
    @Operation(summary = "获取问题列表", description = "分页获取指定课程的问题列表")
    @GetMapping("/courses/{courseId}/questions")
    public ApiResponse<PageResult<ForumQuestion>> listQuestions(
            @PathVariable Long courseId,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String keyword) {
        return ApiResponse.success(forumService.listQuestions(page, size, courseId, status, keyword));
    }

    /**
     * 创建问题
     */
    @Operation(summary = "创建问题", description = "在指定课程下创建新问题")
    @PostMapping("/courses/{courseId}/questions")
    public ApiResponse<ForumQuestion> createQuestion(
            @PathVariable Long courseId,
            @Valid @RequestBody CreateQuestionRequest request,
            HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        request.setCourseId(courseId);
        return ApiResponse.success("问题创建成功", forumService.createQuestion(userId, request));
    }

    /**
     * 获取问题详情
     */
    @Operation(summary = "获取问题详情", description = "获取指定问题的详细信息")
    @GetMapping("/questions/{questionId}")
    public ApiResponse<ForumQuestion> getQuestion(@PathVariable Long questionId) {
        return ApiResponse.success(forumService.getQuestionById(questionId));
    }

    /**
     * 更新问题
     */
    @Operation(summary = "更新问题", description = "更新问题内容（仅作者可操作）")
    @PutMapping("/questions/{questionId}")
    public ApiResponse<ForumQuestion> updateQuestion(
            @PathVariable Long questionId,
            @Valid @RequestBody CreateQuestionRequest request,
            HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        return ApiResponse.success("更新成功", forumService.updateQuestion(questionId, request, userId));
    }

    /**
     * 删除问题
     */
    @Operation(summary = "删除问题", description = "删除指定问题（仅作者可操作）")
    @DeleteMapping("/questions/{questionId}")
    public ApiResponse<Void> deleteQuestion(@PathVariable Long questionId,
                                            HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        forumService.deleteQuestion(questionId, userId);
        return ApiResponse.success();
    }

    /**
     * 问题点赞
     */
    @Operation(summary = "问题点赞", description = "对指定问题点赞")
    @PostMapping("/questions/{questionId}/like")
    public ApiResponse<Void> likeQuestion(@PathVariable Long questionId,
                                          HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        forumService.likeQuestion(questionId, userId);
        return ApiResponse.success("点赞成功");
    }

    /**
     * 获取问题的回答列表
     */
    @Operation(summary = "获取回答列表", description = "分页获取指定问题的回答列表")
    @GetMapping("/questions/{questionId}/answers")
    public ApiResponse<PageResult<ForumAnswer>> listAnswers(
            @PathVariable Long questionId,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size) {
        return ApiResponse.success(forumService.listAnswers(questionId, page, size));
    }

    /**
     * 创建回答
     */
    @Operation(summary = "创建回答", description = "为指定问题创建回答")
    @PostMapping("/questions/{questionId}/answers")
    public ApiResponse<ForumAnswer> createAnswer(
            @PathVariable Long questionId,
            @Valid @RequestBody CreateAnswerRequest request,
            HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        return ApiResponse.success("回答创建成功", forumService.createAnswer(userId, questionId, request));
    }

    /**
     * 接受最佳答案
     */
    @Operation(summary = "接受最佳答案", description = "提问者采纳指定回答为最佳答案")
    @PostMapping("/answers/{answerId}/accept")
    public ApiResponse<Void> acceptAnswer(@PathVariable Long answerId,
                                          HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        forumService.acceptAnswer(answerId, userId);
        return ApiResponse.success("已采纳为最佳答案");
    }

    /**
     * 教师认证回答
     */
    @Operation(summary = "教师认证回答", description = "教师认证指定回答的内容正确性")
    @PostMapping("/answers/{answerId}/verify")
    public ApiResponse<Void> verifyAnswer(@PathVariable Long answerId,
                                          HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        forumService.verifyAnswer(answerId, userId);
        return ApiResponse.success("已认证");
    }

    /**
     * 将回答加入知识库
     */
    @Operation(summary = "加入知识库", description = "将优质回答加入课程知识库")
    @PostMapping("/answers/{answerId}/knowledge")
    public ApiResponse<Void> addToKnowledge(@PathVariable Long answerId,
                                            HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        forumService.addToKnowledge(answerId, userId);
        return ApiResponse.success("已加入知识库");
    }
}
