package com.gezi.ragcourse.rag.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.util.List;

/**
 * 向量搜索请求
 */
@Data
@Schema(description = "向量搜索请求")
public class SearchRequest {

    @NotBlank(message = "搜索关键词不能为空")
    @Schema(description = "搜索关键词", example = "RAG检索增强")
    private String query;

    @Schema(description = "课程ID（限定范围）")
    private Long courseId;

    @Schema(description = "章节ID（限定范围）")
    private Long chapterId;

    @Schema(description = "来源类型过滤")
    private List<String> sourceTypes;

    @Schema(description = "返回结果数量", defaultValue = "5")
    private Integer topK = 5;
}
