package com.gezi.ragcourse.audit.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 审计日志实体
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("audit_log")
public class AuditLog {

    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 操作用户ID
     */
    private Long userId;

    /**
     * 操作用户名称
     */
    private String username;

    /**
     * 操作模块（如COURSE、DOCUMENT、FORUM等）
     */
    private String module;

    /**
     * 操作类型（如CREATE、UPDATE、DELETE等）
     */
    private String action;

    /**
     * 操作描述
     */
    private String description;

    /**
     * 请求方法（GET、POST、PUT、DELETE）
     */
    private String requestMethod;

    /**
     * 请求URL
     */
    private String requestUrl;

    /**
     * 请求参数（JSON格式）
     */
    private String requestParams;

    /**
     * 操作结果: SUCCESS / FAILURE
     */
    @Builder.Default
    private String result = "SUCCESS";

    /**
     * 错误信息（失败时记录）
     */
    private String errorMessage;

    /**
     * IP地址
     */
    private String ipAddress;

    /**
     * 耗时（毫秒）
     */
    private Long durationMs;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;
}
