package com.gezi.ragcourse.modelconfig.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gezi.ragcourse.common.exception.BusinessException;
import com.gezi.ragcourse.modelconfig.dto.CreateModelConfigRequest;
import com.gezi.ragcourse.modelconfig.dto.ModelTestRequest;
import com.gezi.ragcourse.modelconfig.dto.ModelTestResponse;
import com.gezi.ragcourse.modelconfig.entity.ModelConfig;
import com.gezi.ragcourse.modelconfig.entity.RagConfig;
import com.gezi.ragcourse.modelconfig.mapper.ModelConfigMapper;
import com.gezi.ragcourse.modelconfig.mapper.RagConfigMapper;
import com.gezi.ragcourse.modelconfig.service.ModelConfigService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 模型配置服务实现
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ModelConfigServiceImpl implements ModelConfigService {

    private final ModelConfigMapper modelConfigMapper;
    private final RagConfigMapper ragConfigMapper;
    private final ObjectMapper objectMapper;

    @Override
    public List<ModelConfig> listModelConfigs() {
        return modelConfigMapper.selectList(
                new LambdaQueryWrapper<ModelConfig>().orderByDesc(ModelConfig::getCreatedAt)
        );
    }

    @Override
    public ModelConfig getModelConfigById(Long id) {
        ModelConfig config = modelConfigMapper.selectById(id);
        if (config == null) {
            throw new BusinessException(404, "模型配置不存在");
        }
        config.setApiKey(null);
        return config;
    }

    @Override
    public ModelConfig createModelConfig(CreateModelConfigRequest request) {
        String paramsJson = null;
        if (request.getModelParams() != null) {
            try {
                paramsJson = objectMapper.writeValueAsString(request.getModelParams());
            } catch (Exception e) {
                log.error("模型参数JSON序列化失败", e);
            }
        }

        ModelConfig config = ModelConfig.builder()
                .modelName(request.getModelName())
                .provider(request.getProvider())
                .apiEndpoint(request.getApiEndpoint())
                .apiKey(request.getApiKey())
                .modelParams(paramsJson)
                .description(request.getDescription())
                .build();
        modelConfigMapper.insert(config);
        return config;
    }

    @Override
    public ModelConfig updateModelConfig(Long id, CreateModelConfigRequest request) {
        ModelConfig config = modelConfigMapper.selectById(id);
        if (config == null) {
            throw new BusinessException(404, "模型配置不存在");
        }

        String paramsJson = null;
        if (request.getModelParams() != null) {
            try {
                paramsJson = objectMapper.writeValueAsString(request.getModelParams());
            } catch (Exception e) {
                log.error("模型参数JSON序列化失败", e);
            }
        }

        config.setModelName(request.getModelName());
        config.setProvider(request.getProvider());
        config.setApiEndpoint(request.getApiEndpoint());
        if (request.getApiKey() != null) {
            config.setApiKey(request.getApiKey());
        }
        config.setModelParams(paramsJson);
        config.setDescription(request.getDescription());
        modelConfigMapper.updateById(config);
        return config;
    }

    @Override
    public void deleteModelConfig(Long id) {
        if (modelConfigMapper.selectById(id) == null) {
            throw new BusinessException(404, "模型配置不存在");
        }
        modelConfigMapper.deleteById(id);
    }

    @Override
    @Transactional
    public void setActiveModel(Long id) {
        ModelConfig target = modelConfigMapper.selectById(id);
        if (target == null) {
            throw new BusinessException(404, "模型配置不存在");
        }

        // 先将所有模型设为非活跃
        LambdaQueryWrapper<ModelConfig> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ModelConfig::getIsActive, true);
        List<ModelConfig> activeConfigs = modelConfigMapper.selectList(wrapper);
        for (ModelConfig config : activeConfigs) {
            config.setIsActive(false);
            modelConfigMapper.updateById(config);
        }

        // 将目标模型设为活跃
        target.setIsActive(true);
        modelConfigMapper.updateById(target);
    }

    @Override
    public ModelTestResponse testModel(ModelTestRequest request) {
        ModelConfig config;
        if (request.getModelConfigId() != null) {
            config = modelConfigMapper.selectById(request.getModelConfigId());
        } else {
            // 使用当前活跃模型
            LambdaQueryWrapper<ModelConfig> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(ModelConfig::getIsActive, true);
            config = modelConfigMapper.selectOne(wrapper);
        }

        if (config == null) {
            return ModelTestResponse.builder()
                    .success(false)
                    .errorMessage("未找到可用的模型配置")
                    .build();
        }

        // TODO: 实际调用模型API进行测试，以下为模拟逻辑
        long startTime = System.currentTimeMillis();
        try {
            // 实际实现应使用WebClient或RestTemplate调用对应的API
            long latencyMs = System.currentTimeMillis() - startTime;

            return ModelTestResponse.builder()
                    .success(true)
                    .content("模型连接测试成功。模型: " + config.getModelName() + ", 提供商: " + config.getProvider())
                    .latencyMs(latencyMs)
                    .tokenCount(0)
                    .build();
        } catch (Exception e) {
            return ModelTestResponse.builder()
                    .success(false)
                    .errorMessage("模型调用失败: " + e.getMessage())
                    .latencyMs(System.currentTimeMillis() - startTime)
                    .build();
        }
    }

    @Override
    public RagConfig getRagConfig(Long courseId) {
        LambdaQueryWrapper<RagConfig> wrapper = new LambdaQueryWrapper<>();
        // 先查找课程级别的配置
        if (courseId != null) {
            wrapper.eq(RagConfig::getCourseId, courseId);
        } else {
            // 全局配置（courseId为null）
            wrapper.isNull(RagConfig::getCourseId);
        }
        RagConfig config = ragConfigMapper.selectOne(wrapper);

        // 如果没有课程级别配置，返回全局默认配置
        if (config == null && courseId != null) {
            wrapper.clear();
            wrapper.isNull(RagConfig::getCourseId);
            config = ragConfigMapper.selectOne(wrapper);
        }

        // 如果还是没有，返回默认配置
        if (config == null) {
            config = RagConfig.builder()
                    .courseId(courseId)
                    .retrievalStrategy("HYBRID")
                    .topK(5)
                    .similarityThreshold(0.7)
                    .chunkSize(512)
                    .chunkOverlap(50)
                    .build();
        }
        return config;
    }

    @Override
    public RagConfig saveRagConfig(Long courseId, RagConfig ragConfig) {
        // 查找是否已有该课程的RAG配置
        LambdaQueryWrapper<RagConfig> wrapper = new LambdaQueryWrapper<>();
        if (courseId != null) {
            wrapper.eq(RagConfig::getCourseId, courseId);
        } else {
            wrapper.isNull(RagConfig::getCourseId);
        }
        RagConfig existing = ragConfigMapper.selectOne(wrapper);

        if (existing != null) {
            // 更新已有配置
            ragConfig.setId(existing.getId());
            ragConfig.setCourseId(courseId);
            ragConfigMapper.updateById(ragConfig);
        } else {
            // 创建新配置
            ragConfig.setCourseId(courseId);
            ragConfigMapper.insert(ragConfig);
        }
        return ragConfig;
    }
}
