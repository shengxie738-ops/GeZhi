package com.gezi.ragcourse.favorite.service;

import com.gezi.ragcourse.common.api.PageResult;
import com.gezi.ragcourse.favorite.entity.Favorite;

/**
 * 收藏服务接口
 */
public interface FavoriteService {

    /**
     * 获取收藏列表（分页，按目标类型过滤）
     */
    PageResult<Favorite> listFavorites(int page, int size, Long userId, String targetType);

    /**
     * 添加收藏
     */
    Favorite addFavorite(Long userId, String targetType, Long targetId);

    /**
     * 取消收藏
     */
    void removeFavorite(Long userId, String targetType, Long targetId);
}
