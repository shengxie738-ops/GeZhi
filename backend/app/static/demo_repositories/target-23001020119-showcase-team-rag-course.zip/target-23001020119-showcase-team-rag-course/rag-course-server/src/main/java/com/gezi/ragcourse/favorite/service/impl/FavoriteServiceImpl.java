package com.gezi.ragcourse.favorite.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gezi.ragcourse.common.api.PageResult;
import com.gezi.ragcourse.common.exception.BusinessException;
import com.gezi.ragcourse.favorite.entity.Favorite;
import com.gezi.ragcourse.favorite.mapper.FavoriteMapper;
import com.gezi.ragcourse.favorite.service.FavoriteService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
 * 收藏服务实现
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class FavoriteServiceImpl implements FavoriteService {

    private final FavoriteMapper favoriteMapper;

    @Override
    public PageResult<Favorite> listFavorites(int page, int size, Long userId, String targetType) {
        LambdaQueryWrapper<Favorite> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Favorite::getUserId, userId);
        // 按目标类型过滤
        if (StringUtils.hasText(targetType)) {
            wrapper.eq(Favorite::getTargetType, targetType);
        }
        wrapper.orderByDesc(Favorite::getCreatedAt);

        Page<Favorite> pageResult = favoriteMapper.selectPage(new Page<>(page, size), wrapper);
        return PageResult.of(pageResult);
    }

    @Override
    public Favorite addFavorite(Long userId, String targetType, Long targetId) {
        // 检查是否已收藏（防止重复）
        LambdaQueryWrapper<Favorite> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Favorite::getUserId, userId)
                .eq(Favorite::getTargetType, targetType)
                .eq(Favorite::getTargetId, targetId);
        if (favoriteMapper.selectCount(wrapper) > 0) {
            throw new BusinessException("已收藏过该内容");
        }

        Favorite favorite = Favorite.builder()
                .userId(userId)
                .targetType(targetType)
                .targetId(targetId)
                .build();
        favoriteMapper.insert(favorite);
        return favorite;
    }

    @Override
    public void removeFavorite(Long userId, String targetType, Long targetId) {
        LambdaQueryWrapper<Favorite> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Favorite::getUserId, userId)
                .eq(Favorite::getTargetType, targetType)
                .eq(Favorite::getTargetId, targetId);
        int deleted = favoriteMapper.delete(wrapper);
        if (deleted == 0) {
            throw new BusinessException(404, "收藏记录不存在");
        }
    }
}
