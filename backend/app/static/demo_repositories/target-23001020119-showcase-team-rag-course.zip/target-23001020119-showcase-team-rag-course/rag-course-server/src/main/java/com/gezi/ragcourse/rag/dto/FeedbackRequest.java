package com.gezi.ragcourse.rag.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * 消息反馈请求
 */
@Data
@Schema(description = "消息反馈请求")
public class FeedbackRequest {

    @NotBlank(message = "反馈类型不能为空")
    @Schema(description = "反馈类型: POSITIVE, NEGATIVE, UNRESOLVED")
    private String feedbackType;

    @Schema(description = "反馈原因")
    private String reason;

    @Schema(description = "补充说明")
    private String comment;
}
