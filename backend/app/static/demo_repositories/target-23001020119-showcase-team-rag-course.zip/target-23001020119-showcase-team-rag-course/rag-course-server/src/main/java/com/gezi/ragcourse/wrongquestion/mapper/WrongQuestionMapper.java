package com.gezi.ragcourse.wrongquestion.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gezi.ragcourse.wrongquestion.entity.WrongQuestion;
import org.apache.ibatis.annotations.Mapper;

/**
 * 错题Mapper接口
 */
@Mapper
public interface WrongQuestionMapper extends BaseMapper<WrongQuestion> {
}
