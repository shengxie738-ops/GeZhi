package com.gezi.ragcourse.common.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 来源类型枚举
 */
@Getter
@AllArgsConstructor
public enum SourceType {

    KNOWLEDGE("KNOWLEDGE", "知识库文档"),
    FORUM("FORUM", "论坛回答"),
    WRONG_QUESTION("WRONG_QUESTION", "错题解析"),
    TEXTBOOK("TEXTBOOK", "教材内容");

    @EnumValue
    @JsonValue
    private final String code;
    private final String description;
}
