package com.gezi.ragcourse;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * RAG教学系统 - 人工智能技术基础课程后端服务
 *
 * @author gezi
 */
@SpringBootApplication
@MapperScan("com.gezi.ragcourse.*.mapper")
@EnableAsync
@EnableScheduling
public class RagCourseApplication {

    public static void main(String[] args) {
        SpringApplication.run(RagCourseApplication.class, args);
    }
}
