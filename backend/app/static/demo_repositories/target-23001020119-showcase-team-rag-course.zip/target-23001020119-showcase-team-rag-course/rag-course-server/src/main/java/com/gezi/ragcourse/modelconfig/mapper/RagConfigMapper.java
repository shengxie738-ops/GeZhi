package com.gezi.ragcourse.modelconfig.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gezi.ragcourse.modelconfig.entity.RagConfig;
import org.apache.ibatis.annotations.Mapper;

/**
 * RAG配置Mapper接口
 */
@Mapper
public interface RagConfigMapper extends BaseMapper<RagConfig> {
}
