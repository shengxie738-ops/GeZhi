package com.gezi.ragcourse.job.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gezi.ragcourse.common.api.PageResult;
import com.gezi.ragcourse.common.exception.BusinessException;
import com.gezi.ragcourse.document.entity.IngestJob;
import com.gezi.ragcourse.document.mapper.IngestJobMapper;
import com.gezi.ragcourse.job.service.JobService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 任务服务实现
 * 基于文档解析任务（IngestJob）进行管理
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class JobServiceImpl implements JobService {

    private final IngestJobMapper ingestJobMapper;

    @Override
    public PageResult<Map<String, Object>> listJobs(int page, int size, String status) {
        LambdaQueryWrapper<IngestJob> wrapper = new LambdaQueryWrapper<>();
        // 按状态筛选
        if (StringUtils.hasText(status)) {
            wrapper.eq(IngestJob::getStatus, status);
        }
        wrapper.orderByDesc(IngestJob::getCreatedAt);

        Page<IngestJob> pageResult = ingestJobMapper.selectPage(new Page<>(page, size), wrapper);

        // 将实体转为Map返回，便于前端展示
        List<Map<String, Object>> records = pageResult.getRecords().stream()
                .map(this::jobToMap)
                .toList();

        return PageResult.of(records, pageResult.getTotal(),
                pageResult.getCurrent(), pageResult.getSize());
    }

    @Override
    public Map<String, Object> getJobById(Long jobId) {
        IngestJob job = ingestJobMapper.selectById(jobId);
        if (job == null) {
            throw new BusinessException(404, "任务不存在");
        }
        return jobToMap(job);
    }

    @Override
    public void retryJob(Long jobId) {
        // 业务逻辑：重试失败的任务
        IngestJob job = ingestJobMapper.selectById(jobId);
        if (job == null) {
            throw new BusinessException(404, "任务不存在");
        }
        if ("COMPLETED".equals(job.getStatus())) {
            throw new BusinessException("已完成的任务无需重试");
        }
        if ("RUNNING".equals(job.getStatus())) {
            throw new BusinessException("运行中的任务不能重试");
        }

        // 重置任务状态为待处理
        job.setStatus("PENDING");
        job.setProgress(0);
        job.setErrorMessage(null);
        ingestJobMapper.updateById(job);

        // TODO: 重新提交异步任务到消息队列
        log.info("任务[{}]已重试，状态重置为PENDING", jobId);
    }

    @Override
    public void cancelJob(Long jobId) {
        // 业务逻辑：取消运行中或等待中的任务
        IngestJob job = ingestJobMapper.selectById(jobId);
        if (job == null) {
            throw new BusinessException(404, "任务不存在");
        }
        if ("COMPLETED".equals(job.getStatus())) {
            throw new BusinessException("已完成的任务不能取消");
        }
        if ("FAILED".equals(job.getStatus())) {
            throw new BusinessException("已失败的任务不能取消");
        }

        job.setStatus("CANCELLED");
        ingestJobMapper.updateById(job);

        // TODO: 通知消息队列取消任务执行
        log.info("任务[{}]已取消", jobId);
    }

    /**
     * 将IngestJob转为Map展示
     */
    private Map<String, Object> jobToMap(IngestJob job) {
        Map<String, Object> map = new HashMap<>();
        map.put("id", job.getId());
        map.put("documentId", job.getDocumentId());
        map.put("status", job.getStatus());
        map.put("progress", job.getProgress());
        map.put("errorMessage", job.getErrorMessage());
        map.put("createdAt", job.getCreatedAt());
        map.put("updatedAt", job.getUpdatedAt());
        return map;
    }
}
