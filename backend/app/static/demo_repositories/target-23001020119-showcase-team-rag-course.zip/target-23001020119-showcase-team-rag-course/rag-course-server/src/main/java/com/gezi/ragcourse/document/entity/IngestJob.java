package com.gezi.ragcourse.document.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.gezi.ragcourse.common.enums.ParseStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 文档解析任务实体
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("ingest_job")
public class IngestJob {

    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 文档ID
     */
    private Long documentId;

    /**
     * 任务状态
     */
    @Builder.Default
    private ParseStatus status = ParseStatus.PENDING;

    /**
     * 处理进度百分比
     */
    @Builder.Default
    private Integer progress = 0;

    /**
     * 错误信息
     */
    private String errorMessage;

    /**
     * 开始时间
     */
    private LocalDateTime startedAt;

    /**
     * 完成时间
     */
    private LocalDateTime completedAt;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updatedAt;
}
