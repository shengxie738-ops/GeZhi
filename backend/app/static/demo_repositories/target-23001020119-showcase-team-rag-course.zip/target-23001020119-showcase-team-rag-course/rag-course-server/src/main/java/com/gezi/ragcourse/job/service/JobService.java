package com.gezi.ragcourse.job.service;

import com.gezi.ragcourse.common.api.PageResult;

import java.util.Map;

/**
 * 任务服务接口
 */
public interface JobService {

    /**
     * 获取任务列表（分页，支持按状态筛选）
     */
    PageResult<Map<String, Object>> listJobs(int page, int size, String status);

    /**
     * 获取任务详情
     */
    Map<String, Object> getJobById(Long jobId);

    /**
     * 重试任务
     */
    void retryJob(Long jobId);

    /**
     * 取消任务
     */
    void cancelJob(Long jobId);
}
