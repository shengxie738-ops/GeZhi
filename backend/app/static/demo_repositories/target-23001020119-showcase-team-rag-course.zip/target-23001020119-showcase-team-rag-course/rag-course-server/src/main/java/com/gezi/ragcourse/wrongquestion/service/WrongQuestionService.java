package com.gezi.ragcourse.wrongquestion.service;

import com.gezi.ragcourse.common.api.PageResult;
import com.gezi.ragcourse.wrongquestion.dto.CreateWrongQuestionRequest;
import com.gezi.ragcourse.wrongquestion.entity.WrongQuestion;

import java.util.List;

/**
 * 错题服务接口
 */
public interface WrongQuestionService {

    /**
     * 创建错题
     */
    WrongQuestion createWrongQuestion(Long userId, CreateWrongQuestionRequest request);

    /**
     * 错题列表（分页，按课程过滤）
     */
    PageResult<WrongQuestion> listWrongQuestions(int page, int size, Long courseId, Long userId, String status);

    /**
     * 错题详情
     */
    WrongQuestion getWrongQuestionById(Long id);

    /**
     * 更新错题
     */
    WrongQuestion updateWrongQuestion(Long id, CreateWrongQuestionRequest request, Long userId);

    /**
     * 删除错题
     */
    void deleteWrongQuestion(Long id, Long userId);

    /**
     * 批量导入错题
     */
    int importWrongQuestions(Long userId, List<CreateWrongQuestionRequest> requests);
}
