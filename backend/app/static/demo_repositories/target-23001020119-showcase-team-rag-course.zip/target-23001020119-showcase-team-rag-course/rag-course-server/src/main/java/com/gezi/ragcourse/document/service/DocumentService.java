package com.gezi.ragcourse.document.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gezi.ragcourse.common.api.PageResult;
import com.gezi.ragcourse.document.dto.ChunkDTO;
import com.gezi.ragcourse.document.dto.UploadResponse;
import com.gezi.ragcourse.document.entity.KnowledgeDocument;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 文档服务接口
 */
public interface DocumentService {

    /**
     * 上传文档
     */
    UploadResponse uploadDocument(Long userId, Long courseId, Long chapterId, MultipartFile file);

    /**
     * 获取课程文档列表
     */
    PageResult<KnowledgeDocument> listDocuments(Long courseId, int page, int size);

    /**
     * 获取文档详情
     */
    KnowledgeDocument getDocumentById(Long documentId);

    /**
     * 删除文档
     */
    void deleteDocument(Long documentId, Long userId);

    /**
     * 触发文档解析
     */
    void parseDocument(Long documentId);

    /**
     * 获取文档的文本分块
     */
    List<ChunkDTO> getDocumentChunks(Long documentId);
}
