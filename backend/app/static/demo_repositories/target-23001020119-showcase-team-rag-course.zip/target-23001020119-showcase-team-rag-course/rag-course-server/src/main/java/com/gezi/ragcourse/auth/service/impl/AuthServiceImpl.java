package com.gezi.ragcourse.auth.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.gezi.ragcourse.auth.dto.*;
import com.gezi.ragcourse.auth.service.AuthService;
import com.gezi.ragcourse.common.enums.Role;
import com.gezi.ragcourse.common.exception.BusinessException;
import com.gezi.ragcourse.common.util.JwtUtil;
import com.gezi.ragcourse.user.entity.SysUser;
import com.gezi.ragcourse.user.mapper.SysUserMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

/**
 * 认证服务实现
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final SysUserMapper sysUserMapper;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final StringRedisTemplate stringRedisTemplate;

    @Override
    public LoginResponse login(LoginRequest request) {
        // 查询用户
        LambdaQueryWrapper<SysUser> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(SysUser::getUsername, request.getUsername());
        SysUser user = sysUserMapper.selectOne(wrapper);

        if (user == null) {
            throw new BusinessException("用户名或密码错误");
        }

        // 验证密码
        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new BusinessException("用户名或密码错误");
        }

        // 生成Token
        String token = jwtUtil.generateAccessToken(user.getId(), user.getUsername(), user.getRole().name());
        String refreshToken = jwtUtil.generateRefreshToken(user.getId(), user.getUsername());

        // 将refreshToken存入Redis
        stringRedisTemplate.opsForValue().set(
                "refresh_token:" + user.getId(),
                refreshToken,
                7, TimeUnit.DAYS
        );

        // 构建响应
        UserDTO userDTO = UserDTO.builder()
                .id(user.getId())
                .username(user.getUsername())
                .realName(user.getRealName())
                .studentNo(user.getStudentNo())
                .employeeNo(user.getEmployeeNo())
                .email(user.getEmail())
                .role(user.getRole())
                .avatar(user.getAvatar())
                .createdAt(user.getCreatedAt())
                .build();

        return LoginResponse.builder()
                .token(token)
                .refreshToken(refreshToken)
                .user(userDTO)
                .build();
    }

    @Override
    public UserDTO register(RegisterRequest request) {
        // 检查用户名是否已存在
        LambdaQueryWrapper<SysUser> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(SysUser::getUsername, request.getUsername());
        if (sysUserMapper.selectCount(wrapper) > 0) {
            throw new BusinessException("用户名已存在");
        }

        // 根据是否有学号/工号判断角色
        Role role = (request.getStudentNo() != null && !request.getStudentNo().isEmpty())
                ? Role.STUDENT : Role.TEACHER;

        // 构建用户实体
        SysUser user = SysUser.builder()
                .username(request.getUsername())
                .password(passwordEncoder.encode(request.getPassword()))
                .realName(request.getRealName())
                .studentNo(request.getStudentNo())
                .employeeNo(request.getEmployeeNo())
                .email(request.getEmail())
                .role(role)
                .build();

        sysUserMapper.insert(user);

        return UserDTO.builder()
                .id(user.getId())
                .username(user.getUsername())
                .realName(user.getRealName())
                .studentNo(user.getStudentNo())
                .employeeNo(user.getEmployeeNo())
                .email(user.getEmail())
                .role(user.getRole())
                .createdAt(user.getCreatedAt())
                .build();
    }

    @Override
    public void logout(String token) {
        try {
            Long userId = jwtUtil.getUserIdFromToken(token);
            // 删除Redis中的refreshToken
            stringRedisTemplate.delete("refresh_token:" + userId);
            // 将accessToken加入黑名单
            stringRedisTemplate.opsForValue().set("token:blacklist:" + token, "1", 1, TimeUnit.HOURS);
            log.info("用户 {} 已登出", userId);
        } catch (Exception e) {
            log.warn("登出处理异常", e);
        }
    }

    @Override
    public LoginResponse refreshToken(String refreshToken) {
        // 验证refreshToken
        if (!jwtUtil.validateToken(refreshToken) || jwtUtil.isAccessToken(refreshToken)) {
            throw new BusinessException(401, "刷新令牌无效或已过期");
        }

        Long userId = jwtUtil.getUserIdFromToken(refreshToken);
        String username = jwtUtil.getUsernameFromToken(refreshToken);

        // 查询用户
        SysUser user = sysUserMapper.selectById(userId);
        if (user == null) {
            throw new BusinessException(401, "用户不存在");
        }

        // 验证Redis中的refreshToken
        String storedToken = stringRedisTemplate.opsForValue().get("refresh_token:" + userId);
        if (storedToken == null || !storedToken.equals(refreshToken)) {
            throw new BusinessException(401, "刷新令牌已失效，请重新登录");
        }

        // 生成新的Token对
        String newToken = jwtUtil.generateAccessToken(user.getId(), user.getUsername(), user.getRole().name());
        String newRefreshToken = jwtUtil.generateRefreshToken(user.getId(), user.getUsername());

        // 更新Redis
        stringRedisTemplate.opsForValue().set(
                "refresh_token:" + user.getId(),
                newRefreshToken,
                7, TimeUnit.DAYS
        );

        UserDTO userDTO = UserDTO.builder()
                .id(user.getId())
                .username(user.getUsername())
                .realName(user.getRealName())
                .studentNo(user.getStudentNo())
                .employeeNo(user.getEmployeeNo())
                .email(user.getEmail())
                .role(user.getRole())
                .avatar(user.getAvatar())
                .createdAt(user.getCreatedAt())
                .build();

        return LoginResponse.builder()
                .token(newToken)
                .refreshToken(newRefreshToken)
                .user(userDTO)
                .build();
    }

    @Override
    public UserDTO getCurrentUser(Long userId) {
        SysUser user = sysUserMapper.selectById(userId);
        if (user == null) {
            throw new BusinessException(404, "用户不存在");
        }

        return UserDTO.builder()
                .id(user.getId())
                .username(user.getUsername())
                .realName(user.getRealName())
                .studentNo(user.getStudentNo())
                .employeeNo(user.getEmployeeNo())
                .email(user.getEmail())
                .role(user.getRole())
                .avatar(user.getAvatar())
                .createdAt(user.getCreatedAt())
                .build();
    }
}
