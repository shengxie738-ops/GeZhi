package com.gezi.ragcourse.rag.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 引用信息DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "引用信息")
public class CitationDTO {

    @Schema(description = "引用ID")
    private Long id;

    @Schema(description = "内容摘要")
    private String contentPreview;

    @Schema(description = "相似度分数")
    private Double score;

    @Schema(description = "来源文档ID")
    private Long documentId;

    @Schema(description = "来源文档标题")
    private String documentTitle;

    @Schema(description = "chunk ID")
    private Long chunkId;
}
