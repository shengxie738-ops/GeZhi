package com.gezi.ragcourse.wrongquestion.controller;

import com.gezi.ragcourse.common.api.ApiResponse;
import com.gezi.ragcourse.common.api.PageResult;
import com.gezi.ragcourse.wrongquestion.dto.CreateWrongQuestionRequest;
import com.gezi.ragcourse.wrongquestion.entity.WrongQuestion;
import com.gezi.ragcourse.wrongquestion.service.WrongQuestionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 错题管理控制器
 * 权限说明: 学生管理自己的错题，教师可查看课程下所有学生的错题
 */
@Tag(name = "错题模块")
@RestController
@RequestMapping("/wrong-questions")
@RequiredArgsConstructor
public class WrongQuestionController {

    private final WrongQuestionService wrongQuestionService;

    /**
     * 获取错题列表
     */
    @Operation(summary = "获取错题列表", description = "分页获取错题列表，支持按课程、状态过滤")
    @GetMapping
    public ApiResponse<PageResult<WrongQuestion>> listWrongQuestions(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) Long courseId,
            @RequestParam(required = false) String status,
            HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        return ApiResponse.success(wrongQuestionService.listWrongQuestions(page, size, courseId, userId, status));
    }

    /**
     * 创建错题
     */
    @Operation(summary = "创建错题", description = "学生手动添加错题记录")
    @PostMapping
    public ApiResponse<WrongQuestion> createWrongQuestion(@Valid @RequestBody CreateWrongQuestionRequest request,
                                                          HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        return ApiResponse.success("错题创建成功", wrongQuestionService.createWrongQuestion(userId, request));
    }

    /**
     * 获取错题详情
     */
    @Operation(summary = "获取错题详情", description = "获取指定错题的详细信息")
    @GetMapping("/{id}")
    public ApiResponse<WrongQuestion> getWrongQuestion(@PathVariable Long id) {
        return ApiResponse.success(wrongQuestionService.getWrongQuestionById(id));
    }

    /**
     * 更新错题
     */
    @Operation(summary = "更新错题", description = "更新错题信息（仅创建者可操作）")
    @PutMapping("/{id}")
    public ApiResponse<WrongQuestion> updateWrongQuestion(@PathVariable Long id,
                                                          @Valid @RequestBody CreateWrongQuestionRequest request,
                                                          HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        return ApiResponse.success("更新成功", wrongQuestionService.updateWrongQuestion(id, request, userId));
    }

    /**
     * 删除错题
     */
    @Operation(summary = "删除错题", description = "删除指定错题（仅创建者可操作）")
    @DeleteMapping("/{id}")
    public ApiResponse<Void> deleteWrongQuestion(@PathVariable Long id,
                                                 HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        wrongQuestionService.deleteWrongQuestion(id, userId);
        return ApiResponse.success();
    }

    /**
     * 批量导入错题
     */
    @Operation(summary = "批量导入错题", description = "批量导入多条错题记录")
    @PostMapping("/import")
    public ApiResponse<Integer> importWrongQuestions(@RequestBody List<CreateWrongQuestionRequest> requests,
                                                    HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        int count = wrongQuestionService.importWrongQuestions(userId, requests);
        return ApiResponse.success("成功导入" + count + "条错题", count);
    }
}
