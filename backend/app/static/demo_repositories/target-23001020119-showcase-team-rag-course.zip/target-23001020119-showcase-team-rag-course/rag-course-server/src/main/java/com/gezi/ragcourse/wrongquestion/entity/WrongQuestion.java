package com.gezi.ragcourse.wrongquestion.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 错题实体
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("wrong_question")
public class WrongQuestion {

    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 课程ID
     */
    private Long courseId;

    /**
     * 用户ID（学生）
     */
    private Long userId;

    /**
     * 错题标题
     */
    private String title;

    /**
     * 题目内容
     */
    private String questionContent;

    /**
     * 学生答案
     */
    private String studentAnswer;

    /**
     * 正确答案
     */
    private String correctAnswer;

    /**
     * 错误原因分析
     */
    private String errorReason;

    /**
     * 知识点标签（JSON数组格式）
     */
    private String knowledgeTags;

    /**
     * 教师点评
     */
    private String teacherComment;

    /**
     * 状态: PENDING(待复习) / REVIEWED(已复习) / MASTERED(已掌握)
     */
    @Builder.Default
    private String status = "PENDING";

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updatedAt;
}
