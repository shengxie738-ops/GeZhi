package com.gezi.ragcourse.rag.service;

import com.gezi.ragcourse.common.api.PageResult;
import com.gezi.ragcourse.rag.dto.CreateSessionRequest;
import com.gezi.ragcourse.rag.dto.FeedbackRequest;
import com.gezi.ragcourse.rag.dto.SessionDTO;

/**
 * 聊天会话服务接口
 */
public interface ChatService {

    /**
     * 获取会话列表（分页）
     */
    PageResult<SessionDTO> listSessions(Long userId, int page, int size);

    /**
     * 创建新会话
     */
    SessionDTO createSession(Long userId, CreateSessionRequest request);

    /**
     * 获取会话详情（含消息列表）
     */
    SessionDTO getSessionDetail(Long userId, Long sessionId);

    /**
     * 删除会话
     */
    void deleteSession(Long userId, Long sessionId);

    /**
     * 提交消息反馈
     */
    void submitFeedback(Long userId, Long messageId, FeedbackRequest request);
}
