package com.gezi.ragcourse.rag.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 向量搜索结果
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "向量搜索结果")
public class SearchResult {

    @Schema(description = "搜索结果列表")
    private List<SearchResultItem> items;

    @Schema(description = "搜索耗时(毫秒)")
    private Long searchTimeMs;

    @Schema(description = "总结果数")
    private Integer totalResults;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @Schema(description = "单条搜索结果")
    public static class SearchResultItem {
        @Schema(description = "chunk ID")
        private Long chunkId;

        @Schema(description = "内容")
        private String content;

        @Schema(description = "相似度分数")
        private Double score;

        @Schema(description = "来源文档ID")
        private Long documentId;

        @Schema(description = "来源文档标题")
        private String documentTitle;

        @Schema(description = "课程ID")
        private Long courseId;

        @Schema(description = "章节ID")
        private Long chapterId;
    }
}
