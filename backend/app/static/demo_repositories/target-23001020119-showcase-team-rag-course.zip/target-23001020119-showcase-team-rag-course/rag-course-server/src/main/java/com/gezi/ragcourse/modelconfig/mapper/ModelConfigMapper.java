package com.gezi.ragcourse.modelconfig.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gezi.ragcourse.modelconfig.entity.ModelConfig;
import org.apache.ibatis.annotations.Mapper;

/**
 * 模型配置Mapper接口
 */
@Mapper
public interface ModelConfigMapper extends BaseMapper<ModelConfig> {
}
