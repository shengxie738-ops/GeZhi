package com.gezi.ragcourse.modelconfig.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * 模型测试请求
 */
@Data
@Schema(description = "模型测试请求")
public class ModelTestRequest {

    @Schema(description = "模型配置ID（不传则使用当前活跃模型）")
    private Long modelConfigId;

    @NotBlank(message = "测试提示词不能为空")
    @Schema(description = "测试提示词", example = "你好，请用一句话介绍自己")
    private String prompt;
}
