package com.gezi.ragcourse.analytics.service;

import com.gezi.ragcourse.analytics.dto.*;

import java.util.List;

/**
 * 教学分析服务接口
 */
public interface AnalyticsService {

    /**
     * 获取课程概览数据
     */
    OverviewDTO getCourseOverview(Long courseId);

    /**
     * 获取热门问题列表
     */
    List<HotQuestionDTO> getHotQuestions(Long courseId, int limit);

    /**
     * 获取未解决问题列表
     */
    List<UnresolvedDTO> getUnresolvedQuestions(Long courseId);

    /**
     * 获取知识点缺口分析
     */
    List<KnowledgeGapDTO> getKnowledgeGaps(Long courseId);

    /**
     * 获取文档使用统计
     */
    List<DocumentUsageDTO> getDocumentUsage(Long courseId);

    /**
     * 获取模型使用统计
     */
    List<ModelUsageDTO> getModelUsage(Long courseId);
}
