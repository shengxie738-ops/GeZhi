package com.gezi.ragcourse.audit.service;

import com.gezi.ragcourse.common.api.PageResult;
import com.gezi.ragcourse.audit.entity.AuditLog;

/**
 * 审计服务接口
 */
public interface AuditService {

    /**
     * 获取审计日志列表（分页，支持按模块、操作类型、用户ID筛选）
     */
    PageResult<AuditLog> listAuditLogs(int page, int size, String module, String action, Long userId);
}
