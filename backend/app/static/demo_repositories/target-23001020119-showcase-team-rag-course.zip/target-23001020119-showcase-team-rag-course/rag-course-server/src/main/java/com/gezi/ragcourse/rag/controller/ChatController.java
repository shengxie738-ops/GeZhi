package com.gezi.ragcourse.rag.controller;

import com.gezi.ragcourse.common.api.ApiResponse;
import com.gezi.ragcourse.common.api.PageResult;
import com.gezi.ragcourse.rag.dto.CreateSessionRequest;
import com.gezi.ragcourse.rag.dto.FeedbackRequest;
import com.gezi.ragcourse.rag.dto.SessionDTO;
import com.gezi.ragcourse.rag.service.ChatService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * 聊天会话管理控制器
 */
@Tag(name = "聊天会话模块")
@RestController
@RequestMapping("/chat")
@RequiredArgsConstructor
public class ChatController {

    private final ChatService chatService;

    /**
     * 获取会话列表（按userId过滤，分页）
     */
    @Operation(summary = "会话列表", description = "分页获取当前用户的聊天会话列表")
    @ApiResponses({
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "查询成功")
    })
    @GetMapping("/sessions")
    public ApiResponse<PageResult<SessionDTO>> listSessions(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size,
            HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        return ApiResponse.success(chatService.listSessions(userId, page, size));
    }

    /**
     * 创建新会话
     */
    @Operation(summary = "创建会话", description = "创建新的聊天会话，需指定课程ID和可选标题")
    @ApiResponses({
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "创建成功")
    })
    @PostMapping("/sessions")
    public ApiResponse<SessionDTO> createSession(
            @Valid @RequestBody CreateSessionRequest request,
            HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        return ApiResponse.success("会话创建成功", chatService.createSession(userId, request));
    }

    /**
     * 获取会话详情（含消息列表）
     */
    @Operation(summary = "会话详情", description = "获取指定会话的详细信息及消息列表")
    @ApiResponses({
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "查询成功")
    })
    @GetMapping("/sessions/{id}")
    public ApiResponse<SessionDTO> getSessionDetail(
            @PathVariable Long id,
            HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        return ApiResponse.success(chatService.getSessionDetail(userId, id));
    }

    /**
     * 删除会话
     */
    @Operation(summary = "删除会话", description = "删除指定聊天会话（仅会话创建者可操作）")
    @ApiResponses({
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "删除成功")
    })
    @DeleteMapping("/sessions/{id}")
    public ApiResponse<Void> deleteSession(
            @PathVariable Long id,
            HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        chatService.deleteSession(userId, id);
        return ApiResponse.success("会话已删除");
    }

    /**
     * 消息反馈
     */
    @Operation(summary = "消息反馈", description = "对AI回答消息提交反馈（正面/负面/待解决）")
    @ApiResponses({
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "反馈提交成功")
    })
    @PostMapping("/messages/{id}/feedback")
    public ApiResponse<Void> submitFeedback(
            @PathVariable Long id,
            @Valid @RequestBody FeedbackRequest request,
            HttpServletRequest httpRequest) {
        Long userId = (Long) httpRequest.getAttribute("userId");
        chatService.submitFeedback(userId, id, request);
        return ApiResponse.success("反馈已提交");
    }
}
