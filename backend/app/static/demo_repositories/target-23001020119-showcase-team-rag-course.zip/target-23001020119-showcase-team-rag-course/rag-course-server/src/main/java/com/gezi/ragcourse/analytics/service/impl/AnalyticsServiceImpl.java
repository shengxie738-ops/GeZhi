package com.gezi.ragcourse.analytics.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.gezi.ragcourse.analytics.dto.*;
import com.gezi.ragcourse.analytics.service.AnalyticsService;
import com.gezi.ragcourse.course.entity.CourseChapter;
import com.gezi.ragcourse.course.mapper.CourseChapterMapper;
import com.gezi.ragcourse.course.mapper.CourseMemberMapper;
import com.gezi.ragcourse.document.entity.KnowledgeDocument;
import com.gezi.ragcourse.document.mapper.KnowledgeDocumentMapper;
import com.gezi.ragcourse.forum.entity.ForumQuestion;
import com.gezi.ragcourse.forum.mapper.ForumQuestionMapper;
import com.gezi.ragcourse.user.entity.SysUser;
import com.gezi.ragcourse.user.mapper.SysUserMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 教学分析服务实现
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AnalyticsServiceImpl implements AnalyticsService {

    private final ForumQuestionMapper questionMapper;
    private final CourseChapterMapper chapterMapper;
    private final CourseMemberMapper courseMemberMapper;
    private final KnowledgeDocumentMapper documentMapper;
    private final SysUserMapper userMapper;

    @Override
    public OverviewDTO getCourseOverview(Long courseId) {
        // 查询该课程下的问题总数
        LambdaQueryWrapper<ForumQuestion> questionWrapper = new LambdaQueryWrapper<>();
        questionWrapper.eq(ForumQuestion::getCourseId, courseId);
        Long totalQuestions = questionMapper.selectCount(questionWrapper);

        // 查询该课程的学生数量
        Long totalStudents = courseMemberMapper.selectCount(
                new LambdaQueryWrapper<com.gezi.ragcourse.course.entity.CourseMember>()
                        .eq(com.gezi.ragcourse.course.entity.CourseMember::getCourseId, courseId)
                        .eq(com.gezi.ragcourse.course.entity.CourseMember::getMemberRole, "STUDENT")
        );

        // 查询该课程下的文档总数
        Long totalDocuments = documentMapper.selectCount(
                new LambdaQueryWrapper<KnowledgeDocument>()
                        .eq(KnowledgeDocument::getCourseId, courseId)
        );

        return OverviewDTO.builder()
                .totalStudents(totalStudents)
                .totalDocuments(totalDocuments)
                .totalChunks(0L) // TODO: 统计知识片段总数
                .totalQuestions(totalQuestions)
                .totalChatSessions(0L) // TODO: 统计会话总数
                .activeStudentsToday(0L) // TODO: 统计今日活跃学生
                .avgResponseLatency(0L) // TODO: 需要消息时间戳来计算
                .avgAnswerQuality(0.0)
                .dailyStats(List.of())
                .build();
    }

    @Override
    public List<HotQuestionDTO> getHotQuestions(Long courseId, int limit) {
        // 查询浏览次数Top N的热门问题
        LambdaQueryWrapper<ForumQuestion> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ForumQuestion::getCourseId, courseId)
                .orderByDesc(ForumQuestion::getViewCount)
                .last("LIMIT " + limit);

        List<ForumQuestion> questions = questionMapper.selectList(wrapper);
        return questions.stream().map(q -> HotQuestionDTO.builder()
                .id(q.getId())
                .question(q.getTitle())
                .count(q.getViewCount())
                .avgScore(0.0) // TODO: 计算平均相似度
                .relatedDocuments(List.of())
                .build()
        ).toList();
    }

    @Override
    public List<UnresolvedDTO> getUnresolvedQuestions(Long courseId) {
        // 查询未解决的问题，按浏览次数倒序
        LambdaQueryWrapper<ForumQuestion> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ForumQuestion::getCourseId, courseId)
                .eq(ForumQuestion::getStatus, "OPEN")
                .orderByDesc(ForumQuestion::getViewCount);

        List<ForumQuestion> questions = questionMapper.selectList(wrapper);
        List<UnresolvedDTO> result = new ArrayList<>();

        for (ForumQuestion q : questions) {
            // 查询提问者姓名
            SysUser author = userMapper.selectById(q.getAuthorId());
            String authorName = author != null ? author.getRealName() : "未知";

            result.add(UnresolvedDTO.builder()
                    .id(q.getId())
                    .question(q.getTitle())
                    .askedBy(authorName)
                    .askedAt(q.getCreatedAt() != null ? q.getCreatedAt().toString() : "")
                    .answerCount(q.getAnswerCount())
                    .viewCount(q.getViewCount())
                    .priority("medium")
                    .build());
        }
        return result;
    }

    @Override
    public List<KnowledgeGapDTO> getKnowledgeGaps(Long courseId) {
        // 查询课程的所有章节
        LambdaQueryWrapper<CourseChapter> chapterWrapper = new LambdaQueryWrapper<>();
        chapterWrapper.eq(CourseChapter::getCourseId, courseId);
        List<CourseChapter> chapters = chapterMapper.selectList(chapterWrapper);

        // 查询课程下的所有问题，按章节分组统计
        LambdaQueryWrapper<ForumQuestion> questionWrapper = new LambdaQueryWrapper<>();
        questionWrapper.eq(ForumQuestion::getCourseId, courseId);
        List<ForumQuestion> allQuestions = questionMapper.selectList(questionWrapper);

        Map<Long, List<ForumQuestion>> questionsByChapter = allQuestions.stream()
                .filter(q -> q.getChapterId() != null)
                .collect(Collectors.groupingBy(ForumQuestion::getChapterId));

        List<KnowledgeGapDTO> gaps = new ArrayList<>();
        for (CourseChapter chapter : chapters) {
            List<ForumQuestion> chapterQuestions = questionsByChapter
                    .getOrDefault(chapter.getId(), List.of());
            long unresolvedCount = chapterQuestions.stream()
                    .filter(q -> "OPEN".equals(q.getStatus()))
                    .count();

            double gapScore = chapterQuestions.isEmpty() ? 0.0
                    : (unresolvedCount * 100.0 / chapterQuestions.size());

            gaps.add(KnowledgeGapDTO.builder()
                    .topic(chapter.getTitle())
                    .gapScore(Math.round(gapScore * 100.0) / 100.0)
                    .relatedQuestions(chapterQuestions.stream()
                            .map(ForumQuestion::getTitle).toList())
                    .relatedDocuments(List.of())
                    .suggestion(unresolvedCount > 0 ? "建议补充该章节知识点" : "")
                    .build());
        }
        return gaps;
    }

    @Override
    public List<DocumentUsageDTO> getDocumentUsage(Long courseId) {
        // 查询课程下的所有文档及其使用统计
        LambdaQueryWrapper<KnowledgeDocument> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(KnowledgeDocument::getCourseId, courseId);
        List<KnowledgeDocument> documents = documentMapper.selectList(wrapper);

        return documents.stream().map(doc -> DocumentUsageDTO.builder()
                .documentId(doc.getId())
                .documentTitle(doc.getTitle())
                .citationCount(doc.getChunkCount()) // TODO: 应替换为实际引用次数
                .avgRelevanceScore(0.0) // TODO: 计算平均相关性分数
                .build()
        ).toList();
    }

    @Override
    public List<ModelUsageDTO> getModelUsage(Long courseId) {
        // TODO: 实际应从模型调用日志表中统计每日查询次数、延迟和Token消耗
        // 目前返回模拟数据供前端联调
        List<ModelUsageDTO.DailyUsage> dailyUsageList = new ArrayList<>();
        for (int i = 6; i >= 0; i--) {
            LocalDate date = LocalDate.now().minusDays(i);
            dailyUsageList.add(ModelUsageDTO.DailyUsage.builder()
                    .date(date.toString())
                    .count(0)
                    .build());
        }

        return List.of(ModelUsageDTO.builder()
                .modelName("default")
                .totalCalls(0)
                .avgLatency(0L)
                .avgTokens(0L)
                .successRate(100.0)
                .dailyUsage(dailyUsageList)
                .build());
    }
}
