package com.gezi.ragcourse.analytics.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 课程概览DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "课程概览数据")
public class OverviewDTO {

    @Schema(description = "学生总数")
    private Long totalStudents;

    @Schema(description = "文档总数")
    private Long totalDocuments;

    @Schema(description = "知识片段总数")
    private Long totalChunks;

    @Schema(description = "问题总数")
    private Long totalQuestions;

    @Schema(description = "会话总数")
    private Long totalChatSessions;

    @Schema(description = "今日活跃学生数")
    private Long activeStudentsToday;

    @Schema(description = "平均响应延迟(毫秒)")
    private Long avgResponseLatency;

    @Schema(description = "平均回答质量分数")
    private Double avgAnswerQuality;

    @Schema(description = "每日统计列表")
    private List<DailyStat> dailyStats;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @Schema(description = "每日统计")
    public static class DailyStat {
        @Schema(description = "日期")
        private String date;
        @Schema(description = "问题数")
        private Integer questions;
        @Schema(description = "会话数")
        private Integer chatSessions;
        @Schema(description = "活跃用户数")
        private Integer activeUsers;
        @Schema(description = "平均延迟(毫秒)")
        private Integer avgLatency;
    }
}
