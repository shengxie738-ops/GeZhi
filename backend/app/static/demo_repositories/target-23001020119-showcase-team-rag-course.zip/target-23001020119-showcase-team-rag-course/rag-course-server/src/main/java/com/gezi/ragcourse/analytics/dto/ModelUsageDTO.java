package com.gezi.ragcourse.analytics.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 模型使用统计DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "模型使用统计")
public class ModelUsageDTO {

    @Schema(description = "模型名称")
    private String modelName;

    @Schema(description = "总调用次数")
    private Integer totalCalls;

    @Schema(description = "平均延迟(毫秒)")
    private Long avgLatency;

    @Schema(description = "平均Token消耗")
    private Long avgTokens;

    @Schema(description = "成功率(百分比)")
    private Double successRate;

    @Schema(description = "每日使用量")
    private List<DailyUsage> dailyUsage;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @Schema(description = "每日使用量")
    public static class DailyUsage {
        @Schema(description = "日期")
        private String date;
        @Schema(description = "调用次数")
        private Integer count;
    }
}
