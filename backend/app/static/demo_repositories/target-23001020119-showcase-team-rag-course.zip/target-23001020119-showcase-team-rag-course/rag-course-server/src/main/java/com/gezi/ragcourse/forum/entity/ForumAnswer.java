package com.gezi.ragcourse.forum.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 论坛回答实体
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("forum_answer")
public class ForumAnswer {

    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 所属问题ID
     */
    private Long questionId;

    /**
     * 作者用户ID
     */
    private Long authorId;

    /**
     * 回答内容
     */
    private String content;

    /**
     * 是否为教师回答
     */
    @Builder.Default
    private Boolean isTeacherAnswer = false;

    /**
     * 是否被采纳为最佳答案
     */
    @Builder.Default
    private Boolean isAccepted = false;

    /**
     * 是否经过教师认证
     */
    @Builder.Default
    private Boolean teacherVerified = false;

    /**
     * 点赞数
     */
    @Builder.Default
    private Integer likeCount = 0;

    /**
     * 是否已加入知识库
     */
    @Builder.Default
    private Boolean addedToKnowledge = false;

    /**
     * 逻辑删除
     */
    @TableLogic
    private Integer deleted;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updatedAt;
}
