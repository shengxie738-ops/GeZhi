package com.gezi.ragcourse.rag.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gezi.ragcourse.rag.entity.AnswerFeedback;
import org.apache.ibatis.annotations.Mapper;

/**
 * 回答反馈Mapper接口
 */
@Mapper
public interface AnswerFeedbackMapper extends BaseMapper<AnswerFeedback> {
}
