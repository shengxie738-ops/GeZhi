package com.gezi.ragcourse.document.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gezi.ragcourse.document.entity.IngestJob;
import org.apache.ibatis.annotations.Mapper;

/**
 * 文档解析任务Mapper接口
 */
@Mapper
public interface IngestJobMapper extends BaseMapper<IngestJob> {
}
