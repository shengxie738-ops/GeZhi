package com.gezi.ragcourse.common.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 回答状态枚举
 */
@Getter
@AllArgsConstructor
public enum AnswerStatus {

    ACCEPTED("ACCEPTED", "已采纳"),
    NOT_ACCEPTED("NOT_ACCEPTED", "未采纳"),
    VERIFIED("VERIFIED", "已验证"),
    NOT_VERIFIED("NOT_VERIFIED", "未验证"),
    ADDED_TO_KNOWLEDGE("ADDED_TO_KNOWLEDGE", "已加入知识库");

    @EnumValue
    @JsonValue
    private final String code;
    private final String description;
}
