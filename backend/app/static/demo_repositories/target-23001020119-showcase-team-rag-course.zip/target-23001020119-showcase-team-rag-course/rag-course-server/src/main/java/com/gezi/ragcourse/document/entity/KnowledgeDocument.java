package com.gezi.ragcourse.document.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.gezi.ragcourse.common.enums.DocumentType;
import com.gezi.ragcourse.common.enums.ParseStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 知识库文档实体
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("knowledge_document")
public class KnowledgeDocument {

    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 课程ID
     */
    private Long courseId;

    /**
     * 章节ID
     */
    private Long chapterId;

    /**
     * 文档标题
     */
    private String title;

    /**
     * 文档类型
     */
    private DocumentType docType;

    /**
     * 文件存储路径
     */
    private String filePath;

    /**
     * 文件大小(字节)
     */
    private Long fileSize;

    /**
     * 解析状态
     */
    @Builder.Default
    private ParseStatus parseStatus = ParseStatus.PENDING;

    /**
     * 上传用户ID
     */
    private Long uploadedBy;

    /**
     * chunk数量
     */
    @Builder.Default
    private Integer chunkCount = 0;

    /**
     * 逻辑删除
     */
    @TableLogic
    private Integer deleted;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updatedAt;
}
