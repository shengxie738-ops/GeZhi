package com.gezi.ragcourse.notification.service;

import com.gezi.ragcourse.common.api.PageResult;
import com.gezi.ragcourse.notification.entity.Notification;

/**
 * 通知服务接口
 */
public interface NotificationService {

    /**
     * 获取通知列表（分页）
     */
    PageResult<Notification> listNotifications(int page, int size, Long userId, Boolean unreadOnly);

    /**
     * 获取未读通知数量
     */
    long getUnreadCount(Long userId);

    /**
     * 标记单条通知为已读
     */
    void markAsRead(Long notificationId, Long userId);

    /**
     * 标记所有通知为已读
     */
    void markAllAsRead(Long userId);
}
