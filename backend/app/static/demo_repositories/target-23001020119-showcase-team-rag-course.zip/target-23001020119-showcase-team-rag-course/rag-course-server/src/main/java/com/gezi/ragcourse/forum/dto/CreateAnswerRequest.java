package com.gezi.ragcourse.forum.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * 创建回答请求
 */
@Data
@Schema(description = "创建回答请求")
public class CreateAnswerRequest {

    @NotBlank(message = "内容不能为空")
    @Schema(description = "回答内容")
    private String content;
}
