package com.gezi.ragcourse.forum.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gezi.ragcourse.forum.entity.ForumQuestion;
import org.apache.ibatis.annotations.Mapper;

/**
 * 论坛问题Mapper接口
 */
@Mapper
public interface ForumQuestionMapper extends BaseMapper<ForumQuestion> {
}
