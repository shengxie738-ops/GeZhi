package com.gezi.ragcourse.auth.service;

import com.gezi.ragcourse.auth.dto.LoginRequest;
import com.gezi.ragcourse.auth.dto.LoginResponse;
import com.gezi.ragcourse.auth.dto.RegisterRequest;
import com.gezi.ragcourse.auth.dto.UserDTO;

/**
 * 认证服务接口
 */
public interface AuthService {

    /**
     * 用户登录
     */
    LoginResponse login(LoginRequest request);

    /**
     * 用户注册
     */
    UserDTO register(RegisterRequest request);

    /**
     * 用户登出
     */
    void logout(String token);

    /**
     * 刷新令牌
     */
    LoginResponse refreshToken(String refreshToken);

    /**
     * 获取当前用户信息
     */
    UserDTO getCurrentUser(Long userId);
}
