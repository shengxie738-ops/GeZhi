package com.gezi.ragcourse.modelconfig.controller;

import com.gezi.ragcourse.common.api.ApiResponse;
import com.gezi.ragcourse.modelconfig.dto.CreateModelConfigRequest;
import com.gezi.ragcourse.modelconfig.dto.ModelTestRequest;
import com.gezi.ragcourse.modelconfig.dto.ModelTestResponse;
import com.gezi.ragcourse.modelconfig.entity.ModelConfig;
import com.gezi.ragcourse.modelconfig.entity.RagConfig;
import com.gezi.ragcourse.modelconfig.service.ModelConfigService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 模型配置控制器
 * 权限说明: 所有接口需要管理员角色
 */
@Tag(name = "模型配置模块")
@RestController
@RequestMapping("/admin/model-config")
@RequiredArgsConstructor
public class ModelConfigController {

    private final ModelConfigService modelConfigService;

    /**
     * 获取模型配置列表
     */
    @Operation(summary = "获取模型配置列表", description = "获取所有模型配置")
    @GetMapping
    public ApiResponse<List<ModelConfig>> listModelConfigs() {
        return ApiResponse.success(modelConfigService.listModelConfigs());
    }

    /**
     * 获取模型配置详情
     */
    @Operation(summary = "获取模型配置详情", description = "获取指定模型配置的详细信息")
    @GetMapping("/{id}")
    public ApiResponse<ModelConfig> getModelConfig(@PathVariable Long id) {
        return ApiResponse.success(modelConfigService.getModelConfigById(id));
    }

    /**
     * 创建模型配置
     */
    @Operation(summary = "创建模型配置", description = "新增一个模型配置")
    @PostMapping
    public ApiResponse<ModelConfig> createModelConfig(@Valid @RequestBody CreateModelConfigRequest request) {
        return ApiResponse.success("创建成功", modelConfigService.createModelConfig(request));
    }

    /**
     * 更新模型配置
     */
    @Operation(summary = "更新模型配置", description = "更新指定模型配置")
    @PutMapping("/{id}")
    public ApiResponse<ModelConfig> updateModelConfig(@PathVariable Long id,
                                                     @Valid @RequestBody CreateModelConfigRequest request) {
        return ApiResponse.success("更新成功", modelConfigService.updateModelConfig(id, request));
    }

    /**
     * 删除模型配置
     */
    @Operation(summary = "删除模型配置", description = "删除指定模型配置")
    @DeleteMapping("/{id}")
    public ApiResponse<Void> deleteModelConfig(@PathVariable Long id) {
        modelConfigService.deleteModelConfig(id);
        return ApiResponse.success();
    }

    /**
     * 设置活跃模型
     */
    @Operation(summary = "设置活跃模型", description = "将指定模型设置为当前活跃模型")
    @PostMapping("/{id}/set-active")
    public ApiResponse<Void> setActiveModel(@PathVariable Long id) {
        modelConfigService.setActiveModel(id);
        return ApiResponse.success("已切换活跃模型");
    }

    /**
     * 测试模型连接
     */
    @Operation(summary = "测试模型连接", description = "测试模型API连通性和响应")
    @PostMapping("/test")
    public ApiResponse<ModelTestResponse> testModel(@Valid @RequestBody ModelTestRequest request) {
        return ApiResponse.success(modelConfigService.testModel(request));
    }

    /**
     * 获取RAG配置
     */
    @Operation(summary = "获取RAG配置", description = "获取指定课程或全局的RAG检索配置")
    @GetMapping("/rag")
    public ApiResponse<RagConfig> getRagConfig(@RequestParam(required = false) Long courseId) {
        return ApiResponse.success(modelConfigService.getRagConfig(courseId));
    }

    /**
     * 保存RAG配置
     */
    @Operation(summary = "保存RAG配置", description = "保存或更新RAG检索配置")
    @PostMapping("/rag")
    public ApiResponse<RagConfig> saveRagConfig(@RequestParam(required = false) Long courseId,
                                                @RequestBody RagConfig ragConfig) {
        return ApiResponse.success("保存成功", modelConfigService.saveRagConfig(courseId, ragConfig));
    }
}
