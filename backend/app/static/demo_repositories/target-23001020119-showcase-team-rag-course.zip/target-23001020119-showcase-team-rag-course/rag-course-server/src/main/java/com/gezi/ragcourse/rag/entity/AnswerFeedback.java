package com.gezi.ragcourse.rag.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 回答反馈实体
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("answer_feedback")
public class AnswerFeedback {

    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 消息ID
     */
    private Long messageId;

    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 反馈类型: HELPFUL(有帮助), NOT_HELPFUL(无帮助), INCORRECT(不正确)
     */
    private String feedbackType;

    /**
     * 反馈内容
     */
    private String content;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;
}
