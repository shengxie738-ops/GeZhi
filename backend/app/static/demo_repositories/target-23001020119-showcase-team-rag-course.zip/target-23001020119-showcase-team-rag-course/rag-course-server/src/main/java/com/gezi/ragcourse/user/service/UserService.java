package com.gezi.ragcourse.user.service;

import com.gezi.ragcourse.auth.dto.UserDTO;
import com.gezi.ragcourse.common.api.PageResult;
import com.gezi.ragcourse.user.dto.UpdateUserRequest;

/**
 * 用户服务接口
 */
public interface UserService {

    /**
     * 获取用户信息
     */
    UserDTO getUserById(Long id);

    /**
     * 更新用户信息
     */
    UserDTO updateUser(Long id, UpdateUserRequest request);

    /**
     * 获取用户列表（分页）
     */
    PageResult<UserDTO> listUsers(int page, int size, String keyword);

    /**
     * 删除用户
     */
    void deleteUser(Long id);

    /**
     * 启用/禁用用户
     */
    void toggleUserStatus(Long id);
}
