package com.gezi.ragcourse.course.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gezi.ragcourse.course.entity.CourseChapter;
import org.apache.ibatis.annotations.Mapper;

/**
 * 课程章节Mapper接口
 */
@Mapper
public interface CourseChapterMapper extends BaseMapper<CourseChapter> {
}
