
# RAG Course — 人工智能技术基础 RAG 教学系统

&gt; 面向高校人工智能课程的检索增强生成（RAG）教学平台。系统将课程 PDF 课件、实验文档、论坛问答和错题分析接入轻量级 RAG 系统，帮助学生快速找到已有解法，同时为教师提供知识库维护、问答审核和学习分析能力。

---

## 目录

1. [项目概述](#项目概述)
2. [技术栈](#技术栈)
3. [架构设计](#架构设计)
4. [核心功能](#核心功能)
5. [快速启动](#快速启动)
6. [本地开发](#本地开发)
7. [部署指南](#部署指南)
8. [API 文档](#api-文档)
9. [常见问题](#常见问题)
10. [已修复问题](#已修复问题)
11. [License](#license)

---

## 项目概述

RAG Course 是一个专为高校人工智能课程设计的检索增强生成教学平台，具备以下核心特点：

- **智能问答**：基于课程知识库的 RAG 问答系统，帮助学生快速找到问题答案
- **知识管理**：支持 PDF、DOCX、Markdown 等多种格式文档的智能解析
- **论坛互动**：集成论坛问答功能，支持师生互动
- **错题记录**：学生错题管理与分析
- **教学分析**：为教师提供全面的学习数据分析

---

## 技术栈

| 层级 | 技术 |
|------|------|
| **前端** | Vue 3 + TypeScript + Vite + Element Plus + Pinia + ECharts |
| **后端** | Java 21 + Spring Boot 3.4 + Spring Security + MyBatis-Plus |
| **RAG 服务** | Python 3.12 + FastAPI + Qdrant + jieba + sentence-transformers |
| **基础设施** | Docker Compose + MySQL 8 + Redis 7 + Qdrant + MinIO |

---

## 架构设计

### 系统架构图

```mermaid
flowchart TB
    subgraph Client[客户端]
        W[Vue 3 SPA]
    end
    subgraph Gateway[网关层]
        N[Nginx 反向代理]
    end
    subgraph Backend[后端服务]
        B[Spring Boot 主后端 :8080]
        R[FastAPI RAG 服务 :8000]
    end
    subgraph Storage[存储层]
        M[(MySQL 8)]
        RE[(Redis 7)]
        O[(MinIO)]
        Q[(Qdrant)]
    end
    subgraph External[外部服务]
        LLM[通义千问 / OpenAI 兼容 API]
    end

    W --&gt;|HTTP / SSE| N
    N --&gt;|/api/*| B
    B --&gt;|Internal API| R
    B --&gt; M
    B --&gt; RE
    B --&gt; O
    R --&gt; M
    R --&gt; Q
    R --&gt; LLM
```

### 后端类图

```mermaid
classDiagram
    %% 基础类
    class RagCourseApplication {
        +main(String[] args)
    }
    
    %% 控制器层
    class AuthController
    class CourseController
    class DocumentController
    class RagController
    class ChatController
    class ForumController
    class StorageController
    class AnalyticsController
    class FavoriteController
    class ModelConfigController
    class NotificationController
    class AuditController
    class UserController
    class WrongQuestionController
    class JobController

    %% 服务层
    class AuthService
    class CourseService
    class DocumentService
    class RagService
    class ChatService
    class ForumService
    class StorageService
    class AnalyticsService
    class FavoriteService
    class ModelConfigService
    class NotificationService
    class AuditService
    class UserService
    class JobService

    %% Mapper层
    class SysUserMapper
    class CourseMapper
    class CourseMemberMapper
    class CourseChapterMapper
    class KnowledgeDocumentMapper
    class KnowledgeChunkMapper
    class IngestJobMapper
    class ChatSessionMapper
    class ChatMessageMapper
    class MessageCitationMapper
    class AnswerFeedbackMapper
    class ForumQuestionMapper
    class ForumAnswerMapper
    class WrongQuestionMapper
    class FavoriteMapper
    class ModelConfigMapper
    class RagConfigMapper
    class NotificationMapper
    class AuditLogMapper

    %% 实体层
    class SysUser
    class Course
    class CourseMember
    class CourseChapter
    class KnowledgeDocument
    class KnowledgeChunk
    class IngestJob
    class ChatSession
    class ChatMessage
    class MessageCitation
    class AnswerFeedback
    class ForumQuestion
    class ForumAnswer
    class WrongQuestion
    class Favorite
    class ModelConfig
    class RagConfig
    class Notification
    class AuditLog

    %% 通用组件
    class ApiResponse~T~
    class JwtAuthenticationFilter
    class JwtUtil
    class GlobalExceptionHandler
    class BusinessException

    %% 枚举
    class Role
    class DocumentType
    class ParseStatus
    class ForumStatus
    class AnswerStatus
    class SourceType

    %% 配置类
    class SecurityConfig
    class CorsConfig
    class MyBatisPlusConfig
    class RedisConfig
    class MinioConfig
    class SwaggerConfig

    %% 关系
    RagCourseApplication --&gt; AuthController
    RagCourseApplication --&gt; CourseController
    RagCourseApplication --&gt; DocumentController
    RagCourseApplication --&gt; RagController
    RagCourseApplication --&gt; ChatController
    RagCourseApplication --&gt; ForumController
    RagCourseApplication --&gt; StorageController
    RagCourseApplication --&gt; AnalyticsController
    RagCourseApplication --&gt; FavoriteController
    RagCourseApplication --&gt; ModelConfigController
    RagCourseApplication --&gt; NotificationController
    RagCourseApplication --&gt; AuditController
    RagCourseApplication --&gt; UserController
    RagCourseApplication --&gt; WrongQuestionController
    RagCourseApplication --&gt; JobController

    AuthController --&gt; AuthService
    CourseController --&gt; CourseService
    DocumentController --&gt; DocumentService
    RagController --&gt; RagService
    ChatController --&gt; ChatService
    ForumController --&gt; ForumService
    StorageController --&gt; StorageService
    AnalyticsController --&gt; AnalyticsService
    FavoriteController --&gt; FavoriteService
    ModelConfigController --&gt; ModelConfigService
    NotificationController --&gt; NotificationService
    AuditController --&gt; AuditService
    UserController --&gt; UserService
    JobController --&gt; JobService

    AuthService --&gt; SysUserMapper
    CourseService --&gt; CourseMapper
    CourseService --&gt; CourseMemberMapper
    CourseService --&gt; CourseChapterMapper
    DocumentService --&gt; KnowledgeDocumentMapper
    DocumentService --&gt; KnowledgeChunkMapper
    DocumentService --&gt; IngestJobMapper
    RagService --&gt; KnowledgeChunkMapper
    ChatService --&gt; ChatSessionMapper
    ChatService --&gt; ChatMessageMapper
    ChatService --&gt; MessageCitationMapper
    ChatService --&gt; AnswerFeedbackMapper
    ForumService --&gt; ForumQuestionMapper
    ForumService --&gt; ForumAnswerMapper
    FavoriteService --&gt; FavoriteMapper
    ModelConfigService --&gt; ModelConfigMapper
    ModelConfigService --&gt; RagConfigMapper
    NotificationService --&gt; NotificationMapper
    AuditService --&gt; AuditLogMapper
    UserService --&gt; SysUserMapper

    SysUserMapper --&gt; SysUser
    CourseMapper --&gt; Course
    CourseMemberMapper --&gt; CourseMember
    CourseChapterMapper --&gt; CourseChapter
    KnowledgeDocumentMapper --&gt; KnowledgeDocument
    KnowledgeChunkMapper --&gt; KnowledgeChunk
    IngestJobMapper --&gt; IngestJob
    ChatSessionMapper --&gt; ChatSession
    ChatMessageMapper --&gt; ChatMessage
    MessageCitationMapper --&gt; MessageCitation
    AnswerFeedbackMapper --&gt; AnswerFeedback
    ForumQuestionMapper --&gt; ForumQuestion
    ForumAnswerMapper --&gt; ForumAnswer
    WrongQuestionMapper --&gt; WrongQuestion
    FavoriteMapper --&gt; Favorite
    ModelConfigMapper --&gt; ModelConfig
    RagConfigMapper --&gt; RagConfig
    NotificationMapper --&gt; Notification
    AuditLogMapper --&gt; AuditLog

    SecurityConfig --&gt; JwtAuthenticationFilter
    JwtAuthenticationFilter --&gt; JwtUtil
    GlobalExceptionHandler --&gt; BusinessException
```

### RAG 服务类图

```mermaid
classDiagram
    %% FastAPI 应用
    class FastAPI {
        +app: FastAPI
    }
    
    %% API 路由
    class Router {
        +api_router
    }
    
    %% API 端点
    class HealthRouter
    class IngestRouter
    class RetrieveRouter
    class GenerateRouter
    
    %% 核心模块
    class Settings {
        +app_env: str
        +mock_mode: bool
        +qdrant_url: str
        +embedding_provider: str
        +chat_provider: str
    }
    
    %% 文档解析
    class BaseParser
    class PDFParser
    class DOCXParser
    class MarkdownParser
    class TextParser
    class ParserFactory
    
    %% 文本切分
    class BaseChunker
    class OverlapChunker
    class SemanticChunker
    class ChunkerFactory
    
    %% 向量化
    class BaseEmbedding
    class LocalEmbedding
    class OpenAIEmbedding
    class QwenEmbedding
    class EmbeddingFactory
    
    %% 检索
    class BM25Retriever
    class VectorRetriever
    class HybridRetriever
    class Reranker
    
    %% 答案生成
    class AnswerGenerator
    class PromptBuilder
    class CitationBuilder
    
    %% 向量存储
    class VectorStore
    class QdrantStore
    class MockStore
    
    %% 数据库
    class MySQLClient
    class MockClient
    
    %% 工作器
    class IngestWorker
    class ReindexWorker
    
    %% 关系
    FastAPI --&gt; Router
    Router --&gt; HealthRouter
    Router --&gt; IngestRouter
    Router --&gt; RetrieveRouter
    Router --&gt; GenerateRouter
    
    IngestRouter --&gt; IngestWorker
    IngestWorker --&gt; ParserFactory
    IngestWorker --&gt; ChunkerFactory
    IngestWorker --&gt; EmbeddingFactory
    IngestWorker --&gt; VectorStore
    
    RetrieveRouter --&gt; HybridRetriever
    HybridRetriever --&gt; BM25Retriever
    HybridRetriever --&gt; VectorRetriever
    HybridRetriever --&gt; Reranker
    
    GenerateRouter --&gt; AnswerGenerator
    AnswerGenerator --&gt; PromptBuilder
    AnswerGenerator --&gt; CitationBuilder
    
    ParserFactory ..|&gt; BaseParser
    PDFParser --|&gt; BaseParser
    DOCXParser --|&gt; BaseParser
    MarkdownParser --|&gt; BaseParser
    TextParser --|&gt; BaseParser
    
    ChunkerFactory ..|&gt; BaseChunker
    OverlapChunker --|&gt; BaseChunker
    SemanticChunker --|&gt; BaseChunker
    
    EmbeddingFactory ..|&gt; BaseEmbedding
    LocalEmbedding --|&gt; BaseEmbedding
    OpenAIEmbedding --|&gt; BaseEmbedding
    QwenEmbedding --|&gt; BaseEmbedding
    
    VectorStore ..|&gt; QdrantStore
    VectorStore ..|&gt; MockStore
    
    MySQLClient --|&gt; BaseClient
    MockClient --|&gt; BaseClient
```

### ER 关系图

```mermaid
erDiagram
    sys_user ||--o{ course : "创建"
    sys_user ||--o{ course_member : "加入"
    course ||--o{ course_member : "成员"
    course ||--o{ knowledge_document : "文档"
    course ||--o{ forum_question : "问题"
    course ||--o{ chat_session : "会话"
    course ||--o{ wrong_question : "错题"
    course ||--o| rag_config : "配置"
    knowledge_document ||--o{ knowledge_chunk : "知识块"
    knowledge_document ||--o{ ingest_job : "解析任务"
    forum_question ||--o{ forum_answer : "回答"
    chat_session ||--o{ chat_message : "消息"
    chat_message ||--o{ message_citation : "引用"
    chat_message ||--o| answer_feedback : "反馈"
```

---

## 核心功能

### 1. 用户认证与授权
- JWT Token 认证
- 多角色权限控制（学生/教师/管理员）
- 密码安全存储（BCrypt）

### 2. 课程管理
- 课程创建与管理
- 邀请码加入课程
- 课程成员管理

### 3. 知识库
- 文档上传与存储（PDF/DOCX/MD/TXT）
- 智能文档解析
- 文本切分与向量化
- 知识块管理

### 4. RAG 问答
- 混合检索（BM25 + 向量）
- 答案生成（支持 SSE 流式）
- 引用标注
- 反馈机制

### 5. 论坛
- 问题发布与回答
- 最佳答案选择
- 教师认证回答
- 点赞功能

### 6. 错题本
- 错题记录与管理
- 错题分类与分析

### 7. 教学分析
- 热门问题
- 未解决问题
- 知识缺口分析
- 文档使用统计
- 模型使用统计

### 8. 系统管理
- 模型配置
- 审计日志
- 通知管理
- 收藏管理

---

## 快速启动

### 前置要求

- Docker
- Docker Compose

### 启动步骤

```bash
# 1. 克隆项目
git clone &lt;repository-url&gt;
cd rag-course

# 2. 配置环境变量
cp .env.example .env
# 编辑 .env，设置 MODEL_API_KEY 等必填项

# 3. 一键启动所有服务
docker compose up -d --build
```

启动后访问：
- 前端：`http://localhost`
- 后端 API：`http://localhost:8080/api`
- RAG 服务：`http://localhost:8000`
- Swagger 文档：`http://localhost:8080/api/swagger-ui.html`

---

## 本地开发

### 前端开发

```bash
cd rag-course-web
npm install
npm run dev
```

### 后端开发

```bash
cd rag-course-server
mvn spring-boot:run -Dspring-boot.run.profiles=dev
```

### RAG 服务开发

```bash
cd rag-course-rag-service
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --port 8000
```

### 演示账号

| 角色 | 用户名 | 密码 | 主要功能 |
|------|--------|------|---------|
| 教师 | `teacher` | `Teacher@123` | 创建课程、上传文档、管理知识库、查看分析 |
| 学生 | `23001020119` | `Student@123` | 加入课程、提问问答、管理错题、收藏 |
| 管理员 | `admin` | `Admin@123` | 用户管理、模型配置、系统监控 |

---

## 部署指南

### 服务清单

| 服务 | 端口 | 说明 |
|------|------|------|
| nginx | 80, 443 | 反向代理和静态资源 |
| backend | 8080 | Spring Boot 主后端 |
| rag-service | 8000 | FastAPI RAG 服务 |
| mysql | 3306 | MySQL 8 关系型数据库 |
| redis | 6379 | Redis 7 缓存 |
| qdrant | 6333 | Qdrant 向量数据库 |
| minio | 9000, 9001 | MinIO 对象存储 |

### 环境变量（关键项）

| 变量 | 说明 | 生产要求 |
|------|------|---------|
| `JWT_SECRET` | JWT 签名密钥 | 替换为 256 位以上随机值 |
| `MODEL_API_KEY` | LLM API Key | 必须设置 |
| `MINIO_ACCESS_KEY/SECRET_KEY` | MinIO 凭证 | 替换默认 minioadmin |
| `RAG_INTERNAL_TOKEN` | 内部 API Token | 替换为强随机值 |
| `MYSQL_ROOT_PASSWORD` | MySQL root 密码 | 必须设置 |
| `EMBEDDING_PROVIDER/MODEL` | Embedding 模型 | 根据需求选择 |

### 数据持久化

通过 Docker Named Volumes 持久化：
- MySQL（`/var/lib/mysql`）
- Redis（`/data`）
- MinIO（`/data`）
- Qdrant（`/qdrant/storage`）

### 备份策略

| 数据 | 频率 | 保留 | 方式 |
|------|------|------|------|
| MySQL | 每日 02:00 | 30 天 | mysqldump |
| MinIO | 每周日 03:00 | 90 天 | mc mirror |
| Qdrant | 每日 03:00 | 7 天 | API snapshot |

---

## API 文档

详细的 API 文档参见 `docs/api.md`，包括：

- 认证模块（5 个）
- 课程模块（7 个）
- 文档模块（9 个）
- RAG 问答模块（7 个）
- 论坛模块（10 个）
- 错题模块（6 个）
- 教师分析模块（6 个）
- 模型配置模块（7 个）
- 通知模块（4 个）

Swagger UI 文档地址：`http://localhost:8080/api/swagger-ui.html`

---

## 常见问题

- **前端空白页**：检查 `.env.development` 中 `VITE_API_BASE_URL` 是否指向后端

- **文档一直"解析中"：确认 RAG 服务已启动，检查日志；开发环境默认 `MOCK_MODE=true`

- **Docker MySQL 连接失败**：检查 `docker-compose.yml` 中 MySQL 服务状态

- **切换 Embedding 模型**：修改 RAG 服务 `.env`，重建索引；注意向量维度需匹配

---

## 已修复问题

- **前端类型错误**：修复了 Vue/TypeScript 文件中的类型错误和导入路径问题，对齐了前端 API 层与后端 Controller 的请求路径

- **后端权限校验**：RagController 的 search 接口补充了 userId 提取，确保与 ask 接口行为一致；AuthController logout 方法增加 token 空值防御

- **API 密钥安全**：CORS 配置改为通过 `cors.allowed-origins` 配置项动态设置，生产环境可限制为实际域名，避免开放所有来源

- **RESTful 规范**：FavoriteController DELETE 接口从 `@RequestParam` 改为 `@PathVariable`，符合 REST 路径语义

- **代码质量**：清理了 JobService 中未使用的 import

---

## License

MIT License

