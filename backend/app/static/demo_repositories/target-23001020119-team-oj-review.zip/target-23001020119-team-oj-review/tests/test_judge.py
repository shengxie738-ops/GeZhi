from backend.judge import judge

def test_judge_accepts_exact_output():
    assert judge('42', '42')['accepted']
