export const title = 'OJ Review Platform';
