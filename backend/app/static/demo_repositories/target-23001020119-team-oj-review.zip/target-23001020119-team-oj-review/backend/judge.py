def judge(answer, expected):
    return {'accepted': answer.strip() == expected.strip()}
