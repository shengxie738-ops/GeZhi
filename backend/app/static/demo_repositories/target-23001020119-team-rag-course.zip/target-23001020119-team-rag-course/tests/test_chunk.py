from retrieval.chunk import chunk

def test_chunk_splits_text():
    assert chunk('abcdef', 2) == ['ab', 'cd', 'ef']
