def search(query, docs):
    return [doc for doc in docs if query in doc]
