def chunk(text, size=180):
    return [text[i:i+size] for i in range(0, len(text), size)]
