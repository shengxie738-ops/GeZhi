export function renderAnswer(answer: string) { return `引用来源：${answer}`; }
