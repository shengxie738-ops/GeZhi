from app.graph import shortest_path

def test_shortest_path():
    assert shortest_path({'A': [('B', 2)]}, 'A', 'B')['distance'] == 2
