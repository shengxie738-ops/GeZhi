import heapq

def shortest_path(edges, start, target):
    heap = [(0, start, [start])]
    seen = set()
    while heap:
        cost, node, path = heapq.heappop(heap)
        if node == target:
            return {'distance': cost, 'path': path}
        if node in seen:
            continue
        seen.add(node)
        for nxt, weight in edges.get(node, []):
            heapq.heappush(heap, (cost + weight, nxt, path + [nxt]))
    return {'distance': -1, 'path': []}
