from graph import shortest_path

edges = {'A': [('B', 4), ('C', 2)], 'C': [('B', 1), ('D', 7)], 'B': [('D', 3)]}
print(shortest_path(edges, 'A', 'D'))
