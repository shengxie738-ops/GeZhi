package edu.demo;

class BookingServiceTest {
  void rejectsOverlap() {
    assert !new BookingService().canBook(10, 9);
  }
}
