package edu.demo;

public class Application {
  public static void main(String[] args) {
    System.out.println("Lab booking API demo");
  }
}
