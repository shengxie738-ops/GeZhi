package edu.demo;

public class BookingService {
  public boolean canBook(int existingEnd, int newStart) {
    return existingEnd <= newStart;
  }
}
