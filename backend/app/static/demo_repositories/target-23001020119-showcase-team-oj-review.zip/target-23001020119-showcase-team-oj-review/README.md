# OJ Review - 在线评测与教学复盘系统

面向大学生的简化版 Online Judge 系统，集在线评测、团队协作、教师复盘于一体。

## 项目简介

OJ Review 是一个教学导向的在线编程评测平台，帮助教师组织编程实训课程，学生在线提交代码并获得即时反馈。系统支持 Java、Python、C++ 三种语言，通过 Docker 容器隔离执行用户代码，保障安全性。

### 核心功能

- **在线评测**: 支持多语言代码提交，自动判题，实时反馈
- **课程管理**: 章节式题目组织，成员管理
- **团队协作**: 学生分组，团队排行榜
- **教师复盘**: 针对提交、题目、团队的评语与分析
- **错题本**: 自动收录错误提交，支持笔记和掌握标记
- **数据分析**: 课程、学生、题目多维度统计

## 系统架构

### 整体架构图

```mermaid
graph TB
    subgraph "前端层"
        A[Vue 3 前端应用]
    end
    
    subgraph "网关层"
        B[Nginx 反向代理]
    end
    
    subgraph "服务层"
        C[Spring Boot 后端服务]
        D[FastAPI 判题服务]
    end
    
    subgraph "数据层"
        E[MySQL 数据库]
        F[Redis 缓存/队列]
    end
    
    subgraph "执行层"
        G[Docker 容器沙箱]
    end
    
    A --> B
    B --> C
    B --> D
    C --> E
    C --> F
    D --> F
    D --> G
```

### 核心类图

#### 1. 用户与权限模块

```mermaid
classDiagram
    class SysUser {
        +Long id
        +String username
        +String password
        +String realName
        +String email
        +String phone
        +String avatar
        +String role
        +String studentId
        +Integer status
        +Integer deleted
        +LocalDateTime createTime
        +LocalDateTime updateTime
    }
    
    class UserRole {
        <<enumeration>>
        ADMIN
        TEACHER
        STUDENT
    }
    
    class UserService {
        <<interface>>
        +getByUsername(String username) SysUser
        +createUser(UserCreateDTO dto) SysUser
        +updateUser(Long userId, UserUpdateDTO dto) void
        +listUsers(int page, int size, String role, String keyword) PageResult~SysUser~
        +getUserById(Long userId) SysUser
        +existsByUsername(String username) boolean
        +existsByEmail(String email) boolean
    }
    
    class AuthService {
        <<interface>>
        +login(LoginDTO dto) LoginVO
        +register(RegisterDTO dto) UserVO
        +refreshToken(RefreshTokenDTO dto) LoginVO
    }
    
    SysUser --> UserRole : role
    UserService --> SysUser : manages
    AuthService --> UserService : uses
```

#### 2. 课程与章节模块

```mermaid
classDiagram
    class Course {
        +Long id
        +String name
        +String description
        +String coverImage
        +Long creatorId
        +String status
        +String term
        +Integer deleted
        +LocalDateTime createTime
        +LocalDateTime updateTime
    }
    
    class CourseChapter {
        +Long id
        +Long courseId
        +String title
        +String description
        +Integer sortOrder
        +Integer deleted
        +LocalDateTime createTime
        +LocalDateTime updateTime
    }
    
    class CourseMember {
        +Long id
        +Long courseId
        +Long userId
        +String role
        +LocalDateTime joinTime
    }
    
    class CourseStatus {
        <<enumeration>>
        DRAFT
        ACTIVE
        ARCHIVED
    }
    
    class CourseService {
        <<interface>>
        +createCourse(CourseCreateDTO dto, Long creatorId) Course
        +updateCourse(Long courseId, CourseUpdateDTO dto) void
        +deleteCourse(Long courseId) void
        +getCourseById(Long courseId) Course
        +listCourses(int page, int size, String keyword) PageResult~Course~
    }
    
    class ChapterService {
        <<interface>>
        +createChapter(ChapterCreateDTO dto) CourseChapter
        +updateChapter(Long chapterId, ChapterCreateDTO dto) void
        +deleteChapter(Long chapterId) void
        +listChapters(Long courseId) List~CourseChapter~
    }
    
    Course --> CourseStatus : status
    Course --> CourseChapter : has
    Course --> CourseMember : has
    CourseService --> Course : manages
    ChapterService --> CourseChapter : manages
```

#### 3. 题目与测试用例模块

```mermaid
classDiagram
    class Problem {
        +Long id
        +String title
        +String description
        +String inputDesc
        +String outputDesc
        +String sampleInput
        +String sampleOutput
        +String hint
        +String difficulty
        +Long timeLimit
        +Long memoryLimit
        +Long creatorId
        +Long chapterId
        +String tags
        +Integer submitCount
        +Integer acceptedCount
        +Integer status
        +Integer deleted
        +LocalDateTime createTime
        +LocalDateTime updateTime
    }
    
    class ProblemTestCase {
        +Long id
        +Long problemId
        +String inputData
        +String expectedOutput
        +Integer sortOrder
        +Integer isHidden
        +LocalDateTime createTime
    }
    
    class Difficulty {
        <<enumeration>>
        EASY
        MEDIUM
        HARD
    }
    
    class ProblemService {
        <<interface>>
        +createProblem(ProblemCreateDTO dto, Long creatorId) Problem
        +updateProblem(Long problemId, ProblemUpdateDTO dto) void
        +deleteProblem(Long problemId) void
        +getProblemById(Long problemId) Problem
        +listProblems(ProblemQueryDTO queryDTO) PageResult~Problem~
    }
    
    class TestCaseService {
        <<interface>>
        +createTestCase(ProblemTestCase testCase) ProblemTestCase
        +updateTestCase(Long testCaseId, ProblemTestCase testCase) void
        +deleteTestCase(Long testCaseId) void
        +listTestCases(Long problemId) List~ProblemTestCase~
    }
    
    Problem --> Difficulty : difficulty
    Problem --> ProblemTestCase : has
    ProblemService --> Problem : manages
    TestCaseService --> ProblemTestCase : manages
```

#### 4. 提交与判题模块

```mermaid
classDiagram
    class Submission {
        +Long id
        +Long userId
        +Long problemId
        +Long courseId
        +String language
        +String code
        +String status
        +Long timeUsed
        +Long memoryUsed
        +Integer testCasesPassed
        +Integer testCasesTotal
        +String compileOutput
        +LocalDateTime createTime
    }
    
    class SubmissionCaseResult {
        +Long id
        +Long submissionId
        +Long testCaseId
        +String status
        +Long timeUsed
        +Long memoryUsed
        +String actualOutput
        +String errorMessage
        +LocalDateTime createTime
    }
    
    class CodeDraft {
        +Long id
        +Long userId
        +Long problemId
        +String code
        +String language
        +LocalDateTime updateTime
    }
    
    class SubmissionStatus {
        <<enumeration>>
        PENDING
        JUDGING
        ACCEPTED
        WRONG_ANSWER
        TIME_LIMIT_EXCEEDED
        MEMORY_LIMIT_EXCEEDED
        RUNTIME_ERROR
        COMPILE_ERROR
        SYSTEM_ERROR
    }
    
    class SubmissionService {
        <<interface>>
        +submitCode(SubmitCodeDTO dto, Long userId) Submission
        +listSubmissions(SubmissionQueryDTO queryDTO, Long userId) PageResult~Submission~
        +getSubmissionById(Long submissionId) Submission
        +updateSubmissionStatus(Long submissionId, String status, Long timeUsed, Long memoryUsed, Integer passed, Integer total, String compileOutput) void
    }
    
    class JudgeService {
        <<interface>>
        +submitToJudge(Submission submission) void
        +handleJudgeCallback(JudgeCallbackDTO dto) void
    }
    
    Submission --> SubmissionStatus : status
    Submission --> SubmissionCaseResult : has
    SubmissionService --> Submission : manages
    JudgeService --> Submission : updates
```

#### 5. 判题服务模块

```mermaid
classDiagram
    class JudgeDispatcher {
        -Semaphore semaphore
        -int running_count
        -Runner runner
        -Redis redis_client
        -bool _running
        -dict _handlers
        +start() void
        +stop() void
        +poll_from_queue() JudgeTask
        +process_task(JudgeTask task) void
    }
    
    class JudgeWorker {
        -JudgeDispatcher dispatcher
        -Task _task
        +start() void
        +stop() void
    }
    
    class LanguageHandler {
        <<abstract>>
        +str LANGUAGE
        +str IMAGE
        +str FILE_EXTENSION
        +bool NEED_COMPILE
        +prepare_source(str source_code, str work_dir) str*
        +compile(str source_code, str work_dir) tuple~bool, str~*
        +get_run_command(str work_dir) list~str~*
        +get_docker_image() str
    }
    
    class JavaHandler {
        +str LANGUAGE = "JAVA"
        +str IMAGE = "oj-judge-java"
        +str FILE_EXTENSION = ".java"
        +bool NEED_COMPILE = true
        +prepare_source(str source_code, str work_dir) str
        +compile(str source_code, str work_dir) tuple~bool, str~
        +get_run_command(str work_dir) list~str~
    }
    
    class PythonHandler {
        +str LANGUAGE = "PYTHON"
        +str IMAGE = "oj-judge-python"
        +str FILE_EXTENSION = ".py"
        +bool NEED_COMPILE = false
        +prepare_source(str source_code, str work_dir) str
        +compile(str source_code, str work_dir) tuple~bool, str~
        +get_run_command(str work_dir) list~str~
    }
    
    class CppHandler {
        +str LANGUAGE = "CPP"
        +str IMAGE = "oj-judge-cpp"
        +str FILE_EXTENSION = ".cpp"
        +bool NEED_COMPILE = true
        +prepare_source(str source_code, str work_dir) str
        +compile(str source_code, str work_dir) tuple~bool, str~
        +get_run_command(str work_dir) list~str~
    }
    
    class Runner {
        +run(str language, str work_dir, str input_data, int time_limit_ms, int memory_limit_mb) dict
    }
    
    class Comparator {
        +compare(str expected, str actual) bool
    }
    
    JudgeWorker --> JudgeDispatcher : uses
    JudgeDispatcher --> LanguageHandler : uses
    JudgeDispatcher --> Runner : uses
    JudgeDispatcher --> Comparator : uses
    LanguageHandler <|-- JavaHandler : extends
    LanguageHandler <|-- PythonHandler : extends
    LanguageHandler <|-- CppHandler : extends
```

#### 6. 团队协作模块

```mermaid
classDiagram
    class Team {
        +Long id
        +String name
        +String description
        +Long leaderId
        +Long courseId
        +Integer deleted
        +LocalDateTime createTime
        +LocalDateTime updateTime
    }
    
    class TeamMember {
        +Long id
        +Long teamId
        +Long userId
        +String role
        +LocalDateTime joinTime
    }
    
    class TeamService {
        <<interface>>
        +createTeam(TeamCreateDTO dto, Long leaderId) Team
        +updateTeam(Long teamId, TeamCreateDTO dto) void
        +deleteTeam(Long teamId) void
        +getTeamById(Long teamId) Team
        +listTeams(Long courseId) List~Team~
        +addMember(Long teamId, TeamMemberDTO dto) void
        +removeMember(Long teamId, Long userId) void
    }
    
    Team --> TeamMember : has
    TeamService --> Team : manages
```

#### 7. 教师复盘模块

```mermaid
classDiagram
    class TeacherReview {
        +Long id
        +Long teacherId
        +Long studentId
        +Long courseId
        +Long submissionId
        +Long problemId
        +String comment
        +String rating
        +LocalDateTime createTime
        +LocalDateTime updateTime
    }
    
    class ReviewService {
        <<interface>>
        +createReview(ReviewCreateDTO dto, Long teacherId) TeacherReview
        +updateReview(Long reviewId, ReviewCreateDTO dto) void
        +deleteReview(Long reviewId) void
        +getReviewById(Long reviewId) TeacherReview
        +listReviews(Long courseId, Long studentId) List~TeacherReview~
    }
    
    ReviewService --> TeacherReview : manages
```

#### 8. 错题本模块

```mermaid
classDiagram
    class WrongBook {
        +Long id
        +Long userId
        +Long problemId
        +Long submissionId
        +String status
        +Integer wrongCount
        +String note
        +LocalDateTime createTime
        +LocalDateTime updateTime
    }
    
    class WrongBookStatus {
        <<enumeration>>
        UNRESOLVED
        RESOLVED
        MASTERED
    }
    
    class WrongBookService {
        <<interface>>
        +getWrongBook(Long userId, Long problemId) WrongBook
        +updateWrongBook(Long wrongBookId, WrongBookUpdateDTO dto) void
        +listWrongBooks(Long userId, String status) List~WrongBook~
        +markAsResolved(Long wrongBookId) void
        +markAsMastered(Long wrongBookId) void
    }
    
    WrongBook --> WrongBookStatus : status
    WrongBookService --> WrongBook : manages
```

#### 9. 通知与审计模块

```mermaid
classDiagram
    class Notification {
        +Long id
        +Long userId
        +String title
        +String content
        +String type
        +Integer isRead
        +Long relatedId
        +LocalDateTime createTime
    }
    
    class AuditLog {
        +Long id
        +Long userId
        +String username
        +String action
        +String module
        +String description
        +String requestMethod
        +String requestUrl
        +String ip
        +Integer result
        +LocalDateTime createTime
    }
    
    class NotificationService {
        <<interface>>
        +sendNotification(Long userId, String title, String content, String type, Long relatedId) void
        +markAsRead(Long notificationId) void
        +listNotifications(Long userId, Boolean isRead) List~Notification~
        +getUnreadCount(Long userId) int
    }
    
    NotificationService --> Notification : manages
```

## 技术栈

| 层级 | 技术 |
|------|------|
| 前端 | Vue 3 + TypeScript + Tailwind CSS + Pinia |
| 后端 | Spring Boot 3 + MyBatis-Plus + JWT |
| 判题服务 | Python FastAPI + Docker SDK |
| 数据库 | MySQL 8.0 |
| 缓存/队列 | Redis 7 |
| 反向代理 | Nginx |
| 容器化 | Docker + Docker Compose |

## 目录结构

```
oj-review/
├── oj-review-web/          # 前端 Vue 3 项目
│   ├── src/
│   │   ├── api/            # API 请求
│   │   ├── components/     # 公共组件
│   │   ├── layouts/        # 布局组件
│   │   ├── router/         # 路由配置
│   │   ├── stores/         # Pinia 状态管理
│   │   ├── types/          # TypeScript 类型
│   │   ├── utils/          # 工具函数
│   │   └── views/          # 页面视图
│   ├── Dockerfile
│   └── package.json
├── oj-review-server/       # 后端 Spring Boot 项目
│   ├── src/main/java/      # Java 源码
│   ├── src/main/resources/ # 配置文件
│   ├── Dockerfile
│   └── pom.xml
├── oj-review-judge/        # 判题服务（Python）
│   ├── app/
│   │   ├── api/            # API 路由
│   │   ├── core/           # 配置、安全、日志
│   │   ├── judge/          # 调度器、编译器、运行器
│   │   ├── languages/      # 语言处理器
│   │   ├── schemas/        # 数据模型
│   │   └── workers/        # 判题工作进程
│   ├── docker-images/      # 各语言沙箱镜像
│   ├── Dockerfile
│   └── requirements.txt
├── scripts/                # 数据库脚本
│   ├── init-db.sql         # 建表 SQL（15 张表）
│   └── seed-data.sql       # 种子数据
├── nginx/                  # Nginx 配置
│   └── nginx.conf
├── docs/                   # 文档
│   ├── api.md              # API 文档
│   └── database.md         # 数据库文档
├── .github/workflows/      # GitHub CI
│   └── ci.yml
├── docker-compose.yml      # Docker Compose 编排
└── .env.example            # 环境变量模板
```

## 环境要求

### Docker 部署（推荐）

- Docker >= 20.10
- Docker Compose >= 2.0

### 本地开发

- JDK 21+
- Maven 3.8+
- Node.js 20+
- Python 3.12+
- MySQL 8.0
- Redis 7

## 快速开始

### 1. Docker 一键启动（推荐）

```bash
# 克隆项目
git clone <repo-url>
cd oj-review

# 复制环境变量
cp .env.example .env
# 按需修改 .env 中的配置

# 启动所有服务
docker-compose up -d

# 查看服务状态
docker-compose ps
```

启动后访问:
- 前端页面: http://localhost
- 后端 API: http://localhost/api/v1
- 判题服务: http://localhost/judge-api

### 2. 本地开发启动

**数据库初始化:**

```bash
mysql -u root -p < scripts/init-db.sql
mysql -u root -p oj_review < scripts/seed-data.sql
```

**启动后端:**

```bash
cd oj-review-server
mvn spring-boot:run -Dspring-boot.run.profiles=dev
```

**启动前端:**

```bash
cd oj-review-web
npm install
npm run dev
```

**启动判题服务:**

```bash
cd oj-review-judge
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8090 --reload
```

## 默认演示账号

| 角色 | 用户名 | 密码 |
|------|--------|------|
| 管理员 | admin | Admin@123 |
| 教师 | teacher | Teacher@123 |
| 学生 | xieyu | Student@123 |
| 学生 | jiangjc | Student@123 |
| 学生 | luzhiyu | Student@123 |
| 学生 | shenyanci | Student@123 |
| 学生 | guxingci | Student@123 |
| 学生 | suchen | Student@123 |

## API 文档

详见 [docs/api.md](docs/api.md)

Swagger UI（开发环境）: http://localhost:8080/swagger-ui.html

## 数据库文档

详见 [docs/database.md](docs/database.md)

## 核心业务流程

### 1. 用户注册与登录流程

```mermaid
sequenceDiagram
    participant U as 用户
    participant F as 前端
    participant B as 后端
    participant DB as 数据库
    
    U->>F: 输入注册信息
    F->>B: POST /api/v1/auth/register
    B->>DB: 检查用户名/邮箱
    DB-->>B: 返回检查结果
    alt 用户名/邮箱已存在
        B-->>F: 返回错误信息
        F-->>U: 显示错误
    else 用户名/邮箱可用
        B->>DB: 创建用户记录
        DB-->>B: 返回用户ID
        B-->>F: 返回注册成功
        F-->>U: 显示成功，跳转登录
    end
    
    U->>F: 输入登录信息
    F->>B: POST /api/v1/auth/login
    B->>DB: 验证用户名密码
    DB-->>B: 返回用户信息
    alt 验证失败
        B-->>F: 返回错误信息
        F-->>U: 显示错误
    else 验证成功
        B->>B: 生成JWT Token
        B-->>F: 返回Token和用户信息
        F->>F: 存储Token
        F-->>U: 登录成功，跳转首页
    end
```

### 2. 代码提交与判题流程

```mermaid
sequenceDiagram
    participant S as 学生
    participant F as 前端
    participant B as 后端
    participant R as Redis
    participant J as 判题服务
    participant D as Docker
    
    S->>F: 编写代码并提交
    F->>B: POST /api/v1/submissions
    B->>DB: 保存提交记录（状态：PENDING）
    B->>R: 推送判题任务到队列
    B-->>F: 返回提交ID
    F-->>S: 显示"判题中"
    
    J->>R: BRPOP 拉取任务
    R-->>J: 返回任务数据
    J->>J: 解析任务，更新状态为JUDGING
    
    loop 每个测试用例
        J->>D: 创建容器运行代码
        D-->>J: 返回运行结果
        J->>J: 比较输出，记录结果
    end
    
    J->>B: POST /api/v1/judge/callback
    B->>DB: 更新提交状态和结果
    B->>R: 发布状态更新消息
    R-->>F: 推送状态更新（WebSocket）
    F-->>S: 显示判题结果
```

### 3. 教师复盘流程

```mermaid
sequenceDiagram
    participant T as 教师
    participant F as 前端
    participant B as 后端
    participant DB as 数据库
    participant S as 学生
    
    T->>F: 查看学生提交列表
    F->>B: GET /api/v1/submissions?courseId=xxx
    B->>DB: 查询提交记录
    DB-->>B: 返回提交列表
    B-->>F: 返回数据
    F-->>T: 显示提交列表
    
    T->>F: 选择提交进行复盘
    F->>B: GET /api/v1/submissions/{id}
    B->>DB: 查询提交详情
    DB-->>B: 返回详情
    B-->>F: 返回数据
    F-->>T: 显示代码和判题结果
    
    T->>F: 编写复盘评语
    F->>B: POST /api/v1/reviews
    B->>DB: 保存复盘记录
    B->>B: 创建通知
    B-->>F: 返回成功
    F-->>T: 显示成功
    
    B->>S: 推送通知（WebSocket）
    S->>F: 查看通知
    F->>B: GET /api/v1/notifications
    B-->>F: 返回通知列表
    F-->>S: 显示复盘评语
```

## 数据库设计

### ER 图

```mermaid
erDiagram
    SYS_USER ||--o{ SUBMISSION : submits
    SYS_USER ||--o{ COURSE_MEMBER : joins
    SYS_USER ||--o{ TEAM_MEMBER : joins
    SYS_USER ||--o{ WRONG_BOOK : has
    SYS_USER ||--o{ NOTIFICATION : receives
    SYS_USER ||--o{ TEACHER_REVIEW : writes
    SYS_USER ||--o{ AUDIT_LOG : performs
    
    COURSE ||--o{ COURSE_CHAPTER : contains
    COURSE ||--o{ COURSE_MEMBER : has
    COURSE ||--o{ TEAM : has
    COURSE ||--o{ PROBLEM : contains
    COURSE ||--o{ SUBMISSION : records
    COURSE ||--o{ TEACHER_REVIEW : includes
    
    COURSE_CHAPTER ||--o{ PROBLEM : organizes
    
    PROBLEM ||--o{ PROBLEM_TEST_CASE : has
    PROBLEM ||--o{ SUBMISSION : receives
    PROBLEM ||--o{ WRONG_BOOK : appears_in
    PROBLEM ||--o{ TEACHER_REVIEW : reviewed_by
    
    SUBMISSION ||--o{ SUBMISSION_CASE_RESULT : produces
    SUBMISSION ||--o{ WRONG_BOOK : triggers
    SUBMISSION ||--o{ TEACHER_REVIEW : reviewed_by
    
    TEAM ||--o{ TEAM_MEMBER : has
    
    SYS_USER {
        bigint id PK
        varchar username
        varchar password
        varchar real_name
        varchar email
        varchar phone
        varchar avatar
        varchar role
        varchar student_id
        int status
        int deleted
        datetime create_time
        datetime update_time
    }
    
    COURSE {
        bigint id PK
        varchar name
        text description
        varchar cover_image
        bigint creator_id FK
        varchar status
        varchar term
        int deleted
        datetime create_time
        datetime update_time
    }
    
    COURSE_CHAPTER {
        bigint id PK
        bigint course_id FK
        varchar title
        text description
        int sort_order
        int deleted
        datetime create_time
        datetime update_time
    }
    
    COURSE_MEMBER {
        bigint id PK
        bigint course_id FK
        bigint user_id FK
        varchar role
        datetime join_time
    }
    
    PROBLEM {
        bigint id PK
        varchar title
        text description
        text input_desc
        text output_desc
        text sample_input
        text sample_output
        text hint
        varchar difficulty
        bigint time_limit
        bigint memory_limit
        bigint creator_id FK
        bigint chapter_id FK
        varchar tags
        int submit_count
        int accepted_count
        int status
        int deleted
        datetime create_time
        datetime update_time
    }
    
    PROBLEM_TEST_CASE {
        bigint id PK
        bigint problem_id FK
        text input_data
        text expected_output
        int sort_order
        int is_hidden
        datetime create_time
    }
    
    SUBMISSION {
        bigint id PK
        bigint user_id FK
        bigint problem_id FK
        bigint course_id FK
        varchar language
        text code
        varchar status
        bigint time_used
        bigint memory_used
        int test_cases_passed
        int test_cases_total
        text compile_output
        datetime create_time
    }
    
    SUBMISSION_CASE_RESULT {
        bigint id PK
        bigint submission_id FK
        bigint test_case_id FK
        varchar status
        bigint time_used
        bigint memory_used
        text actual_output
        text error_message
        datetime create_time
    }
    
    CODE_DRAFT {
        bigint id PK
        bigint user_id FK
        bigint problem_id FK
        text code
        varchar language
        datetime update_time
    }
    
    TEAM {
        bigint id PK
        varchar name
        text description
        bigint leader_id FK
        bigint course_id FK
        int deleted
        datetime create_time
        datetime update_time
    }
    
    TEAM_MEMBER {
        bigint id PK
        bigint team_id FK
        bigint user_id FK
        varchar role
        datetime join_time
    }
    
    TEACHER_REVIEW {
        bigint id PK
        bigint teacher_id FK
        bigint student_id FK
        bigint course_id FK
        bigint submission_id FK
        bigint problem_id FK
        text comment
        varchar rating
        datetime create_time
        datetime update_time
    }
    
    WRONG_BOOK {
        bigint id PK
        bigint user_id FK
        bigint problem_id FK
        bigint submission_id FK
        varchar status
        int wrong_count
        text note
        datetime create_time
        datetime update_time
    }
    
    NOTIFICATION {
        bigint id PK
        bigint user_id FK
        varchar title
        text content
        varchar type
        int is_read
        bigint related_id
        datetime create_time
    }
    
    AUDIT_LOG {
        bigint id PK
        bigint user_id FK
        varchar username
        varchar action
        varchar module
        text description
        varchar request_method
        varchar request_url
        varchar ip
        int result
        datetime create_time
    }
```

## 常见问题

### Docker 启动失败

- 确保 Docker 服务已启动
- 检查端口 80、3306、6379、8080、8090 是否被占用
- 首次启动需要拉取镜像，请耐心等待

### 判题服务无法运行代码

- 确保 Docker 守护进程正在运行
- 判题服务需要挂载 `/var/run/docker.sock`，Linux 下注意权限
- 需要预先构建判题沙箱镜像: `cd oj-review-judge && docker build -t oj-judge-java -f docker-images/java/Dockerfile docker-images/java/`

### 数据库连接失败

- 检查 `.env` 文件中的数据库配置
- MySQL 容器首次启动需要时间初始化，请等待 healthcheck 通过
- 查看日志: `docker-compose logs mysql`

### 前端页面空白

- 检查后端服务是否正常运行
- 检查 Nginx 配置中的代理地址是否正确
- 查看浏览器控制台是否有报错

## 贡献指南

1. Fork 本仓库
2. 创建特性分支: `git checkout -b feature/your-feature`
3. 提交更改: `git commit -m 'Add some feature'`
4. 推送分支: `git push origin feature/your-feature`
5. 提交 Pull Request

## 许可证

本项目采用 MIT 许可证 - 详见 [LICENSE](LICENSE) 文件

## 联系方式

- 项目维护者: [Your Name]
- 邮箱: [your.email@example.com]
- 项目链接: [https://github.com/your-username/oj-review](https://github.com/your-username/oj-review)