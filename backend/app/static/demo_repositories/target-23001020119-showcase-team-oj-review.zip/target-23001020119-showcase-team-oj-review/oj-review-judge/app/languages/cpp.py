from pathlib import Path

from app.judge.compiler import Compiler


class CppHandler:
    """C++ 语言处理器"""

    LANGUAGE = "CPP"
    IMAGE = "oj-judge-cpp"
    FILE_EXTENSION = ".cpp"
    NEED_COMPILE = True

    @staticmethod
    def prepare_source(source_code: str, work_dir: str) -> str:
        """
        准备 C++ 源代码文件

        Args:
            source_code: C++ 源代码
            work_dir: 工作目录

        Returns:
            源文件路径
        """
        source_path = Path(work_dir) / "main.cpp"
        source_path.write_text(source_code, encoding="utf-8")
        return str(source_path)

    @staticmethod
    def compile(source_code: str, work_dir: str) -> tuple[bool, str]:
        """
        编译 C++ 代码

        Args:
            source_code: C++ 源代码
            work_dir: 工作目录

        Returns:
            (是否成功, 编译输出)
        """
        CppHandler.prepare_source(source_code, work_dir)
        return Compiler.compile_cpp(source_code, work_dir)

    @staticmethod
    def get_run_command(work_dir: str) -> list[str]:
        """获取运行命令"""
        return ["/home/judge/code/main"]
