from contextlib import asynccontextmanager

import redis.asyncio as aioredis
from fastapi import FastAPI
from loguru import logger

from app.api.judge import router as judge_router
from app.core.config import settings
from app.core.logging import setup_logging


@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期管理：启动时连接 Redis，关闭时清理资源"""
    setup_logging()
    logger.info("判题服务启动中...")

    # 连接 Redis
    app.state.redis = aioredis.Redis(
        host=settings.REDIS_HOST,
        port=settings.REDIS_PORT,
        password=settings.REDIS_PASSWORD or None,
        decode_responses=True,
    )
    try:
        await app.state.redis.ping()
        logger.info("Redis 连接成功: {}:{}", settings.REDIS_HOST, settings.REDIS_PORT)
    except Exception as e:
        logger.error("Redis 连接失败: {}", str(e))
        raise

    yield

    # 关闭时清理
    await app.state.redis.close()
    logger.info("判题服务已关闭")


app = FastAPI(
    title="OJ Review 判题服务",
    description="在线评测系统判题微服务，负责代码编译、运行与结果判定",
    version="1.0.0",
    lifespan=lifespan,
)

app.include_router(judge_router, prefix="/api/v1")


@app.get("/")
async def root():
    return {"service": "oj-judge", "status": "running"}
