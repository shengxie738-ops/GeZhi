from pathlib import Path


class PythonHandler:
    """Python 语言处理器"""

    LANGUAGE = "PYTHON"
    IMAGE = "oj-judge-python"
    FILE_EXTENSION = ".py"
    NEED_COMPILE = False

    @staticmethod
    def prepare_source(source_code: str, work_dir: str) -> str:
        """
        准备 Python 源代码文件

        Args:
            source_code: Python 源代码
            work_dir: 工作目录

        Returns:
            源文件路径
        """
        source_path = Path(work_dir) / "main.py"
        source_path.write_text(source_code, encoding="utf-8")
        return str(source_path)

    @staticmethod
    def compile(source_code: str, work_dir: str) -> tuple[bool, str]:
        """
        Python 无需编译，直接返回成功

        Args:
            source_code: 源代码
            work_dir: 工作目录

        Returns:
            (True, "")
        """
        PythonHandler.prepare_source(source_code, work_dir)
        return True, ""

    @staticmethod
    def get_run_command(work_dir: str) -> list[str]:
        """获取运行命令"""
        return ["python3", "/home/judge/code/main.py"]
