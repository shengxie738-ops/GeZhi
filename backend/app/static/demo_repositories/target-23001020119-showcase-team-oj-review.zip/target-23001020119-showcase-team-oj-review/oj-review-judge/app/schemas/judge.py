from pydantic import BaseModel


class TestCase(BaseModel):
    """测试用例定义"""
    id: int
    input_data: str
    expected_output: str
    is_public: bool
    score: float


class JudgeTask(BaseModel):
    """判题任务"""
    submission_id: int
    problem_id: int
    language: str  # JAVA, PYTHON, CPP
    source_code: str
    time_limit_ms: int = 1000
    memory_limit_mb: int = 256
    test_cases: list[TestCase]


class CaseResult(BaseModel):
    """单个测试用例的判题结果"""
    test_case_id: int
    status: str  # ACCEPTED, WRONG_ANSWER, TIME_LIMIT_EXCEEDED, etc.
    time_used_ms: int
    memory_used_kb: int
    actual_output: str = ""
    error_message: str = ""


class JudgeResult(BaseModel):
    """完整判题结果"""
    submission_id: int
    status: str
    score: float
    passed_case_count: int
    total_case_count: int
    time_used_ms: int
    memory_used_kb: int
    compile_output: str = ""
    runtime_output: str = ""
    case_results: list[CaseResult]
