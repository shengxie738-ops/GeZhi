"""判题 API 路由：提交判题任务、查询判题状态"""

import json

from fastapi import APIRouter, Depends, HTTPException, Request
from loguru import logger

from app.core.security import require_internal_token
from app.schemas.judge import JudgeTask, JudgeResult

router = APIRouter(tags=["判题服务"])


@router.post("/judge/submit", dependencies=[Depends(require_internal_token)])
async def submit_judge_task(task: JudgeTask, request: Request):
    """
    提交判题任务

    将判题任务推入 Redis 队列，由 Worker 异步消费处理。
    需要 X-Internal-Token 请求头验证。
    """
    redis_client = request.app.state.redis
    try:
        task_json = task.model_dump_json()
        await redis_client.lpush("oj:judge:queue", task_json)
        logger.info(
            "判题任务已入队: submission_id={}, language={}",
            task.submission_id,
            task.language,
        )
        return {
            "code": 0,
            "message": "判题任务已提交",
            "data": {"submission_id": task.submission_id},
        }
    except Exception as e:
        logger.error("判题任务入队失败: {}", str(e))
        raise HTTPException(status_code=500, detail="判题任务提交失败")


@router.get("/judge/status/{submission_id}", dependencies=[Depends(require_internal_token)])
async def get_judge_status(submission_id: int, request: Request):
    """
    查询判题状态

    从 Redis 中读取指定提交的判题结果缓存。
    """
    redis_client = request.app.state.redis
    cache_key = f"oj:judge:result:{submission_id}"
    try:
        data = await redis_client.get(cache_key)
        if data is None:
            raise HTTPException(status_code=404, detail="判题结果不存在或尚未完成")
        result = json.loads(data)
        return {"code": 0, "message": "success", "data": result}
    except HTTPException:
        raise
    except Exception as e:
        logger.error("查询判题状态失败: {}", str(e))
        raise HTTPException(status_code=500, detail="查询失败")


@router.post("/judge/callback", dependencies=[Depends(require_internal_token)])
async def judge_callback(result: JudgeResult, request: Request):
    """
    判题结果回调

    Worker 完成判题后调用此接口通知结果，同时将结果缓存到 Redis。
    """
    redis_client = request.app.state.redis
    cache_key = f"oj:judge:result:{result.submission_id}"
    try:
        await redis_client.setex(
            cache_key,
            3600,
            result.model_dump_json(),
        )
        logger.info(
            "判题结果已缓存: submission_id={}, status={}, score={}",
            result.submission_id,
            result.status,
            result.score,
        )
        return {"code": 0, "message": "回调处理成功"}
    except Exception as e:
        logger.error("判题结果回调处理失败: {}", str(e))
        raise HTTPException(status_code=500, detail="回调处理失败")


@router.get("/health")
async def health_check(request: Request):
    """健康检查接口"""
    redis_ok = False
    try:
        await request.app.state.redis.ping()
        redis_ok = True
    except Exception:
        pass

    return {
        "status": "healthy" if redis_ok else "degraded",
        "redis": "connected" if redis_ok else "disconnected",
    }
