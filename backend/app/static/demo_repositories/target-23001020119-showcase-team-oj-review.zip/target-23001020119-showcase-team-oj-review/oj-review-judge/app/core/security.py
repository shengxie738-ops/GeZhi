from fastapi import HTTPException, Request, Security
from fastapi.security import APIKeyHeader

from app.core.config import settings

api_key_header = APIKeyHeader(name="X-Internal-Token", auto_error=False)


def verify_token(token: str | None) -> bool:
    """验证内部 token 是否有效"""
    if not token:
        return False
    return token == settings.INTERNAL_TOKEN


async def require_internal_token(request: Request) -> None:
    """API Key 验证依赖项，用于保护内部接口"""
    token = request.headers.get("X-Internal-Token")
    if not verify_token(token):
        raise HTTPException(status_code=401, detail="无效的内部令牌")
