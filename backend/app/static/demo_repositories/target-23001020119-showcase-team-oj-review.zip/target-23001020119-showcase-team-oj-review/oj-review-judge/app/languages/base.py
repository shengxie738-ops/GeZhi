from abc import ABC, abstractmethod


class LanguageHandler(ABC):
    """语言处理器抽象基类"""

    LANGUAGE: str = ""
    IMAGE: str = ""
    FILE_EXTENSION: str = ""
    NEED_COMPILE: bool = True

    @staticmethod
    @abstractmethod
    def prepare_source(source_code: str, work_dir: str) -> str:
        """
        准备源代码文件

        Args:
            source_code: 源代码字符串
            work_dir: 工作目录路径

        Returns:
            源文件路径
        """
        ...

    @staticmethod
    @abstractmethod
    def compile(source_code: str, work_dir: str) -> tuple[bool, str]:
        """
        编译源代码

        Args:
            source_code: 源代码字符串
            work_dir: 工作目录路径

        Returns:
            (是否编译成功, 编译输出信息)
        """
        ...

    @staticmethod
    @abstractmethod
    def get_run_command(work_dir: str) -> list[str]:
        """
        获取运行命令

        Args:
            work_dir: 工作目录路径

        Returns:
            运行命令列表
        """
        ...

    @classmethod
    def get_docker_image(cls) -> str:
        """获取 Docker 镜像名称"""
        return cls.IMAGE
