import re
from pathlib import Path

from loguru import logger

from app.judge.compiler import Compiler


class JavaHandler:
    """Java 语言处理器"""

    LANGUAGE = "JAVA"
    IMAGE = "oj-judge-java"
    FILE_EXTENSION = ".java"
    NEED_COMPILE = True

    @staticmethod
    def prepare_source(source_code: str, work_dir: str) -> str:
        """
        准备 Java 源代码文件

        Java 要求文件名与公共类名一致，此处统一使用 Main 类名

        Args:
            source_code: Java 源代码
            work_dir: 工作目录

        Returns:
            源文件路径
        """
        # 将公共类名替换为 Main
        modified_code = JavaHandler._replace_class_name(source_code)
        source_path = Path(work_dir) / "Main.java"
        source_path.write_text(modified_code, encoding="utf-8")
        return str(source_path)

    @staticmethod
    def compile(source_code: str, work_dir: str) -> tuple[bool, str]:
        """
        编译 Java 代码

        Args:
            source_code: Java 源代码
            work_dir: 工作目录

        Returns:
            (是否成功, 编译输出)
        """
        JavaHandler.prepare_source(source_code, work_dir)
        return Compiler.compile_java(source_code, work_dir)

    @staticmethod
    def get_run_command(work_dir: str) -> list[str]:
        """获取运行命令"""
        return ["java", "-cp", "/home/judge/code", "Main"]

    @staticmethod
    def _replace_class_name(source_code: str) -> str:
        """
        将公共类名替换为 Main

        匹配 public class XXXX 模式并替换
        """
        pattern = r"(public\s+class\s+)\w+"
        replacement = r"\g<1>Main"
        modified = re.sub(pattern, replacement, source_code, count=1)
        if modified == source_code:
            logger.warning("未找到公共类声明，可能需要用户使用 Main 作为类名")
        return modified
