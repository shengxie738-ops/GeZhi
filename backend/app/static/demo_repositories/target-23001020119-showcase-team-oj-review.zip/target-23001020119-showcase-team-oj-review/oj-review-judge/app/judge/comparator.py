class Comparator:
    """输出比较器，用于判断程序实际输出与期望输出是否匹配"""

    @staticmethod
    def normalize(text: str) -> str:
        """标准化输出文本：去除每行末尾空白，去除末尾空行"""
        lines = text.split("\n")
        # 去除每行末尾空白
        lines = [line.rstrip() for line in lines]
        # 去除末尾空行
        while lines and lines[-1] == "":
            lines.pop()
        return "\n".join(lines)

    @staticmethod
    def compare(expected: str, actual: str) -> bool:
        """
        比较期望输出与实际输出

        规则:
        - 忽略每行末尾空白字符
        - 忽略末尾多余空行
        - 逐行比较内容
        """
        normalized_expected = Comparator.normalize(expected)
        normalized_actual = Comparator.normalize(actual)
        return normalized_expected == normalized_actual
