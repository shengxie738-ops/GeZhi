from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """判题服务配置"""

    # Redis 配置
    REDIS_HOST: str = "localhost"
    REDIS_PORT: int = 6379
    REDIS_PASSWORD: str = ""

    # Redis 队列和频道
    JUDGE_QUEUE_KEY: str = "oj:judge:queue"
    JUDGE_RESULT_CHANNEL: str = "oj:judge:result"

    # 后端回调
    BACKEND_CALLBACK_URL: str = "http://localhost:8080/api/v1/submissions/callback"
    INTERNAL_TOKEN: str = "oj-judge-internal-token"

    # 判题并发和资源限制
    MAX_CONCURRENT_JOBS: int = 5
    DEFAULT_TIME_LIMIT: int = 1000  # 毫秒
    DEFAULT_MEMORY_LIMIT: int = 256  # MB

    # 支持的编程语言
    SUPPORTED_LANGUAGES: list[str] = ["JAVA", "PYTHON", "CPP"]

    model_config = {"env_prefix": "OJ_", "env_file": ".env", "extra": "ignore"}


settings = Settings()
