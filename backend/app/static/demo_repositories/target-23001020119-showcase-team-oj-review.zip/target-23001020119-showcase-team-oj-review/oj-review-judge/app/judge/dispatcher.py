import asyncio
import json
import tempfile
import shutil
from pathlib import Path

import httpx
import redis.asyncio as aioredis
from loguru import logger

from app.core.config import settings
from app.judge.comparator import Comparator
from app.judge.runner import Runner
from app.languages.java import JavaHandler
from app.languages.python import PythonHandler
from app.languages.cpp import CppHandler
from app.schemas.judge import (
    CaseResult,
    JudgeResult,
    JudgeTask,
)


class JudgeDispatcher:
    """判题调度器，负责从队列拉取任务、分发执行、回调结果"""

    def __init__(self) -> None:
        self.semaphore = asyncio.Semaphore(settings.MAX_CONCURRENT_JOBS)
        self.running_count: int = 0
        self.runner: Runner | None = None
        self.redis_client: aioredis.Redis | None = None
        self._running = False
        # 语言处理器映射
        self._handlers = {
            "JAVA": JavaHandler,
            "PYTHON": PythonHandler,
            "CPP": CppHandler,
        }

    async def start(self) -> None:
        """启动判题消费者循环"""
        self._running = True
        self.runner = Runner()
        self.redis_client = aioredis.Redis(
            host=settings.REDIS_HOST,
            port=settings.REDIS_PORT,
            password=settings.REDIS_PASSWORD or None,
            decode_responses=True,
        )
        logger.info(
            "判题调度器启动，并发上限: {}", settings.MAX_CONCURRENT_JOBS
        )

        while self._running:
            try:
                task = await self.poll_from_queue()
                if task is not None:
                    asyncio.create_task(self._process_with_semaphore(task))
                else:
                    # 队列为空时休眠，避免忙等待
                    await asyncio.sleep(0.5)
            except asyncio.CancelledError:
                logger.info("判题调度器收到取消信号")
                break
            except Exception as e:
                logger.error("判题调度器异常: {}", str(e))
                await asyncio.sleep(1.0)

        logger.info("判题调度器已停止")

    async def stop(self) -> None:
        """停止判题调度器"""
        self._running = False
        if self.redis_client:
            await self.redis_client.close()
        logger.info("判题调度器资源已清理")

    async def _process_with_semaphore(self, task: JudgeTask) -> None:
        """使用信号量控制并发处理任务"""
        async with self.semaphore:
            self.running_count += 1
            try:
                await self.process_task(task)
            finally:
                self.running_count -= 1

    async def poll_from_queue(self) -> JudgeTask | None:
        """
        从 Redis 队列拉取判题任务

        使用 BRPOP 实现阻塞式拉取，超时 1 秒

        Returns:
            判题任务，队列为空时返回 None
        """
        if not self.redis_client:
            return None

        try:
            result = await self.redis_client.brpop(
                settings.JUDGE_QUEUE_KEY, timeout=1
            )
            if result is None:
                return None

            _, data = result
            task_data = json.loads(data)
            return JudgeTask(**task_data)
        except json.JSONDecodeError as e:
            logger.error("任务数据解析失败: {}", str(e))
            return None
        except Exception as e:
            logger.error("从队列拉取任务失败: {}", str(e))
            return None

    async def process_task(self, task: JudgeTask) -> None:
        """
        处理单个判题任务

        流程:
        1. 编译代码（如需要）
        2. 逐个运行测试用例
        3. 比较输出结果
        4. 计算总分
        5. 回调后端更新结果

        Args:
            task: 判题任务
        """
        logger.info(
            "开始处理判题任务: submission_id={}, language={}, case_count={}",
            task.submission_id,
            task.language,
            len(task.test_cases),
        )

        # 更新状态为 JUDGING
        await self._update_status(task.submission_id, "JUDGING")

        # 创建临时工作目录
        work_dir = tempfile.mkdtemp(prefix=f"oj_judge_{task.submission_id}_")

        try:
            handler = self._handlers.get(task.language)
            if handler is None:
                await self._send_result(
                    JudgeResult(
                        submission_id=task.submission_id,
                        status="SYSTEM_ERROR",
                        score=0.0,
                        passed_case_count=0,
                        total_case_count=len(task.test_cases),
                        time_used_ms=0,
                        memory_used_kb=0,
                        compile_output="",
                        runtime_output=f"不支持的编程语言: {task.language}",
                        case_results=[],
                    )
                )
                return

            # 编译阶段（如需要）
            if handler.NEED_COMPILE:
                success, compile_output = handler.compile(task.source_code, work_dir)
                if not success:
                    await self._send_result(
                        JudgeResult(
                            submission_id=task.submission_id,
                            status="COMPILE_ERROR",
                            score=0.0,
                            passed_case_count=0,
                            total_case_count=len(task.test_cases),
                            time_used_ms=0,
                            memory_used_kb=0,
                            compile_output=compile_output,
                            runtime_output="",
                            case_results=[],
                        )
                    )
                    return
            else:
                handler.prepare_source(task.source_code, work_dir)
                compile_output = ""

            # 逐个运行测试用例
            case_results: list[CaseResult] = []
            total_score = 0.0
            max_time = 0
            max_memory = 0
            passed_count = 0

            for tc in task.test_cases:
                run_result = await self.runner.run(
                    language=task.language,
                    work_dir=work_dir,
                    input_data=tc.input_data,
                    time_limit_ms=task.time_limit_ms,
                    memory_limit_mb=task.memory_limit_mb,
                )

                # 判定状态
                if run_result["status"] == "ACCEPTED":
                    is_match = Comparator.compare(
                        tc.expected_output, run_result["output"]
                    )
                    if is_match:
                        case_status = "ACCEPTED"
                        total_score += tc.score
                        passed_count += 1
                    else:
                        case_status = "WRONG_ANSWER"
                else:
                    case_status = run_result["status"]

                case_results.append(
                    CaseResult(
                        test_case_id=tc.id,
                        status=case_status,
                        time_used_ms=run_result["time_ms"],
                        memory_used_kb=run_result["memory_kb"],
                        actual_output=run_result.get("output", ""),
                        error_message=run_result.get("error", ""),
                    )
                )

                max_time = max(max_time, run_result["time_ms"])
                max_memory = max(max_memory, run_result["memory_kb"])

            # 确定总体状态
            if passed_count == len(task.test_cases):
                overall_status = "ACCEPTED"
            elif any(cr.status in ("RUNTIME_ERROR", "SEGFAULT") for cr in case_results):
                overall_status = "RUNTIME_ERROR"
            elif any(cr.status == "TIME_LIMIT_EXCEEDED" for cr in case_results):
                overall_status = "TIME_LIMIT_EXCEEDED"
            elif any(cr.status == "MEMORY_LIMIT_EXCEEDED" for cr in case_results):
                overall_status = "MEMORY_LIMIT_EXCEEDED"
            else:
                overall_status = "WRONG_ANSWER"

            await self._send_result(
                JudgeResult(
                    submission_id=task.submission_id,
                    status=overall_status,
                    score=total_score,
                    passed_case_count=passed_count,
                    total_case_count=len(task.test_cases),
                    time_used_ms=max_time,
                    memory_used_kb=max_memory,
                    compile_output=compile_output,
                    runtime_output="",
                    case_results=case_results,
                )
            )

        except Exception as e:
            logger.error("判题任务处理异常: submission_id={}, error={}", task.submission_id, str(e))
            await self._send_result(
                JudgeResult(
                    submission_id=task.submission_id,
                    status="SYSTEM_ERROR",
                    score=0.0,
                    passed_case_count=0,
                    total_case_count=len(task.test_cases),
                    time_used_ms=0,
                    memory_used_kb=0,
                    compile_output="",
                    runtime_output=str(e),
                    case_results=[],
                )
            )
        finally:
            # 清理临时目录
            try:
                shutil.rmtree(work_dir, ignore_errors=True)
            except Exception:
                pass

    async def _update_status(self, submission_id: int, status: str) -> None:
        """通过 Redis 发布状态更新消息"""
        if self.redis_client:
            try:
                await self.redis_client.publish(
                    settings.JUDGE_RESULT_CHANNEL,
                    json.dumps({"submission_id": submission_id, "status": status}),
                )
                logger.debug("状态已更新: submission_id={}, status={}", submission_id, status)
            except Exception as e:
                logger.error("状态更新失败: {}", str(e))

    async def _send_result(self, result: JudgeResult) -> None:
        """发送判题结果：缓存到 Redis 并回调后端"""
        # 缓存到 Redis
        if self.redis_client:
            try:
                cache_key = f"oj:judge:result:{result.submission_id}"
                await self.redis_client.setex(cache_key, 3600, result.model_dump_json())
            except Exception as e:
                logger.error("结果缓存失败: {}", str(e))

        # 回调后端
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.post(
                    settings.BACKEND_CALLBACK_URL,
                    json=result.model_dump(),
                    headers={"X-Internal-Token": settings.INTERNAL_TOKEN},
                )
                if response.status_code == 200:
                    logger.info(
                        "判题结果回调成功: submission_id={}, status={}",
                        result.submission_id,
                        result.status,
                    )
                else:
                    logger.error(
                        "判题结果回调失败: submission_id={}, status_code={}",
                        result.submission_id,
                        response.status_code,
                    )
        except Exception as e:
            logger.error("判题结果回调异常: submission_id={}, error={}", result.submission_id, str(e))