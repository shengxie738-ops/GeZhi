class ResourceLimiter:
    """Docker 容器资源限制配置生成器"""

    @staticmethod
    def get_container_config(
        time_limit_ms: int,
        memory_limit_mb: int,
        image: str,
        command: list[str] | None = None,
        volumes: dict[str, dict[str, str]] | None = None,
    ) -> dict:
        """
        生成 Docker 容器配置

        安全限制:
        - CPU 限制: 按内存比例分配
        - 内存限制: 硬限制 + 交换分区限制
        - 进程数限制: 防止 fork 炸弹
        - 网络隔离: 禁止网络访问
        - 只读根文件系统
        - 禁用权限提升
        - 非 root 用户运行

        Args:
            time_limit_ms: 时间限制（毫秒）
            memory_limit_mb: 内存限制（MB）
            image: Docker 镜像名
            command: 容器启动命令
            volumes: 卷挂载配置

        Returns:
            Docker 容器创建参数字典
        """
        # 计算 CPU 限制（纳秒），每 256MB 内存分配 1 个 CPU 核心
        cpu_cores = max(1, memory_limit_mb // 256)
        cpu_period = 100000  # 100ms
        cpu_quota = cpu_period * cpu_cores

        config: dict = {
            "image": image,
            "detach": True,
            "network_disabled": True,  # 禁止网络访问
            "read_only": True,  # 只读根文件系统
            "mem_limit": f"{memory_limit_mb}m",  # 内存硬限制
            "memswap_limit": f"{memory_limit_mb}m",  # 禁止交换（内存+swap 总量=内存限制）
            "cpu_period": cpu_period,
            "cpu_quota": cpu_quota,
            "pids_limit": 64,  # 进程数限制，防止 fork 炸弹
            "security_opt": ["no-new-privileges"],  # 禁止权限提升
            "user": "judge",  # 非 root 用户运行
            "tmpfs": {"/tmp": "size=64m"},  # 临时文件系统
        }

        if command is not None:
            config["command"] = command

        if volumes is not None:
            config["volumes"] = volumes

        return config

    @staticmethod
    def get_timeout_seconds(time_limit_ms: int) -> float:
        """将毫秒时间限制转换为秒，并添加 1 秒缓冲"""
        return time_limit_ms / 1000.0 + 1.0
