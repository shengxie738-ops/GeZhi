import sys

from loguru import logger


def setup_logging() -> None:
    """配置 loguru 日志：控制台 + 文件输出"""
    # 移除默认处理器
    logger.remove()

    # 控制台输出（彩色）
    logger.add(
        sys.stdout,
        level="INFO",
        format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | "
        "<level>{level: <8}</level> | "
        "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - "
        "<level>{message}</level>",
        colorize=True,
    )

    # 文件输出（按天轮转，保留 7 天）
    logger.add(
        "logs/judge_{time:YYYY-MM-DD}.log",
        level="DEBUG",
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | "
        "{name}:{function}:{line} - {message}",
        rotation="00:00",
        retention="7 days",
        compression="zip",
        encoding="utf-8",
    )

    # 错误日志单独输出
    logger.add(
        "logs/judge_error_{time:YYYY-MM-DD}.log",
        level="ERROR",
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | "
        "{name}:{function}:{line} - {message}",
        rotation="00:00",
        retention="30 days",
        compression="zip",
        encoding="utf-8",
    )

    logger.info("日志系统初始化完成")
