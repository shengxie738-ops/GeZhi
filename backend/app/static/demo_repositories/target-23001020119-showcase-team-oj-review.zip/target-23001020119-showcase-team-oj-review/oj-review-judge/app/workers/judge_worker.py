"""判题 Worker：循环从 Redis 队列拉取任务，执行判题流程，回调后端"""

import asyncio
import signal

from loguru import logger

from app.core.config import settings
from app.core.logging import setup_logging
from app.judge.dispatcher import JudgeDispatcher


class JudgeWorker:
    """判题 Worker 管理器"""

    def __init__(self) -> None:
        self.dispatcher = JudgeDispatcher()
        self._task: asyncio.Task | None = None

    async def start(self) -> None:
        """启动 Worker"""
        setup_logging()
        logger.info("判题 Worker 启动中...")
        logger.info("Redis: {}:{}", settings.REDIS_HOST, settings.REDIS_PORT)
        logger.info("并发上限: {}", settings.MAX_CONCURRENT_JOBS)

        self._task = asyncio.create_task(self.dispatcher.start())

        # 注册信号处理
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                loop.add_signal_handler(sig, lambda: asyncio.create_task(self.stop()))
            except NotImplementedError:
                # Windows 不支持 add_signal_handler
                pass

        try:
            await self._task
        except asyncio.CancelledError:
            logger.info("Worker 任务已取消")

    async def stop(self) -> None:
        """停止 Worker"""
        logger.info("正在停止判题 Worker...")
        await self.dispatcher.stop()
        if self._task and not self._task.done():
            self._task.cancel()
        logger.info("判题 Worker 已停止")


def main():
    """Worker 入口"""
    worker = JudgeWorker()
    asyncio.run(worker.start())


if __name__ == "__main__":
    main()
