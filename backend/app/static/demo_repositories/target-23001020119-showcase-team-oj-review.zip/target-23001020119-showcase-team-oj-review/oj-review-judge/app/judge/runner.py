import os
import tempfile

import docker
from loguru import logger

from app.judge.limiter import ResourceLimiter


class Runner:
    """Docker 容器运行器，负责在隔离容器中执行用户代码"""

    def __init__(self) -> None:
        self.docker_client = docker.from_env()

    async def run(
        self,
        language: str,
        work_dir: str,
        input_data: str,
        time_limit_ms: int,
        memory_limit_mb: int,
    ) -> dict:
        """
        在 Docker 容器中运行代码

        Args:
            language: 编程语言 (JAVA, PYTHON, CPP)
            work_dir: 工作目录（包含编译后的文件）
            input_data: 标准输入数据
            time_limit_ms: 时间限制（毫秒）
            memory_limit_mb: 内存限制（MB）

        Returns:
            包含 status, output, time_ms, memory_kb 的字典
        """
        # 创建输入文件
        input_file = os.path.join(work_dir, "input.txt")
        with open(input_file, "w", encoding="utf-8") as f:
            f.write(input_data)

        # 获取语言对应的镜像和运行命令
        image, command = self._get_run_config(language)

        # 生成容器配置
        volumes = {
            work_dir: {"bind": "/home/judge/code", "mode": "ro"},
            os.path.join(work_dir, "input.txt"): {
                "bind": "/home/judge/input.txt",
                "mode": "ro",
            },
        }

        container_config = ResourceLimiter.get_container_config(
            time_limit_ms=time_limit_ms,
            memory_limit_mb=memory_limit_mb,
            image=image,
            command=command,
            volumes=volumes,
        )

        timeout_seconds = ResourceLimiter.get_timeout_seconds(time_limit_ms)
        container = None

        try:
            logger.info("启动判题容器: language={}, image={}", language, image)
            container = self.docker_client.containers.run(**container_config)

            # 等待容器执行完成
            result = container.wait(timeout=timeout_seconds)
            exit_code = result.get("StatusCode", -1)

            # 获取标准输出
            stdout = container.logs(stdout=True, stderr=False).decode("utf-8", errors="replace")
            # 获取标准错误
            stderr = container.logs(stdout=False, stderr=True).decode("utf-8", errors="replace")

            # 获取资源使用统计
            stats = container.stats(stream=False)
            memory_used_kb = self._get_memory_usage(stats)
            time_used_ms = self._get_cpu_time(stats)

            if exit_code == 0:
                status = "ACCEPTED"
            elif exit_code == 137:
                # 被 SIGKILL 杀死，可能是 OOM
                status = "MEMORY_LIMIT_EXCEEDED"
            elif exit_code == 124:
                status = "TIME_LIMIT_EXCEEDED"
            else:
                status = "RUNTIME_ERROR"

            return {
                "status": status,
                "output": stdout,
                "error": stderr,
                "time_ms": time_used_ms,
                "memory_kb": memory_used_kb,
            }

        except docker.errors.ContainerError as e:
            logger.error("容器执行异常: {}", str(e))
            return {
                "status": "RUNTIME_ERROR",
                "output": "",
                "error": str(e),
                "time_ms": 0,
                "memory_kb": 0,
            }
        except docker.errors.ImageNotFound:
            logger.error("Docker 镜像未找到: {}", image)
            return {
                "status": "SYSTEM_ERROR",
                "output": "",
                "error": f"Docker 镜像未找到: {image}",
                "time_ms": 0,
                "memory_kb": 0,
            }
        except Exception as e:
            logger.error("运行异常: {}", str(e))
            return {
                "status": "SYSTEM_ERROR",
                "output": "",
                "error": str(e),
                "time_ms": 0,
                "memory_kb": 0,
            }
        finally:
            # 确保容器被清理
            if container is not None:
                try:
                    container.remove(force=True)
                except Exception:
                    pass

    def _get_run_config(self, language: str) -> tuple[str, list[str]]:
        """
        获取语言对应的 Docker 镜像和运行命令

        Args:
            language: 编程语言

        Returns:
            (镜像名, 运行命令)
        """
        configs = {
            "JAVA": (
                "oj-judge-java",
                [
                    "sh",
                    "-c",
                    "java -cp /home/judge/code Main < /home/judge/input.txt",
                ],
            ),
            "PYTHON": (
                "oj-judge-python",
                [
                    "sh",
                    "-c",
                    "python3 /home/judge/code/main.py < /home/judge/input.txt",
                ],
            ),
            "CPP": (
                "oj-judge-cpp",
                [
                    "sh",
                    "-c",
                    "/home/judge/code/main < /home/judge/input.txt",
                ],
            ),
        }
        if language not in configs:
            raise ValueError(f"不支持的编程语言: {language}")
        return configs[language]

    @staticmethod
    def _get_memory_usage(stats: dict) -> int:
        """从 Docker 统计信息中提取内存使用量（KB）"""
        try:
            memory_stats = stats.get("memory_stats", {})
            usage = memory_stats.get("usage", 0)
            # 减去缓存
            cache = memory_stats.get("stats", {}).get("cache", 0)
            return max(0, (usage - cache)) // 1024
        except (KeyError, TypeError):
            return 0

    @staticmethod
    def _get_cpu_time(stats: dict) -> int:
        """从 Docker 统计信息中提取 CPU 使用时间（毫秒）"""
        try:
            cpu_stats = stats.get("cpu_stats", {})
            cpu_usage = cpu_stats.get("cpu_usage", {})
            total_cpu = cpu_usage.get("total_usage", 0)
            return total_cpu // 1_000_000  # 纳秒转毫秒
        except (KeyError, TypeError):
            return 0
