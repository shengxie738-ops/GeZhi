import os
import subprocess
from pathlib import Path

from loguru import logger


class Compiler:
    """代码编译器，负责将源代码编译为可执行文件"""

    COMPILE_TIMEOUT = 30  # 编译超时（秒）

    @staticmethod
    def compile_java(source_code: str, work_dir: str) -> tuple[bool, str]:
        """
        编译 Java 源代码

        Args:
            source_code: Java 源代码
            work_dir: 工作目录

        Returns:
            (是否成功, 编译输出信息)
        """
        source_path = Path(work_dir) / "Main.java"
        source_path.write_text(source_code, encoding="utf-8")

        try:
            result = subprocess.run(
                ["javac", str(source_path)],
                capture_output=True,
                text=True,
                timeout=Compiler.COMPILE_TIMEOUT,
                cwd=work_dir,
            )
            if result.returncode != 0:
                logger.warning("Java 编译失败: {}", result.stderr)
                return False, result.stderr
            logger.info("Java 编译成功")
            return True, ""
        except subprocess.TimeoutExpired:
            logger.error("Java 编译超时")
            return False, "编译超时"
        except FileNotFoundError:
            logger.error("javac 未找到，请确保已安装 JDK")
            return False, "javac 未找到"

    @staticmethod
    def compile_cpp(source_code: str, work_dir: str) -> tuple[bool, str]:
        """
        编译 C++ 源代码

        Args:
            source_code: C++ 源代码
            work_dir: 工作目录

        Returns:
            (是否成功, 编译输出信息)
        """
        source_path = Path(work_dir) / "main.cpp"
        source_path.write_text(source_code, encoding="utf-8")
        output_path = Path(work_dir) / "main"

        try:
            result = subprocess.run(
                [
                    "g++",
                    "-std=c++17",
                    "-O2",
                    "-Wall",
                    "-o",
                    str(output_path),
                    str(source_path),
                ],
                capture_output=True,
                text=True,
                timeout=Compiler.COMPILE_TIMEOUT,
                cwd=work_dir,
            )
            if result.returncode != 0:
                logger.warning("C++ 编译失败: {}", result.stderr)
                return False, result.stderr
            logger.info("C++ 编译成功")
            return True, ""
        except subprocess.TimeoutExpired:
            logger.error("C++ 编译超时")
            return False, "编译超时"
        except FileNotFoundError:
            logger.error("g++ 未找到，请确保已安装 GCC")
            return False, "g++ 未找到"
