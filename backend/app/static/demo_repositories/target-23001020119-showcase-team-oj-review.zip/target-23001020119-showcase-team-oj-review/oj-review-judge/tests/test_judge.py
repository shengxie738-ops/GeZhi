"""判题服务单元测试"""

import pytest
from app.judge.comparator import Comparator
from app.judge.limiter import ResourceLimiter


class TestComparator:
    """输出比较器测试"""

    def test_identical_output(self):
        assert Comparator.compare("hello\nworld\n", "hello\nworld\n") is True

    def test_trailing_whitespace(self):
        assert Comparator.compare("hello\nworld", "hello  \nworld   ") is True

    def test_trailing_blank_lines(self):
        assert Comparator.compare("hello\n", "hello\n\n\n") is True

    def test_different_content(self):
        assert Comparator.compare("hello\n", "world\n") is False

    def test_empty_outputs(self):
        assert Comparator.compare("", "") is True

    def test_one_empty_one_not(self):
        assert Comparator.compare("hello", "") is False

    def test_normalize_removes_trailing_spaces(self):
        assert Comparator.normalize("  hello  \n  world  \n") == "  hello\n  world"

    def test_normalize_removes_trailing_blank_lines(self):
        assert Comparator.normalize("hello\n\n\n") == "hello"

    def test_multiline_with_mixed_whitespace(self):
        expected = "1 2 3\n4 5 6\n"
        actual = "1 2 3  \n4 5 6\t\n"
        assert Comparator.compare(expected, actual) is True

    def test_windows_line_endings(self):
        expected = "hello\r\nworld\r\n"
        actual = "hello\nworld\n"
        # \r\n 经过 rstrip 后 \r 会被去除
        assert Comparator.compare(expected, actual) is True


class TestResourceLimiter:
    """资源限制器测试"""

    def test_basic_config(self):
        config = ResourceLimiter.get_container_config(
            time_limit_ms=1000,
            memory_limit_mb=256,
            image="test-image",
        )
        assert config["image"] == "test-image"
        assert config["mem_limit"] == "256m"
        assert config["memswap_limit"] == "256m"
        assert config["network_disabled"] is True
        assert config["read_only"] is True
        assert config["pids_limit"] == 64
        assert config["user"] == "judge"
        assert "no-new-privileges" in config["security_opt"]

    def test_cpu_scaling(self):
        config = ResourceLimiter.get_container_config(
            time_limit_ms=1000,
            memory_limit_mb=512,
            image="test-image",
        )
        # 512MB / 256 = 2 cores
        assert config["cpu_quota"] == 200000

    def test_minimum_cpu_cores(self):
        config = ResourceLimiter.get_container_config(
            time_limit_ms=1000,
            memory_limit_mb=64,
            image="test-image",
        )
        # 最少 1 个核心
        assert config["cpu_quota"] == 100000

    def test_with_command_and_volumes(self):
        config = ResourceLimiter.get_container_config(
            time_limit_ms=2000,
            memory_limit_mb=256,
            image="test-image",
            command=["python3", "main.py"],
            volumes={"/tmp/code": {"bind": "/code", "mode": "ro"}},
        )
        assert config["command"] == ["python3", "main.py"]
        assert "/tmp/code" in config["volumes"]

    def test_timeout_conversion(self):
        assert ResourceLimiter.get_timeout_seconds(1000) == 2.0
        assert ResourceLimiter.get_timeout_seconds(5000) == 6.0
        assert ResourceLimiter.get_timeout_seconds(100) == 1.1


class TestSchemas:
    """数据模型测试"""

    def test_judge_task_creation(self):
        from app.schemas.judge import JudgeTask, TestCase

        task = JudgeTask(
            submission_id=1,
            problem_id=100,
            language="PYTHON",
            source_code="print(input())",
            time_limit_ms=1000,
            memory_limit_mb=256,
            test_cases=[
                TestCase(
                    id=1,
                    input_data="5",
                    expected_output="5",
                    is_public=True,
                    score=10.0,
                )
            ],
        )
        assert task.submission_id == 1
        assert task.language == "PYTHON"
        assert len(task.test_cases) == 1

    def test_judge_result_creation(self):
        from app.schemas.judge import JudgeResult, CaseResult

        result = JudgeResult(
            submission_id=1,
            status="ACCEPTED",
            score=100.0,
            passed_case_count=3,
            total_case_count=3,
            time_used_ms=50,
            memory_used_kb=1024,
            compile_output="",
            runtime_output="",
            case_results=[
                CaseResult(
                    test_case_id=1,
                    status="ACCEPTED",
                    time_used_ms=10,
                    memory_used_kb=512,
                    actual_output="5",
                    error_message="",
                )
            ],
        )
        assert result.status == "ACCEPTED"
        assert result.score == 100.0

    def test_case_result_defaults(self):
        from app.schemas.judge import CaseResult

        cr = CaseResult(
            test_case_id=1,
            status="ACCEPTED",
            time_used_ms=10,
            memory_used_kb=512,
        )
        assert cr.actual_output == ""
        assert cr.error_message == ""
