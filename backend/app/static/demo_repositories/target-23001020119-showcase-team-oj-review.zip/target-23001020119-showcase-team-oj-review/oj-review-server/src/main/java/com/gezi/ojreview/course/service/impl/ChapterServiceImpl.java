package com.gezi.ojreview.course.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gezi.ojreview.common.api.ErrorCode;
import com.gezi.ojreview.common.exception.BusinessException;
import com.gezi.ojreview.course.dto.ChapterCreateDTO;
import com.gezi.ojreview.course.entity.CourseChapter;
import com.gezi.ojreview.course.mapper.CourseChapterMapper;
import com.gezi.ojreview.course.service.ChapterService;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

/**
 * 章节服务实现
 */
@Service
public class ChapterServiceImpl extends ServiceImpl<CourseChapterMapper, CourseChapter> implements ChapterService {

    @Override
    public CourseChapter createChapter(Long courseId, ChapterCreateDTO dto) {
        CourseChapter chapter = new CourseChapter();
        chapter.setCourseId(courseId);
        chapter.setTitle(dto.getTitle());
        chapter.setDescription(dto.getDescription());
        chapter.setSortOrder(dto.getSortOrder());
        save(chapter);
        return chapter;
    }

    @Override
    public void updateChapter(Long chapterId, ChapterCreateDTO dto) {
        CourseChapter chapter = getById(chapterId);
        if (chapter == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND, "章节不存在");
        }
        if (StringUtils.hasText(dto.getTitle())) {
            chapter.setTitle(dto.getTitle());
        }
        if (dto.getDescription() != null) {
            chapter.setDescription(dto.getDescription());
        }
        if (dto.getSortOrder() != null) {
            chapter.setSortOrder(dto.getSortOrder());
        }
        updateById(chapter);
    }

    @Override
    public void deleteChapter(Long chapterId) {
        if (getById(chapterId) == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND, "章节不存在");
        }
        removeById(chapterId);
    }

    @Override
    public List<CourseChapter> listChapters(Long courseId) {
        return list(new LambdaQueryWrapper<CourseChapter>()
                .eq(CourseChapter::getCourseId, courseId)
                .orderByAsc(CourseChapter::getSortOrder));
    }
}
