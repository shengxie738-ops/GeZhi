package com.gezi.ojreview.wrongbook.controller;

import com.gezi.ojreview.common.api.PageResult;
import com.gezi.ojreview.common.api.Result;
import com.gezi.ojreview.common.security.UserDetailsImpl;
import com.gezi.ojreview.config.WebMvcConfig;
import com.gezi.ojreview.wrongbook.dto.WrongBookUpdateDTO;
import com.gezi.ojreview.wrongbook.entity.WrongBook;
import com.gezi.ojreview.wrongbook.service.WrongBookService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * 错题本控制器
 */
@Tag(name = "错题本管理")
@RestController
@RequestMapping("/api/v1/wrong-book")
@RequiredArgsConstructor
public class WrongBookController {

    private final WrongBookService wrongBookService;

    @Operation(summary = "获取错题本列表")
    @GetMapping
    public Result<PageResult<WrongBook>> listWrongBooks(
            @RequestParam(required = false) String status,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size,
            @WebMvcConfig.CurrentUser UserDetailsImpl currentUser) {
        PageResult<WrongBook> result = wrongBookService.listByUserId(
                currentUser.getUserId(), status, page, size);
        return Result.ok(result);
    }

    @Operation(summary = "更新错题状态")
    @PutMapping("/{id}")
    public Result<Void> updateWrongBook(@PathVariable Long id,
                                        @Valid @RequestBody WrongBookUpdateDTO dto) {
        wrongBookService.updateWrongBook(id, dto);
        return Result.ok();
    }

    @Operation(summary = "删除错题记录")
    @DeleteMapping("/{id}")
    public Result<Void> deleteWrongBook(@PathVariable Long id) {
        wrongBookService.deleteWrongBook(id);
        return Result.ok();
    }
}
