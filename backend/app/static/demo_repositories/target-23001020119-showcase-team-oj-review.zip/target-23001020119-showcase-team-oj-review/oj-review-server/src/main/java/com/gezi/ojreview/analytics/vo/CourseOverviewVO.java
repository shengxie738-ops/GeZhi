package com.gezi.ojreview.analytics.vo;

import lombok.Data;

/**
 * 课程概览VO
 */
@Data
public class CourseOverviewVO {

    private long studentCount;

    private long submissionCount;

    private long acceptedCount;

    private long activeStudentCount;
}
