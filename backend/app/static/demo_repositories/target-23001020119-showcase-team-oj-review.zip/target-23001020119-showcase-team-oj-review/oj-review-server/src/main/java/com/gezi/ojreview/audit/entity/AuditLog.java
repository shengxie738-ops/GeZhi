package com.gezi.ojreview.audit.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 审计日志实体
 * 记录系统中的重要操作，用于安全审计和问题追踪
 */
@Data
@TableName("audit_log")
public class AuditLog {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 操作人ID */
    private Long userId;

    /** 操作人用户名 */
    private String username;

    /** 操作类型（如：LOGIN, CREATE, UPDATE, DELETE, SUBMIT） */
    private String action;

    /** 操作模块（如：USER, COURSE, PROBLEM, SUBMISSION） */
    private String module;

    /** 操作描述 */
    private String description;

    /** 请求方法（GET, POST, PUT, DELETE） */
    private String requestMethod;

    /** 请求URL */
    private String requestUrl;

    /** 请求IP */
    private String ip;

    /** 操作结果（0-失败, 1-成功） */
    private Integer result;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
}
