package com.gezi.ojreview.analytics.controller;

import com.gezi.ojreview.analytics.service.AnalyticsService;
import com.gezi.ojreview.analytics.vo.CourseOverviewVO;
import com.gezi.ojreview.analytics.vo.ProblemStatsVO;
import com.gezi.ojreview.analytics.vo.StudentStatsVO;
import com.gezi.ojreview.common.api.Result;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 分析控制器（教师端）
 */
@Tag(name = "数据分析")
@RestController
@RequestMapping("/api/v1/teacher/analytics")
@RequiredArgsConstructor
@PreAuthorize("hasRole('TEACHER') or hasRole('ADMIN')")
public class AnalyticsController {

    private final AnalyticsService analyticsService;

    @Operation(summary = "获取课程概览")
    @GetMapping("/courses/{courseId}/overview")
    public Result<CourseOverviewVO> getCourseOverview(@PathVariable Long courseId) {
        CourseOverviewVO overview = analyticsService.getCourseOverview(courseId);
        return Result.ok(overview);
    }

    @Operation(summary = "获取题目统计")
    @GetMapping("/courses/{courseId}/problems")
    public Result<List<ProblemStatsVO>> getProblemStats(@PathVariable Long courseId) {
        List<ProblemStatsVO> stats = analyticsService.getProblemStats(courseId);
        return Result.ok(stats);
    }

    @Operation(summary = "获取学生统计")
    @GetMapping("/courses/{courseId}/students")
    public Result<List<StudentStatsVO>> getStudentStats(@PathVariable Long courseId) {
        List<StudentStatsVO> stats = analyticsService.getStudentStats(courseId);
        return Result.ok(stats);
    }

    @Operation(summary = "获取提交趋势")
    @GetMapping("/courses/{courseId}/trend")
    public Result<Map<String, Object>> getSubmissionTrend(
            @PathVariable Long courseId,
            @RequestParam(defaultValue = "30") int days) {
        Map<String, Object> trend = analyticsService.getSubmissionTrend(courseId, days);
        return Result.ok(trend);
    }

    @Operation(summary = "获取错误分布")
    @GetMapping("/courses/{courseId}/errors")
    public Result<Map<String, Object>> getErrorDistribution(@PathVariable Long courseId) {
        Map<String, Object> distribution = analyticsService.getErrorDistribution(courseId);
        return Result.ok(distribution);
    }
}
