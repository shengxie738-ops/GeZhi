package com.gezi.ojreview.notification.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gezi.ojreview.common.api.ErrorCode;
import com.gezi.ojreview.common.api.PageResult;
import com.gezi.ojreview.common.exception.BusinessException;
import com.gezi.ojreview.common.util.PageUtil;
import com.gezi.ojreview.notification.entity.Notification;
import com.gezi.ojreview.notification.mapper.NotificationMapper;
import com.gezi.ojreview.notification.service.NotificationService;
import org.springframework.stereotype.Service;

/**
 * 通知服务实现
 */
@Service
public class NotificationServiceImpl extends ServiceImpl<NotificationMapper, Notification> implements NotificationService {

    @Override
    public void sendNotification(Long userId, String title, String content, String type, Long relatedId) {
        Notification notification = new Notification();
        notification.setUserId(userId);
        notification.setTitle(title);
        notification.setContent(content);
        notification.setType(type);
        notification.setIsRead(0);
        notification.setRelatedId(relatedId);
        save(notification);
    }

    @Override
    public PageResult<Notification> listByUserId(Long userId, Boolean isRead, int page, int size) {
        Page<Notification> pageParam = PageUtil.createPage(page, size);
        LambdaQueryWrapper<Notification> wrapper = new LambdaQueryWrapper<Notification>()
                .eq(Notification::getUserId, userId);
        if (isRead != null) {
            wrapper.eq(Notification::getIsRead, isRead ? 1 : 0);
        }
        wrapper.orderByDesc(Notification::getCreateTime);

        Page<Notification> result = page(pageParam, wrapper);
        return PageUtil.toPageResult(result);
    }

    @Override
    public void markAsRead(Long notificationId) {
        Notification notification = getById(notificationId);
        if (notification == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND, "通知不存在");
        }
        notification.setIsRead(1);
        updateById(notification);
    }

    @Override
    public void markAllAsRead(Long userId) {
        update(new LambdaUpdateWrapper<Notification>()
                .eq(Notification::getUserId, userId)
                .eq(Notification::getIsRead, 0)
                .set(Notification::getIsRead, 1));
    }

    @Override
    public long getUnreadCount(Long userId) {
        return count(new LambdaQueryWrapper<Notification>()
                .eq(Notification::getUserId, userId)
                .eq(Notification::getIsRead, 0));
    }

    @Override
    public void deleteNotification(Long notificationId) {
        if (getById(notificationId) == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND, "通知不存在");
        }
        removeById(notificationId);
    }
}
