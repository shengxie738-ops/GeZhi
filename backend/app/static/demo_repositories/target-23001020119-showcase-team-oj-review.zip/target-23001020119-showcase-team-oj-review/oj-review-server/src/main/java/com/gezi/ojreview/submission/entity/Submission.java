package com.gezi.ojreview.submission.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 提交实体
 */
@Data
@TableName("submission")
public class Submission {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long userId;

    private Long problemId;

    private Long courseId;

    private String language;

    private String code;

    private String status;

    private Long timeUsed;

    private Long memoryUsed;

    private Integer testCasesPassed;

    private Integer testCasesTotal;

    private String compileOutput;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
}
