package com.gezi.ojreview.judge.service.impl;

import com.gezi.ojreview.judge.dto.JudgeCallbackDTO;
import com.gezi.ojreview.judge.service.JudgeService;
import com.gezi.ojreview.submission.entity.Submission;
import com.gezi.ojreview.submission.service.SubmissionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

/**
 * 判题服务实现
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class JudgeServiceImpl implements JudgeService {

    private final RedisTemplate<String, Object> redisTemplate;
    private final SubmissionService submissionService;
    private final SimpMessagingTemplate messagingTemplate;
    private final RestTemplate restTemplate;

    @Value("${judge.service-url}")
    private String judgeServiceUrl;

    @Value("${judge.internal-token}")
    private String internalToken;

    private static final String JUDGE_QUEUE_KEY = "judge:queue";
    private static final String JUDGE_STATUS_PREFIX = "judge:status:";

    @Override
    public void sendToJudgeQueue(Long submissionId) {
        redisTemplate.opsForList().rightPush(JUDGE_QUEUE_KEY, submissionId);
        redisTemplate.opsForValue().set(JUDGE_STATUS_PREFIX + submissionId, "QUEUING");
        log.info("提交任务已加入判题队列: submissionId={}", submissionId);
    }

    @Override
    public void handleCallback(JudgeCallbackDTO callbackDTO) {
        Long submissionId = callbackDTO.getSubmissionId();
        String status = callbackDTO.getStatus();

        submissionService.updateSubmissionStatus(
                submissionId,
                status,
                callbackDTO.getTimeUsed(),
                callbackDTO.getMemoryUsed(),
                callbackDTO.getTestCasesPassed(),
                callbackDTO.getTestCasesTotal(),
                callbackDTO.getCompileOutput()
        );

        redisTemplate.opsForValue().set(JUDGE_STATUS_PREFIX + submissionId, status);

        Map<String, Object> message = new HashMap<>();
        message.put("submissionId", submissionId);
        message.put("status", status);
        message.put("timeUsed", callbackDTO.getTimeUsed());
        message.put("memoryUsed", callbackDTO.getMemoryUsed());

        messagingTemplate.convertAndSend("/topic/submission/" + submissionId, message);

        log.info("判题回调处理完成: submissionId={}, status={}", submissionId, status);
    }

    @Override
    public String getJudgeStatus(Long submissionId) {
        Object status = redisTemplate.opsForValue().get(JUDGE_STATUS_PREFIX + submissionId);
        return status != null ? status.toString() : null;
    }
}
