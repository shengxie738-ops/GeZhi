package com.gezi.ojreview.analytics.service;

import com.gezi.ojreview.analytics.vo.CourseOverviewVO;
import com.gezi.ojreview.analytics.vo.ProblemStatsVO;
import com.gezi.ojreview.analytics.vo.StudentStatsVO;

import java.util.List;
import java.util.Map;

/**
 * 分析服务接口
 */
public interface AnalyticsService {

    /**
     * 获取课程概览统计
     */
    CourseOverviewVO getCourseOverview(Long courseId);

    /**
     * 获取题目统计列表
     */
    List<ProblemStatsVO> getProblemStats(Long courseId);

    /**
     * 获取学生统计列表
     */
    List<StudentStatsVO> getStudentStats(Long courseId);

    /**
     * 获取提交趋势数据
     */
    Map<String, Object> getSubmissionTrend(Long courseId, int days);

    /**
     * 获取错误分布数据
     */
    Map<String, Object> getErrorDistribution(Long courseId);
}
