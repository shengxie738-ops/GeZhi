package com.gezi.ojreview.team.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * 团队成员DTO
 */
@Data
public class TeamMemberDTO {

    @NotNull(message = "用户ID不能为空")
    private Long userId;
}
