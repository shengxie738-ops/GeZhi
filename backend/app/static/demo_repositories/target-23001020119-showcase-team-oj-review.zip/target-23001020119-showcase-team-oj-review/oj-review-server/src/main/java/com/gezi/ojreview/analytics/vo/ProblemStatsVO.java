package com.gezi.ojreview.analytics.vo;

import lombok.Data;

/**
 * 题目统计VO
 */
@Data
public class ProblemStatsVO {

    private Long problemId;

    private String title;

    private String difficulty;

    private long submitCount;

    private long acceptedCount;

    private double acceptanceRate;
}
