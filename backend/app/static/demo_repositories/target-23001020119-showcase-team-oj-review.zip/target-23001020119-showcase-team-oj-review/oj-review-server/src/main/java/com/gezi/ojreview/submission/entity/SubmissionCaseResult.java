package com.gezi.ojreview.submission.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 测试点结果实体
 */
@Data
@TableName("submission_case_result")
public class SubmissionCaseResult {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long submissionId;

    private Integer caseIndex;

    private String status;

    private Long timeUsed;

    private Long memoryUsed;

    private String input;

    private String expectedOutput;

    private String actualOutput;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
}
