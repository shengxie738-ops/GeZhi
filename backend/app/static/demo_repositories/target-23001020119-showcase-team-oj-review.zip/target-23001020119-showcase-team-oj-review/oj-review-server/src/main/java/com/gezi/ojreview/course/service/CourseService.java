package com.gezi.ojreview.course.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gezi.ojreview.common.api.PageResult;
import com.gezi.ojreview.course.dto.CourseCreateDTO;
import com.gezi.ojreview.course.dto.CourseUpdateDTO;
import com.gezi.ojreview.course.entity.Course;

import java.util.List;

/**
 * 课程服务接口
 */
public interface CourseService extends IService<Course> {

    Course createCourse(CourseCreateDTO dto, Long creatorId);

    void updateCourse(Long courseId, CourseUpdateDTO dto);

    PageResult<Course> listCourses(int page, int size, String keyword, String status);

    Course getCourseById(Long courseId);

    void deleteCourse(Long courseId);

    List<Course> listCoursesByUserId(Long userId);
}
