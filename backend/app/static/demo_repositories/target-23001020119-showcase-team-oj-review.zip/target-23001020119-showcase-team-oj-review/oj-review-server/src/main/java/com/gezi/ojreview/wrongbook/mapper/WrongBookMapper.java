package com.gezi.ojreview.wrongbook.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gezi.ojreview.wrongbook.entity.WrongBook;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface WrongBookMapper extends BaseMapper<WrongBook> {
}
