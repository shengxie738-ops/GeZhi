package com.gezi.ojreview.course.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gezi.ojreview.course.entity.CourseMember;

import java.util.List;

/**
 * 课程成员服务接口
 */
public interface CourseMemberService extends IService<CourseMember> {

    void addMember(Long courseId, Long userId, String role);

    void removeMember(Long courseId, Long userId);

    List<CourseMember> listMembers(Long courseId);

    boolean isMember(Long courseId, Long userId);

    List<Long> getStudentIds(Long courseId);
}
