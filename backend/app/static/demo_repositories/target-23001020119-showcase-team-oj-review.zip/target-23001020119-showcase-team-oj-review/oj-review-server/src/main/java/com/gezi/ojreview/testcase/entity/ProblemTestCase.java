package com.gezi.ojreview.testcase.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 测试用例实体
 */
@Data
@TableName("problem_test_case")
public class ProblemTestCase {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long problemId;

    private String input;

    private String expectedOutput;

    private Integer sortOrder;

    private Integer isHidden;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}
