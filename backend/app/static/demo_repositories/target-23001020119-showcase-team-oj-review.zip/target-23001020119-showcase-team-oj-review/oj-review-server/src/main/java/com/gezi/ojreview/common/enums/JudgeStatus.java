package com.gezi.ojreview.common.enums;

import lombok.Getter;

/**
 * 判题状态枚举
 */
@Getter
public enum JudgeStatus {

    PENDING("PENDING", "等待中"),
    QUEUING("QUEUING", "排队中"),
    COMPILING("COMPILING", "编译中"),
    RUNNING("RUNNING", "运行中"),
    ACCEPTED("ACCEPTED", "通过"),
    WRONG_ANSWER("WRONG_ANSWER", "答案错误"),
    TIME_LIMIT_EXCEEDED("TIME_LIMIT_EXCEEDED", "超时"),
    MEMORY_LIMIT_EXCEEDED("MEMORY_LIMIT_EXCEEDED", "内存超限"),
    RUNTIME_ERROR("RUNTIME_ERROR", "运行时错误"),
    COMPILE_ERROR("COMPILE_ERROR", "编译错误"),
    OUTPUT_LIMIT_EXCEEDED("OUTPUT_LIMIT_EXCEEDED", "输出超限"),
    SYSTEM_ERROR("SYSTEM_ERROR", "系统错误");

    private final String code;
    private final String description;

    JudgeStatus(String code, String description) {
        this.code = code;
        this.description = description;
    }
}
