package com.gezi.ojreview.team.controller;

import com.gezi.ojreview.common.api.Result;
import com.gezi.ojreview.common.security.UserDetailsImpl;
import com.gezi.ojreview.config.WebMvcConfig;
import com.gezi.ojreview.team.dto.TeamCreateDTO;
import com.gezi.ojreview.team.dto.TeamMemberDTO;
import com.gezi.ojreview.team.entity.Team;
import com.gezi.ojreview.team.service.TeamService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 团队控制器
 */
@Tag(name = "团队管理")
@RestController
@RequestMapping("/api/v1/teams")
@RequiredArgsConstructor
public class TeamController {

    private final TeamService teamService;

    @Operation(summary = "创建团队")
    @PostMapping
    public Result<Team> createTeam(@Valid @RequestBody TeamCreateDTO dto,
                                   @WebMvcConfig.CurrentUser UserDetailsImpl currentUser) {
        Team team = teamService.createTeam(dto, currentUser.getUserId());
        return Result.ok(team);
    }

    @Operation(summary = "获取团队详情")
    @GetMapping("/{id}")
    public Result<Team> getTeam(@PathVariable Long id) {
        Team team = teamService.getTeamById(id);
        return Result.ok(team);
    }

    @Operation(summary = "获取课程下的团队列表")
    @GetMapping
    public Result<List<Team>> listTeams(@RequestParam Long courseId) {
        List<Team> teams = teamService.listTeams(courseId);
        return Result.ok(teams);
    }

    @Operation(summary = "获取我的团队列表")
    @GetMapping("/mine")
    public Result<List<Team>> myTeams(@WebMvcConfig.CurrentUser UserDetailsImpl currentUser) {
        List<Team> teams = teamService.listTeamsByUserId(currentUser.getUserId());
        return Result.ok(teams);
    }

    @Operation(summary = "删除团队")
    @DeleteMapping("/{id}")
    public Result<Void> deleteTeam(@PathVariable Long id) {
        teamService.deleteTeam(id);
        return Result.ok();
    }

    @Operation(summary = "添加团队成员")
    @PostMapping("/{teamId}/members")
    public Result<Void> addMember(@PathVariable Long teamId, @Valid @RequestBody TeamMemberDTO dto) {
        teamService.addMember(teamId, dto);
        return Result.ok();
    }

    @Operation(summary = "移除团队成员")
    @DeleteMapping("/{teamId}/members/{userId}")
    public Result<Void> removeMember(@PathVariable Long teamId, @PathVariable Long userId) {
        teamService.removeMember(teamId, userId);
        return Result.ok();
    }
}
