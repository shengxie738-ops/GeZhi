package com.gezi.ojreview.course.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * 创建课程DTO
 */
@Data
public class CourseCreateDTO {

    @NotBlank(message = "课程名称不能为空")
    private String name;

    private String description;

    private String coverImage;

    private String term;
}
