package com.gezi.ojreview.team.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gezi.ojreview.team.dto.TeamCreateDTO;
import com.gezi.ojreview.team.dto.TeamMemberDTO;
import com.gezi.ojreview.team.entity.Team;

import java.util.List;

/**
 * 团队服务接口
 */
public interface TeamService extends IService<Team> {

    Team createTeam(TeamCreateDTO dto, Long leaderId);

    void deleteTeam(Long teamId);

    Team getTeamById(Long teamId);

    List<Team> listTeams(Long courseId);

    void addMember(Long teamId, TeamMemberDTO dto);

    void removeMember(Long teamId, Long userId);

    List<Team> listTeamsByUserId(Long userId);
}
