package com.gezi.ojreview.common.enums;

import lombok.Getter;

/**
 * 用户角色枚举
 */
@Getter
public enum UserRole {

    /** 学生 */
    STUDENT("STUDENT", "学生"),

    /** 教师 */
    TEACHER("TEACHER", "教师"),

    /** 管理员 */
    ADMIN("ADMIN", "管理员");

    private final String code;
    private final String description;

    UserRole(String code, String description) {
        this.code = code;
        this.description = description;
    }
}
