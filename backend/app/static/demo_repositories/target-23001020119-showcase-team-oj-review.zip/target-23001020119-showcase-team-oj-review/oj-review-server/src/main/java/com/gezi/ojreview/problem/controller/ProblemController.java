package com.gezi.ojreview.problem.controller;

import com.gezi.ojreview.common.api.PageResult;
import com.gezi.ojreview.common.api.Result;
import com.gezi.ojreview.common.security.UserDetailsImpl;
import com.gezi.ojreview.config.WebMvcConfig;
import com.gezi.ojreview.problem.dto.ProblemCreateDTO;
import com.gezi.ojreview.problem.dto.ProblemQueryDTO;
import com.gezi.ojreview.problem.dto.ProblemUpdateDTO;
import com.gezi.ojreview.problem.entity.Problem;
import com.gezi.ojreview.problem.service.ProblemService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * 题目控制器
 */
@Tag(name = "题目管理")
@RestController
@RequestMapping("/api/v1/problems")
@RequiredArgsConstructor
public class ProblemController {

    private final ProblemService problemService;

    @Operation(summary = "创建题目")
    @PostMapping
    @PreAuthorize("hasRole('TEACHER') or hasRole('ADMIN')")
    public Result<Problem> createProblem(@Valid @RequestBody ProblemCreateDTO dto,
                                         @WebMvcConfig.CurrentUser UserDetailsImpl currentUser) {
        Problem problem = problemService.createProblem(dto, currentUser.getUserId());
        return Result.ok(problem);
    }

    @Operation(summary = "获取题目详情")
    @GetMapping("/{id}")
    public Result<Problem> getProblem(@PathVariable Long id) {
        Problem problem = problemService.getProblemById(id);
        return Result.ok(problem);
    }

    @Operation(summary = "分页查询题目列表")
    @GetMapping
    public Result<PageResult<Problem>> listProblems(ProblemQueryDTO queryDTO) {
        PageResult<Problem> result = problemService.listProblems(queryDTO);
        return Result.ok(result);
    }

    @Operation(summary = "更新题目")
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('TEACHER') or hasRole('ADMIN')")
    public Result<Void> updateProblem(@PathVariable Long id,
                                      @Valid @RequestBody ProblemUpdateDTO dto) {
        problemService.updateProblem(id, dto);
        return Result.ok();
    }

    @Operation(summary = "删除题目")
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> deleteProblem(@PathVariable Long id) {
        problemService.deleteProblem(id);
        return Result.ok();
    }
}
