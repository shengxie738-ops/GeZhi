package com.gezi.ojreview.auth.service;

import com.gezi.ojreview.auth.dto.LoginDTO;
import com.gezi.ojreview.auth.dto.RefreshTokenDTO;
import com.gezi.ojreview.auth.dto.RegisterDTO;
import com.gezi.ojreview.auth.vo.LoginVO;
import com.gezi.ojreview.auth.vo.UserVO;

/**
 * 认证服务接口
 */
public interface AuthService {

    /**
     * 用户登录
     */
    LoginVO login(LoginDTO dto);

    /**
     * 用户注册
     */
    void register(RegisterDTO dto);

    /**
     * 刷新Token
     */
    LoginVO refreshToken(RefreshTokenDTO dto);

    /**
     * 用户登出
     */
    void logout(String authorization);

    /**
     * 获取当前用户信息
     */
    UserVO getCurrentUser(Long userId);
}
