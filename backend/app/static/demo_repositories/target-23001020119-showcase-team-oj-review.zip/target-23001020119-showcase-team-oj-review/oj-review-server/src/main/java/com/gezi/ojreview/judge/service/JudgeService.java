package com.gezi.ojreview.judge.service;

import com.gezi.ojreview.judge.dto.JudgeCallbackDTO;

/**
 * 判题服务接口
 */
public interface JudgeService {

    /**
     * 发送判题任务到队列
     */
    void sendToJudgeQueue(Long submissionId);

    /**
     * 处理判题回调
     */
    void handleCallback(JudgeCallbackDTO callbackDTO);

    /**
     * 获取判题状态
     */
    String getJudgeStatus(Long submissionId);
}
