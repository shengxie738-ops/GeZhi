package com.gezi.ojreview.notification.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gezi.ojreview.common.api.PageResult;
import com.gezi.ojreview.notification.entity.Notification;

/**
 * 通知服务接口
 */
public interface NotificationService extends IService<Notification> {

    /**
     * 发送通知
     */
    void sendNotification(Long userId, String title, String content, String type, Long relatedId);

    /**
     * 分页查询用户通知
     */
    PageResult<Notification> listByUserId(Long userId, Boolean isRead, int page, int size);

    /**
     * 标记通知为已读
     */
    void markAsRead(Long notificationId);

    /**
     * 标记所有通知为已读
     */
    void markAllAsRead(Long userId);

    /**
     * 获取未读通知数量
     */
    long getUnreadCount(Long userId);

    /**
     * 删除通知
     */
    void deleteNotification(Long notificationId);
}
