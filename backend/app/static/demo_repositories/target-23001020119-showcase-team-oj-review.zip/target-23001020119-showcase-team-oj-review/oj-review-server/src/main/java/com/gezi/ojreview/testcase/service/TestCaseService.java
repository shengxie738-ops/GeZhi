package com.gezi.ojreview.testcase.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gezi.ojreview.testcase.entity.ProblemTestCase;

import java.util.List;

/**
 * 测试用例服务接口
 */
public interface TestCaseService extends IService<ProblemTestCase> {

    List<ProblemTestCase> listByProblemId(Long problemId);

    ProblemTestCase addTestCase(ProblemTestCase testCase);

    void updateTestCase(ProblemTestCase testCase);

    void deleteTestCase(Long testCaseId);

    void deleteByProblemId(Long problemId);
}
