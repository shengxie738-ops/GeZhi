package com.gezi.ojreview.course.controller;

import com.gezi.ojreview.common.api.PageResult;
import com.gezi.ojreview.common.api.Result;
import com.gezi.ojreview.common.security.UserDetailsImpl;
import com.gezi.ojreview.config.WebMvcConfig;
import com.gezi.ojreview.course.dto.CourseCreateDTO;
import com.gezi.ojreview.course.dto.CourseUpdateDTO;
import com.gezi.ojreview.course.entity.Course;
import com.gezi.ojreview.course.service.CourseMemberService;
import com.gezi.ojreview.course.service.CourseService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 课程控制器
 */
@Tag(name = "课程管理")
@RestController
@RequestMapping("/api/v1/courses")
@RequiredArgsConstructor
public class CourseController {

    private final CourseService courseService;
    private final CourseMemberService courseMemberService;

    @Operation(summary = "创建课程")
    @PostMapping
    @PreAuthorize("hasRole('TEACHER') or hasRole('ADMIN')")
    public Result<Course> createCourse(@Valid @RequestBody CourseCreateDTO dto,
                                       @WebMvcConfig.CurrentUser UserDetailsImpl currentUser) {
        Course course = courseService.createCourse(dto, currentUser.getUserId());
        return Result.ok(course);
    }

    @Operation(summary = "获取课程详情")
    @GetMapping("/{id}")
    public Result<Course> getCourse(@PathVariable Long id) {
        Course course = courseService.getCourseById(id);
        return Result.ok(course);
    }

    @Operation(summary = "分页查询课程列表")
    @GetMapping
    public Result<PageResult<Course>> listCourses(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String status) {
        PageResult<Course> result = courseService.listCourses(page, size, keyword, status);
        return Result.ok(result);
    }

    @Operation(summary = "获取我的课程列表")
    @GetMapping("/mine")
    public Result<List<Course>> myCourses(@WebMvcConfig.CurrentUser UserDetailsImpl currentUser) {
        List<Course> courses = courseService.listCoursesByUserId(currentUser.getUserId());
        return Result.ok(courses);
    }

    @Operation(summary = "更新课程")
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('TEACHER') or hasRole('ADMIN')")
    public Result<Void> updateCourse(@PathVariable Long id,
                                     @Valid @RequestBody CourseUpdateDTO dto) {
        courseService.updateCourse(id, dto);
        return Result.ok();
    }

    @Operation(summary = "删除课程")
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> deleteCourse(@PathVariable Long id) {
        courseService.deleteCourse(id);
        return Result.ok();
    }

    @Operation(summary = "添加课程成员")
    @PostMapping("/{courseId}/members/{userId}")
    @PreAuthorize("hasRole('TEACHER') or hasRole('ADMIN')")
    public Result<Void> addMember(@PathVariable Long courseId,
                                  @PathVariable Long userId,
                                  @RequestParam(defaultValue = "STUDENT") String role) {
        courseMemberService.addMember(courseId, userId, role);
        return Result.ok();
    }

    @Operation(summary = "移除课程成员")
    @DeleteMapping("/{courseId}/members/{userId}")
    @PreAuthorize("hasRole('TEACHER') or hasRole('ADMIN')")
    public Result<Void> removeMember(@PathVariable Long courseId, @PathVariable Long userId) {
        courseMemberService.removeMember(courseId, userId);
        return Result.ok();
    }

    @Operation(summary = "获取课程成员列表")
    @GetMapping("/{courseId}/members")
    public Result<?> listMembers(@PathVariable Long courseId) {
        return Result.ok(courseMemberService.listMembers(courseId));
    }
}
