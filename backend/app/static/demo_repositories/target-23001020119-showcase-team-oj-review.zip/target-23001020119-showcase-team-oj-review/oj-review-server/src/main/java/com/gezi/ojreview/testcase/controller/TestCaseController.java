package com.gezi.ojreview.testcase.controller;

import com.gezi.ojreview.common.api.Result;
import com.gezi.ojreview.testcase.entity.ProblemTestCase;
import com.gezi.ojreview.testcase.service.TestCaseService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 测试用例控制器
 */
@Tag(name = "测试用例管理")
@RestController
@RequestMapping("/api/v1/problems/{problemId}/testcases")
@RequiredArgsConstructor
public class TestCaseController {

    private final TestCaseService testCaseService;

    @Operation(summary = "获取题目测试用例列表")
    @GetMapping
    public Result<List<ProblemTestCase>> listTestCases(@PathVariable Long problemId) {
        List<ProblemTestCase> list = testCaseService.listByProblemId(problemId);
        return Result.ok(list);
    }

    @Operation(summary = "添加测试用例")
    @PostMapping
    @PreAuthorize("hasRole('TEACHER') or hasRole('ADMIN')")
    public Result<ProblemTestCase> addTestCase(@PathVariable Long problemId,
                                               @RequestBody ProblemTestCase testCase) {
        testCase.setProblemId(problemId);
        ProblemTestCase result = testCaseService.addTestCase(testCase);
        return Result.ok(result);
    }

    @Operation(summary = "更新测试用例")
    @PutMapping("/{testCaseId}")
    @PreAuthorize("hasRole('TEACHER') or hasRole('ADMIN')")
    public Result<Void> updateTestCase(@PathVariable Long testCaseId,
                                       @RequestBody ProblemTestCase testCase) {
        testCase.setId(testCaseId);
        testCaseService.updateTestCase(testCase);
        return Result.ok();
    }

    @Operation(summary = "删除测试用例")
    @DeleteMapping("/{testCaseId}")
    @PreAuthorize("hasRole('TEACHER') or hasRole('ADMIN')")
    public Result<Void> deleteTestCase(@PathVariable Long testCaseId) {
        testCaseService.deleteTestCase(testCaseId);
        return Result.ok();
    }
}
