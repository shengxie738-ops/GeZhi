package com.gezi.ojreview.judge.controller;

import com.gezi.ojreview.common.api.Result;
import com.gezi.ojreview.judge.dto.JudgeCallbackDTO;
import com.gezi.ojreview.judge.service.JudgeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

/**
 * 判题回调控制器
 */
@Slf4j
@Tag(name = "判题回调")
@RestController
@RequestMapping("/api/v1/judge")
@RequiredArgsConstructor
public class JudgeController {

    private final JudgeService judgeService;

    @Operation(summary = "判题服务回调")
    @PostMapping("/callback")
    public Result<Void> callback(@RequestBody JudgeCallbackDTO callbackDTO,
                                 @RequestHeader("X-Internal-Token") String token) {
        log.info("收到判题回调: submissionId={}", callbackDTO.getSubmissionId());
        judgeService.handleCallback(callbackDTO);
        return Result.ok();
    }

    @Operation(summary = "查询判题状态")
    @GetMapping("/status/{submissionId}")
    public Result<String> getStatus(@PathVariable Long submissionId) {
        String status = judgeService.getJudgeStatus(submissionId);
        return Result.ok(status);
    }
}
