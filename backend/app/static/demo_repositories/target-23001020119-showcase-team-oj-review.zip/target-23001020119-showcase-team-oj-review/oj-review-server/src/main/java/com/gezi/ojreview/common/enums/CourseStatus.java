package com.gezi.ojreview.common.enums;

import lombok.Getter;

/**
 * 课程状态枚举
 */
@Getter
public enum CourseStatus {

    /** 进行中 */
    ACTIVE("ACTIVE", "进行中"),

    /** 已归档 */
    ARCHIVED("ARCHIVED", "已归档");

    private final String code;
    private final String description;

    CourseStatus(String code, String description) {
        this.code = code;
        this.description = description;
    }
}
