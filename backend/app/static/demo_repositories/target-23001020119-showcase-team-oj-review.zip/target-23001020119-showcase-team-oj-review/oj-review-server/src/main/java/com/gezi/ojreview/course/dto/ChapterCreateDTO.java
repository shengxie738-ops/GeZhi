package com.gezi.ojreview.course.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * 创建章节DTO
 */
@Data
public class ChapterCreateDTO {

    @NotBlank(message = "章节标题不能为空")
    private String title;

    private String description;

    private Integer sortOrder;
}
