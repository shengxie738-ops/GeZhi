package com.gezi.ojreview.analytics.vo;

import lombok.Data;

/**
 * 学生统计VO
 */
@Data
public class StudentStatsVO {

    private Long userId;

    private String username;

    private String realName;

    private long submitCount;

    private long acceptedCount;

    private long uniqueProblemCount;
}
