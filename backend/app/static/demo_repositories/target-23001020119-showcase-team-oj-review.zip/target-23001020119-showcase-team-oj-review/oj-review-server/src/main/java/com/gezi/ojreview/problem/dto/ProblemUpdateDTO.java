package com.gezi.ojreview.problem.dto;

import lombok.Data;

/**
 * 更新题目DTO
 */
@Data
public class ProblemUpdateDTO {

    private String title;

    private String description;

    private String inputDesc;

    private String outputDesc;

    private String sampleInput;

    private String sampleOutput;

    private String hint;

    private String difficulty;

    private Long timeLimit;

    private Long memoryLimit;

    private String tags;
}
