package com.gezi.ojreview.course.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gezi.ojreview.course.entity.CourseMember;
import com.gezi.ojreview.course.mapper.CourseMemberMapper;
import com.gezi.ojreview.course.service.CourseMemberService;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 课程成员服务实现
 */
@Service
public class CourseMemberServiceImpl extends ServiceImpl<CourseMemberMapper, CourseMember> implements CourseMemberService {

    @Override
    public void addMember(Long courseId, Long userId, String role) {
        boolean exists = exists(new LambdaQueryWrapper<CourseMember>()
                .eq(CourseMember::getCourseId, courseId)
                .eq(CourseMember::getUserId, userId));
        if (!exists) {
            CourseMember member = new CourseMember();
            member.setCourseId(courseId);
            member.setUserId(userId);
            member.setRole(role);
            member.setJoinTime(LocalDateTime.now());
            save(member);
        }
    }

    @Override
    public void removeMember(Long courseId, Long userId) {
        remove(new LambdaQueryWrapper<CourseMember>()
                .eq(CourseMember::getCourseId, courseId)
                .eq(CourseMember::getUserId, userId));
    }

    @Override
    public List<CourseMember> listMembers(Long courseId) {
        return list(new LambdaQueryWrapper<CourseMember>()
                .eq(CourseMember::getCourseId, courseId));
    }

    @Override
    public boolean isMember(Long courseId, Long userId) {
        return exists(new LambdaQueryWrapper<CourseMember>()
                .eq(CourseMember::getCourseId, courseId)
                .eq(CourseMember::getUserId, userId));
    }

    @Override
    public List<Long> getStudentIds(Long courseId) {
        List<CourseMember> members = list(new LambdaQueryWrapper<CourseMember>()
                .eq(CourseMember::getCourseId, courseId)
                .eq(CourseMember::getRole, "STUDENT"));
        return members.stream().map(CourseMember::getUserId).toList();
    }
}
