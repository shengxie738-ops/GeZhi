package com.gezi.ojreview.course.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gezi.ojreview.course.entity.CourseChapter;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CourseChapterMapper extends BaseMapper<CourseChapter> {
}
