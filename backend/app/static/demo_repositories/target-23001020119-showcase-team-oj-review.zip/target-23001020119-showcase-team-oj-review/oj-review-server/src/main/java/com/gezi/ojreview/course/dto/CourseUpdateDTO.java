package com.gezi.ojreview.course.dto;

import lombok.Data;

/**
 * 更新课程DTO
 */
@Data
public class CourseUpdateDTO {

    private String name;

    private String description;

    private String coverImage;

    private String status;

    private String term;
}
