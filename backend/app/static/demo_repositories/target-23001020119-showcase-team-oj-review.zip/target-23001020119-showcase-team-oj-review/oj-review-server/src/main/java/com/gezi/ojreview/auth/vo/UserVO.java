package com.gezi.ojreview.auth.vo;

import lombok.Data;

/**
 * 用户信息VO
 */
@Data
public class UserVO {

    private Long id;

    private String username;

    private String realName;

    private String email;

    private String phone;

    private String avatar;

    private String role;

    private String studentId;
}
