package com.gezi.ojreview.team.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * 创建团队DTO
 */
@Data
public class TeamCreateDTO {

    @NotBlank(message = "团队名称不能为空")
    private String name;

    private String description;

    private Long courseId;
}
