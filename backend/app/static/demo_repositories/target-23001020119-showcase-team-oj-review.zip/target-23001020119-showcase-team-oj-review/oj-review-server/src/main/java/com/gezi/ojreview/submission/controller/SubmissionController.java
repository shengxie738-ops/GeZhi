package com.gezi.ojreview.submission.controller;

import com.gezi.ojreview.common.api.PageResult;
import com.gezi.ojreview.common.api.Result;
import com.gezi.ojreview.common.security.UserDetailsImpl;
import com.gezi.ojreview.config.WebMvcConfig;
import com.gezi.ojreview.submission.dto.SubmissionQueryDTO;
import com.gezi.ojreview.submission.dto.SubmitCodeDTO;
import com.gezi.ojreview.submission.entity.Submission;
import com.gezi.ojreview.submission.service.SubmissionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * 提交控制器
 */
@Tag(name = "提交管理")
@RestController
@RequestMapping("/api/v1/submissions")
@RequiredArgsConstructor
public class SubmissionController {

    private final SubmissionService submissionService;

    @Operation(summary = "提交代码")
    @PostMapping
    public Result<Submission> submitCode(@Valid @RequestBody SubmitCodeDTO dto,
                                         @WebMvcConfig.CurrentUser UserDetailsImpl currentUser) {
        Submission submission = submissionService.submitCode(dto, currentUser.getUserId());
        return Result.ok(submission);
    }

    @Operation(summary = "查询提交记录")
    @GetMapping
    public Result<PageResult<Submission>> listSubmissions(
            SubmissionQueryDTO queryDTO,
            @WebMvcConfig.CurrentUser UserDetailsImpl currentUser) {
        Long userId = currentUser.getRole().equals("STUDENT") ? currentUser.getUserId() : null;
        PageResult<Submission> result = submissionService.listSubmissions(queryDTO, userId);
        return Result.ok(result);
    }

    @Operation(summary = "获取提交详情")
    @GetMapping("/{id}")
    public Result<Submission> getSubmission(@PathVariable Long id) {
        Submission submission = submissionService.getSubmissionById(id);
        return Result.ok(submission);
    }

    @Operation(summary = "获取我的提交记录")
    @GetMapping("/mine")
    public Result<PageResult<Submission>> mySubmissions(
            SubmissionQueryDTO queryDTO,
            @WebMvcConfig.CurrentUser UserDetailsImpl currentUser) {
        PageResult<Submission> result = submissionService.listSubmissions(queryDTO, currentUser.getUserId());
        return Result.ok(result);
    }
}
