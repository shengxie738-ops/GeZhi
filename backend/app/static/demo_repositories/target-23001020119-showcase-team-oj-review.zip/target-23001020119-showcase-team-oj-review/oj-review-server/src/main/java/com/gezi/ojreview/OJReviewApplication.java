package com.gezi.ojreview;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * OJ Review 启动类
 */
@SpringBootApplication
@MapperScan("com.gezi.ojreview.*.mapper")
public class OJReviewApplication {

    public static void main(String[] args) {
        SpringApplication.run(OJReviewApplication.class, args);
    }
}
