package com.gezi.ojreview.review.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * 创建复盘DTO
 */
@Data
public class ReviewCreateDTO {

    @NotNull(message = "学生ID不能为空")
    private Long studentId;

    private Long courseId;

    private Long submissionId;

    private Long problemId;

    @NotBlank(message = "复盘评论不能为空")
    private String comment;

    private String rating;
}
