package com.gezi.ojreview.wrongbook.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gezi.ojreview.common.api.ErrorCode;
import com.gezi.ojreview.common.api.PageResult;
import com.gezi.ojreview.common.exception.BusinessException;
import com.gezi.ojreview.common.util.PageUtil;
import com.gezi.ojreview.wrongbook.dto.WrongBookUpdateDTO;
import com.gezi.ojreview.wrongbook.entity.WrongBook;
import com.gezi.ojreview.wrongbook.mapper.WrongBookMapper;
import com.gezi.ojreview.wrongbook.service.WrongBookService;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
 * 错题本服务实现
 */
@Service
public class WrongBookServiceImpl extends ServiceImpl<WrongBookMapper, WrongBook> implements WrongBookService {

    @Override
    public void addWrongBook(Long userId, Long problemId, Long submissionId) {
        WrongBook existing = getByUserAndProblem(userId, problemId);
        if (existing != null) {
            existing.setWrongCount(existing.getWrongCount() + 1);
            existing.setSubmissionId(submissionId);
            existing.setStatus("UNRESOLVED");
            updateById(existing);
        } else {
            WrongBook wrongBook = new WrongBook();
            wrongBook.setUserId(userId);
            wrongBook.setProblemId(problemId);
            wrongBook.setSubmissionId(submissionId);
            wrongBook.setStatus("UNRESOLVED");
            wrongBook.setWrongCount(1);
            save(wrongBook);
        }
    }

    @Override
    public void updateWrongBook(Long id, WrongBookUpdateDTO dto) {
        WrongBook wrongBook = getById(id);
        if (wrongBook == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND, "错题记录不存在");
        }
        if (StringUtils.hasText(dto.getStatus())) {
            wrongBook.setStatus(dto.getStatus());
        }
        if (dto.getNote() != null) {
            wrongBook.setNote(dto.getNote());
        }
        updateById(wrongBook);
    }

    @Override
    public PageResult<WrongBook> listByUserId(Long userId, String status, int page, int size) {
        Page<WrongBook> pageParam = PageUtil.createPage(page, size);
        LambdaQueryWrapper<WrongBook> wrapper = new LambdaQueryWrapper<WrongBook>()
                .eq(WrongBook::getUserId, userId);
        if (StringUtils.hasText(status)) {
            wrapper.eq(WrongBook::getStatus, status);
        }
        wrapper.orderByDesc(WrongBook::getUpdateTime);

        Page<WrongBook> result = page(pageParam, wrapper);
        return PageUtil.toPageResult(result);
    }

    @Override
    public void deleteWrongBook(Long id) {
        if (getById(id) == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND, "错题记录不存在");
        }
        removeById(id);
    }

    @Override
    public WrongBook getByUserAndProblem(Long userId, Long problemId) {
        return getOne(new LambdaQueryWrapper<WrongBook>()
                .eq(WrongBook::getUserId, userId)
                .eq(WrongBook::getProblemId, problemId));
    }
}
