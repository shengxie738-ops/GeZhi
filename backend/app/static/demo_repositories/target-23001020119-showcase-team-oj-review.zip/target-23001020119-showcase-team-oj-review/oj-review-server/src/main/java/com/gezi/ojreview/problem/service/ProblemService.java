package com.gezi.ojreview.problem.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gezi.ojreview.common.api.PageResult;
import com.gezi.ojreview.problem.dto.ProblemCreateDTO;
import com.gezi.ojreview.problem.dto.ProblemQueryDTO;
import com.gezi.ojreview.problem.dto.ProblemUpdateDTO;
import com.gezi.ojreview.problem.entity.Problem;

/**
 * 题目服务接口
 */
public interface ProblemService extends IService<Problem> {

    Problem createProblem(ProblemCreateDTO dto, Long creatorId);

    void updateProblem(Long problemId, ProblemUpdateDTO dto);

    void deleteProblem(Long problemId);

    Problem getProblemById(Long problemId);

    PageResult<Problem> listProblems(ProblemQueryDTO queryDTO);
}
