package com.gezi.ojreview.review.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 教师复盘实体
 */
@Data
@TableName("teacher_review")
public class TeacherReview {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long teacherId;

    private Long studentId;

    private Long courseId;

    private Long submissionId;

    private Long problemId;

    private String comment;

    private String rating;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}
