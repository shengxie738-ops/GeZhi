package com.gezi.ojreview.testcase.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gezi.ojreview.common.api.ErrorCode;
import com.gezi.ojreview.common.exception.BusinessException;
import com.gezi.ojreview.testcase.entity.ProblemTestCase;
import com.gezi.ojreview.testcase.mapper.ProblemTestCaseMapper;
import com.gezi.ojreview.testcase.service.TestCaseService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 测试用例服务实现
 */
@Service
public class TestCaseServiceImpl extends ServiceImpl<ProblemTestCaseMapper, ProblemTestCase> implements TestCaseService {

    @Override
    public List<ProblemTestCase> listByProblemId(Long problemId) {
        return list(new LambdaQueryWrapper<ProblemTestCase>()
                .eq(ProblemTestCase::getProblemId, problemId)
                .orderByAsc(ProblemTestCase::getSortOrder));
    }

    @Override
    public ProblemTestCase addTestCase(ProblemTestCase testCase) {
        save(testCase);
        return testCase;
    }

    @Override
    public void updateTestCase(ProblemTestCase testCase) {
        if (getById(testCase.getId()) == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND, "测试用例不存在");
        }
        updateById(testCase);
    }

    @Override
    public void deleteTestCase(Long testCaseId) {
        if (getById(testCaseId) == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND, "测试用例不存在");
        }
        removeById(testCaseId);
    }

    @Override
    public void deleteByProblemId(Long problemId) {
        remove(new LambdaQueryWrapper<ProblemTestCase>()
                .eq(ProblemTestCase::getProblemId, problemId));
    }
}
