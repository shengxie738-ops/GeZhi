package com.gezi.ojreview.testcase.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gezi.ojreview.testcase.entity.ProblemTestCase;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ProblemTestCaseMapper extends BaseMapper<ProblemTestCase> {
}
