package com.gezi.ojreview.analytics.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.gezi.ojreview.analytics.service.AnalyticsService;
import com.gezi.ojreview.analytics.vo.CourseOverviewVO;
import com.gezi.ojreview.analytics.vo.ProblemStatsVO;
import com.gezi.ojreview.analytics.vo.StudentStatsVO;
import com.gezi.ojreview.course.entity.CourseMember;
import com.gezi.ojreview.course.service.CourseMemberService;
import com.gezi.ojreview.problem.entity.Problem;
import com.gezi.ojreview.problem.service.ProblemService;
import com.gezi.ojreview.submission.entity.Submission;
import com.gezi.ojreview.submission.service.SubmissionService;
import com.gezi.ojreview.user.entity.SysUser;
import com.gezi.ojreview.user.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 分析服务实现
 */
@Service
@RequiredArgsConstructor
public class AnalyticsServiceImpl implements AnalyticsService {

    private final SubmissionService submissionService;
    private final ProblemService problemService;
    private final CourseMemberService courseMemberService;
    private final UserService userService;

    @Override
    public CourseOverviewVO getCourseOverview(Long courseId) {
        List<Long> studentIds = courseMemberService.getStudentIds(courseId);
        List<Submission> submissions = submissionService.list(
                new LambdaQueryWrapper<Submission>().eq(Submission::getCourseId, courseId));

        CourseOverviewVO vo = new CourseOverviewVO();
        vo.setStudentCount(studentIds.size());
        vo.setSubmissionCount(submissions.size());
        vo.setAcceptedCount(submissions.stream()
                .filter(s -> "ACCEPTED".equals(s.getStatus())).count());

        long uniqueAcceptedUsers = submissions.stream()
                .filter(s -> "ACCEPTED".equals(s.getStatus()))
                .map(Submission::getUserId)
                .distinct()
                .count();
        vo.setActiveStudentCount(uniqueAcceptedUsers);

        return vo;
    }

    @Override
    public List<ProblemStatsVO> getProblemStats(Long courseId) {
        List<Submission> submissions = submissionService.list(
                new LambdaQueryWrapper<Submission>().eq(Submission::getCourseId, courseId));

        Map<Long, List<Submission>> byProblem = submissions.stream()
                .collect(Collectors.groupingBy(Submission::getProblemId));

        List<ProblemStatsVO> stats = new ArrayList<>();
        for (Map.Entry<Long, List<Submission>> entry : byProblem.entrySet()) {
            Problem problem = problemService.getById(entry.getKey());
            if (problem == null) continue;

            List<Submission> problemSubs = entry.getValue();
            ProblemStatsVO vo = new ProblemStatsVO();
            vo.setProblemId(problem.getId());
            vo.setTitle(problem.getTitle());
            vo.setDifficulty(problem.getDifficulty());
            vo.setSubmitCount(problemSubs.size());
            vo.setAcceptedCount(problemSubs.stream()
                    .filter(s -> "ACCEPTED".equals(s.getStatus())).count());
            vo.setAcceptanceRate(problemSubs.isEmpty() ? 0.0
                    : (double) vo.getAcceptedCount() / vo.getSubmitCount() * 100);
            stats.add(vo);
        }
        return stats;
    }

    @Override
    public List<StudentStatsVO> getStudentStats(Long courseId) {
        List<Long> studentIds = courseMemberService.getStudentIds(courseId);
        List<Submission> submissions = submissionService.list(
                new LambdaQueryWrapper<Submission>().eq(Submission::getCourseId, courseId));

        Map<Long, List<Submission>> byUser = submissions.stream()
                .collect(Collectors.groupingBy(Submission::getUserId));

        List<StudentStatsVO> stats = new ArrayList<>();
        for (Long studentId : studentIds) {
            SysUser user = userService.getById(studentId);
            if (user == null) continue;

            List<Submission> userSubs = byUser.getOrDefault(studentId, List.of());
            StudentStatsVO vo = new StudentStatsVO();
            vo.setUserId(studentId);
            vo.setUsername(user.getUsername());
            vo.setRealName(user.getRealName());
            vo.setSubmitCount(userSubs.size());
            vo.setAcceptedCount(userSubs.stream()
                    .filter(s -> "ACCEPTED".equals(s.getStatus())).count());
            vo.setUniqueProblemCount(userSubs.stream()
                    .map(Submission::getProblemId).distinct().count());
            stats.add(vo);
        }
        return stats;
    }

    @Override
    public Map<String, Object> getSubmissionTrend(Long courseId, int days) {
        LocalDateTime since = LocalDateTime.now().minusDays(days);
        List<Submission> submissions = submissionService.list(
                new LambdaQueryWrapper<Submission>()
                        .eq(Submission::getCourseId, courseId)
                        .ge(Submission::getCreateTime, since));

        Map<String, Long> dailyCounts = submissions.stream()
                .collect(Collectors.groupingBy(
                        s -> s.getCreateTime().toLocalDate().toString(),
                        Collectors.counting()));

        Map<String, Object> result = new HashMap<>();
        result.put("dailyCounts", dailyCounts);
        result.put("totalSubmissions", submissions.size());
        return result;
    }

    @Override
    public Map<String, Object> getErrorDistribution(Long courseId) {
        List<Submission> submissions = submissionService.list(
                new LambdaQueryWrapper<Submission>().eq(Submission::getCourseId, courseId));

        Map<String, Long> distribution = submissions.stream()
                .collect(Collectors.groupingBy(Submission::getStatus, Collectors.counting()));

        Map<String, Object> result = new HashMap<>();
        result.put("distribution", distribution);
        result.put("total", submissions.size());
        return result;
    }
}
