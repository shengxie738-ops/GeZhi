package com.gezi.ojreview.submission.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gezi.ojreview.common.api.ErrorCode;
import com.gezi.ojreview.common.api.PageResult;
import com.gezi.ojreview.common.exception.BusinessException;
import com.gezi.ojreview.common.util.PageUtil;
import com.gezi.ojreview.problem.entity.Problem;
import com.gezi.ojreview.problem.service.ProblemService;
import com.gezi.ojreview.submission.dto.SubmissionQueryDTO;
import com.gezi.ojreview.submission.dto.SubmitCodeDTO;
import com.gezi.ojreview.submission.entity.Submission;
import com.gezi.ojreview.submission.mapper.SubmissionMapper;
import com.gezi.ojreview.submission.service.SubmissionService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
 * 提交服务实现
 */
@Service
@RequiredArgsConstructor
public class SubmissionServiceImpl extends ServiceImpl<SubmissionMapper, Submission> implements SubmissionService {

    private final ProblemService problemService;
    private final RedisTemplate<String, Object> redisTemplate;

    private static final String JUDGE_QUEUE_KEY = "judge:queue";

    @Override
    public Submission submitCode(SubmitCodeDTO dto, Long userId) {
        Problem problem = problemService.getProblemById(dto.getProblemId());

        Submission submission = new Submission();
        submission.setUserId(userId);
        submission.setProblemId(dto.getProblemId());
        submission.setCourseId(dto.getCourseId());
        submission.setLanguage(dto.getLanguage());
        submission.setCode(dto.getCode());
        submission.setStatus("PENDING");
        submission.setTestCasesPassed(0);
        submission.setTestCasesTotal(0);
        save(submission);

        problem.setSubmitCount(problem.getSubmitCount() + 1);
        problemService.updateById(problem);

        redisTemplate.opsForList().rightPush(JUDGE_QUEUE_KEY, submission.getId());

        return submission;
    }

    @Override
    public PageResult<Submission> listSubmissions(SubmissionQueryDTO queryDTO, Long userId) {
        Page<Submission> pageParam = PageUtil.createPage(queryDTO.getPage(), queryDTO.getSize());
        LambdaQueryWrapper<Submission> wrapper = new LambdaQueryWrapper<>();

        if (userId != null) {
            wrapper.eq(Submission::getUserId, userId);
        }
        if (queryDTO.getProblemId() != null) {
            wrapper.eq(Submission::getProblemId, queryDTO.getProblemId());
        }
        if (StringUtils.hasText(queryDTO.getStatus())) {
            wrapper.eq(Submission::getStatus, queryDTO.getStatus());
        }
        if (StringUtils.hasText(queryDTO.getLanguage())) {
            wrapper.eq(Submission::getLanguage, queryDTO.getLanguage());
        }
        wrapper.orderByDesc(Submission::getCreateTime);

        Page<Submission> result = page(pageParam, wrapper);
        return PageUtil.toPageResult(result);
    }

    @Override
    public Submission getSubmissionById(Long submissionId) {
        Submission submission = getById(submissionId);
        if (submission == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND, "提交记录不存在");
        }
        return submission;
    }

    @Override
    public void updateSubmissionStatus(Long submissionId, String status, Long timeUsed,
                                       Long memoryUsed, Integer passed, Integer total, String compileOutput) {
        Submission submission = getById(submissionId);
        if (submission != null) {
            submission.setStatus(status);
            if (timeUsed != null) submission.setTimeUsed(timeUsed);
            if (memoryUsed != null) submission.setMemoryUsed(memoryUsed);
            if (passed != null) submission.setTestCasesPassed(passed);
            if (total != null) submission.setTestCasesTotal(total);
            if (compileOutput != null) submission.setCompileOutput(compileOutput);
            updateById(submission);

            if ("ACCEPTED".equals(status)) {
                Problem problem = problemService.getById(submission.getProblemId());
                if (problem != null) {
                    problem.setAcceptedCount(problem.getAcceptedCount() + 1);
                    problemService.updateById(problem);
                }
            }
        }
    }
}
