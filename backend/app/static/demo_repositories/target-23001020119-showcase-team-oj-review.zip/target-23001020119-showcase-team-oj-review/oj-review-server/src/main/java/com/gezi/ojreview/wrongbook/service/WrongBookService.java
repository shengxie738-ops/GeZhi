package com.gezi.ojreview.wrongbook.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gezi.ojreview.common.api.PageResult;
import com.gezi.ojreview.wrongbook.dto.WrongBookUpdateDTO;
import com.gezi.ojreview.wrongbook.entity.WrongBook;

/**
 * 错题本服务接口
 */
public interface WrongBookService extends IService<WrongBook> {

    void addWrongBook(Long userId, Long problemId, Long submissionId);

    void updateWrongBook(Long id, WrongBookUpdateDTO dto);

    PageResult<WrongBook> listByUserId(Long userId, String status, int page, int size);

    void deleteWrongBook(Long id);

    WrongBook getByUserAndProblem(Long userId, Long problemId);
}
