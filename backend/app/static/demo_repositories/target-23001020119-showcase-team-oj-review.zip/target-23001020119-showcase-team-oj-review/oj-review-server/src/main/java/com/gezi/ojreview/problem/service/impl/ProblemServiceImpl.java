package com.gezi.ojreview.problem.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gezi.ojreview.common.api.ErrorCode;
import com.gezi.ojreview.common.api.PageResult;
import com.gezi.ojreview.common.exception.BusinessException;
import com.gezi.ojreview.common.util.PageUtil;
import com.gezi.ojreview.problem.dto.ProblemCreateDTO;
import com.gezi.ojreview.problem.dto.ProblemQueryDTO;
import com.gezi.ojreview.problem.dto.ProblemUpdateDTO;
import com.gezi.ojreview.problem.entity.Problem;
import com.gezi.ojreview.problem.mapper.ProblemMapper;
import com.gezi.ojreview.problem.service.ProblemService;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
 * 题目服务实现
 */
@Service
public class ProblemServiceImpl extends ServiceImpl<ProblemMapper, Problem> implements ProblemService {

    @Override
    public Problem createProblem(ProblemCreateDTO dto, Long creatorId) {
        Problem problem = new Problem();
        problem.setTitle(dto.getTitle());
        problem.setDescription(dto.getDescription());
        problem.setInputDesc(dto.getInputDesc());
        problem.setOutputDesc(dto.getOutputDesc());
        problem.setSampleInput(dto.getSampleInput());
        problem.setSampleOutput(dto.getSampleOutput());
        problem.setHint(dto.getHint());
        problem.setDifficulty(dto.getDifficulty());
        problem.setTimeLimit(dto.getTimeLimit() != null ? dto.getTimeLimit() : 1000L);
        problem.setMemoryLimit(dto.getMemoryLimit() != null ? dto.getMemoryLimit() : 256L);
        problem.setCreatorId(creatorId);
        problem.setChapterId(dto.getChapterId());
        problem.setTags(dto.getTags());
        problem.setSubmitCount(0);
        problem.setAcceptedCount(0);
        problem.setStatus(1);
        save(problem);
        return problem;
    }

    @Override
    public void updateProblem(Long problemId, ProblemUpdateDTO dto) {
        Problem problem = getById(problemId);
        if (problem == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND, "题目不存在");
        }
        if (StringUtils.hasText(dto.getTitle())) problem.setTitle(dto.getTitle());
        if (StringUtils.hasText(dto.getDescription())) problem.setDescription(dto.getDescription());
        if (dto.getInputDesc() != null) problem.setInputDesc(dto.getInputDesc());
        if (dto.getOutputDesc() != null) problem.setOutputDesc(dto.getOutputDesc());
        if (dto.getSampleInput() != null) problem.setSampleInput(dto.getSampleInput());
        if (dto.getSampleOutput() != null) problem.setSampleOutput(dto.getSampleOutput());
        if (dto.getHint() != null) problem.setHint(dto.getHint());
        if (StringUtils.hasText(dto.getDifficulty())) problem.setDifficulty(dto.getDifficulty());
        if (dto.getTimeLimit() != null) problem.setTimeLimit(dto.getTimeLimit());
        if (dto.getMemoryLimit() != null) problem.setMemoryLimit(dto.getMemoryLimit());
        if (dto.getTags() != null) problem.setTags(dto.getTags());
        updateById(problem);
    }

    @Override
    public void deleteProblem(Long problemId) {
        if (getById(problemId) == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND, "题目不存在");
        }
        removeById(problemId);
    }

    @Override
    public Problem getProblemById(Long problemId) {
        Problem problem = getById(problemId);
        if (problem == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND, "题目不存在");
        }
        return problem;
    }

    @Override
    public PageResult<Problem> listProblems(ProblemQueryDTO queryDTO) {
        Page<Problem> pageParam = PageUtil.createPage(queryDTO.getPage(), queryDTO.getSize());
        LambdaQueryWrapper<Problem> wrapper = new LambdaQueryWrapper<>();

        if (StringUtils.hasText(queryDTO.getKeyword())) {
            wrapper.like(Problem::getTitle, queryDTO.getKeyword());
        }
        if (StringUtils.hasText(queryDTO.getDifficulty())) {
            wrapper.eq(Problem::getDifficulty, queryDTO.getDifficulty());
        }
        if (queryDTO.getChapterId() != null) {
            wrapper.eq(Problem::getChapterId, queryDTO.getChapterId());
        }
        if (StringUtils.hasText(queryDTO.getTags())) {
            wrapper.like(Problem::getTags, queryDTO.getTags());
        }
        wrapper.orderByDesc(Problem::getCreateTime);

        Page<Problem> result = page(pageParam, wrapper);
        return PageUtil.toPageResult(result);
    }
}
