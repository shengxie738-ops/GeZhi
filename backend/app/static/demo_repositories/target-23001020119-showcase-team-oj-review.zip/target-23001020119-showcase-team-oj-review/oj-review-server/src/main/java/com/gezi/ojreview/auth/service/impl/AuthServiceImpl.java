package com.gezi.ojreview.auth.service.impl;

import com.gezi.ojreview.auth.dto.LoginDTO;
import com.gezi.ojreview.auth.dto.RefreshTokenDTO;
import com.gezi.ojreview.auth.dto.RegisterDTO;
import com.gezi.ojreview.auth.service.AuthService;
import com.gezi.ojreview.auth.vo.LoginVO;
import com.gezi.ojreview.auth.vo.UserVO;
import com.gezi.ojreview.common.api.ErrorCode;
import com.gezi.ojreview.common.exception.BusinessException;
import com.gezi.ojreview.common.security.JwtUtil;
import com.gezi.ojreview.user.entity.SysUser;
import com.gezi.ojreview.user.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.concurrent.TimeUnit;

/**
 * 认证服务实现
 */
@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final UserService userService;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final StringRedisTemplate stringRedisTemplate;

    private static final String TOKEN_BLACKLIST_PREFIX = "token:blacklist:";

    @Override
    public LoginVO login(LoginDTO dto) {
        SysUser user = userService.getByUsername(dto.getUsername());
        if (user == null) {
            throw new BusinessException(ErrorCode.UNAUTHORIZED, "用户名或密码错误");
        }
        if (!passwordEncoder.matches(dto.getPassword(), user.getPassword())) {
            throw new BusinessException(ErrorCode.UNAUTHORIZED, "用户名或密码错误");
        }
        if (user.getStatus() != null && user.getStatus() == 0) {
            throw new BusinessException(ErrorCode.FORBIDDEN, "账号已被禁用");
        }

        String token = jwtUtil.generateToken(user.getId(), user.getUsername(), user.getRole());

        LoginVO loginVO = new LoginVO();
        loginVO.setAccessToken(token);
        loginVO.setTokenType("Bearer");
        loginVO.setExpiresIn(86400L);

        UserVO userVO = toUserVO(user);
        loginVO.setUser(userVO);

        return loginVO;
    }

    @Override
    public void register(RegisterDTO dto) {
        if (!dto.getPassword().equals(dto.getConfirmPassword())) {
            throw new BusinessException(ErrorCode.PARAM_ERROR, "两次密码不一致");
        }

        com.gezi.ojreview.user.dto.UserCreateDTO createDTO = new com.gezi.ojreview.user.dto.UserCreateDTO();
        createDTO.setUsername(dto.getUsername());
        createDTO.setPassword(dto.getPassword());
        createDTO.setRealName(dto.getRealName());
        createDTO.setEmail(dto.getEmail());
        createDTO.setRole("STUDENT");
        userService.createUser(createDTO);
    }

    @Override
    public LoginVO refreshToken(RefreshTokenDTO dto) {
        String oldToken = dto.getRefreshToken();
        if (!StringUtils.hasText(oldToken) || !jwtUtil.validateToken(oldToken)) {
            throw new BusinessException(ErrorCode.UNAUTHORIZED, "Token无效或已过期");
        }

        String blacklistKey = TOKEN_BLACKLIST_PREFIX + oldToken;
        if (stringRedisTemplate.hasKey(blacklistKey)) {
            throw new BusinessException(ErrorCode.UNAUTHORIZED, "Token已被注销");
        }

        Long userId = jwtUtil.getUserId(oldToken);
        String username = jwtUtil.getUsername(oldToken);
        String role = jwtUtil.getRole(oldToken);

        stringRedisTemplate.opsForValue().set(blacklistKey, "1", 24, TimeUnit.HOURS);

        String newToken = jwtUtil.generateToken(userId, username, role);

        LoginVO loginVO = new LoginVO();
        loginVO.setAccessToken(newToken);
        loginVO.setTokenType("Bearer");
        loginVO.setExpiresIn(86400L);

        SysUser user = userService.getUserById(userId);
        loginVO.setUser(toUserVO(user));

        return loginVO;
    }

    @Override
    public void logout(String authorization) {
        if (StringUtils.hasText(authorization) && authorization.startsWith("Bearer ")) {
            String token = authorization.substring(7);
            String blacklistKey = TOKEN_BLACKLIST_PREFIX + token;
            stringRedisTemplate.opsForValue().set(blacklistKey, "1", 24, TimeUnit.HOURS);
        }
    }

    @Override
    public UserVO getCurrentUser(Long userId) {
        SysUser user = userService.getUserById(userId);
        return toUserVO(user);
    }

    private UserVO toUserVO(SysUser user) {
        UserVO vo = new UserVO();
        vo.setId(user.getId());
        vo.setUsername(user.getUsername());
        vo.setRealName(user.getRealName());
        vo.setEmail(user.getEmail());
        vo.setPhone(user.getPhone());
        vo.setAvatar(user.getAvatar());
        vo.setRole(user.getRole());
        vo.setStudentId(user.getStudentId());
        return vo;
    }
}
