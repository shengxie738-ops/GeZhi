package com.gezi.ojreview.wrongbook.dto;

import lombok.Data;

/**
 * 更新错题DTO
 */
@Data
public class WrongBookUpdateDTO {

    private String status;

    private String note;
}
