package com.gezi.ojreview.user.dto;

import lombok.Data;

/**
 * 更新用户DTO
 */
@Data
public class UserUpdateDTO {

    private String realName;

    private String email;

    private String phone;

    private String avatar;

    private String studentId;
}
