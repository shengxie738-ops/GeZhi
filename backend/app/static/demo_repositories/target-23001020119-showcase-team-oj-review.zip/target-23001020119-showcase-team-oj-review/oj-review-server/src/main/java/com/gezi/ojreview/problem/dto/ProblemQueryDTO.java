package com.gezi.ojreview.problem.dto;

import lombok.Data;

/**
 * 题目查询DTO
 */
@Data
public class ProblemQueryDTO {

    private Integer page = 1;

    private Integer size = 10;

    private String keyword;

    private String difficulty;

    private Long chapterId;

    private String tags;
}
