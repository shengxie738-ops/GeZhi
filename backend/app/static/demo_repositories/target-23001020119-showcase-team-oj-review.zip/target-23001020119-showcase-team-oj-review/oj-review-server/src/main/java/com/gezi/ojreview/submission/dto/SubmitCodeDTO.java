package com.gezi.ojreview.submission.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * 提交代码DTO
 */
@Data
public class SubmitCodeDTO {

    @NotNull(message = "题目ID不能为空")
    private Long problemId;

    private Long courseId;

    @NotBlank(message = "编程语言不能为空")
    private String language;

    @NotBlank(message = "代码不能为空")
    private String code;
}
