package com.gezi.ojreview.auth.vo;

import lombok.Data;

/**
 * 登录返回VO
 */
@Data
public class LoginVO {

    private String accessToken;

    private String tokenType;

    private Long expiresIn;

    private UserVO user;
}
