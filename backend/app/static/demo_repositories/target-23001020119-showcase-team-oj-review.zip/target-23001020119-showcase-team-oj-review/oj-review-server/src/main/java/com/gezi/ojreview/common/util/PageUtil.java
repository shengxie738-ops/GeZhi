package com.gezi.ojreview.common.util;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gezi.ojreview.common.api.PageResult;

import java.util.List;

/**
 * 分页工具类
 */
public class PageUtil {

    private PageUtil() {
    }

    /**
     * 创建 MyBatis-Plus 分页对象
     */
    public static <T> Page<T> createPage(long current, long size) {
        return new Page<>(current, size);
    }

    /**
     * 创建 MyBatis-Plus 分页对象（带默认值）
     */
    public static <T> Page<T> createPage(Long current, Long size) {
        long pageNum = (current != null && current > 0) ? current : 1;
        long pageSize = (size != null && size > 0) ? size : 10;
        return new Page<>(pageNum, pageSize);
    }

    /**
     * 将 MyBatis-Plus 分页结果转换为 PageResult
     */
    public static <T> PageResult<T> toPageResult(IPage<T> page) {
        return PageResult.of(page.getRecords(), page.getTotal(), page.getCurrent(), page.getSize());
    }

    /**
     * 创建空分页结果
     */
    public static <T> PageResult<T> emptyResult() {
        return PageResult.empty();
    }
}
