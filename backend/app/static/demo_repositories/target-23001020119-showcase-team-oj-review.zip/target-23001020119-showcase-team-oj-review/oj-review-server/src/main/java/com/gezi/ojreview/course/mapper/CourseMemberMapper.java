package com.gezi.ojreview.course.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gezi.ojreview.course.entity.CourseMember;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CourseMemberMapper extends BaseMapper<CourseMember> {
}
