package com.gezi.ojreview.common.enums;

import lombok.Getter;

/**
 * 提交状态枚举
 */
@Getter
public enum SubmissionStatus {

    /** 等待中 */
    PENDING("PENDING", "等待中"),

    /** 排队中 */
    QUEUING("QUEUING", "排队中"),

    /** 编译中 */
    COMPILING("COMPILING", "编译中"),

    /** 运行中 */
    RUNNING("RUNNING", "运行中"),

    /** 通过 */
    ACCEPTED("ACCEPTED", "通过"),

    /** 答案错误 */
    WRONG_ANSWER("WRONG_ANSWER", "答案错误"),

    /** 超时 */
    TIME_LIMIT_EXCEEDED("TIME_LIMIT_EXCEEDED", "超时"),

    /** 内存超限 */
    MEMORY_LIMIT_EXCEEDED("MEMORY_LIMIT_EXCEEDED", "内存超限"),

    /** 运行时错误 */
    RUNTIME_ERROR("RUNTIME_ERROR", "运行时错误"),

    /** 编译错误 */
    COMPILE_ERROR("COMPILE_ERROR", "编译错误"),

    /** 输出超限 */
    OUTPUT_LIMIT_EXCEEDED("OUTPUT_LIMIT_EXCEEDED", "输出超限"),

    /** 系统错误 */
    SYSTEM_ERROR("SYSTEM_ERROR", "系统错误");

    private final String code;
    private final String description;

    SubmissionStatus(String code, String description) {
        this.code = code;
        this.description = description;
    }
}
