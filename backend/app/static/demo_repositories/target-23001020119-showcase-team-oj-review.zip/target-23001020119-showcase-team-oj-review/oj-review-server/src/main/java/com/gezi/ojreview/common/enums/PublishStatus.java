package com.gezi.ojreview.common.enums;

import lombok.Getter;

/**
 * 发布状态枚举
 */
@Getter
public enum PublishStatus {

    /** 草稿 */
    DRAFT("DRAFT", "草稿"),

    /** 已发布 */
    PUBLISHED("PUBLISHED", "已发布");

    private final String code;
    private final String description;

    PublishStatus(String code, String description) {
        this.code = code;
        this.description = description;
    }
}
