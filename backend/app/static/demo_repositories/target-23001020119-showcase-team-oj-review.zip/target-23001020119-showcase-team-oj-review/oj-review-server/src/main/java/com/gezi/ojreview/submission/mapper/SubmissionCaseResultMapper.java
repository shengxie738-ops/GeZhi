package com.gezi.ojreview.submission.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gezi.ojreview.submission.entity.SubmissionCaseResult;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SubmissionCaseResultMapper extends BaseMapper<SubmissionCaseResult> {
}
