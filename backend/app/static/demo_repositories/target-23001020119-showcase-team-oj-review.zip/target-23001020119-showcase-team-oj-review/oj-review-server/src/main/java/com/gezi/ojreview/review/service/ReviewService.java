package com.gezi.ojreview.review.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gezi.ojreview.common.api.PageResult;
import com.gezi.ojreview.review.dto.ReviewCreateDTO;
import com.gezi.ojreview.review.entity.TeacherReview;

/**
 * 复盘服务接口
 */
public interface ReviewService extends IService<TeacherReview> {

    TeacherReview createReview(ReviewCreateDTO dto, Long teacherId);

    PageResult<TeacherReview> listReviews(Long courseId, Long studentId, int page, int size);

    TeacherReview getReviewById(Long reviewId);

    void deleteReview(Long reviewId);
}
