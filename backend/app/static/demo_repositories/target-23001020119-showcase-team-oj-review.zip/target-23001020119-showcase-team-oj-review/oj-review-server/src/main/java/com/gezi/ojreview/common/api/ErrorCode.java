package com.gezi.ojreview.common.api;

import lombok.Getter;

/**
 * 错误码枚举
 */
@Getter
public enum ErrorCode {

    /** 参数错误 */
    PARAM_ERROR(40001, "参数错误"),

    /** 未授权 */
    UNAUTHORIZED(40101, "未授权，请先登录"),

    /** 禁止访问 */
    FORBIDDEN(40301, "无权限访问"),

    /** 资源不存在 */
    NOT_FOUND(40401, "资源不存在"),

    /** 资源冲突 */
    CONFLICT(40901, "资源冲突"),

    /** 请求过于频繁 */
    TOO_MANY_REQUESTS(42901, "请求过于频繁，请稍后再试"),

    /** 系统内部错误 */
    SYSTEM_ERROR(50001, "系统内部错误"),

    /** 判题错误 */
    JUDGE_ERROR(50010, "判题服务异常"),

    /** 判题超时 */
    JUDGE_TIMEOUT(50011, "判题服务超时");

    private final Integer code;
    private final String message;

    ErrorCode(Integer code, String message) {
        this.code = code;
        this.message = message;
    }
}
