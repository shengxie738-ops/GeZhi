package com.gezi.ojreview.common.enums;

import lombok.Getter;

/**
 * 题目难度枚举
 */
@Getter
public enum Difficulty {

    /** 简单 */
    EASY("EASY", "简单"),

    /** 中等 */
    MEDIUM("MEDIUM", "中等"),

    /** 困难 */
    HARD("HARD", "困难");

    private final String code;
    private final String description;

    Difficulty(String code, String description) {
        this.code = code;
        this.description = description;
    }
}
