package com.gezi.ojreview.review.controller;

import com.gezi.ojreview.common.api.PageResult;
import com.gezi.ojreview.common.api.Result;
import com.gezi.ojreview.common.security.UserDetailsImpl;
import com.gezi.ojreview.config.WebMvcConfig;
import com.gezi.ojreview.review.dto.ReviewCreateDTO;
import com.gezi.ojreview.review.entity.TeacherReview;
import com.gezi.ojreview.review.service.ReviewService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * 复盘控制器（教师端）
 */
@Tag(name = "教师复盘")
@RestController
@RequestMapping("/api/v1/teacher/reviews")
@RequiredArgsConstructor
@PreAuthorize("hasRole('TEACHER') or hasRole('ADMIN')")
public class ReviewController {

    private final ReviewService reviewService;

    @Operation(summary = "创建复盘")
    @PostMapping
    public Result<TeacherReview> createReview(@Valid @RequestBody ReviewCreateDTO dto,
                                              @WebMvcConfig.CurrentUser UserDetailsImpl currentUser) {
        TeacherReview review = reviewService.createReview(dto, currentUser.getUserId());
        return Result.ok(review);
    }

    @Operation(summary = "查询复盘列表")
    @GetMapping
    public Result<PageResult<TeacherReview>> listReviews(
            @RequestParam(required = false) Long courseId,
            @RequestParam(required = false) Long studentId,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size) {
        PageResult<TeacherReview> result = reviewService.listReviews(courseId, studentId, page, size);
        return Result.ok(result);
    }

    @Operation(summary = "获取复盘详情")
    @GetMapping("/{id}")
    public Result<TeacherReview> getReview(@PathVariable Long id) {
        TeacherReview review = reviewService.getReviewById(id);
        return Result.ok(review);
    }

    @Operation(summary = "删除复盘")
    @DeleteMapping("/{id}")
    public Result<Void> deleteReview(@PathVariable Long id) {
        reviewService.deleteReview(id);
        return Result.ok();
    }
}
