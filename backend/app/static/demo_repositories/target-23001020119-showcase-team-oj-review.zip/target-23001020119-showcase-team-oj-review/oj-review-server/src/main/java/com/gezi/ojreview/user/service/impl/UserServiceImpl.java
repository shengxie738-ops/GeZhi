package com.gezi.ojreview.user.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gezi.ojreview.common.api.ErrorCode;
import com.gezi.ojreview.common.api.PageResult;
import com.gezi.ojreview.common.exception.BusinessException;
import com.gezi.ojreview.common.util.PageUtil;
import com.gezi.ojreview.user.dto.UserCreateDTO;
import com.gezi.ojreview.user.dto.UserUpdateDTO;
import com.gezi.ojreview.user.entity.SysUser;
import com.gezi.ojreview.user.mapper.SysUserMapper;
import com.gezi.ojreview.user.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
 * 用户服务实现
 */
@Service
@RequiredArgsConstructor
public class UserServiceImpl extends ServiceImpl<SysUserMapper, SysUser> implements UserService {

    private final PasswordEncoder passwordEncoder;

    @Override
    public SysUser getByUsername(String username) {
        return getOne(new LambdaQueryWrapper<SysUser>().eq(SysUser::getUsername, username));
    }

    @Override
    public SysUser createUser(UserCreateDTO dto) {
        if (existsByUsername(dto.getUsername())) {
            throw new BusinessException(ErrorCode.CONFLICT, "用户名已存在");
        }
        if (StringUtils.hasText(dto.getEmail()) && existsByEmail(dto.getEmail())) {
            throw new BusinessException(ErrorCode.CONFLICT, "邮箱已被注册");
        }

        SysUser user = new SysUser();
        user.setUsername(dto.getUsername());
        user.setPassword(passwordEncoder.encode(dto.getPassword()));
        user.setRealName(dto.getRealName());
        user.setEmail(dto.getEmail());
        user.setPhone(dto.getPhone());
        user.setRole(dto.getRole());
        user.setStudentId(dto.getStudentId());
        user.setStatus(1);
        save(user);
        return user;
    }

    @Override
    public void updateUser(Long userId, UserUpdateDTO dto) {
        SysUser user = getById(userId);
        if (user == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND, "用户不存在");
        }

        if (StringUtils.hasText(dto.getRealName())) {
            user.setRealName(dto.getRealName());
        }
        if (StringUtils.hasText(dto.getEmail())) {
            user.setEmail(dto.getEmail());
        }
        if (StringUtils.hasText(dto.getPhone())) {
            user.setPhone(dto.getPhone());
        }
        if (StringUtils.hasText(dto.getAvatar())) {
            user.setAvatar(dto.getAvatar());
        }
        if (StringUtils.hasText(dto.getStudentId())) {
            user.setStudentId(dto.getStudentId());
        }
        updateById(user);
    }

    @Override
    public PageResult<SysUser> listUsers(int page, int size, String role, String keyword) {
        Page<SysUser> pageParam = PageUtil.createPage(page, size);
        LambdaQueryWrapper<SysUser> wrapper = new LambdaQueryWrapper<>();

        if (StringUtils.hasText(role)) {
            wrapper.eq(SysUser::getRole, role);
        }
        if (StringUtils.hasText(keyword)) {
            wrapper.and(w -> w
                    .like(SysUser::getUsername, keyword)
                    .or().like(SysUser::getRealName, keyword)
                    .or().like(SysUser::getStudentId, keyword));
        }
        wrapper.orderByDesc(SysUser::getCreateTime);

        Page<SysUser> result = page(pageParam, wrapper);
        return PageUtil.toPageResult(result);
    }

    @Override
    public SysUser getUserById(Long userId) {
        SysUser user = getById(userId);
        if (user == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND, "用户不存在");
        }
        return user;
    }

    @Override
    public boolean existsByUsername(String username) {
        return count(new LambdaQueryWrapper<SysUser>().eq(SysUser::getUsername, username)) > 0;
    }

    @Override
    public boolean existsByEmail(String email) {
        return count(new LambdaQueryWrapper<SysUser>().eq(SysUser::getEmail, email)) > 0;
    }
}
