package com.gezi.ojreview.course.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gezi.ojreview.course.dto.ChapterCreateDTO;
import com.gezi.ojreview.course.entity.CourseChapter;

import java.util.List;

/**
 * 章节服务接口
 */
public interface ChapterService extends IService<CourseChapter> {

    CourseChapter createChapter(Long courseId, ChapterCreateDTO dto);

    void updateChapter(Long chapterId, ChapterCreateDTO dto);

    void deleteChapter(Long chapterId);

    List<CourseChapter> listChapters(Long courseId);
}
