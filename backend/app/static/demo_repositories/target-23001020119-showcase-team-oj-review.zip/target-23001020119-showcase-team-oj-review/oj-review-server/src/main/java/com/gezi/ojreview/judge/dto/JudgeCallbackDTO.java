package com.gezi.ojreview.judge.dto;

import lombok.Data;

/**
 * 判题回调DTO
 */
@Data
public class JudgeCallbackDTO {

    private Long submissionId;

    private String status;

    private Long timeUsed;

    private Long memoryUsed;

    private Integer testCasesPassed;

    private Integer testCasesTotal;

    private String compileOutput;
}
