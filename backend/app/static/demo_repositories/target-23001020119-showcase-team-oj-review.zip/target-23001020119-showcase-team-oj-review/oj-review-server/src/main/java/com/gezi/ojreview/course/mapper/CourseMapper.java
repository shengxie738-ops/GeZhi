package com.gezi.ojreview.course.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gezi.ojreview.course.entity.Course;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CourseMapper extends BaseMapper<Course> {
}
