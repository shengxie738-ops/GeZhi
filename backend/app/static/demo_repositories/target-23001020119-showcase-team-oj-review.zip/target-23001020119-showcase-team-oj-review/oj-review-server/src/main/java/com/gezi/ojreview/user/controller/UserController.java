package com.gezi.ojreview.user.controller;

import com.gezi.ojreview.common.api.PageResult;
import com.gezi.ojreview.common.api.Result;
import com.gezi.ojreview.config.WebMvcConfig;
import com.gezi.ojreview.common.security.UserDetailsImpl;
import com.gezi.ojreview.user.dto.UserCreateDTO;
import com.gezi.ojreview.user.dto.UserUpdateDTO;
import com.gezi.ojreview.user.entity.SysUser;
import com.gezi.ojreview.user.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * 用户控制器
 */
@Tag(name = "用户管理")
@RestController
@RequestMapping("/api/v1/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @Operation(summary = "获取当前用户信息")
    @GetMapping("/me")
    public Result<SysUser> getCurrentUser(@WebMvcConfig.CurrentUser UserDetailsImpl currentUser) {
        SysUser user = userService.getUserById(currentUser.getUserId());
        user.setPassword(null);
        return Result.ok(user);
    }

    @Operation(summary = "根据ID获取用户")
    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('TEACHER')")
    public Result<SysUser> getUserById(@PathVariable Long id) {
        SysUser user = userService.getUserById(id);
        user.setPassword(null);
        return Result.ok(user);
    }

    @Operation(summary = "分页查询用户列表")
    @GetMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('TEACHER')")
    public Result<PageResult<SysUser>> listUsers(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String role,
            @RequestParam(required = false) String keyword) {
        PageResult<SysUser> result = userService.listUsers(page, size, role, keyword);
        result.getRecords().forEach(u -> u.setPassword(null));
        return Result.ok(result);
    }

    @Operation(summary = "创建用户")
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public Result<SysUser> createUser(@Valid @RequestBody UserCreateDTO dto) {
        SysUser user = userService.createUser(dto);
        user.setPassword(null);
        return Result.ok(user);
    }

    @Operation(summary = "更新用户信息")
    @PutMapping("/{id}")
    public Result<Void> updateUser(@PathVariable Long id,
                                   @Valid @RequestBody UserUpdateDTO dto,
                                   @WebMvcConfig.CurrentUser UserDetailsImpl currentUser) {
        if (!currentUser.getRole().equals("ADMIN") && !currentUser.getUserId().equals(id)) {
            return Result.fail(403, "只能修改自己的信息");
        }
        userService.updateUser(id, dto);
        return Result.ok();
    }
}
