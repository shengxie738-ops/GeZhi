package com.gezi.ojreview.submission.dto;

import lombok.Data;

/**
 * 提交查询DTO
 */
@Data
public class SubmissionQueryDTO {

    private Integer page = 1;

    private Integer size = 10;

    private Long problemId;

    private String status;

    private String language;
}
