package com.gezi.ojreview.course.controller;

import com.gezi.ojreview.common.api.Result;
import com.gezi.ojreview.course.dto.ChapterCreateDTO;
import com.gezi.ojreview.course.entity.CourseChapter;
import com.gezi.ojreview.course.service.ChapterService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 章节控制器
 */
@Tag(name = "章节管理")
@RestController
@RequestMapping("/api/v1/courses/{courseId}/chapters")
@RequiredArgsConstructor
public class ChapterController {

    private final ChapterService chapterService;

    @Operation(summary = "创建章节")
    @PostMapping
    @PreAuthorize("hasRole('TEACHER') or hasRole('ADMIN')")
    public Result<CourseChapter> createChapter(@PathVariable Long courseId,
                                               @Valid @RequestBody ChapterCreateDTO dto) {
        CourseChapter chapter = chapterService.createChapter(courseId, dto);
        return Result.ok(chapter);
    }

    @Operation(summary = "获取课程章节列表")
    @GetMapping
    public Result<List<CourseChapter>> listChapters(@PathVariable Long courseId) {
        List<CourseChapter> chapters = chapterService.listChapters(courseId);
        return Result.ok(chapters);
    }

    @Operation(summary = "更新章节")
    @PutMapping("/{chapterId}")
    @PreAuthorize("hasRole('TEACHER') or hasRole('ADMIN')")
    public Result<Void> updateChapter(@PathVariable Long chapterId,
                                      @Valid @RequestBody ChapterCreateDTO dto) {
        chapterService.updateChapter(chapterId, dto);
        return Result.ok();
    }

    @Operation(summary = "删除章节")
    @DeleteMapping("/{chapterId}")
    @PreAuthorize("hasRole('TEACHER') or hasRole('ADMIN')")
    public Result<Void> deleteChapter(@PathVariable Long chapterId) {
        chapterService.deleteChapter(chapterId);
        return Result.ok();
    }
}
