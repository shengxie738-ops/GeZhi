package com.gezi.ojreview.user.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gezi.ojreview.common.api.PageResult;
import com.gezi.ojreview.user.dto.UserCreateDTO;
import com.gezi.ojreview.user.dto.UserUpdateDTO;
import com.gezi.ojreview.user.entity.SysUser;

/**
 * 用户服务接口
 */
public interface UserService extends IService<SysUser> {

    /**
     * 根据用户名查询用户
     */
    SysUser getByUsername(String username);

    /**
     * 创建用户（注册）
     */
    SysUser createUser(UserCreateDTO dto);

    /**
     * 更新用户信息
     */
    void updateUser(Long userId, UserUpdateDTO dto);

    /**
     * 分页查询用户列表
     */
    PageResult<SysUser> listUsers(int page, int size, String role, String keyword);

    /**
     * 根据ID获取用户
     */
    SysUser getUserById(Long userId);

    /**
     * 检查用户名是否存在
     */
    boolean existsByUsername(String username);

    /**
     * 检查邮箱是否存在
     */
    boolean existsByEmail(String email);
}
