package com.gezi.ojreview.submission.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gezi.ojreview.common.api.PageResult;
import com.gezi.ojreview.submission.dto.SubmissionQueryDTO;
import com.gezi.ojreview.submission.dto.SubmitCodeDTO;
import com.gezi.ojreview.submission.entity.Submission;

/**
 * 提交服务接口
 */
public interface SubmissionService extends IService<Submission> {

    Submission submitCode(SubmitCodeDTO dto, Long userId);

    PageResult<Submission> listSubmissions(SubmissionQueryDTO queryDTO, Long userId);

    Submission getSubmissionById(Long submissionId);

    void updateSubmissionStatus(Long submissionId, String status, Long timeUsed, Long memoryUsed,
                                Integer passed, Integer total, String compileOutput);
}
