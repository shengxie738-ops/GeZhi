package com.gezi.ojreview.problem.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * 创建题目DTO
 */
@Data
public class ProblemCreateDTO {

    @NotBlank(message = "题目标题不能为空")
    private String title;

    @NotBlank(message = "题目描述不能为空")
    private String description;

    private String inputDesc;

    private String outputDesc;

    private String sampleInput;

    private String sampleOutput;

    private String hint;

    @NotBlank(message = "难度不能为空")
    private String difficulty;

    private Long timeLimit;

    private Long memoryLimit;

    private Long chapterId;

    private String tags;
}
