package com.gezi.ojreview.auth.controller;

import com.gezi.ojreview.auth.dto.LoginDTO;
import com.gezi.ojreview.auth.dto.RefreshTokenDTO;
import com.gezi.ojreview.auth.dto.RegisterDTO;
import com.gezi.ojreview.auth.service.AuthService;
import com.gezi.ojreview.auth.vo.LoginVO;
import com.gezi.ojreview.auth.vo.UserVO;
import com.gezi.ojreview.common.api.Result;
import com.gezi.ojreview.common.security.UserDetailsImpl;
import com.gezi.ojreview.config.WebMvcConfig;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * 认证控制器
 */
@Tag(name = "认证管理")
@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    @Operation(summary = "用户登录")
    @PostMapping("/login")
    public Result<LoginVO> login(@Valid @RequestBody LoginDTO dto) {
        LoginVO loginVO = authService.login(dto);
        return Result.ok(loginVO);
    }

    @Operation(summary = "用户注册")
    @PostMapping("/register")
    public Result<Void> register(@Valid @RequestBody RegisterDTO dto) {
        authService.register(dto);
        return Result.ok();
    }

    @Operation(summary = "刷新Token")
    @PostMapping("/refresh")
    public Result<LoginVO> refreshToken(@Valid @RequestBody RefreshTokenDTO dto) {
        LoginVO loginVO = authService.refreshToken(dto);
        return Result.ok(loginVO);
    }

    @Operation(summary = "用户登出")
    @PostMapping("/logout")
    public Result<Void> logout(@RequestHeader("Authorization") String authorization) {
        authService.logout(authorization);
        return Result.ok();
    }

    @Operation(summary = "获取当前登录用户信息")
    @GetMapping("/me")
    public Result<UserVO> getCurrentUser(@WebMvcConfig.CurrentUser UserDetailsImpl currentUser) {
        UserVO userVO = authService.getCurrentUser(currentUser.getUserId());
        return Result.ok(userVO);
    }
}
