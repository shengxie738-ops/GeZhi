package com.gezi.ojreview.team.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gezi.ojreview.common.api.ErrorCode;
import com.gezi.ojreview.common.exception.BusinessException;
import com.gezi.ojreview.team.dto.TeamCreateDTO;
import com.gezi.ojreview.team.dto.TeamMemberDTO;
import com.gezi.ojreview.team.entity.Team;
import com.gezi.ojreview.team.entity.TeamMember;
import com.gezi.ojreview.team.mapper.TeamMapper;
import com.gezi.ojreview.team.mapper.TeamMemberMapper;
import com.gezi.ojreview.team.service.TeamService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 团队服务实现
 */
@Service
@RequiredArgsConstructor
public class TeamServiceImpl extends ServiceImpl<TeamMapper, Team> implements TeamService {

    private final TeamMemberMapper teamMemberMapper;

    @Override
    @Transactional
    public Team createTeam(TeamCreateDTO dto, Long leaderId) {
        Team team = new Team();
        team.setName(dto.getName());
        team.setDescription(dto.getDescription());
        team.setLeaderId(leaderId);
        team.setCourseId(dto.getCourseId());
        save(team);

        TeamMember member = new TeamMember();
        member.setTeamId(team.getId());
        member.setUserId(leaderId);
        member.setRole("LEADER");
        member.setJoinTime(LocalDateTime.now());
        teamMemberMapper.insert(member);

        return team;
    }

    @Override
    public void deleteTeam(Long teamId) {
        if (getById(teamId) == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND, "团队不存在");
        }
        removeById(teamId);
        teamMemberMapper.delete(new LambdaQueryWrapper<TeamMember>()
                .eq(TeamMember::getTeamId, teamId));
    }

    @Override
    public Team getTeamById(Long teamId) {
        Team team = getById(teamId);
        if (team == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND, "团队不存在");
        }
        return team;
    }

    @Override
    public List<Team> listTeams(Long courseId) {
        return list(new LambdaQueryWrapper<Team>()
                .eq(Team::getCourseId, courseId)
                .orderByDesc(Team::getCreateTime));
    }

    @Override
    public void addMember(Long teamId, TeamMemberDTO dto) {
        boolean exists = teamMemberMapper.selectCount(
                new LambdaQueryWrapper<TeamMember>()
                        .eq(TeamMember::getTeamId, teamId)
                        .eq(TeamMember::getUserId, dto.getUserId())) > 0;
        if (!exists) {
            TeamMember member = new TeamMember();
            member.setTeamId(teamId);
            member.setUserId(dto.getUserId());
            member.setRole("MEMBER");
            member.setJoinTime(LocalDateTime.now());
            teamMemberMapper.insert(member);
        }
    }

    @Override
    public void removeMember(Long teamId, Long userId) {
        teamMemberMapper.delete(new LambdaQueryWrapper<TeamMember>()
                .eq(TeamMember::getTeamId, teamId)
                .eq(TeamMember::getUserId, userId));
    }

    @Override
    public List<Team> listTeamsByUserId(Long userId) {
        List<TeamMember> memberships = teamMemberMapper.selectList(
                new LambdaQueryWrapper<TeamMember>().eq(TeamMember::getUserId, userId));
        if (memberships.isEmpty()) {
            return List.of();
        }
        List<Long> teamIds = memberships.stream().map(TeamMember::getTeamId).toList();
        return listByIds(teamIds);
    }
}
