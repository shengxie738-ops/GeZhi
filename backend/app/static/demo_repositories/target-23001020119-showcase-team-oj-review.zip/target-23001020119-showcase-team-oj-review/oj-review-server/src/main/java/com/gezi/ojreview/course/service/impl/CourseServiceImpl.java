package com.gezi.ojreview.course.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gezi.ojreview.common.api.ErrorCode;
import com.gezi.ojreview.common.api.PageResult;
import com.gezi.ojreview.common.exception.BusinessException;
import com.gezi.ojreview.common.util.PageUtil;
import com.gezi.ojreview.course.dto.CourseCreateDTO;
import com.gezi.ojreview.course.dto.CourseUpdateDTO;
import com.gezi.ojreview.course.entity.Course;
import com.gezi.ojreview.course.entity.CourseMember;
import com.gezi.ojreview.course.mapper.CourseMapper;
import com.gezi.ojreview.course.service.CourseMemberService;
import com.gezi.ojreview.course.service.CourseService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.List;

/**
 * 课程服务实现
 */
@Service
@RequiredArgsConstructor
public class CourseServiceImpl extends ServiceImpl<CourseMapper, Course> implements CourseService {

    private final CourseMemberService courseMemberService;

    @Override
    @Transactional
    public Course createCourse(CourseCreateDTO dto, Long creatorId) {
        Course course = new Course();
        course.setName(dto.getName());
        course.setDescription(dto.getDescription());
        course.setCoverImage(dto.getCoverImage());
        course.setCreatorId(creatorId);
        course.setStatus("ACTIVE");
        course.setTerm(dto.getTerm());
        save(course);

        courseMemberService.addMember(course.getId(), creatorId, "TEACHER");
        return course;
    }

    @Override
    public void updateCourse(Long courseId, CourseUpdateDTO dto) {
        Course course = getById(courseId);
        if (course == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND, "课程不存在");
        }
        if (StringUtils.hasText(dto.getName())) {
            course.setName(dto.getName());
        }
        if (StringUtils.hasText(dto.getDescription())) {
            course.setDescription(dto.getDescription());
        }
        if (StringUtils.hasText(dto.getCoverImage())) {
            course.setCoverImage(dto.getCoverImage());
        }
        if (StringUtils.hasText(dto.getStatus())) {
            course.setStatus(dto.getStatus());
        }
        if (StringUtils.hasText(dto.getTerm())) {
            course.setTerm(dto.getTerm());
        }
        updateById(course);
    }

    @Override
    public PageResult<Course> listCourses(int page, int size, String keyword, String status) {
        Page<Course> pageParam = PageUtil.createPage(page, size);
        LambdaQueryWrapper<Course> wrapper = new LambdaQueryWrapper<>();

        if (StringUtils.hasText(keyword)) {
            wrapper.like(Course::getName, keyword);
        }
        if (StringUtils.hasText(status)) {
            wrapper.eq(Course::getStatus, status);
        }
        wrapper.orderByDesc(Course::getCreateTime);

        Page<Course> result = page(pageParam, wrapper);
        return PageUtil.toPageResult(result);
    }

    @Override
    public Course getCourseById(Long courseId) {
        Course course = getById(courseId);
        if (course == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND, "课程不存在");
        }
        return course;
    }

    @Override
    public void deleteCourse(Long courseId) {
        if (getById(courseId) == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND, "课程不存在");
        }
        removeById(courseId);
    }

    @Override
    public List<Course> listCoursesByUserId(Long userId) {
        List<CourseMember> members = courseMemberService.list(
                new LambdaQueryWrapper<CourseMember>().eq(CourseMember::getUserId, userId));
        if (members.isEmpty()) {
            return List.of();
        }
        List<Long> courseIds = members.stream().map(CourseMember::getCourseId).toList();
        return listByIds(courseIds);
    }
}
