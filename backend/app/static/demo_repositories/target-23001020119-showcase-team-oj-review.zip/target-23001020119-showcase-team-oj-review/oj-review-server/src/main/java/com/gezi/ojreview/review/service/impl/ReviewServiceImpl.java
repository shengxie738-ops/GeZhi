package com.gezi.ojreview.review.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gezi.ojreview.common.api.ErrorCode;
import com.gezi.ojreview.common.api.PageResult;
import com.gezi.ojreview.common.exception.BusinessException;
import com.gezi.ojreview.common.util.PageUtil;
import com.gezi.ojreview.review.dto.ReviewCreateDTO;
import com.gezi.ojreview.review.entity.TeacherReview;
import com.gezi.ojreview.review.mapper.TeacherReviewMapper;
import com.gezi.ojreview.review.service.ReviewService;
import org.springframework.stereotype.Service;

/**
 * 复盘服务实现
 */
@Service
public class ReviewServiceImpl extends ServiceImpl<TeacherReviewMapper, TeacherReview> implements ReviewService {

    @Override
    public TeacherReview createReview(ReviewCreateDTO dto, Long teacherId) {
        TeacherReview review = new TeacherReview();
        review.setTeacherId(teacherId);
        review.setStudentId(dto.getStudentId());
        review.setCourseId(dto.getCourseId());
        review.setSubmissionId(dto.getSubmissionId());
        review.setProblemId(dto.getProblemId());
        review.setComment(dto.getComment());
        review.setRating(dto.getRating());
        save(review);
        return review;
    }

    @Override
    public PageResult<TeacherReview> listReviews(Long courseId, Long studentId, int page, int size) {
        Page<TeacherReview> pageParam = PageUtil.createPage(page, size);
        LambdaQueryWrapper<TeacherReview> wrapper = new LambdaQueryWrapper<>();

        if (courseId != null) {
            wrapper.eq(TeacherReview::getCourseId, courseId);
        }
        if (studentId != null) {
            wrapper.eq(TeacherReview::getStudentId, studentId);
        }
        wrapper.orderByDesc(TeacherReview::getCreateTime);

        Page<TeacherReview> result = page(pageParam, wrapper);
        return PageUtil.toPageResult(result);
    }

    @Override
    public TeacherReview getReviewById(Long reviewId) {
        TeacherReview review = getById(reviewId);
        if (review == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND, "复盘记录不存在");
        }
        return review;
    }

    @Override
    public void deleteReview(Long reviewId) {
        if (getById(reviewId) == null) {
            throw new BusinessException(ErrorCode.NOT_FOUND, "复盘记录不存在");
        }
        removeById(reviewId);
    }
}
