package com.gezi.ojreview.common.enums;

import lombok.Getter;

/**
 * 错题状态枚举
 */
@Getter
public enum WrongBookStatus {

    UNRESOLVED("UNRESOLVED", "未解决"),
    REVIEWING("REVIEWING", "复习中"),
    RESOLVED("RESOLVED", "已解决"),
    MASTERED("MASTERED", "已掌握");

    private final String code;
    private final String description;

    WrongBookStatus(String code, String description) {
        this.code = code;
        this.description = description;
    }
}
