-- ============================================================
-- OJ Review 数据库初始化脚本
-- 创建所有 15 张表
-- ============================================================

SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4;

-- 1. 用户表
CREATE TABLE IF NOT EXISTS `sys_user` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '用户ID',
    `username` VARCHAR(50) NOT NULL COMMENT '用户名（登录用）',
    `password` VARCHAR(255) NOT NULL COMMENT '密码（BCrypt加密）',
    `real_name` VARCHAR(50) NOT NULL COMMENT '真实姓名',
    `student_no` VARCHAR(30) DEFAULT NULL COMMENT '学号/工号',
    `email` VARCHAR(100) DEFAULT NULL COMMENT '邮箱',
    `avatar` VARCHAR(500) DEFAULT NULL COMMENT '头像URL',
    `role` ENUM('STUDENT', 'TEACHER', 'ADMIN') NOT NULL DEFAULT 'STUDENT' COMMENT '角色',
    `status` TINYINT NOT NULL DEFAULT 1 COMMENT '状态：0-禁用 1-启用',
    `last_login_at` DATETIME DEFAULT NULL COMMENT '最后登录时间',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_username` (`username`),
    UNIQUE KEY `uk_student_no` (`student_no`),
    KEY `idx_role` (`role`),
    KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户表';

-- 2. 课程表
CREATE TABLE IF NOT EXISTS `course` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '课程ID',
    `name` VARCHAR(100) NOT NULL COMMENT '课程名称',
    `code` VARCHAR(50) NOT NULL COMMENT '课程代码',
    `description` TEXT COMMENT '课程描述',
    `cover_image` VARCHAR(500) DEFAULT NULL COMMENT '封面图URL',
    `teacher_id` BIGINT NOT NULL COMMENT '授课教师ID',
    `status` ENUM('DRAFT', 'PUBLISHED', 'ARCHIVED') NOT NULL DEFAULT 'DRAFT' COMMENT '课程状态',
    `max_students` INT NOT NULL DEFAULT 100 COMMENT '最大学生数',
    `start_date` DATE DEFAULT NULL COMMENT '开始日期',
    `end_date` DATE DEFAULT NULL COMMENT '结束日期',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_code` (`code`),
    KEY `idx_teacher_id` (`teacher_id`),
    KEY `idx_status` (`status`),
    CONSTRAINT `fk_course_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `sys_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='课程表';

-- 3. 课程成员表
CREATE TABLE IF NOT EXISTS `course_member` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '记录ID',
    `course_id` BIGINT NOT NULL COMMENT '课程ID',
    `user_id` BIGINT NOT NULL COMMENT '用户ID',
    `role` ENUM('STUDENT', 'TEACHER', 'TA') NOT NULL DEFAULT 'STUDENT' COMMENT '课程角色',
    `joined_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '加入时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_course_user` (`course_id`, `user_id`),
    KEY `idx_user_id` (`user_id`),
    CONSTRAINT `fk_cm_course` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`),
    CONSTRAINT `fk_cm_user` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='课程成员表';

-- 4. 课程章节表
CREATE TABLE IF NOT EXISTS `course_chapter` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '章节ID',
    `course_id` BIGINT NOT NULL COMMENT '课程ID',
    `title` VARCHAR(200) NOT NULL COMMENT '章节标题',
    `description` TEXT COMMENT '章节描述',
    `sort_order` INT NOT NULL DEFAULT 0 COMMENT '排序序号',
    `status` ENUM('DRAFT', 'PUBLISHED') NOT NULL DEFAULT 'DRAFT' COMMENT '状态',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    KEY `idx_course_id` (`course_id`),
    CONSTRAINT `fk_chapter_course` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='课程章节表';

-- 5. 题目表
CREATE TABLE IF NOT EXISTS `problem` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '题目ID',
    `title` VARCHAR(200) NOT NULL COMMENT '题目标题',
    `description` TEXT NOT NULL COMMENT '题目描述（Markdown）',
    `input_description` TEXT COMMENT '输入说明',
    `output_description` TEXT COMMENT '输出说明',
    `sample_input` TEXT COMMENT '样例输入',
    `sample_output` TEXT COMMENT '样例输出',
    `hint` TEXT COMMENT '提示/说明',
    `difficulty` ENUM('EASY', 'MEDIUM', 'HARD') NOT NULL DEFAULT 'MEDIUM' COMMENT '难度',
    `time_limit_ms` INT NOT NULL DEFAULT 1000 COMMENT '时间限制（毫秒）',
    `memory_limit_mb` INT NOT NULL DEFAULT 256 COMMENT '内存限制（MB）',
    `chapter_id` BIGINT DEFAULT NULL COMMENT '所属章节ID',
    `course_id` BIGINT DEFAULT NULL COMMENT '所属课程ID',
    `author_id` BIGINT DEFAULT NULL COMMENT '出题人ID',
    `status` ENUM('DRAFT', 'PUBLISHED', 'ARCHIVED') NOT NULL DEFAULT 'DRAFT' COMMENT '状态',
    `accept_count` INT NOT NULL DEFAULT 0 COMMENT '通过次数',
    `submit_count` INT NOT NULL DEFAULT 0 COMMENT '提交次数',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    KEY `idx_chapter_id` (`chapter_id`),
    KEY `idx_course_id` (`course_id`),
    KEY `idx_difficulty` (`difficulty`),
    KEY `idx_status` (`status`),
    CONSTRAINT `fk_problem_chapter` FOREIGN KEY (`chapter_id`) REFERENCES `course_chapter` (`id`),
    CONSTRAINT `fk_problem_course` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`),
    CONSTRAINT `fk_problem_author` FOREIGN KEY (`author_id`) REFERENCES `sys_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='题目表';

-- 6. 测试用例表
CREATE TABLE IF NOT EXISTS `problem_test_case` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '测试用例ID',
    `problem_id` BIGINT NOT NULL COMMENT '题目ID',
    `input_data` TEXT NOT NULL COMMENT '输入数据',
    `expected_output` TEXT NOT NULL COMMENT '期望输出',
    `is_public` TINYINT NOT NULL DEFAULT 0 COMMENT '是否公开（样例测试点）',
    `score` DECIMAL(5,1) NOT NULL DEFAULT 0 COMMENT '分值',
    `sort_order` INT NOT NULL DEFAULT 0 COMMENT '排序序号',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    KEY `idx_problem_id` (`problem_id`),
    CONSTRAINT `fk_tc_problem` FOREIGN KEY (`problem_id`) REFERENCES `problem` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='测试用例表';

-- 7. 代码草稿表
CREATE TABLE IF NOT EXISTS `code_draft` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '草稿ID',
    `user_id` BIGINT NOT NULL COMMENT '用户ID',
    `problem_id` BIGINT NOT NULL COMMENT '题目ID',
    `language` VARCHAR(20) NOT NULL COMMENT '编程语言',
    `source_code` TEXT NOT NULL COMMENT '源代码',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_user_problem_lang` (`user_id`, `problem_id`, `language`),
    CONSTRAINT `fk_draft_user` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`id`),
    CONSTRAINT `fk_draft_problem` FOREIGN KEY (`problem_id`) REFERENCES `problem` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='代码草稿表';

-- 8. 提交表
CREATE TABLE IF NOT EXISTS `submission` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '提交ID',
    `user_id` BIGINT NOT NULL COMMENT '用户ID',
    `problem_id` BIGINT NOT NULL COMMENT '题目ID',
    `course_id` BIGINT DEFAULT NULL COMMENT '课程ID',
    `language` VARCHAR(20) NOT NULL COMMENT '编程语言（JAVA/PYTHON/CPP）',
    `source_code` TEXT NOT NULL COMMENT '源代码',
    `status` ENUM('PENDING','JUDGING','ACCEPTED','WRONG_ANSWER','TIME_LIMIT_EXCEEDED','MEMORY_LIMIT_EXCEEDED','RUNTIME_ERROR','COMPILE_ERROR','SYSTEM_ERROR') NOT NULL DEFAULT 'PENDING' COMMENT '判题状态',
    `score` DECIMAL(6,1) NOT NULL DEFAULT 0 COMMENT '得分',
    `time_used_ms` INT DEFAULT NULL COMMENT '运行时间（毫秒）',
    `memory_used_kb` INT DEFAULT NULL COMMENT '内存使用（KB）',
    `compile_output` TEXT COMMENT '编译输出',
    `runtime_output` TEXT COMMENT '运行时输出',
    `passed_case_count` INT NOT NULL DEFAULT 0 COMMENT '通过测试点数',
    `total_case_count` INT NOT NULL DEFAULT 0 COMMENT '总测试点数',
    `ip_address` VARCHAR(45) DEFAULT NULL COMMENT '提交IP地址',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '提交时间',
    `judged_at` DATETIME DEFAULT NULL COMMENT '判题完成时间',
    PRIMARY KEY (`id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_problem_id` (`problem_id`),
    KEY `idx_course_id` (`course_id`),
    KEY `idx_status` (`status`),
    KEY `idx_created_at` (`created_at`),
    CONSTRAINT `fk_sub_user` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`id`),
    CONSTRAINT `fk_sub_problem` FOREIGN KEY (`problem_id`) REFERENCES `problem` (`id`),
    CONSTRAINT `fk_sub_course` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='提交表';

-- 9. 测试点结果表
CREATE TABLE IF NOT EXISTS `submission_case_result` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '结果ID',
    `submission_id` BIGINT NOT NULL COMMENT '提交ID',
    `test_case_id` BIGINT NOT NULL COMMENT '测试用例ID',
    `status` VARCHAR(30) NOT NULL COMMENT '状态（ACCEPTED/WRONG_ANSWER等）',
    `time_used_ms` INT DEFAULT NULL COMMENT '运行时间（毫秒）',
    `memory_used_kb` INT DEFAULT NULL COMMENT '内存使用（KB）',
    `actual_output` TEXT COMMENT '实际输出',
    `error_message` TEXT COMMENT '错误信息',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    KEY `idx_submission_id` (`submission_id`),
    KEY `idx_test_case_id` (`test_case_id`),
    CONSTRAINT `fk_tcr_submission` FOREIGN KEY (`submission_id`) REFERENCES `submission` (`id`),
    CONSTRAINT `fk_tcr_test_case` FOREIGN KEY (`test_case_id`) REFERENCES `problem_test_case` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='测试点结果表';

-- 10. 错题本表
CREATE TABLE IF NOT EXISTS `wrong_book` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '记录ID',
    `user_id` BIGINT NOT NULL COMMENT '用户ID',
    `problem_id` BIGINT NOT NULL COMMENT '题目ID',
    `submission_id` BIGINT DEFAULT NULL COMMENT '最近一次错误提交ID',
    `error_type` VARCHAR(30) DEFAULT NULL COMMENT '错误类型',
    `note` TEXT COMMENT '用户笔记',
    `is_mastered` TINYINT NOT NULL DEFAULT 0 COMMENT '是否已掌握',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_user_problem` (`user_id`, `problem_id`),
    KEY `idx_problem_id` (`problem_id`),
    KEY `idx_is_mastered` (`is_mastered`),
    CONSTRAINT `fk_wb_user` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`id`),
    CONSTRAINT `fk_wb_problem` FOREIGN KEY (`problem_id`) REFERENCES `problem` (`id`),
    CONSTRAINT `fk_wb_submission` FOREIGN KEY (`submission_id`) REFERENCES `submission` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='错题本表';

-- 11. 团队表
CREATE TABLE IF NOT EXISTS `team` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '团队ID',
    `name` VARCHAR(100) NOT NULL COMMENT '团队名称',
    `description` TEXT COMMENT '团队描述',
    `course_id` BIGINT NOT NULL COMMENT '所属课程ID',
    `leader_id` BIGINT DEFAULT NULL COMMENT '队长用户ID',
    `max_members` INT NOT NULL DEFAULT 6 COMMENT '最大成员数',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    KEY `idx_course_id` (`course_id`),
    KEY `idx_leader_id` (`leader_id`),
    CONSTRAINT `fk_team_course` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`),
    CONSTRAINT `fk_team_leader` FOREIGN KEY (`leader_id`) REFERENCES `sys_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='团队表';

-- 12. 团队成员表
CREATE TABLE IF NOT EXISTS `team_member` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '记录ID',
    `team_id` BIGINT NOT NULL COMMENT '团队ID',
    `user_id` BIGINT NOT NULL COMMENT '用户ID',
    `role` ENUM('MEMBER', 'LEADER') NOT NULL DEFAULT 'MEMBER' COMMENT '团队内角色',
    `joined_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '加入时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_team_user` (`team_id`, `user_id`),
    KEY `idx_user_id` (`user_id`),
    CONSTRAINT `fk_tm_team` FOREIGN KEY (`team_id`) REFERENCES `team` (`id`),
    CONSTRAINT `fk_tm_user` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='团队成员表';

-- 13. 教师复盘表
CREATE TABLE IF NOT EXISTS `teacher_review` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '复盘ID',
    `teacher_id` BIGINT NOT NULL COMMENT '教师ID',
    `course_id` BIGINT NOT NULL COMMENT '课程ID',
    `submission_id` BIGINT DEFAULT NULL COMMENT '关联提交ID',
    `problem_id` BIGINT DEFAULT NULL COMMENT '关联题目ID',
    `team_id` BIGINT DEFAULT NULL COMMENT '关联团队ID',
    `content` TEXT NOT NULL COMMENT '复盘内容（Markdown）',
    `review_type` ENUM('SUBMISSION', 'TEAM', 'PROBLEM', 'GENERAL') NOT NULL DEFAULT 'GENERAL' COMMENT '复盘类型',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    KEY `idx_teacher_id` (`teacher_id`),
    KEY `idx_course_id` (`course_id`),
    KEY `idx_submission_id` (`submission_id`),
    KEY `idx_team_id` (`team_id`),
    CONSTRAINT `fk_tr_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `sys_user` (`id`),
    CONSTRAINT `fk_tr_course` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`),
    CONSTRAINT `fk_tr_submission` FOREIGN KEY (`submission_id`) REFERENCES `submission` (`id`),
    CONSTRAINT `fk_tr_team` FOREIGN KEY (`team_id`) REFERENCES `team` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='教师复盘表';

-- 14. 通知表
CREATE TABLE IF NOT EXISTS `notification` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '通知ID',
    `user_id` BIGINT NOT NULL COMMENT '接收用户ID',
    `title` VARCHAR(200) NOT NULL COMMENT '通知标题',
    `content` TEXT NOT NULL COMMENT '通知内容',
    `type` ENUM('SYSTEM', 'COURSE', 'JUDGE', 'TEAM', 'REVIEW') NOT NULL DEFAULT 'SYSTEM' COMMENT '通知类型',
    `is_read` TINYINT NOT NULL DEFAULT 0 COMMENT '是否已读',
    `related_id` BIGINT DEFAULT NULL COMMENT '关联业务ID',
    `related_type` VARCHAR(30) DEFAULT NULL COMMENT '关联业务类型',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_is_read` (`is_read`),
    KEY `idx_type` (`type`),
    KEY `idx_created_at` (`created_at`),
    CONSTRAINT `fk_notif_user` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='通知表';

-- 15. 审计日志表
CREATE TABLE IF NOT EXISTS `audit_log` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '日志ID',
    `user_id` BIGINT DEFAULT NULL COMMENT '操作用户ID',
    `action` VARCHAR(50) NOT NULL COMMENT '操作类型',
    `resource_type` VARCHAR(30) NOT NULL COMMENT '资源类型',
    `resource_id` BIGINT DEFAULT NULL COMMENT '资源ID',
    `detail` TEXT COMMENT '操作详情（JSON）',
    `ip_address` VARCHAR(45) DEFAULT NULL COMMENT 'IP地址',
    `user_agent` VARCHAR(500) DEFAULT NULL COMMENT 'User-Agent',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_action` (`action`),
    KEY `idx_resource` (`resource_type`, `resource_id`),
    KEY `idx_created_at` (`created_at`),
    CONSTRAINT `fk_log_user` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='审计日志表';
