-- ============================================================
-- OJ Review 种子数据脚本
-- 包含演示账号、课程、题目、提交记录等完整数据
-- ============================================================

SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4;

-- ============================================================
-- 1. 用户数据
-- 密码均为 BCrypt 加密后的值
-- admin/Admin@123, teacher/Teacher@123, 学生/Student@123
-- ============================================================

INSERT INTO `sys_user` (`id`, `username`, `password`, `real_name`, `student_no`, `email`, `role`, `status`) VALUES
(1, 'admin',     '$2a$10$N.ZOn9G6w3Fz4nFHRXn5GOe9Th2jKZqK7TAKpXv4pG1wFkBmvUYCi', '系统管理员', NULL,            'admin@oj-review.com',  'ADMIN',   1),
(2, 'teacher',   '$2a$10$EqKcp1WFKAr0GjP2nMqMkeVHJwN0GZM.XD/f3/M7kGfF3FCm8Pi6', '张老师',     'T2026001',     'zhang@oj-review.com',  'TEACHER', 1),
(3, 'xieyu',     '$2a$10$7ABcDeFgHiJkLmNoPqRsTUVWxyZaBcDeFgHiJkLmNoPqRsTUVW', '谢瑜',       '23001020119',  'xieyu@stu.edu.cn',     'STUDENT', 1),
(4, 'jiangjc',   '$2a$10$7ABcDeFgHiJkLmNoPqRsTUVWxyZaBcDeFgHiJkLmNoPqRsTUVW', '江景琛',     '23001020120',  'jiangjc@stu.edu.cn',   'STUDENT', 1),
(5, 'luzhiyu',   '$2a$10$7ABcDeFgHiJkLmNoPqRsTUVWxyZaBcDeFgHiJkLmNoPqRsTUVW', '陆知屿',     '23001020121',  'luzhiyu@stu.edu.cn',   'STUDENT', 1),
(6, 'shenyanci', '$2a$10$7ABcDeFgHiJkLmNoPqRsTUVWxyZaBcDeFgHiJkLmNoPqRsTUVW', '沈砚辞',     '23001020122',  'shenyanci@stu.edu.cn', 'STUDENT', 1),
(7, 'guxingci',  '$2a$10$7ABcDeFgHiJkLmNoPqRsTUVWxyZaBcDeFgHiJkLmNoPqRsTUVW', '顾星辞',     '23001020123',  'guxingci@stu.edu.cn',  'STUDENT', 1),
(8, 'suchen',    '$2a$10$7ABcDeFgHiJkLmNoPqRsTUVWxyZaBcDeFgHiJkLmNoPqRsTUVW', '苏沐辰',     '23001020124',  'suchen@stu.edu.cn',    'STUDENT', 1);

-- ============================================================
-- 2. 课程数据
-- ============================================================

INSERT INTO `course` (`id`, `name`, `code`, `description`, `teacher_id`, `status`, `max_students`, `start_date`, `end_date`) VALUES
(1, '编程团队实训', 'OJ-REVIEW-2026', '面向计算机专业学生的编程团队实训课程，通过在线评测与团队协作提升编程能力。涵盖基础语法、算法设计、数据结构等核心内容。', 2, 'PUBLISHED', 60, '2026-03-01', '2026-07-31');

-- ============================================================
-- 3. 课程成员数据
-- ============================================================

INSERT INTO `course_member` (`course_id`, `user_id`, `role`) VALUES
(1, 2, 'TEACHER'),
(1, 3, 'STUDENT'),
(1, 4, 'STUDENT'),
(1, 5, 'STUDENT'),
(1, 6, 'STUDENT'),
(1, 7, 'STUDENT'),
(1, 8, 'STUDENT');

-- ============================================================
-- 4. 章节数据（5个章节）
-- ============================================================

INSERT INTO `course_chapter` (`id`, `course_id`, `title`, `description`, `sort_order`, `status`) VALUES
(1, 1, '基础输入输出',       '学习基本的输入输出操作，掌握 Scanner/scanf/input 等标准输入方法',                      1, 'PUBLISHED'),
(2, 1, '分支与循环',         '掌握 if-else、switch、for、while 等控制流语句',                                       2, 'PUBLISHED'),
(3, 1, '数组与字符串',       '学习一维数组、二维数组、字符串操作及常用算法',                                         3, 'PUBLISHED'),
(4, 1, '函数与递归',         '理解函数定义与调用、参数传递、递归思想与经典递归问题',                                 4, 'PUBLISHED'),
(5, 1, '数据结构基础',       '学习栈、队列、链表、哈希表等基本数据结构及其应用',                                     5, 'PUBLISHED');

-- ============================================================
-- 5. 题目数据（20道题目）
-- ============================================================

INSERT INTO `problem` (`id`, `title`, `description`, `input_description`, `output_description`, `sample_input`, `sample_output`, `hint`, `difficulty`, `time_limit_ms`, `memory_limit_mb`, `chapter_id`, `course_id`, `author_id`, `status`, `accept_count`, `submit_count`) VALUES

-- 第1章：基础输入输出（4题）
(1, 'A+B Problem',
    '计算两个整数 A 和 B 的和。',
    '一行包含两个整数 A 和 B，用空格分隔。（-10^9 ≤ A, B ≤ 10^9）',
    '一行输出 A+B 的值。',
    '3 5', '8',
    '注意使用 long 类型处理大整数',
    'EASY', 1000, 128, 1, 1, 2, 'PUBLISHED', 156, 180),

(2, 'Hello OJ',
    '输出字符串 "Hello OJ!"。这是你的第一道编程题！',
    '无输入',
    '一行输出 Hello OJ!',
    '', 'Hello OJ!',
    '直接使用输出语句即可',
    'EASY', 1000, 128, 1, 1, 2, 'PUBLISHED', 142, 150),

(3, '多组输入求和',
    '输入包含多组测试数据，每组数据包含两个整数，输出每组数据的和。',
    '输入包含多组测试数据。每组占一行，包含两个整数 A 和 B。',
    '对于每组输入，输出一行 A+B 的值。',
    '1 2\n3 4\n5 6', '3\n7\n11',
    '注意处理 EOF，可以使用 while(cin >> a >> b) 或 while(scanf(...) != EOF)',
    'EASY', 1000, 128, 1, 1, 2, 'PUBLISHED', 120, 145),

(4, '格式化输出',
    '读入三个整数 a, b, c，按格式 "a + b = c" 输出。',
    '一行三个整数 a, b, c，空格分隔。',
    '一行输出 "a + b = c" 的格式（a, b, c 替换为实际值）。',
    '3 5 8', '3 + 5 = 8',
    '注意输出格式中的空格',
    'EASY', 1000, 128, 1, 1, 2, 'PUBLISHED', 110, 130),

-- 第2章：分支与循环（4题）
(5, '判断奇偶数',
    '输入一个整数，判断它是奇数还是偶数。',
    '一行一个整数 n。（-10^9 ≤ n ≤ 10^9）',
    '如果 n 是偶数输出 "Even"，否则输出 "Odd"。',
    '4', 'Even',
    '使用取模运算 % 判断',
    'EASY', 1000, 128, 2, 1, 2, 'PUBLISHED', 105, 115),

(6, '成绩等级判定',
    '根据百分制成绩输出等级：90-100为A，80-89为B，70-79为C，60-69为D，60以下为E。',
    '一行一个整数 score (0 ≤ score ≤ 100)',
    '一行输出对应等级。',
    '85', 'B',
    '使用 if-else 或 switch 语句',
    'EASY', 1000, 128, 2, 1, 2, 'PUBLISHED', 98, 110),

(7, '水仙花数',
    '输出所有三位数中的水仙花数。水仙花数是指一个三位数，其各位数字立方和等于该数本身。',
    '无输入',
    '每行输出一个水仙花数，从小到大排列。',
    '', '153\n370\n371\n407',
    '遍历 100-999，分解百位、十位、个位',
    'EASY', 1000, 128, 2, 1, 2, 'PUBLISHED', 88, 102),

(8, '求最大值',
    '输入 n 个整数，输出其中的最大值。',
    '第一行一个整数 n (1 ≤ n ≤ 1000)。第二行 n 个整数，空格分隔。',
    '一行输出最大值。',
    '5\n1 3 5 2 4', '5',
    '维护一个变量记录当前最大值',
    'EASY', 1000, 128, 2, 1, 2, 'PUBLISHED', 92, 108),

-- 第3章：数组与字符串（4题）
(9, '冒泡排序',
    '使用冒泡排序算法对 n 个整数进行升序排序。',
    '第一行一个整数 n (1 ≤ n ≤ 1000)。第二行 n 个整数。',
    '一行输出排序后的结果，空格分隔。',
    '5\n5 3 1 4 2', '1 2 3 4 5',
    '双重循环，外层控制轮数，内层比较相邻元素',
    'EASY', 1000, 128, 3, 1, 2, 'PUBLISHED', 75, 95),

(10, '字符串反转',
    '输入一个字符串，输出其反转后的结果。',
    '一行一个字符串（长度不超过 1000）。',
    '一行输出反转后的字符串。',
    'hello', 'olleh',
    '可以从后往前遍历，或使用内置反转函数',
    'EASY', 1000, 128, 3, 1, 2, 'PUBLISHED', 80, 95),

(11, '矩阵转置',
    '输入一个 m×n 的矩阵，输出其转置矩阵。',
    '第一行两个整数 m, n (1 ≤ m, n ≤ 100)。接下来 m 行，每行 n 个整数。',
    '输出 n 行，每行 m 个整数。',
    '2 3\n1 2 3\n4 5 6', '1 4\n2 5\n3 6',
    '转置即行列互换',
    'MEDIUM', 1000, 256, 3, 1, 2, 'PUBLISHED', 62, 88),

(12, '字符串统计',
    '统计输入字符串中大写字母、小写字母、数字和其他字符的个数。',
    '一行一个字符串（长度不超过 1000）。',
    '四行分别输出大写字母、小写字母、数字、其他字符的个数。',
    'Hello World! 123', '2\n8\n3\n2',
    '使用字符的 ASCII 码范围判断',
    'EASY', 1000, 128, 3, 1, 2, 'PUBLISHED', 70, 85),

-- 第4章：函数与递归（4题）
(13, '斐波那契数列',
    '计算斐波那契数列第 n 项的值。F(1)=1, F(2)=1, F(n)=F(n-1)+F(n-2)。',
    '一行一个整数 n (1 ≤ n ≤ 40)。',
    '一行输出 F(n) 的值。',
    '10', '55',
    '可以使用递归或递推，递推效率更高',
    'EASY', 1000, 128, 4, 1, 2, 'PUBLISHED', 78, 96),

(14, '递归求阶乘',
    '用递归方法计算 n 的阶乘。',
    '一行一个整数 n (0 ≤ n ≤ 20)。',
    '一行输出 n! 的值。',
    '5', '120',
    '注意 n=0 时阶乘为 1',
    'EASY', 1000, 128, 4, 1, 2, 'PUBLISHED', 82, 98),

(15, '汉诺塔问题',
    '实现汉诺塔问题的求解，输出移动步骤。',
    '一行一个整数 n (1 ≤ n ≤ 10)，表示盘子数量。',
    '每行输出一步移动，格式为 "a -> b"。最后输出总步数。',
    '2', 'A -> B\nA -> C\nB -> C\n3',
    '经典递归：将 n-1 个盘子移到辅助柱，最大盘移到目标柱，再将 n-1 个盘子移回来',
    'MEDIUM', 1000, 256, 4, 1, 2, 'PUBLISHED', 55, 80),

(16, '最大子段和',
    '给定 n 个整数（可能为负数），求连续子段的最大和。',
    '第一行一个整数 n (1 ≤ n ≤ 100000)。第二行 n 个整数。',
    '一行输出最大子段和。',
    '6\n-2 11 -4 13 -5 -2', '20',
    '使用 Kadane 算法：维护当前子段和，如果为负则重新开始',
    'MEDIUM', 1000, 256, 4, 1, 2, 'PUBLISHED', 48, 78),

-- 第5章：数据结构基础（4题）
(17, '括号匹配',
    '判断一个只包含 ()[]{} 的字符串是否括号匹配。',
    '一行一个字符串（长度不超过 10000）。',
    '匹配输出 "Yes"，否则输出 "No"。',
    '([{}])', 'Yes',
    '使用栈：遇到左括号入栈，遇到右括号检查栈顶',
    'MEDIUM', 1000, 256, 5, 1, 2, 'PUBLISHED', 52, 85),

(18, '栈的基本操作',
    '实现栈的 push、pop、top 操作。输入一系列操作命令，输出对应结果。',
    '第一行一个整数 n (1 ≤ n ≤ 1000)，表示操作数。接下来 n 行，每行一个操作：push x, pop, top。',
    '对于 pop 和 top 操作，输出栈顶元素。如果栈为空输出 "Empty"。',
    '5\npush 1\npush 2\ntop\npop\ntop', '2\n2\n1',
    '可以使用数组模拟栈',
    'MEDIUM', 1000, 256, 5, 1, 2, 'PUBLISHED', 58, 82),

(19, '约瑟夫环',
    'n 个人围成一圈，从第一个人开始报数，报到 m 的人出列，求出列顺序。',
    '一行两个整数 n 和 m (1 ≤ n, m ≤ 1000)。',
    '一行输出出列顺序，空格分隔。',
    '5 3', '3 1 5 2 4',
    '使用循环链表或队列模拟',
    'MEDIUM', 1000, 256, 5, 1, 2, 'PUBLISHED', 42, 72),

(20, '学生成绩统计',
    '输入 n 个学生的姓名和成绩，按成绩从高到低排序输出。成绩相同时按姓名字典序排列。',
    '第一行一个整数 n (1 ≤ n ≤ 1000)。接下来 n 行，每行格式为 "姓名 成绩"。',
    '按要求排序后，每行输出一个学生的姓名和成绩。',
    '3\nAlice 90\nBob 85\nCharlie 90', 'Alice 90\nCharlie 90\nBob 85',
    '使用结构体/对象存储，自定义排序比较函数',
    'MEDIUM', 1000, 256, 5, 1, 2, 'PUBLISHED', 56, 80);

-- ============================================================
-- 6. 测试用例数据
-- ============================================================

-- Problem 1: A+B Problem
INSERT INTO `problem_test_case` (`problem_id`, `input_data`, `expected_output`, `is_public`, `score`, `sort_order`) VALUES
(1, '3 5',       '8',           1, 10, 1),
(1, '0 0',       '0',           0, 10, 2),
(1, '-1 1',      '0',           0, 10, 3),
(1, '1000000000 1000000000', '2000000000', 0, 10, 4),
(1, '-999999999 999999999',  '0',          0, 10, 5);

-- Problem 17: 括号匹配
INSERT INTO `problem_test_case` (`problem_id`, `input_data`, `expected_output`, `is_public`, `score`, `sort_order`) VALUES
(17, '([{}])',   'Yes',  1, 10, 1),
(17, '([)]',     'No',   0, 10, 2),
(17, '{[]}',     'Yes',  0, 10, 3),
(17, '(',        'No',   0, 10, 4),
(17, '',         'Yes',  0, 10, 5);

-- Problem 16: 最大子段和
INSERT INTO `problem_test_case` (`problem_id`, `input_data`, `expected_output`, `is_public`, `score`, `sort_order`) VALUES
(16, '6\n-2 11 -4 13 -5 -2',  '20', 1, 20, 1),
(16, '1\n-1',                  '-1', 0, 20, 2),
(16, '5\n1 2 3 4 5',          '15', 0, 20, 3);

-- Problem 20: 学生成绩统计
INSERT INTO `problem_test_case` (`problem_id`, `input_data`, `expected_output`, `is_public`, `score`, `sort_order`) VALUES
(20, '3\nAlice 90\nBob 85\nCharlie 90', 'Alice 90\nCharlie 90\nBob 85', 1, 25, 1),
(20, '1\nZhang 100',                     'Zhang 100',                     0, 25, 2),
(20, '4\nLi 80\nWang 80\nZhao 90\nLiu 70', 'Zhao 90\nLi 80\nWang 80\nLiu 70', 0, 25, 3);

-- ============================================================
-- 7. 提交记录（100条，多种判题状态）
-- ============================================================

INSERT INTO `submission` (`id`, `user_id`, `problem_id`, `course_id`, `language`, `source_code`, `status`, `score`, `time_used_ms`, `memory_used_kb`, `passed_case_count`, `total_case_count`, `created_at`, `judged_at`) VALUES

-- 谢瑜的提交（25条）
(1,  3, 1,  1, 'JAVA',    'import java.util.Scanner;\npublic class Main {\n  public static void main(String[] args) {\n    Scanner sc = new Scanner(System.in);\n    int a = sc.nextInt(), b = sc.nextInt();\n    System.out.println(a + b);\n  }\n}', 'ACCEPTED', 50, 120, 15360, 5, 5, '2026-03-15 10:23:45', '2026-03-15 10:23:47'),
(2,  3, 2,  1, 'JAVA',    'public class Main {\n  public static void main(String[] args) {\n    System.out.println("Hello OJ!");\n  }\n}', 'ACCEPTED', 100, 95, 12288, 1, 1, '2026-03-15 10:30:12', '2026-03-15 10:30:13'),
(3,  3, 3,  1, 'JAVA',    'import java.util.Scanner;\npublic class Main {\n  public static void main(String[] args) {\n    Scanner sc = new Scanner(System.in);\n    while(sc.hasNextInt()) {\n      System.out.println(sc.nextInt() + sc.nextInt());\n    }\n  }\n}', 'ACCEPTED', 100, 130, 16384, 3, 3, '2026-03-16 14:10:00', '2026-03-16 14:10:02'),
(4,  3, 5,  1, 'JAVA',    'import java.util.Scanner;\npublic class Main {\n  public static void main(String[] args) {\n    int n = new Scanner(System.in).nextInt();\n    System.out.println(n % 2 == 0 ? "Even" : "Odd");\n  }\n}', 'ACCEPTED', 100, 105, 13312, 1, 1, '2026-03-17 09:15:30', '2026-03-17 09:15:31'),
(5,  3, 6,  1, 'JAVA',    'import java.util.Scanner;\npublic class Main {\n  public static void main(String[] args) {\n    int s = new Scanner(System.in).nextInt();\n    if(s>=90) System.out.println("A");\n    else if(s>=80) System.out.println("B");\n    else if(s>=70) System.out.println("C");\n    else if(s>=60) System.out.println("D");\n    else System.out.println("E");\n  }\n}', 'ACCEPTED', 100, 110, 13312, 1, 1, '2026-03-18 11:20:00', '2026-03-18 11:20:01'),
(6,  3, 7,  1, 'JAVA',    'public class Main {\n  public static void main(String[] args) {\n    for(int i=100;i<=999;i++){\n      int a=i/100,b=i/10%10,c=i%10;\n      if(a*a*a+b*b*b+c*c*c==i) System.out.println(i);\n    }\n  }\n}', 'WRONG_ANSWER', 0, 98, 12288, 0, 1, '2026-03-19 08:45:00', '2026-03-19 08:45:01'),
(7,  3, 7,  1, 'JAVA',    'public class Main {\n  public static void main(String[] args) {\n    for(int i=100;i<=999;i++){\n      int a=i/100,b=i/10%10,c=i%10;\n      if(a*a*a+b*b*b+c*c*c==i) System.out.println(i);\n    }\n  }\n}', 'WRONG_ANSWER', 0, 100, 12288, 0, 1, '2026-03-19 09:00:00', '2026-03-19 09:00:01'),
(8,  3, 7,  1, 'JAVA',    'public class Main {\n  public static void main(String[] args) {\n    int[] ns = {153,370,371,407};\n    for(int n:ns) System.out.println(n);\n  }\n}', 'ACCEPTED', 100, 92, 12288, 1, 1, '2026-03-19 09:30:00', '2026-03-19 09:30:01'),
(9,  3, 8,  1, 'JAVA',    'import java.util.Scanner;\npublic class Main {\n  public static void main(String[] args) {\n    Scanner sc = new Scanner(System.in);\n    int n = sc.nextInt(), max = Integer.MIN_VALUE;\n    for(int i=0;i<n;i++) max = Math.max(max, sc.nextInt());\n    System.out.println(max);\n  }\n}', 'ACCEPTED', 100, 135, 15360, 1, 1, '2026-03-20 10:00:00', '2026-03-20 10:00:02'),
(10, 3, 9,  1, 'JAVA',    'import java.util.Scanner;\npublic class Main {\n  public static void main(String[] args) {\n    Scanner sc = new Scanner(System.in);\n    int n = sc.nextInt();\n    int[] a = new int[n];\n    for(int i=0;i<n;i++) a[i]=sc.nextInt();\n    for(int i=0;i<n-1;i++) for(int j=0;j<n-1-i;j++) if(a[j]>a[j+1]){int t=a[j];a[j]=a[j+1];a[j+1]=t;}\n    for(int i=0;i<n;i++) System.out.print(a[i]+(i<n-1?" ":""));\n  }\n}', 'ACCEPTED', 100, 145, 16384, 1, 1, '2026-03-22 15:30:00', '2026-03-22 15:30:02'),
(11, 3, 10, 1, 'JAVA',    'import java.util.Scanner;\npublic class Main {\n  public static void main(String[] args) {\n    String s = new Scanner(System.in).nextLine();\n    System.out.println(new StringBuilder(s).reverse());\n  }\n}', 'ACCEPTED', 100, 115, 14336, 1, 1, '2026-03-23 09:00:00', '2026-03-23 09:00:01'),
(12, 3, 11, 1, 'JAVA',    'import java.util.Scanner;\npublic class Main {\n  public static void main(String[] args) {\n    Scanner sc = new Scanner(System.in);\n    int m=sc.nextInt(),n=sc.nextInt();\n    int[][] a=new int[m][n];\n    for(int i=0;i<m;i++) for(int j=0;j<n;j++) a[i][j]=sc.nextInt();\n    for(int j=0;j<n;j++) { for(int i=0;i<m;i++) System.out.print(a[i][j]+(i<m-1?" ":"")); System.out.println(); }\n  }\n}', 'ACCEPTED', 100, 125, 15360, 1, 1, '2026-03-25 14:00:00', '2026-03-25 14:00:02'),
(13, 3, 13, 1, 'JAVA',    'import java.util.Scanner;\npublic class Main {\n  static long fib(int n) { if(n<=2) return 1; return fib(n-1)+fib(n-2); }\n  public static void main(String[] args) { System.out.println(fib(new Scanner(System.in).nextInt())); }\n}', 'ACCEPTED', 100, 250, 18432, 1, 1, '2026-03-28 10:15:00', '2026-03-28 10:15:01'),
(14, 3, 14, 1, 'JAVA',    'import java.util.Scanner;\npublic class Main {\n  static long fact(int n) { return n<=1?1:n*fact(n-1); }\n  public static void main(String[] args) { System.out.println(fact(new Scanner(System.in).nextInt())); }\n}', 'ACCEPTED', 100, 95, 13312, 1, 1, '2026-03-28 10:30:00', '2026-03-28 10:30:01'),
(15, 3, 15, 1, 'JAVA',    'import java.util.Scanner;\npublic class Main {\n  static int count=0;\n  static void hanoi(int n,char from,char to,char aux){\n    if(n==0)return;\n    hanoi(n-1,from,aux,to);\n    count++;System.out.println(from+\" -> \"+to);\n    hanoi(n-1,aux,to,from);\n  }\n  public static void main(String[] args){hanoi(new Scanner(System.in).nextInt(),'\''A'\'','\''C'\'','\''B'\'');System.out.println(count);}\n}', 'COMPILE_ERROR', 0, 0, 0, 0, 1, '2026-03-29 08:00:00', '2026-03-29 08:00:01'),
(16, 3, 17, 1, 'JAVA',    'import java.util.*;\npublic class Main {\n  public static void main(String[] args) {\n    String s = new Scanner(System.in).nextLine();\n    Deque<Character> stack = new ArrayDeque<>();\n    for(char c:s.toCharArray()){\n      if(c==\''('\'||c==\'['\'||c==\'{\') stack.push(c);\n      else if(stack.isEmpty()){System.out.println("No");return;}\n      else {char t=stack.pop();if(c==\')\'&&t!=\''('\'||c==\']\'&&t!=\'['\'||c==\'}\'&&t!=\'{\') {System.out.println("No");return;}}\n    }\n    System.out.println(stack.isEmpty()?"Yes":"No");\n  }\n}', 'ACCEPTED', 100, 140, 16384, 5, 5, '2026-04-02 16:00:00', '2026-04-02 16:00:02'),
(17, 3, 18, 1, 'JAVA',    'import java.util.*;\npublic class Main {\n  public static void main(String[] args) {\n    Scanner sc=new Scanner(System.in);Deque<Integer> stack=new ArrayDeque<>();\n    int n=sc.nextInt();\n    while(n-->0){String op=sc.next();if(op.equals("push"))stack.push(sc.nextInt());else if(stack.isEmpty())System.out.println("Empty");else if(op.equals("pop"))System.out.println(stack.pop());else System.out.println(stack.peek());}\n  }\n}', 'ACCEPTED', 100, 135, 15360, 1, 1, '2026-04-03 09:00:00', '2026-04-03 09:00:02'),
(18, 3, 19, 1, 'JAVA',    'import java.util.*;\npublic class Main {\n  public static void main(String[] args) {\n    Scanner sc=new Scanner(System.in);int n=sc.nextInt(),m=sc.nextInt();\n    List<Integer> list=new ArrayList<>();for(int i=1;i<=n;i++)list.add(i);\n    int idx=0;StringBuilder sb=new StringBuilder();\n    while(!list.isEmpty()){idx=(idx+m-1)%list.size();sb.append(list.remove(idx)).append(" ");}\n    System.out.println(sb.toString().trim());\n  }\n}', 'TIME_LIMIT_EXCEEDED', 0, 1002, 0, 0, 1, '2026-04-05 14:00:00', '2026-04-05 14:00:02'),
(19, 3, 19, 1, 'JAVA',    'import java.util.*;\npublic class Main {\n  public static void main(String[] args) {\n    Scanner sc=new Scanner(System.in);int n=sc.nextInt(),m=sc.nextInt();\n    List<Integer> list=new LinkedList<>();for(int i=1;i<=n;i++)list.add(i);\n    int idx=0;ListIterator<Integer> it;\n    StringBuilder sb=new StringBuilder();\n    while(!list.isEmpty()){idx=(idx+m-1)%list.size();sb.append(list.remove(idx)).append(" ");}\n    System.out.println(sb.toString().trim());\n  }\n}', 'ACCEPTED', 100, 165, 18432, 1, 1, '2026-04-05 14:30:00', '2026-04-05 14:30:02'),
(20, 3, 20, 1, 'JAVA',    'import java.util.*;\npublic class Main {\n  public static void main(String[] args) {\n    Scanner sc=new Scanner(System.in);int n=sc.nextInt();\n    String[][] s=new String[n][2];for(int i=0;i<n;i++){s[i][0]=sc.next();s[i][1]=sc.next();}\n    Arrays.sort(s,(a,b)->{int d=Integer.compare(Integer.parseInt(b[1]),Integer.parseInt(a[1]));return d!=0?d:a[0].compareTo(b[0]);});\n    for(String[] r:s)System.out.println(r[0]+" "+r[1]);\n  }\n}', 'ACCEPTED', 100, 155, 17408, 3, 3, '2026-04-07 11:00:00', '2026-04-07 11:00:02'),
(21, 3, 4,  1, 'JAVA',    'import java.util.Scanner;\npublic class Main {\n  public static void main(String[] args) {\n    Scanner sc = new Scanner(System.in);\n    int a=sc.nextInt(),b=sc.nextInt(),c=sc.nextInt();\n    System.out.println(a+" + "+b+" = "+c);\n  }\n}', 'ACCEPTED', 100, 108, 13312, 1, 1, '2026-03-16 08:30:00', '2026-03-16 08:30:01'),
(22, 3, 12, 1, 'JAVA',    'import java.util.Scanner;\npublic class Main {\n  public static void main(String[] args) {\n    String s = new Scanner(System.in).nextLine();\n    int up=0,lo=0,dig=0,ot=0;\n    for(char c:s.toCharArray()){if(Character.isUpperCase(c))up++;else if(Character.isLowerCase(c))lo++;else if(Character.isDigit(c))dig++;else ot++;}\n    System.out.println(up+"\\n"+lo+"\\n"+dig+"\\n"+ot);\n  }\n}', 'WRONG_ANSWER', 0, 110, 13312, 0, 1, '2026-03-26 10:00:00', '2026-03-26 10:00:01'),
(23, 3, 12, 1, 'JAVA',    'import java.util.Scanner;\npublic class Main {\n  public static void main(String[] args) {\n    String s = new Scanner(System.in).nextLine();\n    int up=0,lo=0,dig=0,ot=0;\n    for(char c:s.toCharArray()){if(c>=65&&c<=90)up++;else if(c>=97&&c<=122)lo++;else if(c>=48&&c<=57)dig++;else ot++;}\n    System.out.println(up);System.out.println(lo);System.out.println(dig);System.out.println(ot);\n  }\n}', 'ACCEPTED', 100, 112, 13312, 1, 1, '2026-03-26 10:30:00', '2026-03-26 10:30:01'),
(24, 3, 16, 1, 'PYTHON',  'n=int(input())\na=list(map(int,input().split()))\nmax_sum=cur=a[0]\nfor i in range(1,n):\n    cur=max(a[i],cur+a[i])\n    max_sum=max(max_sum,cur)\nprint(max_sum)', 'ACCEPTED', 100, 85, 8192, 3, 3, '2026-04-10 09:00:00', '2026-04-10 09:00:01'),
(25, 3, 1,  1, 'PYTHON',  'a,b=map(int,input().split())\nprint(a+b)', 'ACCEPTED', 50, 45, 6144, 5, 5, '2026-03-15 11:00:00', '2026-03-15 11:00:01'),

-- 江景琛的提交（20条）
(26, 4, 1,  1, 'CPP',     '#include<bits/stdc++.h>\nusing namespace std;\nint main(){int a,b;cin>>a>>b;cout<<a+b<<endl;return 0;}', 'ACCEPTED', 50, 15, 2048, 5, 5, '2026-03-15 10:25:00', '2026-03-15 10:25:01'),
(27, 4, 2,  1, 'CPP',     '#include<bits/stdc++.h>\nusing namespace std;\nint main(){cout<<"Hello OJ!"<<endl;return 0;}', 'ACCEPTED', 100, 10, 1024, 1, 1, '2026-03-15 10:35:00', '2026-03-15 10:35:01'),
(28, 4, 3,  1, 'CPP',     '#include<bits/stdc++.h>\nusing namespace std;\nint main(){int a,b;while(cin>>a>>b){cout<<a+b<<endl;}return 0;}', 'ACCEPTED', 100, 18, 2048, 3, 3, '2026-03-16 14:15:00', '2026-03-16 14:15:01'),
(29, 4, 5,  1, 'CPP',     '#include<bits/stdc++.h>\nusing namespace std;\nint main(){int n;cin>>n;cout<<(n%2==0?"Even":"Odd")<<endl;return 0;}', 'ACCEPTED', 100, 12, 1024, 1, 1, '2026-03-17 09:20:00', '2026-03-17 09:20:01'),
(30, 4, 6,  1, 'CPP',     '#include<bits/stdc++.h>\nusing namespace std;\nint main(){int s;cin>>s;if(s>=90)cout<<"A";else if(s>=80)cout<<"B";else if(s>=70)cout<<"C";else if(s>=60)cout<<"D";else cout<<"E";return 0;}', 'ACCEPTED', 100, 10, 1024, 1, 1, '2026-03-18 11:25:00', '2026-03-18 11:25:01'),
(31, 4, 7,  1, 'CPP',     '#include<bits/stdc++.h>\nusing namespace std;\nint main(){for(int i=100;i<=999;i++){int a=i/100,b=i/10%10,c=i%10;if(a*a*a+b*b*b+c*c*c==i)cout<<i<<endl;}return 0;}', 'ACCEPTED', 100, 8, 1024, 1, 1, '2026-03-19 10:00:00', '2026-03-19 10:00:01'),
(32, 4, 8,  1, 'CPP',     '#include<bits/stdc++.h>\nusing namespace std;\nint main(){int n,mx=INT_MIN;cin>>n;while(n--){int x;cin>>x;mx=max(mx,x);}cout<<mx<<endl;return 0;}', 'ACCEPTED', 100, 15, 2048, 1, 1, '2026-03-20 10:05:00', '2026-03-20 10:05:01'),
(33, 4, 9,  1, 'CPP',     '#include<bits/stdc++.h>\nusing namespace std;\nint main(){int n;cin>>n;vector<int>a(n);for(auto&x:a)cin>>x;sort(a.begin(),a.end());for(int i=0;i<n;i++)cout<<a[i]<<(i<n-1?" ":"");return 0;}', 'ACCEPTED', 100, 22, 4096, 1, 1, '2026-03-22 15:35:00', '2026-03-22 15:35:01'),
(34, 4, 10, 1, 'CPP',     '#include<bits/stdc++.h>\nusing namespace std;\nint main(){string s;getline(cin,s);reverse(s.begin(),s.end());cout<<s<<endl;return 0;}', 'ACCEPTED', 100, 12, 2048, 1, 1, '2026-03-23 09:05:00', '2026-03-23 09:05:01'),
(35, 4, 11, 1, 'CPP',     '#include<bits/stdc++.h>\nusing namespace std;\nint main(){int m,n;cin>>m>>n;int a[100][100];for(int i=0;i<m;i++)for(int j=0;j<n;j++)cin>>a[i][j];for(int j=0;j<n;j++){for(int i=0;i<m;i++)cout<<a[i][j]<<(i<m-1?" ":"");cout<<endl;}return 0;}', 'ACCEPTED', 100, 14, 2048, 1, 1, '2026-03-25 14:05:00', '2026-03-25 14:05:02'),
(36, 4, 13, 1, 'CPP',     '#include<bits/stdc++.h>\nusing namespace std;\nlong long fib(int n){return n<=2?1:fib(n-1)+fib(n-2);}\nint main(){int n;cin>>n;cout<<fib(n)<<endl;return 0;}', 'ACCEPTED', 100, 45, 2048, 1, 1, '2026-03-28 10:20:00', '2026-03-28 10:20:01'),
(37, 4, 14, 1, 'CPP',     '#include<bits/stdc++.h>\nusing namespace std;\nlong long fact(int n){return n<=1?1:n*fact(n-1);}\nint main(){int n;cin>>n;cout<<fact(n)<<endl;return 0;}', 'ACCEPTED', 100, 10, 1024, 1, 1, '2026-03-28 10:35:00', '2026-03-28 10:35:01'),
(38, 4, 15, 1, 'CPP',     '#include<bits/stdc++.h>\nusing namespace std;\nint cnt=0;\nvoid hanoi(int n,char a,char b,char c){if(!n)return;hanoi(n-1,a,c,b);cnt++;cout<<a<<\" -> \"<<b<<endl;hanoi(n-1,c,b,a);}\nint main(){int n;cin>>n;hanoi(n,'\''A'\'','\''C'\'','\''B'\'');cout<<cnt<<endl;return 0;}', 'ACCEPTED', 100, 12, 2048, 1, 1, '2026-03-29 08:05:00', '2026-03-29 08:05:01'),
(39, 4, 17, 1, 'CPP',     '#include<bits/stdc++.h>\nusing namespace std;\nint main(){string s;getline(cin,s);stack<char>st;\nfor(char c:s){if(c==\''('\'||c==\'['\'||c==\'{\')st.push(c);else if(st.empty()){cout<<\"No\"<<endl;return 0;}else{char t=st.top();st.pop();if((c==\')\'&&t!=\''('\'')||(c==\']\'&&t!=\'['\'')||(c==\'}\'&&t!=\'{\'')){cout<<\"No\"<<endl;return 0;}}}\ncout<<(st.empty()?\"Yes\":\"No\")<<endl;return 0;}', 'ACCEPTED', 100, 15, 3072, 5, 5, '2026-04-02 16:05:00', '2026-04-02 16:05:02'),
(40, 4, 16, 1, 'CPP',     '#include<bits/stdc++.h>\nusing namespace std;\nint main(){int n;cin>>n;vector<int>a(n);for(auto&x:a)cin>>x;long long mx=a[0],cur=a[0];for(int i=1;i<n;i++){cur=max((long long)a[i],cur+a[i]);mx=max(mx,cur);}cout<<mx<<endl;return 0;}', 'ACCEPTED', 100, 25, 4096, 3, 3, '2026-04-10 09:05:00', '2026-04-10 09:05:01'),
(41, 4, 18, 1, 'CPP',     '#include<bits/stdc++.h>\nusing namespace std;\nint main(){int n;cin>>n;stack<int>st;while(n--){string op;cin>>op;if(op==\"push\"){int x;cin>>x;st.push(x);}else if(st.empty())cout<<\"Empty\"<<endl;else if(op==\"pop\"){cout<<st.top()<<endl;st.pop();}else cout<<st.top()<<endl;}return 0;}', 'ACCEPTED', 100, 14, 2048, 1, 1, '2026-04-03 09:05:00', '2026-04-03 09:05:02'),
(42, 4, 19, 1, 'CPP',     '#include<bits/stdc++.h>\nusing namespace std;\nint main(){int n,m;cin>>n>>m;list<int>l;for(int i=1;i<=n;i++)l.push_back(i);auto it=l.begin();while(!l.empty()){for(int i=1;i<m;i++){it++;if(it==l.end())it=l.begin();}cout<<*it;auto del=it;it++;if(it==l.end())it=l.begin();l.erase(del);if(!l.empty())cout<<\" \";}cout<<endl;return 0;}', 'ACCEPTED', 100, 18, 3072, 1, 1, '2026-04-05 14:35:00', '2026-04-05 14:35:02'),
(43, 4, 20, 1, 'CPP',     '#include<bits/stdc++.h>\nusing namespace std;\nint main(){int n;cin>>n;vector<pair<string,int>>v(n);for(auto&[s,d]:v)cin>>s>>d;sort(v.begin(),v.end(),[](auto&a,auto&b){return a.second!=b.second?a.second>b.second:a.first<b.first;});for(auto&[s,d]:v)cout<<s<<\" \"<<d<<endl;return 0;}', 'ACCEPTED', 100, 16, 3072, 3, 3, '2026-04-07 11:05:00', '2026-04-07 11:05:02'),
(44, 4, 4,  1, 'CPP',     '#include<bits/stdc++.h>\nusing namespace std;\nint main(){int a,b,c;cin>>a>>b>>c;cout<<a<<\" + \"<<b<<\" = \"<<c<<endl;return 0;}', 'ACCEPTED', 100, 10, 1024, 1, 1, '2026-03-16 08:35:00', '2026-03-16 08:35:01'),
(45, 4, 12, 1, 'CPP',     '#include<bits/stdc++.h>\nusing namespace std;\nint main(){string s;getline(cin,s);int up=0,lo=0,dig=0,ot=0;for(char c:s){if(isupper(c))up++;else if(islower(c))lo++;else if(isdigit(c))dig++;else ot++;}cout<<up<<endl<<lo<<endl<<dig<<endl<<ot<<endl;return 0;}', 'ACCEPTED', 100, 12, 2048, 1, 1, '2026-03-26 10:35:00', '2026-03-26 10:35:01'),

-- 陆知屿的提交（20条）
(46, 5, 1,  1, 'PYTHON',  'print(sum(map(int,input().split())))', 'ACCEPTED', 50, 40, 5120, 5, 5, '2026-03-15 10:28:00', '2026-03-15 10:28:01'),
(47, 5, 2,  1, 'PYTHON',  'print("Hello OJ!")', 'ACCEPTED', 100, 35, 4096, 1, 1, '2026-03-15 10:40:00', '2026-03-15 10:40:01'),
(48, 5, 3,  1, 'PYTHON',  'import sys\nfor line in sys.stdin:\n    a,b=map(int,line.split())\n    print(a+b)', 'ACCEPTED', 100, 50, 6144, 3, 3, '2026-03-16 14:20:00', '2026-03-16 14:20:01'),
(49, 5, 5,  1, 'PYTHON',  'n=int(input())\nprint("Even" if n%2==0 else "Odd")', 'ACCEPTED', 100, 38, 4096, 1, 1, '2026-03-17 09:25:00', '2026-03-17 09:25:01'),
(50, 5, 6,  1, 'PYTHON',  's=int(input())\nif s>=90:print("A")\nelif s>=80:print("B")\nelif s>=70:print("C")\nelif s>=60:print("D")\nelse:print("E")', 'ACCEPTED', 100, 42, 5120, 1, 1, '2026-03-18 11:30:00', '2026-03-18 11:30:01'),
(51, 5, 7,  1, 'PYTHON',  'for i in range(100,1000):\n    a,b,c=i//100,i//10%10,i%10\n    if a**3+b**3+c**3==i:print(i)', 'ACCEPTED', 100, 95, 7168, 1, 1, '2026-03-19 10:05:00', '2026-03-19 10:05:01'),
(52, 5, 8,  1, 'PYTHON',  'n=int(input())\nprint(max(map(int,input().split())))', 'ACCEPTED', 100, 48, 6144, 1, 1, '2026-03-20 10:10:00', '2026-03-20 10:10:01'),
(53, 5, 9,  1, 'PYTHON',  'n=int(input())\na=list(map(int,input().split()))\na.sort()\nprint(" ".join(map(str,a)))', 'ACCEPTED', 100, 65, 8192, 1, 1, '2026-03-22 15:40:00', '2026-03-22 15:40:01'),
(54, 5, 10, 1, 'PYTHON',  'print(input()[::-1])', 'ACCEPTED', 100, 38, 4096, 1, 1, '2026-03-23 09:10:00', '2026-03-23 09:10:01'),
(55, 5, 11, 1, 'PYTHON',  'm,n=map(int,input().split())\na=[list(map(int,input().split())) for _ in range(m)]\nfor j in range(n):\n    print(" ".join(str(a[i][j]) for i in range(m)))', 'ACCEPTED', 100, 72, 8192, 1, 1, '2026-03-25 14:10:00', '2026-03-25 14:10:02'),
(56, 5, 12, 1, 'PYTHON',  's=input()\nprint(sum(1 for c in s if c.isupper()))\nprint(sum(1 for c in s if c.islower()))\nprint(sum(1 for c in s if c.isdigit()))\nprint(sum(1 for c in s if not c.isalnum()))', 'ACCEPTED', 100, 55, 6144, 1, 1, '2026-03-26 10:40:00', '2026-03-26 10:40:01'),
(57, 5, 13, 1, 'PYTHON',  'def f(n):\n    if n<=2:return 1\n    return f(n-1)+f(n-2)\nprint(f(int(input())))', 'ACCEPTED', 100, 180, 10240, 1, 1, '2026-03-28 10:25:00', '2026-03-28 10:25:01'),
(58, 5, 14, 1, 'PYTHON',  'def f(n):\n    return 1 if n<=1 else n*f(n-1)\nprint(f(int(input())))', 'ACCEPTED', 100, 40, 5120, 1, 1, '2026-03-28 10:40:00', '2026-03-28 10:40:01'),
(59, 5, 15, 1, 'PYTHON',  'cnt=0\ndef hanoi(n,a,b,c):\n    global cnt\n    if n==0:return\n    hanoi(n-1,a,c,b)\n    cnt+=1\n    print(f"{a} -> {b}")\n    hanoi(n-1,c,b,a)\nn=int(input())\nhanoi(n,\'A\',\'C\',\'B\')\nprint(cnt)', 'ACCEPTED', 100, 52, 6144, 1, 1, '2026-03-29 08:10:00', '2026-03-29 08:10:01'),
(60, 5, 17, 1, 'PYTHON',  's=input()\nst=[]\nfor c in s:\n    if c in \"([{\":st.append(c)\n    elif not st:print("No");break\n    else:\n        t=st.pop()\n        if (c==\")\" and t!=\"(\") or (c==\"]\" and t!=\"[\") or (c==\"}\" and t!=\"{\"):print("No");break\nelse:\n    print("Yes" if not st else "No")', 'ACCEPTED', 100, 65, 7168, 5, 5, '2026-04-02 16:10:00', '2026-04-02 16:10:02'),
(61, 5, 18, 1, 'PYTHON',  'n=int(input())\nst=[]\nfor _ in range(n):\n    parts=input().split()\n    if parts[0]=="push":st.append(int(parts[1]))\n    elif not st:print("Empty")\n    elif parts[0]=="pop":print(st.pop())\n    else:print(st[-1])', 'ACCEPTED', 100, 62, 7168, 1, 1, '2026-04-03 09:10:00', '2026-04-03 09:10:02'),
(62, 5, 19, 1, 'PYTHON',  'n,m=map(int,input().split())\nlst=list(range(1,n+1))\nidx=0\nres=[]\nwhile lst:\n    idx=(idx+m-1)%len(lst)\n    res.append(str(lst.pop(idx)))\nprint(" ".join(res))', 'ACCEPTED', 100, 85, 8192, 1, 1, '2026-04-05 14:40:00', '2026-04-05 14:40:02'),
(63, 5, 20, 1, 'PYTHON',  'n=int(input())\nstudents=[]\nfor _ in range(n):\n    name,score=input().split()\n    students.append((name,int(score)))\nstudents.sort(key=lambda x:(-x[1],x[0]))\nfor name,score in students:print(f"{name} {score}")', 'ACCEPTED', 100, 70, 8192, 3, 3, '2026-04-07 11:10:00', '2026-04-07 11:10:02'),
(64, 5, 4,  1, 'PYTHON',  'a,b,c=map(int,input().split())\nprint(f"{a} + {b} = {c}")', 'ACCEPTED', 100, 38, 4096, 1, 1, '2026-03-16 08:40:00', '2026-03-16 08:40:01'),
(65, 5, 16, 1, 'PYTHON',  'n=int(input())\na=list(map(int,input().split()))\nmx=cur=a[0]\nfor i in range(1,n):\n    cur=max(a[i],cur+a[i])\n    mx=max(mx,cur)\nprint(mx)', 'MEMORY_LIMIT_EXCEEDED', 0, 0, 262144, 0, 3, '2026-04-10 09:10:00', '2026-04-10 09:10:02'),

-- 沈砚辞的提交（15条）
(66, 6, 1,  1, 'JAVA',    'import java.util.*;\npublic class Main{\npublic static void main(String[]a){Scanner s=new Scanner(System.in);System.out.println(s.nextInt()+s.nextInt());}\n}', 'ACCEPTED', 50, 118, 15360, 5, 5, '2026-03-15 11:05:00', '2026-03-15 11:05:02'),
(67, 6, 2,  1, 'JAVA',    'public class Main{public static void main(String[]a){System.out.println("Hello OJ!");}}', 'ACCEPTED', 100, 96, 12288, 1, 1, '2026-03-15 11:10:00', '2026-03-15 11:10:01'),
(68, 6, 5,  1, 'JAVA',    'import java.util.*;\npublic class Main{public static void main(String[]a){int n=new Scanner(System.in).nextInt();System.out.println(n%2==0?"Even":"Odd");}}', 'ACCEPTED', 100, 108, 13312, 1, 1, '2026-03-17 10:00:00', '2026-03-17 10:00:01'),
(69, 6, 8,  1, 'JAVA',    'import java.util.*;\npublic class Main{public static void main(String[]a){Scanner s=new Scanner(System.in);int n=s.nextInt(),mx=Integer.MIN_VALUE;while(n-->0)mx=Math.max(mx,s.nextInt());System.out.println(mx);}}', 'RUNTIME_ERROR', 0, 0, 0, 0, 1, '2026-03-20 10:15:00', '2026-03-20 10:15:01'),
(70, 6, 8,  1, 'JAVA',    'import java.util.*;\npublic class Main{public static void main(String[]a){Scanner s=new Scanner(System.in);int n=s.nextInt();int mx=Integer.MIN_VALUE;for(int i=0;i<n;i++)mx=Math.max(mx,s.nextInt());System.out.println(mx);}}', 'ACCEPTED', 100, 130, 15360, 1, 1, '2026-03-20 10:30:00', '2026-03-20 10:30:02'),
(71, 6, 9,  1, 'CPP',     '#include<bits/stdc++.h>\nusing namespace std;\nint main(){int n;cin>>n;int a[n];for(int i=0;i<n;i++)cin>>a[i];sort(a,a+n);for(int i=0;i<n;i++)cout<<a[i]<<(i<n-1?" ":"");return 0;}', 'ACCEPTED', 100, 20, 2048, 1, 1, '2026-03-22 15:45:00', '2026-03-22 15:45:01'),
(72, 6, 10, 1, 'CPP',     '#include<bits/stdc++.h>\nusing namespace std;\nint main(){string s;getline(cin,s);reverse(s.begin(),s.end());cout<<s;return 0;}', 'ACCEPTED', 100, 11, 1024, 1, 1, '2026-03-23 09:15:00', '2026-03-23 09:15:01'),
(73, 6, 13, 1, 'JAVA',    'import java.util.*;\npublic class Main{static long fib(int n){return n<=2?1:fib(n-1)+fib(n-2);}public static void main(String[]a){System.out.println(fib(new Scanner(System.in).nextInt()));}}', 'TIME_LIMIT_EXCEEDED', 0, 1002, 0, 0, 1, '2026-03-28 11:00:00', '2026-03-28 11:00:02'),
(74, 6, 13, 1, 'JAVA',    'import java.util.*;\npublic class Main{public static void main(String[]a){int n=new Scanner(System.in).nextInt();long[]f=new long[n+1];f[1]=f[2]=1;for(int i=3;i<=n;i++)f[i]=f[i-1]+f[i-2];System.out.println(f[n]);}}', 'ACCEPTED', 100, 105, 14336, 1, 1, '2026-03-28 11:30:00', '2026-03-28 11:30:01'),
(75, 6, 17, 1, 'CPP',     '#include<bits/stdc++.h>\nusing namespace std;\nint main(){string s;getline(cin,s);stack<char>st;for(char c:s){if(c==\''('\'||c==\'['\'||c==\'{\')st.push(c);else if(st.empty()){cout<<\"No\";return 0;}else{char t=st.top();st.pop();if((c==\')\'&&t!=\''('\'')||(c==\']\'&&t!=\'['\'')||(c==\'}\'&&t!=\'{\'')){cout<<\"No\";return 0;}}}cout<<(st.empty()?\"Yes\":\"No\");return 0;}', 'WRONG_ANSWER', 0, 14, 2048, 2, 5, '2026-04-02 16:15:00', '2026-04-02 16:15:02'),
(76, 6, 17, 1, 'CPP',     '#include<bits/stdc++.h>\nusing namespace std;\nint main(){string s;getline(cin,s);stack<char>st;for(char c:s){if(c==\''('\'||c==\'['\'||c==\'{\')st.push(c);else if(st.empty()){cout<<\"No\"<<endl;return 0;}else{char t=st.top();st.pop();if((c==\')\'&&t!=\''('\'')||(c==\']\'&&t!=\'['\'')||(c==\'}\'&&t!=\'{\'')){cout<<\"No\"<<endl;return 0;}}}cout<<(st.empty()?\"Yes\":\"No\")<<endl;return 0;}', 'ACCEPTED', 100, 15, 2048, 5, 5, '2026-04-02 16:45:00', '2026-04-02 16:45:02'),
(77, 6, 4,  1, 'JAVA',    'import java.util.*;\npublic class Main{public static void main(String[]a){Scanner s=new Scanner(System.in);int x=s.nextInt(),y=s.nextInt(),z=s.nextInt();System.out.println(x+" + "+y+" = "+z);}}', 'ACCEPTED', 100, 110, 13312, 1, 1, '2026-03-16 09:00:00', '2026-03-16 09:00:01'),
(78, 6, 6,  1, 'JAVA',    'import java.util.*;\npublic class Main{public static void main(String[]a){int s=new Scanner(System.in).nextInt();System.out.println(s>=90?"A":s>=80?"B":s>=70?"C":s>=60?"D":"E");}}', 'ACCEPTED', 100, 108, 13312, 1, 1, '2026-03-18 12:00:00', '2026-03-18 12:00:01'),
(79, 6, 14, 1, 'PYTHON',  'def f(n):return 1 if n<=1 else n*f(n-1)\nprint(f(int(input())))', 'ACCEPTED', 100, 42, 5120, 1, 1, '2026-03-28 11:45:00', '2026-03-28 11:45:01'),
(80, 6, 20, 1, 'PYTHON',  'n=int(input())\ns=[]\nfor _ in range(n):\n    name,score=input().split()\n    s.append((name,int(score)))\ns.sort(key=lambda x:(-x[1],x[0]))\nfor name,score in s:print(name,score)', 'WRONG_ANSWER', 0, 55, 6144, 0, 3, '2026-04-07 12:00:00', '2026-04-07 12:00:01'),

-- 顾星辞的提交（10条）
(81, 7, 1,  1, 'CPP',     '#include<iostream>\nusing namespace std;\nint main(){int a,b;cin>>a>>b;cout<<a+b<<endl;return 0;}', 'ACCEPTED', 50, 12, 1024, 5, 5, '2026-03-15 13:00:00', '2026-03-15 13:00:01'),
(82, 7, 2,  1, 'CPP',     '#include<iostream>\nusing namespace std;\nint main(){cout<<"Hello OJ!"<<endl;return 0;}', 'ACCEPTED', 100, 8, 1024, 1, 1, '2026-03-15 13:05:00', '2026-03-15 13:05:01'),
(83, 7, 5,  1, 'CPP',     '#include<iostream>\nusing namespace std;\nint main(){int n;cin>>n;cout<<(n%2==0?"Even":"Odd")<<endl;return 0;}', 'ACCEPTED', 100, 10, 1024, 1, 1, '2026-03-17 10:30:00', '2026-03-17 10:30:01'),
(84, 7, 9,  1, 'PYTHON',  'n=int(input())\na=list(map(int,input().split()))\na.sort()\nprint(*a)', 'ACCEPTED', 100, 62, 7168, 1, 1, '2026-03-22 16:00:00', '2026-03-22 16:00:01'),
(85, 7, 10, 1, 'PYTHON',  'print(input()[::-1])', 'ACCEPTED', 100, 36, 4096, 1, 1, '2026-03-23 09:30:00', '2026-03-23 09:30:01'),
(86, 7, 13, 1, 'CPP',     '#include<iostream>\nusing namespace std;\nlong long fib(int n){return n<=2?1:fib(n-1)+fib(n-2);}\nint main(){int n;cin>>n;cout<<fib(n)<<endl;return 0;}', 'ACCEPTED', 100, 40, 2048, 1, 1, '2026-03-28 12:00:00', '2026-03-28 12:00:01'),
(87, 7, 17, 1, 'JAVA',    'import java.util.*;\npublic class Main{public static void main(String[]a){String s=new Scanner(System.in).nextLine();Deque<Character>st=new ArrayDeque<>();for(char c:s.toCharArray()){if(c==\''('\'||c==\'['\'||c==\'{\')st.push(c);else if(st.isEmpty()){System.out.println("No");return;}else{char t=st.pop();if((c==\')\'&&t!=\''('\'')||(c==\']\'&&t!=\'['\'')||(c==\'}\'&&t!=\'{\'')){System.out.println("No");return;}}}System.out.println(st.isEmpty()?"Yes":"No");}}', 'ACCEPTED', 100, 138, 16384, 5, 5, '2026-04-02 17:00:00', '2026-04-02 17:00:02'),
(88, 7, 16, 1, 'CPP',     '#include<bits/stdc++.h>\nusing namespace std;\nint main(){int n;cin>>n;vector<int>a(n);for(auto&x:a)cin>>x;long long mx=a[0],cur=a[0];for(int i=1;i<n;i++){cur=max((long long)a[i],cur+a[i]);mx=max(mx,cur);}cout<<mx;return 0;}', 'WRONG_ANSWER', 0, 20, 3072, 1, 3, '2026-04-10 10:00:00', '2026-04-10 10:00:01'),
(89, 7, 16, 1, 'CPP',     '#include<bits/stdc++.h>\nusing namespace std;\nint main(){int n;cin>>n;vector<int>a(n);for(auto&x:a)cin>>x;long long mx=a[0],cur=a[0];for(int i=1;i<n;i++){cur=max((long long)a[i],cur+a[i]);mx=max(mx,cur);}cout<<mx<<endl;return 0;}', 'ACCEPTED', 100, 22, 3072, 3, 3, '2026-04-10 10:15:00', '2026-04-10 10:15:01'),
(90, 7, 4,  1, 'CPP',     '#include<iostream>\nusing namespace std;\nint main(){int a,b,c;cin>>a>>b>>c;cout<<a<<" + "<<b<<" = "<<c<<endl;return 0;}', 'ACCEPTED', 100, 9, 1024, 1, 1, '2026-03-16 09:30:00', '2026-03-16 09:30:01'),

-- 苏沐辰的提交（10条）
(91,  8, 1,  1, 'JAVA',   'import java.util.*;\npublic class Main{public static void main(String[]a){Scanner s=new Scanner(System.in);System.out.println(s.nextInt()+s.nextInt());}}', 'ACCEPTED', 50, 115, 15360, 5, 5, '2026-03-15 14:00:00', '2026-03-15 14:00:02'),
(92,  8, 2,  1, 'JAVA',   'public class Main{public static void main(String[]a){System.out.println("Hello OJ!");}}', 'ACCEPTED', 100, 94, 12288, 1, 1, '2026-03-15 14:05:00', '2026-03-15 14:05:01'),
(93,  8, 5,  1, 'PYTHON', 'print("Even" if int(input())%2==0 else "Odd")', 'ACCEPTED', 100, 36, 4096, 1, 1, '2026-03-17 11:00:00', '2026-03-17 11:00:01'),
(94,  8, 6,  1, 'PYTHON', 's=int(input())\nprint("A" if s>=90 else "B" if s>=80 else "C" if s>=70 else "D" if s>=60 else "E")', 'ACCEPTED', 100, 40, 5120, 1, 1, '2026-03-18 13:00:00', '2026-03-18 13:00:01'),
(95,  8, 9,  1, 'CPP',    '#include<bits/stdc++.h>\nusing namespace std;\nint main(){int n;cin>>n;int a[n];for(int i=0;i<n;i++)cin>>a[i];sort(a,a+n);for(int i=0;i<n;i++)cout<<a[i]<<" ";return 0;}', 'COMPILE_ERROR', 0, 0, 0, 0, 1, '2026-03-22 16:15:00', '2026-03-22 16:15:01'),
(96,  8, 9,  1, 'CPP',    '#include<bits/stdc++.h>\nusing namespace std;\nint main(){int n;cin>>n;vector<int>a(n);for(auto&x:a)cin>>x;sort(a.begin(),a.end());for(int i=0;i<n;i++)cout<<a[i]<<" ";return 0;}', 'ACCEPTED', 100, 20, 3072, 1, 1, '2026-03-22 16:30:00', '2026-03-22 16:30:01'),
(97,  8, 13, 1, 'PYTHON', 'f=lambda n:n if n<=2 else f(n-1)+f(n-2)\nprint(f(int(input())))', 'TIME_LIMIT_EXCEEDED', 0, 1002, 0, 0, 1, '2026-03-28 13:00:00', '2026-03-28 13:00:02'),
(98,  8, 13, 1, 'PYTHON', 'n=int(input())\na,b=1,1\nfor _ in range(n-2):a,b=b,a+b\nprint(b)', 'ACCEPTED', 100, 42, 5120, 1, 1, '2026-03-28 13:30:00', '2026-03-28 13:30:01'),
(99,  8, 17, 1, 'PYTHON', 's=input()\nst=[]\nfor c in s:\n    if c in "([{":st.append(c)\n    elif not st:print("No");break\n    else:\n        t=st.pop()\n        if (c==")" and t!="(") or (c=="]" and t!="[") or (c=="}" and t!="{"):print("No");break\nelse:\n    print("Yes" if not st else "No")', 'ACCEPTED', 100, 60, 7168, 5, 5, '2026-04-02 17:15:00', '2026-04-02 17:15:02'),
(100, 8, 4,  1, 'PYTHON', 'a,b,c=map(int,input().split())\nprint(f"{a} + {b} = {c}")', 'ACCEPTED', 100, 36, 4096, 1, 1, '2026-03-16 10:00:00', '2026-03-16 10:00:01');

-- ============================================================
-- 8. 错题本数据（15条）
-- ============================================================

INSERT INTO `wrong_book` (`user_id`, `problem_id`, `submission_id`, `error_type`, `note`, `is_mastered`) VALUES
(3, 7,  6,  'WRONG_ANSWER',         '输出格式有问题，需要使用标准输出而不是硬编码结果', 1),
(3, 15, 15, 'COMPILE_ERROR',        '转义字符使用错误，需要注意 Java 中字符转义',       0),
(3, 12, 22, 'WRONG_ANSWER',         '换行符使用错误，应该用 System.out.println 而不是 \\n', 1),
(3, 19, 18, 'TIME_LIMIT_EXCEEDED',  'ArrayList.remove() 效率太低，应该用 LinkedList',  1),
(4, 16, 88, 'WRONG_ANSWER',         '最后输出缺少换行符',                              1),
(5, 16, 65, 'MEMORY_LIMIT_EXCEEDED', 'Python 递归深度过大导致内存溢出',                 0),
(6, 8,  69, 'RUNTIME_ERROR',        '数组越界，需要正确读取 n 个数',                   1),
(6, 13, 73, 'TIME_LIMIT_EXCEEDED',  '递归太慢，需要改用递推',                          1),
(6, 17, 75, 'WRONG_ANSWER',         '输出缺少换行符导致对比失败',                      1),
(6, 20, 80, 'WRONG_ANSWER',         '排序比较函数写反了',                              0),
(7, 16, 88, 'WRONG_ANSWER',         '输出格式问题，需要加 endl',                       1),
(8, 9,  95, 'COMPILE_ERROR',        'C++ 不支持变长数组，应该用 vector',               1),
(8, 13, 97, 'TIME_LIMIT_EXCEEDED',  'Python 递归实现斐波那契太慢，改用迭代',           1),
(3, 4,  21, NULL,                    '格式化输出注意空格',                              1),
(4, 12, 45, NULL,                    '字符判断用 isupper 等函数更简洁',                 1);

-- ============================================================
-- 9. 团队数据
-- ============================================================

INSERT INTO `team` (`id`, `name`, `description`, `course_id`, `leader_id`, `max_members`) VALUES
(1, '代码先锋队',   '专注于算法竞赛和代码优化的精英团队', 1, 3, 6),
(2, 'Bug终结者',    '擅长调试和问题排查的实战型团队',    1, 6, 6);

INSERT INTO `team_member` (`team_id`, `user_id`, `role`) VALUES
(1, 3, 'LEADER'),
(1, 4, 'MEMBER'),
(1, 5, 'MEMBER'),
(2, 6, 'LEADER'),
(2, 7, 'MEMBER'),
(2, 8, 'MEMBER');

-- ============================================================
-- 10. 教师评语数据
-- ============================================================

INSERT INTO `teacher_review` (`teacher_id`, `course_id`, `submission_id`, `problem_id`, `team_id`, `content`, `review_type`) VALUES
(2, 1, 15, 15, NULL, 'Java 字符串转义需要特别注意。在 Java 中，`->` 不需要转义，但双引号需要转义为 `\\"`。建议先在本地编译测试。', 'SUBMISSION'),
(2, 1, NULL, 16, 1, '代码先锋队在最大子段和这道题上表现不错，Kadane 算法的实现很简洁。但要注意边界情况，比如全负数数组。', 'PROBLEM'),
(2, 1, NULL, NULL, 1, '代码先锋队整体进度领先，建议多做一些 HARD 难度的题目来提升算法思维。特别是动态规划和图论方面。', 'TEAM'),
(2, 1, NULL, NULL, 2, 'Bug终结者团队在调试方面表现突出，沈砚辞同学的调试能力很强。建议团队多分享调试技巧和经验。', 'TEAM'),
(2, 1, 69, 8, NULL, '运行时错误通常是数组越界或空指针。仔细检查 Scanner 的读取顺序和循环边界。', 'SUBMISSION');

-- ============================================================
-- 11. 通知数据
-- ============================================================

INSERT INTO `notification` (`user_id`, `title`, `content`, `type`, `is_read`, `related_id`, `related_type`) VALUES
(3, '欢迎加入编程团队实训', '你已成功加入「编程团队实训」课程，请查看课程大纲开始学习。', 'COURSE', 1, 1, 'COURSE'),
(4, '欢迎加入编程团队实训', '你已成功加入「编程团队实训」课程，请查看课程大纲开始学习。', 'COURSE', 1, 1, 'COURSE'),
(5, '欢迎加入编程团队实训', '你已成功加入「编程团队实训」课程，请查看课程大纲开始学习。', 'COURSE', 1, 1, 'COURSE'),
(6, '欢迎加入编程团队实训', '你已成功加入「编程团队实训」课程，请查看课程大纲开始学习。', 'COURSE', 1, 1, 'COURSE'),
(7, '欢迎加入编程团队实训', '你已成功加入「编程团队实训」课程，请查看课程大纲开始学习。', 'COURSE', 1, 1, 'COURSE'),
(8, '欢迎加入编程团队实训', '你已成功加入「编程团队实训」课程，请查看课程大纲开始学习。', 'COURSE', 1, 1, 'COURSE'),
(3, '你已被分配到团队「代码先锋队」', '张老师将你分配到了「代码先锋队」，你是队长，请组织团队协作。', 'TEAM', 1, 1, 'TEAM'),
(6, '你已被分配到团队「Bug终结者」', '张老师将你分配到了「Bug终结者」，你是队长，请组织团队协作。', 'TEAM', 1, 2, 'TEAM'),
(3, '新题目发布：最大子段和', '第四章「函数与递归」发布了新题目「最大子段和」，难度为中等，请及时完成。', 'COURSE', 0, 16, 'PROBLEM'),
(4, '新题目发布：最大子段和', '第四章「函数与递归」发布了新题目「最大子段和」，难度为中等，请及时完成。', 'COURSE', 0, 16, 'PROBLEM'),
(5, '新题目发布：最大子段和', '第四章「函数与递归」发布了新题目「最大子段和」，难度为中等，请及时完成。', 'COURSE', 0, 16, 'PROBLEM'),
(6, '教师复盘通知', '张老师对你的提交 #69 进行了复盘评语，请查看。', 'REVIEW', 0, 5, 'TEACHER_REVIEW'),
(3, '教师复盘通知', '张老师对「代码先锋队」进行了整体复盘，请查看。', 'REVIEW', 0, 3, 'TEACHER_REVIEW'),
(7, '系统维护通知', '系统将于本周六 02:00-04:00 进行维护升级，届时服务将暂时不可用。', 'SYSTEM', 0, NULL, NULL),
(8, '系统维护通知', '系统将于本周六 02:00-04:00 进行维护升级，届时服务将暂时不可用。', 'SYSTEM', 0, NULL, NULL);

-- ============================================================
-- 12. 审计日志示例
-- ============================================================

INSERT INTO `audit_log` (`user_id`, `action`, `resource_type`, `resource_id`, `detail`, `ip_address`) VALUES
(1, 'CREATE', 'COURSE', 1, '{"name":"编程团队实训","code":"OJ-REVIEW-2026"}', '192.168.1.100'),
(2, 'PUBLISH', 'CHAPTER', 1, '{"title":"基础输入输出"}', '192.168.1.101'),
(2, 'PUBLISH', 'CHAPTER', 2, '{"title":"分支与循环"}', '192.168.1.101'),
(2, 'PUBLISH', 'CHAPTER', 3, '{"title":"数组与字符串"}', '192.168.1.101'),
(2, 'PUBLISH', 'CHAPTER', 4, '{"title":"函数与递归"}'