<template>
  <div class="page-container">
    <div class="page-header">
      <h2>课程管理</h2>
      <el-button type="primary" @click="showCreateDialog = true"><el-icon><Plus /></el-icon> 创建课程</el-button>
    </div>

    <!-- 筛选 -->
    <el-card shadow="never" class="filter-card">
      <el-form :inline="true" :model="filterForm">
        <el-form-item label="搜索"><el-input v-model="filterForm.keyword" placeholder="搜索课程" clearable prefix-icon="Search" @keyup.enter="fetchData" /></el-form-item>
        <el-form-item label="状态">
          <el-select v-model="filterForm.status" placeholder="全部" clearable @change="fetchData">
            <el-option label="草稿" value="DRAFT" /><el-option label="已发布" value="PUBLISHED" /><el-option label="已归档" value="ARCHIVED" />
          </el-select>
        </el-form-item>
        <el-form-item><el-button type="primary" @click="fetchData">查询</el-button></el-form-item>
      </el-form>
    </el-card>

    <!-- 课程表格 -->
    <el-card shadow="never" class="table-card">
      <el-table :data="courses" v-loading="loading" stripe>
        <el-table-column prop="code" label="课程代码" width="120" />
        <el-table-column prop="name" label="课程名称" min-width="200" />
        <el-table-column prop="semester" label="学期" width="120" />
        <el-table-column prop="studentCount" label="学生" width="80" align="center" />
        <el-table-column prop="problemCount" label="题目" width="80" align="center" />
        <el-table-column prop="status" label="状态" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="row.status === 'PUBLISHED' ? 'success' : row.status === 'DRAFT' ? 'warning' : 'info'" size="small">
              {{ row.status === 'PUBLISHED' ? '已发布' : row.status === 'DRAFT' ? '草稿' : '已归档' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="260" align="center" fixed="right">
          <template #default="{ row }">
            <el-button text type="primary" size="small" @click="$router.push(`/teacher/courses/${row.id}`)">详情</el-button>
            <el-button v-if="row.status === 'DRAFT'" text type="success" size="small" @click="handlePublish(row)">发布</el-button>
            <el-button text type="warning" size="small" @click="handleEdit(row)">编辑</el-button>
            <el-button text type="danger" size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination-wrapper">
        <el-pagination v-model:current-page="currentPage" :page-size="pageSize" :total="total" layout="prev, pager, next" @current-change="fetchData" />
      </div>
    </el-card>

    <!-- 创建/编辑课程弹窗 -->
    <el-dialog v-model="showCreateDialog" :title="editingCourse ? '编辑课程' : '创建课程'" width="600px" destroy-on-close>
      <el-form ref="formRef" :model="courseForm" :rules="rules" label-width="100px">
        <el-form-item label="课程名称" prop="name"><el-input v-model="courseForm.name" placeholder="请输入课程名称" /></el-form-item>
        <el-form-item label="课程代码" prop="code"><el-input v-model="courseForm.code" placeholder="如 CS101" /></el-form-item>
        <el-form-item label="学期" prop="semester"><el-input v-model="courseForm.semester" placeholder="如 2025-春季" /></el-form-item>
        <el-form-item label="课程描述"><el-input v-model="courseForm.description" type="textarea" :rows="3" /></el-form-item>
        <el-row :gutter="16">
          <el-col :span="12"><el-form-item label="开始时间"><el-date-picker v-model="courseForm.startTime" type="date" style="width:100%" /></el-form-item></el-col>
          <el-col :span="12"><el-form-item label="结束时间"><el-date-picker v-model="courseForm.endTime" type="date" style="width:100%" /></el-form-item></el-col>
        </el-row>
      </el-form>
      <template #footer>
        <el-button @click="showCreateDialog = false">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="handleSubmit">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import type { FormInstance, FormRules } from 'element-plus'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useCourseStore } from '@/stores/course'
import type { Course, CourseForm } from '@/types'

const courseStore = useCourseStore()
const loading = ref(false)
const courses = ref<Course[]>([])
const total = ref(0)
const currentPage = ref(1)
const pageSize = 20
const showCreateDialog = ref(false)
const submitting = ref(false)
const editingCourse = ref<Course | null>(null)
const formRef = ref<FormInstance>()
const filterForm = reactive({ keyword: '', status: '' })

const courseForm = reactive<CourseForm>({ name: '', code: '', description: '', semester: '', startTime: '', endTime: '' })
const rules: FormRules = {
  name: [{ required: true, message: '请输入课程名称', trigger: 'blur' }],
  code: [{ required: true, message: '请输入课程代码', trigger: 'blur' }],
  semester: [{ required: true, message: '请输入学期', trigger: 'blur' }]
}

async function fetchData() {
  loading.value = true
  try {
    await courseStore.fetchCourseList({ page: currentPage.value, pageSize, keyword: filterForm.keyword || undefined, status: filterForm.status || undefined })
    courses.value = courseStore.courseList
    total.value = courseStore.total
  } finally { loading.value = false }
}

function handleEdit(course: Course) {
  editingCourse.value = course
  Object.assign(courseForm, { name: course.name, code: course.code, description: course.description, semester: course.semester, startTime: course.startTime, endTime: course.endTime })
  showCreateDialog.value = true
}

async function handleSubmit() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return
  submitting.value = true
  try {
    if (editingCourse.value) {
      await courseStore.updateCourse(editingCourse.value.id, courseForm)
      ElMessage.success('课程更新成功')
    } else {
      await courseStore.createCourse(courseForm)
      ElMessage.success('课程创建成功')
    }
    showCreateDialog.value = false
    editingCourse.value = null
    fetchData()
  } catch { ElMessage.error('操作失败') } finally { submitting.value = false }
}

async function handlePublish(course: Course) {
  await ElMessageBox.confirm('确定发布该课程？', '确认')
  try {
    const { publishCourse } = await import('@/api/course')
    await publishCourse(course.id)
    ElMessage.success('发布成功')
    fetchData()
  } catch { ElMessage.error('发布失败') }
}

async function handleDelete(course: Course) {
  await ElMessageBox.confirm(`确定删除课程「${course.name}」？`, '警告', { type: 'warning' })
  try { await courseStore.deleteCourse(course.id); ElMessage.success('删除成功') } catch { ElMessage.error('删除失败') }
}

onMounted(fetchData)
</script>

<style scoped>
.filter-card { margin-bottom: 20px; border-radius: 12px; }
.table-card { border-radius: 12px; }
.pagination-wrapper { display: flex; justify-content: flex-end; margin-top: 16px; }
</style>
