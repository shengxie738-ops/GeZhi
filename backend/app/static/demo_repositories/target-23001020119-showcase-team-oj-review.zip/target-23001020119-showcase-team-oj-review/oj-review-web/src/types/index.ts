// ─── 通用类型 ─────────────────────────────────────────
export interface ApiResponse<T = unknown> {
  code: number
  message: string
  data: T
}

export interface PageResult<T> {
  records: T[]
  total: number
  page: number
  pageSize: number
}

export interface PageQuery {
  page: number
  pageSize: number
  keyword?: string
}

export interface TreeNode {
  id: number
  label: string
  children?: TreeNode[]
}

// ─── 用户与认证 ───────────────────────────────────────
export type UserRole = 'STUDENT' | 'TEACHER' | 'ADMIN'

export interface UserInfo {
  id: number
  username: string
  realName: string
  email: string
  phone: string
  avatar: string
  role: UserRole
  school: string
  department: string
  studentNo: string
  status: number
  createdAt: string
  updatedAt: string
}

export interface LoginForm {
  username: string
  password: string
  captcha?: string
}

export interface RegisterForm {
  username: string
  password: string
  confirmPassword: string
  realName: string
  email: string
  phone: string
  role: UserRole
  school: string
  department: string
  studentNo: string
  inviteCode?: string
}

export interface LoginResult {
  token: string
  refreshToken: string
  expiresIn: number
  user: UserInfo
}

// ─── 课程 ─────────────────────────────────────────────
export interface Course {
  id: number
  name: string
  code: string
  description: string
  coverImage: string
  teacherId: number
  teacherName: string
  semester: string
  status: CourseStatus
  studentCount: number
  problemCount: number
  startTime: string
  endTime: string
  createdAt: string
  updatedAt: string
}

export type CourseStatus = 'DRAFT' | 'PUBLISHED' | 'ARCHIVED'

export interface CourseForm {
  name: string
  code: string
  description: string
  coverImage?: string
  semester: string
  startTime: string
  endTime: string
}

export interface CourseStudent {
  id: number
  userId: number
  username: string
  realName: string
  studentNo: string
  courseId: number
  joinedAt: string
  progress: number
  score: number
  lastActiveAt: string
}

// ─── 题目 ─────────────────────────────────────────────
export type Difficulty = 'EASY' | 'MEDIUM' | 'HARD'

export type JudgeStatus =
  | 'PENDING'
  | 'JUDGING'
  | 'ACCEPTED'
  | 'WRONG_ANSWER'
  | 'TIME_LIMIT_EXCEEDED'
  | 'MEMORY_LIMIT_EXCEEDED'
  | 'RUNTIME_ERROR'
  | 'COMPILE_ERROR'
  | 'SYSTEM_ERROR'

export interface Problem {
  id: number
  title: string
  description: string
  inputDescription: string
  outputDescription: string
  samples: ProblemSample[]
  hint: string
  source: string
  difficulty: Difficulty
  timeLimit: number
  memoryLimit: number
  tags: string[]
  courses: number[]
  totalSubmitCount: number
  totalAcceptedCount: number
  acceptanceRate: number
  isPublic: boolean
  createdBy: number
  createdByName: string
  createdAt: string
  updatedAt: string
}

export interface ProblemSample {
  input: string
  output: string
  explanation?: string
}

export interface ProblemForm {
  title: string
  description: string
  inputDescription: string
  outputDescription: string
  samples: ProblemSample[]
  hint: string
  source: string
  difficulty: Difficulty
  timeLimit: number
  memoryLimit: number
  tags: string[]
  courses: number[]
  isPublic: boolean
}

export interface ProblemQuery extends PageQuery {
  difficulty?: Difficulty
  tag?: string
  courseId?: number
  status?: string
}

// ─── 提交 ─────────────────────────────────────────────
export interface Submission {
  id: number
  problemId: number
  problemTitle: string
  userId: number
  username: string
  realName: string
  language: string
  code: string
  status: JudgeStatus
  timeUsed: number
  memoryUsed: number
  score: number
  judgeInfo: string
  errorMessage: string
  testCasesPassed: number
  testCasesTotal: number
  isPublic: boolean
  createdAt: string
}

export interface SubmissionForm {
  problemId: number
  language: string
  code: string
}

export interface SubmissionQuery extends PageQuery {
  problemId?: number
  userId?: number
  language?: string
  status?: JudgeStatus
  courseId?: number
}

export interface JudgeResult {
  status: JudgeStatus
  timeUsed: number
  memoryUsed: number
  testCasesPassed: number
  testCasesTotal: number
  details: TestCaseResult[]
  errorMessage: string
}

export interface TestCaseResult {
  index: number
  status: JudgeStatus
  timeUsed: number
  memoryUsed: number
  input: string
  expectedOutput: string
  actualOutput: string
}

// ─── 错题本 ───────────────────────────────────────────
export interface WrongBookItem {
  id: number
  problemId: number
  problemTitle: string
  problemDifficulty: Difficulty
  userId: number
  wrongCount: number
  lastWrongAt: string
  lastSubmissionId: number
  lastStatus: JudgeStatus
  isResolved: boolean
  resolvedAt: string
  note: string
  tags: string[]
}

export interface WrongBookQuery extends PageQuery {
  difficulty?: Difficulty
  isResolved?: boolean
  tag?: string
}

// ─── 学习分析 ─────────────────────────────────────────
export interface LearningOverview {
  totalProblems: number
  solvedProblems: number
  acceptanceRate: number
  totalSubmissions: number
  acceptedSubmissions: number
  averageScore: number
  ranking: number
  totalStudents: number
  streak: number
  todaySolved: number
  weeklySolved: number
}

export interface DifficultyDistribution {
  easy: { total: number; solved: number }
  medium: { total: number; solved: number }
  hard: { total: number; solved: number }
}

export interface TagStat {
  tag: string
  total: number
  solved: number
  acceptanceRate: number
}

export interface SubmissionTrend {
  date: string
  submitCount: number
  acceptedCount: number
}

export interface CourseProgress {
  courseId: number
  courseName: string
  totalProblems: number
  solvedProblems: number
  progress: number
  rank: number
  score: number
}

export interface DailyActivity {
  date: string
  count: number
}

// ─── 团队 ─────────────────────────────────────────────
export interface Team {
  id: number
  name: string
  description: string
  courseId: number
  courseName: string
  leaderId: number
  leaderName: string
  members: TeamMember[]
  memberCount: number
  maxMembers: number
  inviteCode: string
  createdAt: string
  updatedAt: string
}

export interface TeamMember {
  userId: number
  username: string
  realName: string
  avatar: string
  role: 'LEADER' | 'MEMBER'
  joinedAt: string
}

export interface TeamForm {
  name: string
  description: string
  courseId: number
  maxMembers: number
}

// ─── 通知 ─────────────────────────────────────────────
export type NotificationType = 'SYSTEM' | 'COURSE' | 'TEAM' | 'SUBMISSION' | 'JUDGE'

export interface Notification {
  id: number
  userId: number
  type: NotificationType
  title: string
  content: string
  isRead: boolean
  relatedId: number
  relatedType: string
  createdAt: string
}

export interface NotificationQuery extends PageQuery {
  type?: NotificationType
  isRead?: boolean
}

// ─── 管理员 ───────────────────────────────────────────
export interface UserQuery extends PageQuery {
  role?: UserRole
  status?: number
  school?: string
  department?: string
}

export interface UserForm {
  username: string
  realName: string
  email: string
  phone: string
  role: UserRole
  school: string
  department: string
  studentNo: string
  password?: string
  status?: number
}

export interface JudgeNode {
  id: number
  name: string
  host: string
  port: number
  status: 'ONLINE' | 'OFFLINE' | 'BUSY'
  cpuUsage: number
  memoryUsage: number
  currentTask: number
  maxTask: number
  totalJudged: number
  uptime: number
  lastHeartbeat: string
}

export interface SystemLog {
  id: number
  level: 'INFO' | 'WARN' | 'ERROR'
  module: string
  action: string
  message: string
  userId: number
  username: string
  ip: string
  createdAt: string
}

export interface SystemLogQuery extends PageQuery {
  level?: string
  module?: string
  startTime?: string
  endTime?: string
}

export interface SystemSettings {
  siteName: string
  siteDescription: string
  allowRegister: boolean
  defaultRole: UserRole
  maxUploadSize: number
  submissionRateLimit: number
  judgeTimeout: number
  smtpHost: string
  smtpPort: number
  smtpUser: string
  smtpFrom: string
  maintenanceMode: boolean
  maintenanceMessage: string
}

// ─── 教师端报表 ───────────────────────────────────────
export interface CourseReport {
  courseId: number
  courseName: string
  studentCount: number
  problemCount: number
  submissionCount: number
  acceptanceRate: number
  averageScore: number
  topStudents: CourseStudent[]
  difficultyStats: DifficultyDistribution
  tagStats: TagStat[]
  submissionTrend: SubmissionTrend[]
}

export interface StudentReport {
  userId: number
  username: string
  realName: string
  courses: CourseProgress[]
  overview: LearningOverview
  submissionTrend: SubmissionTrend[]
  tagStats: TagStat[]
}

export interface ReviewData {
  courseId: number
  courseName: string
  period: string
  overview: {
    totalSubmissions: number
    totalStudents: number
    activeStudents: number
    averageScore: number
    completionRate: number
  }
  problemStats: {
    problemId: number
    problemTitle: string
    submitCount: number
    acceptanceRate: number
    averageScore: number
  }[]
  studentStats: {
    userId: number
    realName: string
    submitCount: number
    solvedCount: number
    score: number
    lastActiveAt: string
  }[]
}
