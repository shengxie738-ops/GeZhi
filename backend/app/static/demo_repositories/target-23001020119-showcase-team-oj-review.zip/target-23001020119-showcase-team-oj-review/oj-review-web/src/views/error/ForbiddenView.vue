<template>
  <div class="error-page">
    <div class="error-content">
      <div class="error-code">403</div>
      <h2>访问被拒绝</h2>
      <p class="error-desc">抱歉，您没有权限访问此页面。请联系管理员获取相应权限。</p>
      <div class="error-actions">
        <el-button type="primary" @click="$router.push('/')">
          <el-icon><HomeFilled /></el-icon> 返回首页
        </el-button>
        <el-button @click="$router.back()">
          <el-icon><Back /></el-icon> 返回上一页
        </el-button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
</script>

<style scoped>
.error-page {
  width: 100%;
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f7fa;
}

.error-content {
  text-align: center;
}

.error-code {
  font-size: 160px;
  font-weight: 800;
  color: #e6a23c;
  line-height: 1;
  text-shadow: 4px 4px 0 rgba(230, 162, 60, 0.15);
}

.error-content h2 {
  font-size: 28px;
  color: #1d2129;
  margin: 20px 0 12px;
}

.error-desc {
  font-size: 16px;
  color: #909399;
  margin-bottom: 32px;
}

.error-actions {
  display: flex;
  gap: 12px;
  justify-content: center;
}
</style>
