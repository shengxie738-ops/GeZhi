<template>
  <header class="app-header">
    <div class="header-left">
      <el-icon class="collapse-btn" @click="$emit('toggle-collapse')" :size="20">
        <Fold v-if="!collapsed" />
        <Expand v-else />
      </el-icon>
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: homePath }">首页</el-breadcrumb-item>
        <el-breadcrumb-item v-if="title">{{ title }}</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="header-right">
      <slot name="extra" />
      <el-badge :value="notificationStore.unreadCount" :hidden="!notificationStore.hasUnread" :max="99">
        <el-icon class="header-icon" @click="$router.push(notificationPath)" :size="20"><Bell /></el-icon>
      </el-badge>
      <el-dropdown trigger="click" @command="handleCommand">
        <div class="user-info">
          <el-avatar :size="32" :src="authStore.userInfo?.avatar || ''">
            {{ authStore.userName?.charAt(0) }}
          </el-avatar>
          <span class="user-name">{{ authStore.userName }}</span>
          <el-icon><ArrowDown /></el-icon>
        </div>
        <template #dropdown>
          <el-dropdown-menu>
            <el-dropdown-item command="profile"><el-icon><User /></el-icon>个人资料</el-dropdown-item>
            <el-dropdown-item divided command="logout"><el-icon><SwitchButton /></el-icon>退出登录</el-dropdown-item>
          </el-dropdown-menu>
        </template>
      </el-dropdown>
    </div>
  </header>
</template>

<script setup lang="ts">
import { useAuthStore } from '@/stores/auth'
import { useNotificationStore } from '@/stores/notification'

defineProps<{
  collapsed?: boolean
  title?: string
  homePath?: string
  notificationPath?: string
}>()

const emit = defineEmits<{ 'toggle-collapse': [] }>()

const authStore = useAuthStore()
const notificationStore = useNotificationStore()

function handleCommand(command: string) {
  if (command === 'logout') authStore.logout()
}
</script>

<style scoped>
.app-header {
  height: var(--oj-header-height);
  background: #fff;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.06);
  flex-shrink: 0;
  z-index: 10;
}
.header-left { display: flex; align-items: center; gap: 16px; }
.collapse-btn { cursor: pointer; color: #606266; transition: color 0.2s; }
.collapse-btn:hover { color: var(--oj-primary); }
.header-right { display: flex; align-items: center; gap: 20px; }
.header-icon { cursor: pointer; color: #606266; transition: color 0.2s; }
.header-icon:hover { color: var(--oj-primary); }
.user-info { display: flex; align-items: center; gap: 8px; cursor: pointer; }
.user-name { font-size: 14px; color: #303133; }
</style>
