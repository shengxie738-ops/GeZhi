<template>
  <div class="page-container">
    <div class="page-header">
      <h2>通知中心</h2>
      <el-button type="primary" plain @click="handleMarkAllRead" :disabled="notificationStore.unreadCount === 0">
        <el-icon><Check /></el-icon> 全部已读
      </el-button>
    </div>

    <!-- 筛选 -->
    <el-card shadow="never" class="filter-card">
      <el-radio-group v-model="filterRead" @change="fetchData">
        <el-radio-button :value="undefined">全部</el-radio-button>
        <el-radio-button :value="false">未读</el-radio-button>
        <el-radio-button :value="true">已读</el-radio-button>
      </el-radio-group>
      <el-select v-model="filterType" placeholder="全部类型" clearable style="margin-left: 12px; width: 140px" @change="fetchData">
        <el-option label="系统" value="SYSTEM" />
        <el-option label="课程" value="COURSE" />
        <el-option label="团队" value="TEAM" />
        <el-option label="提交" value="SUBMISSION" />
        <el-option label="评测" value="JUDGE" />
      </el-select>
    </el-card>

    <!-- 通知列表 -->
    <el-card shadow="never" class="notification-card">
      <div v-loading="loading">
        <el-empty v-if="notifications.length === 0" description="暂无通知" />
        <div v-for="n in notifications" :key="n.id" class="notification-item" :class="{ unread: !n.isRead }" @click="handleRead(n)">
          <div class="notify-icon" :class="getNotifyIconClass(n.type)">
            <el-icon :size="20">
              <component :is="getNotifyIcon(n.type)" />
            </el-icon>
          </div>
          <div class="notify-body">
            <div class="notify-title">{{ n.title }}</div>
            <div class="notify-content">{{ n.content }}</div>
            <div class="notify-time">{{ formatDate(n.createdAt) }}</div>
          </div>
          <div class="notify-actions">
            <el-button v-if="!n.isRead" text type="primary" size="small" @click.stop="handleRead(n)">标为已读</el-button>
            <el-button text type="danger" size="small" @click.stop="handleDelete(n)">删除</el-button>
          </div>
        </div>
      </div>

      <div class="pagination-wrapper" v-if="total > pageSize">
        <el-pagination
          v-model:current-page="currentPage"
          :page-size="pageSize"
          :total="total"
          layout="prev, pager, next"
          @current-change="fetchData"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import dayjs from 'dayjs'
import { useNotificationStore } from '@/stores/notification'
import type { Notification, NotificationType } from '@/types'

const notificationStore = useNotificationStore()
const loading = ref(false)
const notifications = ref<Notification[]>([])
const total = ref(0)
const currentPage = ref(1)
const pageSize = 20
const filterRead = ref<boolean | undefined>(undefined)
const filterType = ref<NotificationType | ''>('')

function getNotifyIcon(type: string) {
  const map: Record<string, string> = {
    SYSTEM: 'Setting', COURSE: 'Reading', TEAM: 'UserFilled',
    SUBMISSION: 'Document', JUDGE: 'Cpu'
  }
  return map[type] || 'Bell'
}

function getNotifyIconClass(type: string) {
  const map: Record<string, string> = {
    SYSTEM: 'icon-system', COURSE: 'icon-course', TEAM: 'icon-team',
    SUBMISSION: 'icon-submission', JUDGE: 'icon-judge'
  }
  return map[type] || 'icon-system'
}

function formatDate(date: string) {
  return dayjs(date).format('YYYY-MM-DD HH:mm')
}

async function handleRead(n: Notification) {
  if (!n.isRead) {
    await notificationStore.markAsRead(n.id)
    n.isRead = true
  }
}

async function handleDelete(n: Notification) {
  await notificationStore.deleteNotification(n.id)
  notifications.value = notifications.value.filter(item => item.id !== n.id)
  total.value--
}

async function handleMarkAllRead() {
  await notificationStore.markAllAsRead()
  notifications.value.forEach(n => { n.isRead = true })
}

async function fetchData() {
  loading.value = true
  try {
    await notificationStore.fetchNotifications({
      page: currentPage.value,
      pageSize,
      isRead: filterRead.value,
      type: (filterType.value as NotificationType) || undefined
    })
    notifications.value = notificationStore.notifications
    total.value = notificationStore.total
  } finally {
    loading.value = false
  }
}

onMounted(fetchData)
</script>

<style scoped>
.filter-card {
  margin-bottom: 20px;
  border-radius: 12px;
  display: flex;
  align-items: center;
}

.notification-card {
  border-radius: 12px;
}

.notification-item {
  display: flex;
  align-items: flex-start;
  gap: 16px;
  padding: 16px 0;
  border-bottom: 1px solid #f0f0f0;
  cursor: pointer;
  transition: background 0.2s;
}

.notification-item:hover {
  background: #f8f9fa;
  margin: 0 -20px;
  padding-left: 20px;
  padding-right: 20px;
}

.notification-item:last-child {
  border-bottom: none;
}

.notification-item.unread .notify-title {
  font-weight: 600;
  color: #1d2129;
}

.notify-icon {
  width: 40px;
  height: 40px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.icon-system { background: rgba(144, 147, 153, 0.1); color: #909399; }
.icon-course { background: rgba(64, 158, 255, 0.1); color: #409eff; }
.icon-team { background: rgba(103, 194, 58, 0.1); color: #67c23a; }
.icon-submission { background: rgba(230, 162, 60, 0.1); color: #e6a23c; }
.icon-judge { background: rgba(118, 75, 162, 0.1); color: #764ba2; }

.notify-body {
  flex: 1;
  min-width: 0;
}

.notify-title {
  font-size: 14px;
  color: #606266;
  margin-bottom: 4px;
}

.notify-content {
  font-size: 13px;
  color: #909399;
  margin-bottom: 4px;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.notify-time {
  font-size: 12px;
  color: #c0c4cc;
}

.notify-actions {
  flex-shrink: 0;
}

.pagination-wrapper {
  display: flex;
  justify-content: center;
  margin-top: 20px;
}
</style>
