<template>
  <div class="page-container" v-loading="loading">
    <div class="page-header">
      <h2>编辑题目</h2>
      <el-button @click="$router.back()">返回</el-button>
    </div>

    <el-card shadow="never" class="form-card" v-if="form.title">
      <el-form ref="formRef" :model="form" :rules="rules" label-width="120px" label-position="top">
        <el-row :gutter="24">
          <el-col :span="16">
            <el-form-item label="题目标题" prop="title"><el-input v-model="form.title" /></el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="难度" prop="difficulty">
              <el-select v-model="form.difficulty" style="width:100%">
                <el-option label="简单" value="EASY" /><el-option label="中等" value="MEDIUM" /><el-option label="困难" value="HARD" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="题目描述" prop="description"><el-input v-model="form.description" type="textarea" :rows="6" /></el-form-item>
        <el-form-item label="输入格式"><el-input v-model="form.inputDescription" type="textarea" :rows="3" /></el-form-item>
        <el-form-item label="输出格式"><el-input v-model="form.outputDescription" type="textarea" :rows="3" /></el-form-item>

        <el-form-item label="测试样例">
          <div v-for="(sample, index) in form.samples" :key="index" class="sample-item">
            <div class="sample-header">
              <span>样例 {{ index + 1 }}</span>
              <el-button text type="danger" size="small" @click="form.samples.splice(index, 1)" :disabled="form.samples.length <= 1">删除</el-button>
            </div>
            <el-row :gutter="16">
              <el-col :span="11"><el-input v-model="sample.input" type="textarea" :rows="3" placeholder="输入" /></el-col>
              <el-col :span="11"><el-input v-model="sample.output" type="textarea" :rows="3" placeholder="输出" /></el-col>
              <el-col :span="2"><el-input v-model="sample.explanation" type="textarea" :rows="3" placeholder="解释" /></el-col>
            </el-row>
          </div>
          <el-button type="primary" plain size="small" @click="form.samples.push({ input: '', output: '', explanation: '' })"><el-icon><Plus /></el-icon> 添加样例</el-button>
        </el-form-item>

        <el-form-item label="提示"><el-input v-model="form.hint" type="textarea" :rows="2" /></el-form-item>
        <el-row :gutter="24">
          <el-col :span="8"><el-form-item label="时间限制 (ms)"><el-input-number v-model="form.timeLimit" :min="100" :max="10000" :step="100" style="width:100%" /></el-form-item></el-col>
          <el-col :span="8"><el-form-item label="内存限制 (MB)"><el-input-number v-model="form.memoryLimit" :min="16" :max="1024" :step="16" style="width:100%" /></el-form-item></el-col>
          <el-col :span="8"><el-form-item label="来源"><el-input v-model="form.source" /></el-form-item></el-col>
        </el-row>

        <el-form-item label="知识点标签">
          <div class="tags-input">
            <el-tag v-for="tag in form.tags" :key="tag" closable @close="form.tags = form.tags.filter(t => t !== tag)" class="tag-item">{{ tag }}</el-tag>
            <el-input v-if="tagInputVisible" ref="tagInputRef" v-model="newTag" size="small" style="width:120px" @keyup.enter="addTag" @blur="addTag" />
            <el-button v-else size="small" @click="tagInputVisible = true; nextTick(() => tagInputRef?.focus())">+ 添加标签</el-button>
          </div>
        </el-form-item>

        <el-form-item label="是否公开"><el-switch v-model="form.isPublic" active-text="公开" inactive-text="仅课程内" /></el-form-item>

        <el-form-item>
          <el-button type="primary" :loading="submitting" @click="handleSubmit">保存修改</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, nextTick, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import type { FormInstance, FormRules } from 'element-plus'
import { ElMessage } from 'element-plus'
import * as problemApi from '@/api/problem'
import type { ProblemForm, Problem } from '@/types'

const route = useRoute()
const router = useRouter()
const problemId = Number(route.params.problemId)
const formRef = ref<FormInstance>()
const loading = ref(false)
const submitting = ref(false)
const tagInputVisible = ref(false)
const newTag = ref('')
const tagInputRef = ref()

const form = reactive<ProblemForm>({
  title: '', description: '', inputDescription: '', outputDescription: '',
  samples: [{ input: '', output: '', explanation: '' }],
  hint: '', source: '', difficulty: 'EASY', timeLimit: 1000, memoryLimit: 256,
  tags: [], courses: [], isPublic: true
})

const rules: FormRules = {
  title: [{ required: true, message: '请输入题目标题', trigger: 'blur' }],
  description: [{ required: true, message: '请输入题目描述', trigger: 'blur' }],
  difficulty: [{ required: true, message: '请选择难度', trigger: 'change' }]
}

function addTag() { if (newTag.value && !form.tags.includes(newTag.value)) form.tags.push(newTag.value); tagInputVisible.value = false; newTag.value = '' }

async function handleSubmit() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return
  submitting.value = true
  try {
    await problemApi.updateProblem(problemId, form)
    ElMessage.success('保存成功')
    router.push('/teacher/problems')
  } catch { ElMessage.error('保存失败') } finally { submitting.value = false }
}

onMounted(async () => {
  loading.value = true
  try {
    const res = await problemApi.getProblemDetail(problemId)
    const p = res.data as unknown as Problem
    Object.assign(form, {
      title: p.title, description: p.description, inputDescription: p.inputDescription,
      outputDescription: p.outputDescription, samples: p.samples?.length ? p.samples : [{ input: '', output: '', explanation: '' }],
      hint: p.hint, source: p.source, difficulty: p.difficulty, timeLimit: p.timeLimit,
      memoryLimit: p.memoryLimit, tags: p.tags || [], courses: p.courses || [], isPublic: p.isPublic
    })
  } finally { loading.value = false }
})
</script>

<style scoped>
.form-card { border-radius: 12px; max-width: 960px; }
.sample-item { margin-bottom: 16px; padding: 12px; background: #f8f9fa; border-radius: 8px; }
.sample-header { display: flex; justify-content: space-between; margin-bottom: 8px; font-weight: 600; font-size: 13px; }
.tags-input { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
.tag-item { margin-right: 0; }
</style>
