import { get, post, put, del } from '@/utils/request'
import type { Problem, ProblemForm, ProblemQuery, PageResult } from '@/types'

/** 获取题目列表（分页） */
export function getProblemList(params?: ProblemQuery) {
  return get<PageResult<Problem>>('/problems', params as Record<string, unknown>)
}

/** 获取题目详情 */
export function getProblemDetail(problemId: number) {
  return get<Problem>(`/problems/${problemId}`)
}

/** 创建题目 */
export function createProblem(data: ProblemForm) {
  return post<Problem>('/problems', data)
}

/** 更新题目 */
export function updateProblem(problemId: number, data: Partial<ProblemForm>) {
  return put<Problem>(`/problems/${problemId}`, data)
}

/** 删除题目 */
export function deleteProblem(problemId: number) {
  return del<void>(`/problems/${problemId}`)
}

/** 批量删除题目 */
export function batchDeleteProblems(problemIds: number[]) {
  return del<void>('/problems/batch', { ids: problemIds.join(',') })
}

/** 获取题目标签列表 */
export function getProblemTags() {
  return get<string[]>('/problems/tags')
}

/** 获取题目难度分布统计 */
export function getProblemDifficultyStats(courseId?: number) {
  return get<Record<string, number>>('/problems/stats/difficulty', { courseId })
}

/** 导入题目（JSON/CSV） */
export function importProblems(file: File, courseId?: number) {
  const formData = new FormData()
  formData.append('file', file)
  if (courseId) {
    formData.append('courseId', String(courseId))
  }
  return post<{ success: number; failed: number; errors: string[] }>(
    '/problems/import',
    formData,
    { headers: { 'Content-Type': 'multipart/form-data' } }
  )
}

/** 导出题目 */
export function exportProblems(params?: { courseId?: number; difficulty?: string; tag?: string }) {
  return get<Blob>('/problems/export', params as Record<string, unknown>, {
    responseType: 'blob'
  })
}

/** 题目排序 */
export function sortProblems(courseId: number, problemIds: number[]) {
  return post<void>('/problems/sort', { courseId, problemIds })
}

/** 复制题目到指定课程 */
export function copyProblem(problemId: number, targetCourseIds: number[]) {
  return post<Problem[]>(`/problems/${problemId}/copy`, { targetCourseIds })
}
