<template>
  <div class="page-container" v-loading="loading">
    <template v-if="course">
      <div class="page-header">
        <h2>{{ course.name }}</h2>
        <el-button @click="$router.back()">返回</el-button>
      </div>

      <el-card shadow="never" class="info-card">
        <el-descriptions :column="4" border>
          <el-descriptions-item label="课程代码">{{ course.code }}</el-descriptions-item>
          <el-descriptions-item label="学期">{{ course.semester }}</el-descriptions-item>
          <el-descriptions-item label="学生数">{{ course.studentCount }}</el-descriptions-item>
          <el-descriptions-item label="题目数">{{ course.problemCount }}</el-descriptions-item>
          <el-descriptions-item label="状态">
            <el-tag :type="course.status === 'PUBLISHED' ? 'success' : course.status === 'DRAFT' ? 'warning' : 'info'" size="small">
              {{ course.status === 'PUBLISHED' ? '已发布' : course.status === 'DRAFT' ? '草稿' : '已归档' }}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="描述" :span="3">{{ course.description || '暂无' }}</el-descriptions-item>
        </el-descriptions>
      </el-card>

      <el-tabs v-model="activeTab">
        <!-- 学生管理 -->
        <el-tab-pane label="学生管理" name="students">
          <el-card shadow="never" class="section-card">
            <template #header>
              <div class="card-header">
                <span>学生列表 ({{ studentsTotal }})</span>
                <div>
                  <el-button type="primary" size="small" @click="showInviteCode">邀请码</el-button>
                  <el-button type="success" size="small" @click="handleExport">导出</el-button>
                </div>
              </div>
            </template>
            <el-table :data="students" stripe>
              <el-table-column prop="studentNo" label="学号" width="120" />
              <el-table-column prop="realName" label="姓名" width="120" />
              <el-table-column prop="username" label="用户名" width="120" />
              <el-table-column prop="progress" label="进度" width="160">
                <template #default="{ row }"><el-progress :percentage="row.progress" :stroke-width="6" /></template>
              </el-table-column>
              <el-table-column prop="score" label="分数" width="80" align="center" />
              <el-table-column prop="joinedAt" label="加入时间" width="170">
                <template #default="{ row }">{{ formatDate(row.joinedAt) }}</template>
              </el-table-column>
              <el-table-column label="操作" width="80" align="center">
                <template #default="{ row }">
                  <el-button text type="danger" size="small" @click="handleRemoveStudent(row)">移除</el-button>
                </template>
              </el-table-column>
            </el-table>
          </el-card>
        </el-tab-pane>

        <!-- 课程统计 -->
        <el-tab-pane label="课程统计" name="stats">
          <el-row :gutter="20">
            <el-col :span="12">
              <el-card shadow="never" class="section-card">
                <template #header><span>提交趋势</span></template>
                <v-chart :option="trendOption" style="height:300px" autoresize />
              </el-card>
            </el-col>
            <el-col :span="12">
              <el-card shadow="never" class="section-card">
                <template #header><span>难度分布</span></template>
                <v-chart :option="diffOption" style="height:300px" autoresize />
              </el-card>
            </el-col>
          </el-row>
        </el-tab-pane>
      </el-tabs>
    </template>

    <!-- 邀请码弹窗 -->
    <el-dialog v-model="inviteDialogVisible" title="课程邀请码" width="400px">
      <div class="invite-code-box">
        <el-tag size="large" type="primary">{{ inviteCode }}</el-tag>
        <el-button text type="primary" @click="copyInviteCode">复制</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import dayjs from 'dayjs'
import { ElMessage, ElMessageBox } from 'element-plus'
import * as courseApi from '@/api/course'
import type { Course, CourseStudent } from '@/types'

const route = useRoute()
const courseId = Number(route.params.courseId)
const loading = ref(false)
const course = ref<Course | null>(null)
const activeTab = ref('students')
const students = ref<CourseStudent[]>([])
const studentsTotal = ref(0)
const inviteDialogVisible = ref(false)
const inviteCode = ref('')

const trendOption = computed(() => ({
  tooltip: { trigger: 'axis' }, grid: { left: 50, right: 20, top: 20, bottom: 30 },
  xAxis: { type: 'category', data: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'] },
  yAxis: { type: 'value' },
  series: [{ type: 'line', smooth: true, data: [12, 19, 8, 25, 30, 15, 22], areaStyle: { opacity: 0.15 }, itemStyle: { color: '#409eff' } }]
}))

const diffOption = computed(() => ({
  tooltip: { trigger: 'item', formatter: '{b}: {c} ({d}%)' }, legend: { bottom: 0 },
  series: [{ type: 'pie', radius: ['35%', '65%'], itemStyle: { borderRadius: 6, borderColor: '#fff', borderWidth: 2 },
    data: [
      { value: 30, name: '简单', itemStyle: { color: '#67c23a' } },
      { value: 20, name: '中等', itemStyle: { color: '#e6a23c' } },
      { value: 10, name: '困难', itemStyle: { color: '#f56c6c' } }
    ] }]
}))

function formatDate(d: string) { return dayjs(d).format('YYYY-MM-DD HH:mm') }

async function showInviteCode() {
  try {
    const res = await courseApi.getInviteCode(courseId)
    inviteCode.value = (res.data as unknown as { inviteCode: string }).inviteCode
    inviteDialogVisible.value = true
  } catch { ElMessage.error('获取邀请码失败') }
}

function copyInviteCode() {
  navigator.clipboard.writeText(inviteCode.value)
  ElMessage.success('已复制')
}

function handleExport() { ElMessage.info('正在导出...') }

async function handleRemoveStudent(student: CourseStudent) {
  await ElMessageBox.confirm(`确定移除学生「${student.realName}」？`, '警告', { type: 'warning' })
  try { await courseApi.removeStudent(courseId, student.userId); ElMessage.success('移除成功'); fetchStudents() } catch { ElMessage.error('移除失败') }
}

async function fetchStudents() {
  try {
    const res = await courseApi.getCourseStudents(courseId, { page: 1, pageSize: 100 })
    const data = res.data as unknown as { records: CourseStudent[]; total: number }
    students.value = data.records; studentsTotal.value = data.total
  } catch { /* ignore */ }
}

onMounted(async () => {
  loading.value = true
  try {
    const res = await courseApi.getCourseDetail(courseId)
    course.value = res.data as unknown as Course
    fetchStudents()
  } finally { loading.value = false }
})
</script>

<style scoped>
.info-card { margin-bottom: 20px; border-radius: 12px; }
.section-card { border-radius: 12px; }
.card-header { display: flex; align-items: center; justify-content: space-between; }
.invite-code-box { text-align: center; padding: 20px; }
.invite-code-box .el-tag { font-size: 24px; padding: 12px 24px; }
</style>
