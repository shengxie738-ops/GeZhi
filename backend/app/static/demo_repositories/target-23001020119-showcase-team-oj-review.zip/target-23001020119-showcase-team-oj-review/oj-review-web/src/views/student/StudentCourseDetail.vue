<template>
  <div class="page-container" v-loading="loading">
    <!-- 课程头部信息 -->
    <el-card v-if="course" shadow="never" class="course-header-card">
      <div class="course-header">
        <div class="course-info">
          <h2>{{ course.name }}</h2>
          <p class="course-desc">{{ course.description }}</p>
          <div class="course-tags">
            <el-tag>{{ course.semester }}</el-tag>
            <el-tag type="info">{{ course.teacherName }}</el-tag>
            <el-tag type="warning">{{ course.studentCount }} 名学生</el-tag>
          </div>
        </div>
        <div class="course-progress-ring">
          <el-progress type="circle" :percentage="progress" :width="100" :stroke-width="8" color="#409eff" />
          <span class="progress-label">课程进度</span>
        </div>
      </div>
    </el-card>

    <!-- 课程公告 -->
    <el-card v-if="course" shadow="never" class="section-card">
      <template #header><span>课程公告</span></template>
      <div v-if="announcements.length === 0" class="empty-tip">暂无公告</div>
      <div v-for="(a, i) in announcements" :key="i" class="announcement-item">
        <el-icon><Bell /></el-icon>
        <span>{{ a }}</span>
      </div>
    </el-card>

    <!-- 章节树形列表 -->
    <el-card shadow="never" class="section-card">
      <template #header><span>课程章节</span></template>
      <el-tree
        :data="chapters"
        node-key="id"
        default-expand-all
        :props="{ label: 'title', children: 'children' }"
      >
        <template #default="{ node, data }">
          <div class="chapter-node">
            <div class="node-left">
              <el-icon v-if="data.isChapter" :size="16"><Folder /></el-icon>
              <el-icon v-else :size="16"><Document /></el-icon>
              <span class="node-label">{{ node.label }}</span>
              <el-tag v-if="data.difficulty" :type="getDifficultyType(data.difficulty)" size="small">
                {{ getDifficultyLabel(data.difficulty) }}
              </el-tag>
            </div>
            <div class="node-right">
              <el-tag v-if="data.status === 'ACCEPTED'" type="success" size="small">已通过</el-tag>
              <el-tag v-else-if="data.status === 'WRONG'" type="danger" size="small">未通过</el-tag>
              <el-button v-if="!data.isChapter" type="primary" text size="small" @click.stop="$router.push(`/student/problems/${data.problemId}`)">
                去做题
              </el-button>
            </div>
          </div>
        </template>
      </el-tree>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import * as courseApi from '@/api/course'
import type { Course } from '@/types'

const route = useRoute()
const courseId = Number(route.params.courseId)
const loading = ref(false)
const course = ref<Course | null>(null)
const progress = ref(0)
const announcements = ref<string[]>([
  '期中考试范围：第一章至第三章，请做好准备。',
  '本周五进行第一次代码复盘，请提前完成作业。'
])

interface ChapterNode {
  id: number
  title: string
  isChapter: boolean
  problemId?: number
  difficulty?: string
  status?: string
  children?: ChapterNode[]
}

const chapters = ref<ChapterNode[]>([
  {
    id: 1, title: '第一章：基础语法', isChapter: true,
    children: [
      { id: 11, title: 'A + B Problem', isChapter: false, problemId: 1, difficulty: 'EASY', status: 'ACCEPTED' },
      { id: 12, title: 'Hello World', isChapter: false, problemId: 2, difficulty: 'EASY', status: 'WRONG' },
      { id: 13, title: '数据类型转换', isChapter: false, problemId: 3, difficulty: 'MEDIUM' }
    ]
  },
  {
    id: 2, title: '第二章：循环与条件', isChapter: true,
    children: [
      { id: 21, title: '斐波那契数列', isChapter: false, problemId: 4, difficulty: 'EASY' },
      { id: 22, title: '素数判断', isChapter: false, problemId: 5, difficulty: 'MEDIUM' }
    ]
  },
  {
    id: 3, title: '第三章：数组与字符串', isChapter: true,
    children: [
      { id: 31, title: '字符串反转', isChapter: false, problemId: 6, difficulty: 'EASY' },
      { id: 32, title: '最长回文子串', isChapter: false, problemId: 7, difficulty: 'HARD' }
    ]
  }
])

function getDifficultyType(d: string) {
  const map: Record<string, string> = { EASY: 'success', MEDIUM: 'warning', HARD: 'danger' }
  return (map[d] || 'info') as 'success' | 'warning' | 'danger' | 'info'
}

function getDifficultyLabel(d: string) {
  const map: Record<string, string> = { EASY: '简单', MEDIUM: '中等', HARD: '困难' }
  return map[d] || d
}

onMounted(async () => {
  loading.value = true
  try {
    const res = await courseApi.getCourseDetail(courseId)
    course.value = res.data as unknown as Course
    progress.value = 45 // placeholder
  } finally {
    loading.value = false
  }
})
</script>

<style scoped>
.course-header-card {
  margin-bottom: 20px;
  border-radius: 12px;
}

.course-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.course-info h2 {
  font-size: 22px;
  font-weight: 600;
  color: #1d2129;
  margin-bottom: 8px;
}

.course-desc {
  font-size: 14px;
  color: #606266;
  margin-bottom: 12px;
}

.course-tags {
  display: flex;
  gap: 8px;
}

.course-progress-ring {
  text-align: center;
}

.progress-label {
  display: block;
  font-size: 13px;
  color: #909399;
  margin-top: 8px;
}

.section-card {
  border-radius: 12px;
  margin-bottom: 20px;
}

.announcement-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 0;
  border-bottom: 1px solid #f0f0f0;
  font-size: 14px;
  color: #303133;
}

.announcement-item:last-child {
  border-bottom: none;
}

.chapter-node {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  padding: 6px 0;
}

.node-left {
  display: flex;
  align-items: center;
  gap: 8px;
}

.node-label {
  font-size: 14px;
}

.node-right {
  display: flex;
  align-items: center;
  gap: 8px;
}

.empty-tip {
  text-align: center;
  color: #909399;
  padding: 20px 0;
}
</style>
