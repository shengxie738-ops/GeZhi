<template>
  <div class="page-container">
    <div class="page-header">
      <h2>我的课程</h2>
      <el-button type="primary" @click="showJoinDialog = true">
        <el-icon><Plus /></el-icon> 加入课程
      </el-button>
    </div>

    <!-- 搜索筛选 -->
    <el-card shadow="never" class="filter-card">
      <el-form :inline="true" :model="filterForm">
        <el-form-item label="搜索">
          <el-input v-model="filterForm.keyword" placeholder="搜索课程名称" clearable prefix-icon="Search" @clear="fetchData" @keyup.enter="fetchData" />
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="filterForm.status" placeholder="全部状态" clearable @change="fetchData">
            <el-option label="进行中" value="PUBLISHED" />
            <el-option label="已归档" value="ARCHIVED" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="fetchData">查询</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <!-- 课程卡片网格 -->
    <div v-loading="loading" class="course-grid">
      <el-empty v-if="courses.length === 0" description="暂未加入任何课程" />
      <el-card
        v-for="course in courses"
        :key="course.id"
        shadow="hover"
        class="course-card"
        @click="$router.push(`/student/courses/${course.id}`)"
      >
        <div class="course-cover">
          <img v-if="course.coverImage" :src="course.coverImage" :alt="course.name" />
          <div v-else class="cover-placeholder">
            <el-icon :size="40"><Reading /></el-icon>
          </div>
          <el-tag :type="course.status === 'PUBLISHED' ? 'success' : 'info'" class="course-status" size="small">
            {{ course.status === 'PUBLISHED' ? '进行中' : '已归档' }}
          </el-tag>
        </div>
        <div class="course-body">
          <h3 class="course-name">{{ course.name }}</h3>
          <p class="course-teacher">
            <el-icon><User /></el-icon> {{ course.teacherName }}
          </p>
          <p class="course-meta">
            <span><el-icon><Document /></el-icon> {{ course.problemCount }} 题</span>
            <span><el-icon><UserFilled /></el-icon> {{ course.studentCount }} 人</span>
          </p>
          <el-progress
            :percentage="getProgress(course.id)"
            :stroke-width="6"
            :color="getProgress(course.id) === 100 ? '#67c23a' : '#409eff'"
          />
        </div>
      </el-card>
    </div>

    <!-- 分页 -->
    <div class="pagination-wrapper" v-if="total > pageSize">
      <el-pagination
        v-model:current-page="currentPage"
        :page-size="pageSize"
        :total="total"
        layout="prev, pager, next"
        @current-change="fetchData"
      />
    </div>

    <!-- 加入课程弹窗 -->
    <el-dialog v-model="showJoinDialog" title="加入课程" width="420px" destroy-on-close>
      <el-form ref="joinFormRef" :model="joinForm" :rules="joinRules" label-width="80px">
        <el-form-item label="邀请码" prop="inviteCode">
          <el-input v-model="joinForm.inviteCode" placeholder="请输入课程邀请码" clearable />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showJoinDialog = false">取消</el-button>
        <el-button type="primary" :loading="joining" @click="handleJoin">加入</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import type { FormInstance, FormRules } from 'element-plus'
import { ElMessage } from 'element-plus'
import { useCourseStore } from '@/stores/course'
import * as courseApi from '@/api/course'
import type { Course } from '@/types'

const courseStore = useCourseStore()
const loading = ref(false)
const courses = ref<Course[]>([])
const total = ref(0)
const currentPage = ref(1)
const pageSize = 12

const filterForm = reactive({ keyword: '', status: '' })
const showJoinDialog = ref(false)
const joining = ref(false)
const joinFormRef = ref<FormInstance>()
const joinForm = reactive({ inviteCode: '' })
const joinRules: FormRules = {
  inviteCode: [{ required: true, message: '请输入邀请码', trigger: 'blur' }]
}

function getProgress(courseId: number) {
  return Math.round(Math.random() * 80 + 10) // placeholder
}

async function fetchData() {
  loading.value = true
  try {
    const res = await courseApi.getEnrolledCourses()
    courses.value = res.data as unknown as Course[]
    total.value = courses.value.length
  } finally {
    loading.value = false
  }
}

async function handleJoin() {
  const valid = await joinFormRef.value?.validate().catch(() => false)
  if (!valid) return
  joining.value = true
  try {
    await courseStore.joinCourse(0, joinForm.inviteCode)
    ElMessage.success('加入课程成功')
    showJoinDialog.value = false
    joinForm.inviteCode = ''
    fetchData()
  } catch {
    ElMessage.error('加入失败，请检查邀请码')
  } finally {
    joining.value = false
  }
}

onMounted(fetchData)
</script>

<style scoped>
.filter-card {
  margin-bottom: 20px;
  border-radius: 12px;
}

.course-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 20px;
}

.course-card {
  border-radius: 12px;
  cursor: pointer;
  transition: transform 0.2s;
  overflow: hidden;
}

.course-card:hover {
  transform: translateY(-4px);
}

.course-cover {
  position: relative;
  height: 140px;
  overflow: hidden;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  display: flex;
  align-items: center;
  justify-content: center;
}

.course-cover img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.cover-placeholder {
  color: rgba(255, 255, 255, 0.6);
}

.course-status {
  position: absolute;
  top: 10px;
  right: 10px;
}

.course-body {
  padding: 16px;
}

.course-name {
  font-size: 16px;
  font-weight: 600;
  color: #1d2129;
  margin-bottom: 8px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.course-teacher {
  font-size: 13px;
  color: #909399;
  margin-bottom: 8px;
  display: flex;
  align-items: center;
  gap: 4px;
}

.course-meta {
  font-size: 13px;
  color: #909399;
  display: flex;
  gap: 16px;
  margin-bottom: 12px;
}

.course-meta span {
  display: flex;
  align-items: center;
  gap: 4px;
}

.pagination-wrapper {
  display: flex;
  justify-content: center;
  margin-top: 24px;
}
</style>
