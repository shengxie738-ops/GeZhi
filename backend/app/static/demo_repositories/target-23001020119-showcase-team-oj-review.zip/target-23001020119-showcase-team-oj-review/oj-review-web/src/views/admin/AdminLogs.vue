<template>
  <div class="page-container">
    <div class="page-header"><h2>系统日志</h2></div>

    <el-card shadow="never" class="filter-card">
      <el-form :inline="true" :model="filterForm">
        <el-form-item label="级别">
          <el-select v-model="filterForm.level" placeholder="全部" clearable @change="fetchData">
            <el-option label="INFO" value="INFO" /><el-option label="WARN" value="WARN" /><el-option label="ERROR" value="ERROR" />
          </el-select>
        </el-form-item>
        <el-form-item label="模块">
          <el-select v-model="filterForm.module" placeholder="全部" clearable @change="fetchData">
            <el-option label="认证" value="AUTH" /><el-option label="评测" value="JUDGE" /><el-option label="课程" value="COURSE" /><el-option label="系统" value="SYSTEM" />
          </el-select>
        </el-form-item>
        <el-form-item label="时间">
          <el-date-picker v-model="filterForm.dateRange" type="daterange" start-placeholder="开始" end-placeholder="结束" @change="fetchData" />
        </el-form-item>
        <el-form-item><el-button type="primary" @click="fetchData">查询</el-button></el-form-item>
      </el-form>
    </el-card>

    <el-card shadow="never" class="table-card">
      <el-table :data="logs" v-loading="loading" stripe>
        <el-table-column prop="id" label="ID" width="70" />
        <el-table-column prop="level" label="级别" width="80" align="center">
          <template #default="{ row }">
            <el-tag :type="row.level === 'ERROR' ? 'danger' : row.level === 'WARN' ? 'warning' : 'info'" size="small">{{ row.level }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="module" label="模块" width="100" />
        <el-table-column prop="action" label="操作" width="140" />
        <el-table-column prop="message" label="信息" min-width="260" show-overflow-tooltip />
        <el-table-column prop="username" label="用户" width="100" />
        <el-table-column prop="ip" label="IP" width="140" />
        <el-table-column prop="createdAt" label="时间" width="170">
          <template #default="{ row }">{{ formatDate(row.createdAt) }}</template>
        </el-table-column>
      </el-table>
      <div class="pagination-wrapper">
        <el-pagination v-model:current-page="currentPage" v-model:page-size="pageSize" :page-sizes="[20,50,100]" :total="total" layout="total, sizes, prev, pager, next, jumper" @size-change="fetchData" @current-change="fetchData" />
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import dayjs from 'dayjs'
import { get } from '@/utils/request'
import type { SystemLog, PageResult } from '@/types'

const loading = ref(false)
const logs = ref<SystemLog[]>([])
const total = ref(0)
const currentPage = ref(1)
const pageSize = ref(20)
const filterForm = reactive({ level: '', module: '', dateRange: null as [Date, Date] | null })

function formatDate(d: string) { return dayjs(d).format('YYYY-MM-DD HH:mm:ss') }

async function fetchData() {
  loading.value = true
  try {
    const params: Record<string, unknown> = { page: currentPage.value, pageSize: pageSize.value }
    if (filterForm.level) params.level = filterForm.level
    if (filterForm.module) params.module = filterForm.module
    if (filterForm.dateRange) { params.startTime = filterForm.dateRange[0].toISOString(); params.endTime = filterForm.dateRange[1].toISOString() }
    const res = await get<PageResult<SystemLog>>('/admin/logs', params)
    const data = res.data as unknown as PageResult<SystemLog>
    logs.value = data.records; total.value = data.total
  } catch { /* ignore */ } finally { loading.value = false }
}

onMounted(fetchData)
</script>

<style scoped>
.filter-card { margin-bottom: 20px; border-radius: 12px; }
.table-card { border-radius: 12px; }
.pagination-wrapper { display: flex; justify-content: flex-end; margin-top: 16px; }
</style>
