<template>
  <v-chart :option="chartOption" :style="{ height: height }" autoresize />
</template>

<script setup lang="ts">
import { computed } from 'vue'

const props = withDefaults(defineProps<{
  title?: string
  data: { name: string; value: number; color?: string }[]
  height?: string
  radius?: [string, string]
  centerLabel?: string
}>(), {
  height: '320px',
  radius: () => ['35%', '65%']
})

const chartOption = computed(() => ({
  title: props.title ? { text: props.title, left: 'center', textStyle: { fontSize: 14 } } : undefined,
  tooltip: { trigger: 'item', formatter: '{b}: {c} ({d}%)' },
  legend: { bottom: 0, textStyle: { fontSize: 12 } },
  series: [{
    type: 'pie',
    radius: props.radius,
    avoidLabelOverlap: false,
    itemStyle: { borderRadius: 8, borderColor: '#fff', borderWidth: 2 },
    label: props.centerLabel
      ? { show: true, position: 'center', fontSize: 16, fontWeight: 'bold', formatter: props.centerLabel }
      : { show: true },
    data: props.data.map(d => ({
      value: d.value,
      name: d.name,
      itemStyle: d.color ? { color: d.color } : undefined
    }))
  }]
}))
</script>
