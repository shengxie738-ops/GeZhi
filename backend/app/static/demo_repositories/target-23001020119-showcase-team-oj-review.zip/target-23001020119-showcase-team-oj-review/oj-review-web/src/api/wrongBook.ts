import { get, post, put, del } from '@/utils/request'
import type { WrongBookItem, WrongBookQuery, PageResult } from '@/types'

/** 获取错题本列表（分页） */
export function getWrongBookList(params?: WrongBookQuery) {
  return get<PageResult<WrongBookItem>>('/wrong-book', params as Record<string, unknown>)
}

/** 获取错题详情 */
export function getWrongBookItem(itemId: number) {
  return get<WrongBookItem>(`/wrong-book/${itemId}`)
}

/** 手动添加错题 */
export function addWrongBookItem(data: { problemId: number; note?: string }) {
  return post<WrongBookItem>('/wrong-book', data)
}

/** 更新错题备注 */
export function updateWrongBookNote(itemId: number, note: string) {
  return put<WrongBookItem>(`/wrong-book/${itemId}`, { note })
}

/** 标记错题已解决 */
export function markAsResolved(itemId: number) {
  return put<void>(`/wrong-book/${itemId}/resolve`)
}

/** 标记错题未解决 */
export function markAsUnresolved(itemId: number) {
  return put<void>(`/wrong-book/${itemId}/unresolve`)
}

/** 删除错题 */
export function deleteWrongBookItem(itemId: number) {
  return del<void>(`/wrong-book/${itemId}`)
}

/** 批量删除错题 */
export function batchDeleteWrongBook(itemIds: number[]) {
  return del<void>('/wrong-book/batch', { ids: itemIds.join(',') })
}

/** 获取错题统计 */
export function getWrongBookStats() {
  return get<{
    total: number
    unresolved: number
    resolved: number
    difficultyStats: { easy: number; medium: number; hard: number }
    tagStats: { tag: string; count: number }[]
  }>('/wrong-book/stats')
}

/** 导出错题本 */
export function exportWrongBook(params?: WrongBookQuery) {
  return get<Blob>('/wrong-book/export', params as Record<string, unknown>, {
    responseType: 'blob'
  })
}

/** 重新练习错题（跳转到题目详情的快捷方式，返回最新提交状态） */
export function retryWrongProblem(problemId: number) {
  return get<{ submissionId: number; lastStatus: string }>(`/wrong-book/retry/${problemId}`)
}
