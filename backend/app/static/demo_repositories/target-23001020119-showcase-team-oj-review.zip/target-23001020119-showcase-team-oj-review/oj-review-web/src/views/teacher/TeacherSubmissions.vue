<template>
  <div class="page-container">
    <div class="page-header"><h2>提交记录</h2></div>

    <el-card shadow="never" class="filter-card">
      <el-form :inline="true" :model="filterForm">
        <el-form-item label="学生"><el-input v-model="filterForm.keyword" placeholder="学生姓名/用户名" clearable @keyup.enter="fetchData" /></el-form-item>
        <el-form-item label="语言">
          <el-select v-model="filterForm.language" placeholder="全部" clearable @change="fetchData">
            <el-option label="C++" value="cpp" /><el-option label="Java" value="java" /><el-option label="Python" value="python" />
          </el-select>
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="filterForm.status" placeholder="全部" clearable @change="fetchData">
            <el-option label="通过" value="ACCEPTED" /><el-option label="答案错误" value="WRONG_ANSWER" /><el-option label="编译错误" value="COMPILE_ERROR" />
          </el-select>
        </el-form-item>
        <el-form-item><el-button type="primary" @click="fetchData">查询</el-button></el-form-item>
      </el-form>
    </el-card>

    <el-card shadow="never" class="table-card">
      <el-table :data="submissions" v-loading="loading" stripe @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="50" />
        <el-table-column prop="id" label="编号" width="80" align="center" />
        <el-table-column prop="realName" label="学生" width="120" />
        <el-table-column prop="problemTitle" label="题目" min-width="200" />
        <el-table-column prop="language" label="语言" width="100" />
        <el-table-column prop="status" label="状态" width="130">
          <template #default="{ row }"><el-tag :type="getStatusType(row.status)" size="small">{{ getStatusLabel(row.status) }}</el-tag></template>
        </el-table-column>
        <el-table-column prop="score" label="分数" width="80" align="center" />
        <el-table-column prop="timeUsed" label="耗时" width="100"><template #default="{ row }">{{ row.timeUsed }}ms</template></el-table-column>
        <el-table-column prop="createdAt" label="提交时间" width="170"><template #default="{ row }">{{ formatDate(row.createdAt) }}</template></el-table-column>
        <el-table-column label="操作" width="120" align="center" fixed="right">
          <template #default="{ row }">
            <el-button text type="primary" size="small" @click="$router.push(`/student/submissions/${row.id}`)">详情</el-button>
            <el-button text type="warning" size="small" @click="handleRejudge(row)">重测</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="table-footer">
        <el-button type="warning" size="small" :disabled="selectedIds.length === 0" @click="handleBatchRejudge">批量重测</el-button>
        <el-pagination v-model:current-page="currentPage" v-model:page-size="pageSize" :page-sizes="[20,50,100]" :total="total" layout="total, sizes, prev, pager, next, jumper" @size-change="fetchData" @current-change="fetchData" />
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import dayjs from 'dayjs'
import { ElMessage } from 'element-plus'
import * as submissionApi from '@/api/submission'
import type { Submission, JudgeStatus } from '@/types'

const loading = ref(false)
const submissions = ref<Submission[]>([])
const total = ref(0)
const currentPage = ref(1)
const pageSize = ref(20)
const selectedIds = ref<number[]>([])
const filterForm = reactive({ keyword: '', language: '', status: '' as JudgeStatus | '' })

function getStatusType(s: string) { return ({ ACCEPTED: 'success', WRONG_ANSWER: 'danger', PENDING: 'warning', JUDGING: '', COMPILE_ERROR: 'danger' }[s] || 'info') as 'success'|'danger'|'warning'|'info'|'' }
function getStatusLabel(s: string) { return ({ ACCEPTED: '通过', WRONG_ANSWER: '答案错误', PENDING: '等待', JUDGING: '评测中', COMPILE_ERROR: '编译错误', RUNTIME_ERROR: '运行错误', TIME_LIMIT_EXCEEDED: '超时' }[s] || s) }
function formatDate(d: string) { return dayjs(d).format('YYYY-MM-DD HH:mm:ss') }
function handleSelectionChange(rows: Submission[]) { selectedIds.value = rows.map(r => r.id) }

async function fetchData() {
  loading.value = true
  try {
    const res = await submissionApi.getSubmissionList({ page: currentPage.value, pageSize: pageSize.value, language: filterForm.language || undefined, status: (filterForm.status as JudgeStatus) || undefined })
    const data = res.data as unknown as { records: Submission[]; total: number }
    submissions.value = data.records; total.value = data.total
  } finally { loading.value = false }
}

async function handleRejudge(sub: Submission) {
  try { await submissionApi.rejudgeSubmission(sub.id); ElMessage.success('已提交重测') } catch { ElMessage.error('重测失败') }
}

async function handleBatchRejudge() {
  try { await submissionApi.batchRejudge(selectedIds.value); ElMessage.success('批量重测已提交') } catch { ElMessage.error('批量重测失败') }
}

onMounted(fetchData)
</script>

<style scoped>
.filter-card { margin-bottom: 20px; border-radius: 12px; }
.table-card { border-radius: 12px; }
.table-footer { display: flex; align-items: center; justify-content: space-between; margin-top: 16px; }
</style>
