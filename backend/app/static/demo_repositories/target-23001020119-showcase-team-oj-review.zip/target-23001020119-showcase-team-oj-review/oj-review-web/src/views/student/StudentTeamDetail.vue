<template>
  <div class="page-container" v-loading="loading">
    <template v-if="team">
      <div class="page-header">
        <h2>{{ team.name }}</h2>
        <el-button @click="$router.back()">返回</el-button>
      </div>

      <el-row :gutter="20">
        <el-col :span="16">
          <!-- 团队信息 -->
          <el-card shadow="never" class="section-card">
            <template #header><span>团队信息</span></template>
            <el-descriptions :column="2" border>
              <el-descriptions-item label="团队名称">{{ team.name }}</el-descriptions-item>
              <el-descriptions-item label="所属课程">{{ team.courseName }}</el-descriptions-item>
              <el-descriptions-item label="队长">{{ team.leaderName }}</el-descriptions-item>
              <el-descriptions-item label="人数">{{ team.memberCount }}/{{ team.maxMembers }}</el-descriptions-item>
              <el-descriptions-item label="邀请码" :span="2">
                <el-tag>{{ team.inviteCode }}</el-tag>
                <el-button text type="primary" size="small" style="margin-left: 8px" @click="copyCode">复制</el-button>
              </el-descriptions-item>
              <el-descriptions-item label="描述" :span="2">{{ team.description || '暂无描述' }}</el-descriptions-item>
            </el-descriptions>
          </el-card>

          <!-- 贡献度柱状图 -->
          <el-card shadow="never" class="section-card">
            <template #header><span>成员贡献度</span></template>
            <v-chart :option="contributionOption" style="height: 300px" autoresize />
          </el-card>
        </el-col>

        <el-col :span="8">
          <!-- 成员列表 -->
          <el-card shadow="never" class="section-card">
            <template #header><span>成员列表</span></template>
            <div v-for="member in team.members" :key="member.userId" class="member-item">
              <el-avatar :size="36" :src="member.avatar">{{ member.realName?.charAt(0) }}</el-avatar>
              <div class="member-info">
                <span class="member-name">{{ member.realName }}
                  <el-tag v-if="member.role === 'LEADER'" type="warning" size="small">队长</el-tag>
                </span>
                <span class="member-join">加入时间：{{ formatDate(member.joinedAt) }}</span>
              </div>
            </div>
          </el-card>

          <!-- 任务完成进度 -->
          <el-card shadow="never" class="section-card" style="margin-top: 20px">
            <template #header><span>任务完成进度</span></template>
            <div v-for="(task, i) in tasks" :key="i" class="task-item">
              <div class="task-header">
                <span>{{ task.name }}</span>
                <span class="task-progress">{{ task.completed }}/{{ task.total }}</span>
              </div>
              <el-progress :percentage="Math.round(task.completed / task.total * 100)" :stroke-width="8" />
            </div>
            <div v-if="tasks.length === 0" class="empty-tip">暂无任务</div>
          </el-card>
        </el-col>
      </el-row>
    </template>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import dayjs from 'dayjs'
import { ElMessage } from 'element-plus'
import * as teamApi from '@/api/team'
import type { Team } from '@/types'

const route = useRoute()
const teamId = Number(route.params.teamId)
const loading = ref(false)
const team = ref<Team | null>(null)

const tasks = ref([
  { name: '第一章练习', completed: 5, total: 5 },
  { name: '第二章练习', completed: 3, total: 6 },
  { name: '期中项目', completed: 1, total: 3 }
])

const contributionOption = computed(() => ({
  tooltip: { trigger: 'axis' },
  grid: { left: 80, right: 20, top: 20, bottom: 40 },
  xAxis: { type: 'value' },
  yAxis: { type: 'category', data: team.value?.members?.map(m => m.realName) || [] },
  series: [{
    type: 'bar',
    data: team.value?.members?.map(() => Math.floor(Math.random() * 50 + 10)) || [],
    itemStyle: { color: '#409eff', borderRadius: [0, 4, 4, 0] },
    barWidth: 24
  }]
}))

function formatDate(date: string) {
  return dayjs(date).format('YYYY-MM-DD')
}

function copyCode() {
  if (team.value?.inviteCode) {
    navigator.clipboard.writeText(team.value.inviteCode)
    ElMessage.success('邀请码已复制')
  }
}

onMounted(async () => {
  loading.value = true
  try {
    const res = await teamApi.getTeamDetail(teamId)
    team.value = res.data as unknown as Team
  } finally {
    loading.value = false
  }
})
</script>

<style scoped>
.section-card {
  border-radius: 12px;
  margin-bottom: 20px;
}

.member-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px 0;
  border-bottom: 1px solid #f0f0f0;
}

.member-item:last-child {
  border-bottom: none;
}

.member-info {
  flex: 1;
}

.member-name {
  display: block;
  font-size: 14px;
  font-weight: 500;
  color: #303133;
}

.member-join {
  font-size: 12px;
  color: #909399;
}

.task-item {
  margin-bottom: 16px;
}

.task-item:last-child {
  margin-bottom: 0;
}

.task-header {
  display: flex;
  justify-content: space-between;
  font-size: 13px;
  color: #303133;
  margin-bottom: 6px;
}

.task-progress {
  color: #909399;
}

.empty-tip {
  text-align: center;
  color: #909399;
  padding: 20px 0;
}
</style>
