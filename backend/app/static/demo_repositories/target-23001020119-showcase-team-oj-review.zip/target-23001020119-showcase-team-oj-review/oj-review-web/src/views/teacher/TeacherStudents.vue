<template>
  <div class="page-container">
    <div class="page-header"><h2>学生管理</h2></div>

    <el-card shadow="never" class="filter-card">
      <el-form :inline="true" :model="filterForm">
        <el-form-item label="课程">
          <el-select v-model="filterForm.courseId" placeholder="全部课程" clearable @change="fetchData" style="width:200px">
            <el-option v-for="c in courses" :key="c.id" :label="c.name" :value="c.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="搜索"><el-input v-model="filterForm.keyword" placeholder="姓名/学号" clearable @keyup.enter="fetchData" /></el-form-item>
        <el-form-item><el-button type="primary" @click="fetchData">查询</el-button></el-form-item>
      </el-form>
    </el-card>

    <el-card shadow="never" class="table-card">
      <el-table :data="students" v-loading="loading" stripe>
        <el-table-column prop="studentNo" label="学号" width="120" />
        <el-table-column prop="realName" label="姓名" width="120">
          <template #default="{ row }"><el-link type="primary" @click="$router.push(`/teacher/students/${row.userId}`)">{{ row.realName }}</el-link></template>
        </el-table-column>
        <el-table-column prop="username" label="用户名" width="120" />
        <el-table-column prop="progress" label="进度" width="160">
          <template #default="{ row }"><el-progress :percentage="row.progress" :stroke-width="6" /></template>
        </el-table-column>
        <el-table-column prop="score" label="分数" width="80" align="center">
          <template #default="{ row }"><span :style="{ color: row.score >= 60 ? '#67c23a' : '#f56c6c', fontWeight: 600 }">{{ row.score }}</span></template>
        </el-table-column>
        <el-table-column prop="lastActiveAt" label="最近活跃" width="170">
          <template #default="{ row }">{{ formatDate(row.lastActiveAt) }}</template>
        </el-table-column>
        <el-table-column prop="joinedAt" label="加入时间" width="170">
          <template #default="{ row }">{{ formatDate(row.joinedAt) }}</template>
        </el-table-column>
      </el-table>
      <div class="pagination-wrapper">
        <el-pagination v-model:current-page="currentPage" :page-size="pageSize" :total="total" layout="total, prev, pager, next" @current-change="fetchData" />
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import dayjs from 'dayjs'
import * as courseApi from '@/api/course'
import type { Course, CourseStudent } from '@/types'

const loading = ref(false)
const students = ref<CourseStudent[]>([])
const total = ref(0)
const currentPage = ref(1)
const pageSize = 20
const courses = ref<Course[]>([])
const filterForm = reactive({ courseId: undefined as number | undefined, keyword: '' })

function formatDate(d: string) { return d ? dayjs(d).format('YYYY-MM-DD HH:mm') : '-' }

async function fetchData() {
  if (!filterForm.courseId) { students.value = []; return }
  loading.value = true
  try {
    const res = await courseApi.getCourseStudents(filterForm.courseId, { page: currentPage.value, pageSize, keyword: filterForm.keyword || undefined })
    const data = res.data as unknown as { records: CourseStudent[]; total: number }
    students.value = data.records; total.value = data.total
  } finally { loading.value = false }
}

onMounted(async () => {
  try {
    const res = await courseApi.getCourseList({ page: 1, pageSize: 100 })
    courses.value = (res.data as unknown as { records: Course[] }).records
  } catch { /* ignore */ }
})
</script>

<style scoped>
.filter-card { margin-bottom: 20px; border-radius: 12px; }
.table-card { border-radius: 12px; }
.pagination-wrapper { display: flex; justify-content: flex-end; margin-top: 16px; }
</style>
