import router from '@/router'
import { useAuthStore } from '@/stores/auth'
import type { UserRole } from '@/types'

const publicPages = ['/login', '/register', '/403', '/404']

const roleHomeMap: Record<UserRole, string> = {
  STUDENT: '/student/dashboard',
  TEACHER: '/teacher/dashboard',
  ADMIN: '/admin/dashboard'
}

router.beforeEach((to, _from, next) => {
  const authStore = useAuthStore()
  const token = authStore.token
  const userRole = authStore.userInfo?.role

  // 设置页面标题
  const title = to.meta.title as string
  document.title = title ? `${title} - OJ Review` : 'OJ Review'

  // 公开页面直接放行
  if (to.meta.public || publicPages.includes(to.path)) {
    if (token && (to.path === '/login' || to.path === '/register')) {
      // 已登录用户访问登录/注册页，重定向到首页
      if (userRole) {
        return next(roleHomeMap[userRole])
      }
      return next('/login')
    }
    return next()
  }

  // 需要认证的页面
  if (!token) {
    return next({ path: '/login', query: { redirect: to.fullPath } })
  }

  // 角色权限校验
  const requiredRole = to.meta.role as UserRole | undefined
  if (requiredRole && userRole !== requiredRole) {
    // ADMIN 可以访问所有页面
    if (userRole === 'ADMIN') {
      return next()
    }
    return next('/403')
  }

  next()
})

router.afterEach(() => {
  // 可在此处添加页面加载完成逻辑（如 NProgress.done()）
})

export default router
