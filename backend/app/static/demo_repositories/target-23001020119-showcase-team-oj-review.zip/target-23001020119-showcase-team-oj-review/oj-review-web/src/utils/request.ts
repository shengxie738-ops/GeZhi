import axios from 'axios'
import type { AxiosInstance, AxiosRequestConfig, InternalAxiosRequestConfig, AxiosResponse } from 'axios'
import { ElMessage } from 'element-plus'
import router from '@/router'
import type { ApiResponse } from '@/types'

const service: AxiosInstance = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json'
  }
})

// 请求拦截器：注入 Token
service.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    const token = localStorage.getItem('token')
    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// 响应拦截器：统一错误处理
service.interceptors.response.use(
  (response: AxiosResponse<ApiResponse>) => {
    const res = response.data

    // 如果返回的是文件流（下载场景），直接返回
    if (response.config.responseType === 'blob') {
      return response
    }

    // 业务错误码处理
    if (res.code !== 200) {
      ElMessage.error(res.message || '请求失败')

      // Token 过期或未授权
      if (res.code === 401) {
        localStorage.removeItem('token')
        localStorage.removeItem('refreshToken')
        router.push('/login')
      }

      // 无权限
      if (res.code === 403) {
        router.push('/403')
      }

      return Promise.reject(new Error(res.message || '请求失败'))
    }

    return res as unknown as AxiosResponse
  },
  (error) => {
    let message = '网络异常，请稍后重试'

    if (error.response) {
      const status = error.response.status
      switch (status) {
        case 400:
          message = '请求参数错误'
          break
        case 401:
          message = '登录已过期，请重新登录'
          localStorage.removeItem('token')
          localStorage.removeItem('refreshToken')
          router.push('/login')
          break
        case 403:
          message = '没有权限访问该资源'
          router.push('/403')
          break
        case 404:
          message = '请求的资源不存在'
          break
        case 409:
          message = '数据冲突，请刷新后重试'
          break
        case 422:
          message = '数据校验失败'
          break
        case 429:
          message = '请求过于频繁，请稍后重试'
          break
        case 500:
          message = '服务器内部错误'
          break
        case 502:
          message = '网关错误'
          break
        case 503:
          message = '服务暂不可用'
          break
        default:
          message = `请求失败 (${status})`
      }
    } else if (error.code === 'ECONNABORTED') {
      message = '请求超时，请稍后重试'
    } else if (!window.navigator.onLine) {
      message = '网络连接已断开，请检查网络'
    }

    ElMessage.error(message)
    return Promise.reject(error)
  }
)

// 封装请求方法
export function get<T = unknown>(url: string, params?: Record<string, unknown>, config?: AxiosRequestConfig): Promise<ApiResponse<T>> {
  return service.get(url, { params, ...config }) as unknown as Promise<ApiResponse<T>>
}

export function post<T = unknown>(url: string, data?: unknown, config?: AxiosRequestConfig): Promise<ApiResponse<T>> {
  return service.post(url, data, config) as unknown as Promise<ApiResponse<T>>
}

export function put<T = unknown>(url: string, data?: unknown, config?: AxiosRequestConfig): Promise<ApiResponse<T>> {
  return service.put(url, data, config) as unknown as Promise<ApiResponse<T>>
}

export function del<T = unknown>(url: string, params?: Record<string, unknown>): Promise<ApiResponse<T>> {
  return service.delete(url, { params }) as unknown as Promise<ApiResponse<T>>
}

export function upload<T = unknown>(url: string, file: File, fieldName = 'file', extraData?: Record<string, unknown>): Promise<ApiResponse<T>> {
  const formData = new FormData()
  formData.append(fieldName, file)
  if (extraData) {
    Object.entries(extraData).forEach(([key, value]) => {
      formData.append(key, String(value))
    })
  }
  return service.post(url, formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  }) as unknown as Promise<ApiResponse<T>>
}

export default service
