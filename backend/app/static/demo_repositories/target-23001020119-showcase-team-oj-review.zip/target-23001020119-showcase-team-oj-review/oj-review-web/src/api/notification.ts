import { get, post, del } from '@/utils/request'
import type { Notification, NotificationQuery, PageResult } from '@/types'

/** 获取通知列表（分页） */
export function getNotificationList(params?: NotificationQuery) {
  return get<PageResult<Notification>>('/notifications', params as Record<string, unknown>)
}

/** 获取未读通知数量 */
export function getUnreadCount() {
  return get<{ count: number }>('/notifications/unread-count')
}

/** 获取通知详情 */
export function getNotificationDetail(notificationId: number) {
  return get<Notification>(`/notifications/${notificationId}`)
}

/** 标记单条通知已读 */
export function markAsRead(notificationId: number) {
  return post<void>(`/notifications/${notificationId}/read`)
}

/** 标记所有通知已读 */
export function markAllAsRead() {
  return post<void>('/notifications/read-all')
}

/** 删除通知 */
export function deleteNotification(notificationId: number) {
  return del<void>(`/notifications/${notificationId}`)
}

/** 批量删除通知 */
export function batchDeleteNotifications(notificationIds: number[]) {
  return del<void>('/notifications/batch', { ids: notificationIds.join(',') })
}

/** 获取最新通知（轮询用，返回最近10条） */
export function getLatestNotifications() {
  return get<Notification[]>('/notifications/latest')
}

/** 管理员：发送系统通知 */
export function sendSystemNotification(data: {
  title: string
  content: string
  targetRole?: string
  targetUserIds?: number[]
  courseId?: number
}) {
  return post<{ success: number; failed: number }>('/notifications/send', data)
}
