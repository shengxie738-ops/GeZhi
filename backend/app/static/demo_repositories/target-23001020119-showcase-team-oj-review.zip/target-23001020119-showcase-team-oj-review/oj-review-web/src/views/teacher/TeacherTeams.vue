<template>
  <div class="page-container">
    <div class="page-header">
      <h2>团队管理</h2>
      <div>
        <el-select v-model="selectedCourseId" placeholder="选择课程" style="width:200px;margin-right:12px" @change="fetchData">
          <el-option v-for="c in courses" :key="c.id" :label="c.name" :value="c.id" />
        </el-select>
        <el-button type="primary" @click="handleAutoAssign" :disabled="!selectedCourseId"><el-icon><MagicStick /></el-icon> 自动分组</el-button>
      </div>
    </div>

    <el-card shadow="never" class="table-card">
      <el-table :data="teams" v-loading="loading" stripe>
        <el-table-column prop="name" label="团队名称" min-width="160" />
        <el-table-column prop="leaderName" label="队长" width="120" />
        <el-table-column prop="memberCount" label="人数" width="100" align="center">
          <template #default="{ row }">{{ row.memberCount }}/{{ row.maxMembers }}</template>
        </el-table-column>
        <el-table-column prop="inviteCode" label="邀请码" width="140">
          <template #default="{ row }"><el-tag size="small">{{ row.inviteCode }}</el-tag></template>
        </el-table-column>
        <el-table-column prop="createdAt" label="创建时间" width="170">
          <template #default="{ row }">{{ formatDate(row.createdAt) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="160" align="center" fixed="right">
          <template #default="{ row }">
            <el-button text type="primary" size="small" @click="viewDetail(row)">详情</el-button>
            <el-button text type="danger" size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination-wrapper">
        <el-pagination v-model:current-page="currentPage" :page-size="pageSize" :total="total" layout="total, prev, pager, next" @current-change="fetchData" />
      </div>
    </el-card>

    <!-- 自动分组弹窗 -->
    <el-dialog v-model="autoDialogVisible" title="自动分组" width="400px" destroy-on-close>
      <el-form label-width="100px">
        <el-form-item label="每组人数"><el-input-number v-model="autoTeamSize" :min="2" :max="10" /></el-form-item>
        <el-form-item label="分组方式">
          <el-radio-group v-model="autoMethod">
            <el-radio value="random">随机</el-radio>
            <el-radio value="balanced">均衡</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="autoDialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="autoAssigning" @click="confirmAutoAssign">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import dayjs from 'dayjs'
import { ElMessage, ElMessageBox } from 'element-plus'
import * as teamApi from '@/api/team'
import * as courseApi from '@/api/course'
import type { Team, Course } from '@/types'

const loading = ref(false)
const teams = ref<Team[]>([])
const total = ref(0)
const currentPage = ref(1)
const pageSize = 20
const courses = ref<Course[]>([])
const selectedCourseId = ref<number>()
const autoDialogVisible = ref(false)
const autoTeamSize = ref(5)
const autoMethod = ref<'random' | 'balanced'>('random')
const autoAssigning = ref(false)

function formatDate(d: string) { return dayjs(d).format('YYYY-MM-DD HH:mm') }

function viewDetail(team: Team) { ElMessage.info(`查看团队：${team.name}`) }

async function fetchData() {
  if (!selectedCourseId.value) return
  loading.value = true
  try {
    const res = await teamApi.getTeamsByCourse(selectedCourseId.value, { page: currentPage.value, pageSize })
    const data = res.data as unknown as { records: Team[]; total: number }
    teams.value = data.records; total.value = data.total
  } finally { loading.value = false }
}

function handleAutoAssign() { autoDialogVisible.value = true }

async function confirmAutoAssign() {
  if (!selectedCourseId.value) return
  autoAssigning.value = true
  try {
    await teamApi.autoAssignTeams(selectedCourseId.value, { teamSize: autoTeamSize.value, method: autoMethod.value })
    ElMessage.success('自动分组完成')
    autoDialogVisible.value = false
    fetchData()
  } catch { ElMessage.error('自动分组失败') } finally { autoAssigning.value = false }
}

async function handleDelete(team: Team) {
  await ElMessageBox.confirm(`确定删除团队「${team.name}」？`, '警告', { type: 'warning' })
  try { await teamApi.deleteTeam(team.id); ElMessage.success('删除成功'); fetchData() } catch { ElMessage.error('删除失败') }
}

onMounted(async () => {
  try {
    const res = await courseApi.getCourseList({ page: 1, pageSize: 100 })
    courses.value = (res.data as unknown as { records: Course[] }).records
    if (courses.value.length) { selectedCourseId.value = courses.value[0].id; fetchData() }
  } catch { /* ignore */ }
})
</script>

<style scoped>
.table-card { border-radius: 12px; }
.pagination-wrapper { display: flex; justify-content: flex-end; margin-top: 16px; }
</style>
