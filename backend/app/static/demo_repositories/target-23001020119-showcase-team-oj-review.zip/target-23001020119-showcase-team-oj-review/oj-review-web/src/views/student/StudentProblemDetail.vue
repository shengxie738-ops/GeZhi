<template>
  <div class="problem-page" v-loading="loading">
    <div class="problem-layout">
      <!-- 左侧：题目描述 -->
      <div class="problem-left">
        <el-card shadow="never" class="problem-card">
          <template #header>
            <div class="problem-header">
              <div class="problem-title-row">
                <h2>{{ problem?.title }}</h2>
                <el-tag v-if="problem" :type="getDifficultyType(problem.difficulty)" size="small">
                  {{ getDifficultyLabel(problem.difficulty) }}
                </el-tag>
              </div>
              <div class="problem-meta">
                <span>时间限制：{{ problem?.timeLimit }}ms</span>
                <span>内存限制：{{ problem?.memoryLimit }}MB</span>
                <span>提交次数：{{ problem?.totalSubmitCount }}</span>
                <span>通过率：{{ problem?.acceptanceRate }}%</span>
              </div>
            </div>
          </template>

          <!-- 题目内容标签页 -->
          <el-tabs v-model="activeTab">
            <el-tab-pane label="题目描述" name="description">
              <div class="problem-content">
                <div class="section">
                  <h3>题目描述</h3>
                  <div class="markdown-body" v-html="problem?.description"></div>
                </div>
                <div class="section">
                  <h3>输入格式</h3>
                  <div class="markdown-body" v-html="problem?.inputDescription"></div>
                </div>
                <div class="section">
                  <h3>输出格式</h3>
                  <div class="markdown-body" v-html="problem?.outputDescription"></div>
                </div>

                <!-- 公开样例 -->
                <div v-for="(sample, index) in problem?.samples" :key="index" class="section">
                  <h3>样例 {{ index + 1 }}</h3>
                  <div class="sample-box">
                    <div class="sample-part">
                      <div class="sample-label">输入</div>
                      <pre class="sample-content">{{ sample.input }}</pre>
                    </div>
                    <div class="sample-part">
                      <div class="sample-label">输出</div>
                      <pre class="sample-content">{{ sample.output }}</pre>
                    </div>
                    <div v-if="sample.explanation" class="sample-part">
                      <div class="sample-label">解释</div>
                      <div class="sample-content">{{ sample.explanation }}</div>
                    </div>
                  </div>
                </div>

                <div v-if="problem?.hint" class="section">
                  <h3>提示</h3>
                  <div class="markdown-body" v-html="problem.hint"></div>
                </div>

                <div v-if="problem?.tags?.length" class="section">
                  <h3>知识点</h3>
                  <el-tag v-for="tag in problem.tags" :key="tag" class="tag-item">{{ tag }}</el-tag>
                </div>
              </div>
            </el-tab-pane>

            <el-tab-pane label="提交记录" name="history">
              <el-table :data="submissionHistory" stripe>
                <el-table-column prop="id" label="编号" width="80" />
                <el-table-column prop="language" label="语言" width="100" />
                <el-table-column prop="status" label="状态" width="140">
                  <template #default="{ row }">
                    <el-tag :type="getStatusType(row.status)" size="small">{{ getStatusLabel(row.status) }}</el-tag>
                  </template>
                </el-table-column>
                <el-table-column prop="score" label="分数" width="80" align="center" />
                <el-table-column prop="timeUsed" label="耗时" width="100">
                  <template #default="{ row }">{{ row.timeUsed }}ms</template>
                </el-table-column>
                <el-table-column prop="createdAt" label="提交时间" min-width="170">
                  <template #default="{ row }">{{ formatDate(row.createdAt) }}</template>
                </el-table-column>
                <el-table-column label="操作" width="80" align="center">
                  <template #default="{ row }">
                    <el-button text type="primary" size="small" @click="$router.push(`/student/submissions/${row.id}`)">查看</el-button>
                  </template>
                </el-table-column>
              </el-table>
            </el-tab-pane>
          </el-tabs>
        </el-card>
      </div>

      <!-- 右侧：代码编辑器 -->
      <div class="problem-right">
        <el-card shadow="never" class="editor-card">
          <template #header>
            <div class="editor-header">
              <el-select v-model="language" size="small" style="width: 140px">
                <el-option label="C++" value="cpp" />
                <el-option label="Java" value="java" />
                <el-option label="Python" value="python" />
                <el-option label="JavaScript" value="javascript" />
                <el-option label="Go" value="go" />
              </el-select>
              <div class="editor-actions">
                <el-select v-model="editorTheme" size="small" style="width: 120px">
                  <el-option label="浅色主题" value="light" />
                  <el-option label="深色主题" value="vs-dark" />
                </el-select>
                <el-select v-model="fontSize" size="small" style="width: 90px">
                  <el-option v-for="s in [12, 14, 16, 18, 20]" :key="s" :label="`${s}px`" :value="s" />
                </el-select>
              </div>
            </div>
          </template>

          <!-- Monaco Editor 区域 -->
          <div ref="editorContainer" class="editor-container"></div>

          <!-- 底部按钮 -->
          <div class="editor-footer">
            <el-button @click="handleReset">
              <el-icon><RefreshLeft /></el-icon> 重置
            </el-button>
            <el-button type="warning" @click="handleRunSample" :loading="running">
              <el-icon><CaretRight /></el-icon> 运行样例
            </el-button>
            <el-button type="primary" @click="handleSubmit" :loading="submitting">
              <el-icon><Upload /></el-icon> 提交代码
            </el-button>
          </div>
        </el-card>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onBeforeUnmount, watch, nextTick } from 'vue'
import { useRoute } from 'vue-router'
import dayjs from 'dayjs'
import { ElMessage } from 'element-plus'
import * as problemApi from '@/api/problem'
import * as submissionApi from '@/api/submission'
import type { Problem, Submission } from '@/types'

const route = useRoute()
const problemId = Number(route.params.problemId)

const loading = ref(false)
const problem = ref<Problem | null>(null)
const activeTab = ref('description')
const language = ref('cpp')
const editorTheme = ref('vs-dark')
const fontSize = ref(14)
const code = ref('')
const running = ref(false)
const submitting = ref(false)
const submissionHistory = ref<Submission[]>([])
const editorContainer = ref<HTMLElement>()
let editor: { dispose: () => void } | null = null

const defaultCode: Record<string, string> = {
  cpp: '#include <iostream>\nusing namespace std;\n\nint main() {\n    // 在此编写代码\n    return 0;\n}',
  java: 'public class Main {\n    public static void main(String[] args) {\n        // 在此编写代码\n    }\n}',
  python: '# 在此编写代码\n',
  javascript: '// 在此编写代码\n',
  go: 'package main\n\nimport "fmt"\n\nfunc main() {\n    // 在此编写代码\n}'
}

function getDifficultyType(d: string) {
  const map: Record<string, string> = { EASY: 'success', MEDIUM: 'warning', HARD: 'danger' }
  return (map[d] || 'info') as 'success' | 'warning' | 'danger' | 'info'
}

function getDifficultyLabel(d: string) {
  const map: Record<string, string> = { EASY: '简单', MEDIUM: '中等', HARD: '困难' }
  return map[d] || d
}

function getStatusType(status: string) {
  const map: Record<string, string> = {
    ACCEPTED: 'success', WRONG_ANSWER: 'danger', PENDING: 'warning', JUDGING: '',
    TIME_LIMIT_EXCEEDED: 'danger', MEMORY_LIMIT_EXCEEDED: 'danger',
    RUNTIME_ERROR: 'danger', COMPILE_ERROR: 'danger', SYSTEM_ERROR: 'info'
  }
  return (map[status] || 'info') as 'success' | 'danger' | 'warning' | 'info' | ''
}

function getStatusLabel(status: string) {
  const map: Record<string, string> = {
    ACCEPTED: '通过', WRONG_ANSWER: '答案错误', PENDING: '等待中', JUDGING: '评测中',
    TIME_LIMIT_EXCEEDED: '超时', MEMORY_LIMIT_EXCEEDED: '内存超限',
    RUNTIME_ERROR: '运行错误', COMPILE_ERROR: '编译错误', SYSTEM_ERROR: '系统错误'
  }
  return map[status] || status
}

function formatDate(date: string) {
  return dayjs(date).format('MM-DD HH:mm')
}

async function initEditor() {
  if (!editorContainer.value) return
  try {
    const monaco = await import('@monaco-editor/loader')
    const loader = monaco.default || monaco
    const monacoEditor = await (loader as unknown as { init: () => Promise<unknown> }).init()
    const m = monacoEditor as {
      editor: {
        create: (el: HTMLElement, opts: Record<string, unknown>) => { dispose: () => void; getValue: () => string; setValue: (v: string) => void }
      }
    }
    editor = m.editor.create(editorContainer.value, {
      value: code.value || defaultCode[language.value] || '',
      language: language.value,
      theme: editorTheme.value,
      fontSize: fontSize.value,
      minimap: { enabled: false },
      automaticLayout: true,
      scrollBeyondLastLine: false,
      lineNumbers: 'on',
      tabSize: 4
    })
  } catch {
    // Monaco Editor 加载失败时的后备
    if (editorContainer.value) {
      editorContainer.value.innerHTML = '<textarea style="width:100%;height:100%;font-family:monospace;font-size:14px;padding:12px;border:none;resize:none;outline:none" placeholder="代码编辑器加载中..."></textarea>'
    }
  }
}

function handleReset() {
  code.value = defaultCode[language.value] || ''
}

async function handleRunSample() {
  running.value = true
  try {
    ElMessage.info('正在运行样例...')
    // 实际调用后端运行样例接口
    await new Promise(resolve => setTimeout(resolve, 1000))
    ElMessage.success('样例运行通过')
  } finally {
    running.value = false
  }
}

async function handleSubmit() {
  if (!code.value.trim()) {
    ElMessage.warning('请先编写代码')
    return
  }
  submitting.value = true
  try {
    await submissionApi.submitCode({
      problemId,
      language: language.value,
      code: code.value
    })
    ElMessage.success('代码提交成功')
    activeTab.value = 'history'
    fetchHistory()
  } catch {
    ElMessage.error('提交失败')
  } finally {
    submitting.value = false
  }
}

async function fetchHistory() {
  try {
    const res = await submissionApi.getProblemSubmissionHistory(problemId, { page: 1, pageSize: 20 })
    submissionHistory.value = (res.data as unknown as { records: Submission[] }).records
  } catch { /* ignore */ }
}

watch(language, () => {
  code.value = defaultCode[language.value] || ''
})

onMounted(async () => {
  loading.value = true
  try {
    const res = await problemApi.getProblemDetail(problemId)
    problem.value = res.data as unknown as Problem
    code.value = defaultCode[language.value] || ''
    await nextTick()
    await initEditor()
    fetchHistory()
  } finally {
    loading.value = false
  }
})

onBeforeUnmount(() => {
  editor?.dispose()
})
</script>

<style scoped>
.problem-page {
  height: 100%;
}

.problem-layout {
  display: flex;
  gap: 16px;
  height: calc(100vh - var(--oj-header-height) - 40px);
}

.problem-left {
  flex: 1;
  min-width: 0;
  overflow-y: auto;
}

.problem-right {
  width: 48%;
  display: flex;
  flex-direction: column;
}

.problem-card {
  border-radius: 12px;
  height: 100%;
  display: flex;
  flex-direction: column;
}

.problem-card :deep(.el-card__body) {
  flex: 1;
  overflow-y: auto;
}

.problem-header {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.problem-title-row {
  display: flex;
  align-items: center;
  gap: 12px;
}

.problem-title-row h2 {
  font-size: 20px;
  font-weight: 600;
  color: #1d2129;
}

.problem-meta {
  display: flex;
  gap: 20px;
  font-size: 13px;
  color: #909399;
}

.problem-content .section {
  margin-bottom: 20px;
}

.problem-content h3 {
  font-size: 15px;
  font-weight: 600;
  color: #303133;
  margin-bottom: 8px;
  padding-bottom: 6px;
  border-bottom: 1px solid #f0f0f0;
}

.markdown-body {
  font-size: 14px;
  line-height: 1.8;
  color: #303133;
}

.sample-box {
  background: #f8f9fa;
  border-radius: 8px;
  padding: 12px;
}

.sample-part {
  margin-bottom: 8px;
}

.sample-part:last-child {
  margin-bottom: 0;
}

.sample-label {
  font-size: 12px;
  font-weight: 600;
  color: #909399;
  margin-bottom: 4px;
}

.sample-content {
  font-family: 'Courier New', monospace;
  font-size: 13px;
  background: #fff;
  padding: 8px 12px;
  border-radius: 4px;
  border: 1px solid #e4e7ed;
  white-space: pre-wrap;
  word-break: break-all;
}

.tag-item {
  margin-right: 6px;
  margin-bottom: 4px;
}

.editor-card {
  border-radius: 12px;
  flex: 1;
  display: flex;
  flex-direction: column;
}

.editor-card :deep(.el-card__body) {
  flex: 1;
  display: flex;
  flex-direction: column;
  padding: 0;
}

.editor-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.editor-actions {
  display: flex;
  gap: 8px;
}

.editor-container {
  flex: 1;
  min-height: 300px;
}

.editor-footer {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  padding: 12px 16px;
  border-top: 1px solid #f0f0f0;
}
</style>
