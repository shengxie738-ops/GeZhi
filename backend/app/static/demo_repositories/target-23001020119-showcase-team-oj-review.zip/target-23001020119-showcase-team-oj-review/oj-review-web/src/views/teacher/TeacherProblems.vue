<template>
  <div class="page-container">
    <div class="page-header">
      <h2>题库管理</h2>
      <el-button type="primary" @click="$router.push('/teacher/problems/create')"><el-icon><Plus /></el-icon> 创建题目</el-button>
    </div>

    <el-card shadow="never" class="filter-card">
      <el-form :inline="true" :model="filterForm">
        <el-form-item label="搜索"><el-input v-model="filterForm.keyword" placeholder="搜索题目" clearable prefix-icon="Search" @keyup.enter="fetchData" /></el-form-item>
        <el-form-item label="难度">
          <el-select v-model="filterForm.difficulty" placeholder="全部" clearable @change="fetchData">
            <el-option label="简单" value="EASY" /><el-option label="中等" value="MEDIUM" /><el-option label="困难" value="HARD" />
          </el-select>
        </el-form-item>
        <el-form-item><el-button type="primary" @click="fetchData">查询</el-button></el-form-item>
      </el-form>
    </el-card>

    <el-card shadow="never" class="table-card">
      <el-table :data="problems" v-loading="loading" stripe @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="50" />
        <el-table-column prop="id" label="编号" width="80" align="center" />
        <el-table-column prop="title" label="题目" min-width="220" />
        <el-table-column prop="difficulty" label="难度" width="100" align="center">
          <template #default="{ row }"><el-tag :type="diffType(row.difficulty)" size="small">{{ diffLabel(row.difficulty) }}</el-tag></template>
        </el-table-column>
        <el-table-column label="知识点" min-width="160">
          <template #default="{ row }"><el-tag v-for="t in row.tags?.slice(0,3)" :key="t" size="small" class="tag-item">{{ t }}</el-tag></template>
        </el-table-column>
        <el-table-column prop="totalSubmitCount" label="提交" width="80" align="center" />
        <el-table-column label="通过率" width="100" align="center"><template #default="{ row }">{{ row.acceptanceRate }}%</template></el-table-column>
        <el-table-column prop="isPublic" label="公开" width="80" align="center">
          <template #default="{ row }"><el-tag :type="row.isPublic ? 'success' : 'info'" size="small">{{ row.isPublic ? '是' : '否' }}</el-tag></template>
        </el-table-column>
        <el-table-column label="操作" width="160" align="center" fixed="right">
          <template #default="{ row }">
            <el-button text type="primary" size="small" @click="$router.push(`/teacher/problems/${row.id}/edit`)">编辑</el-button>
            <el-button text type="danger" size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="table-footer">
        <el-button type="danger" size="small" :disabled="selectedIds.length === 0" @click="handleBatchDelete">批量删除</el-button>
        <el-pagination v-model:current-page="currentPage" v-model:page-size="pageSize" :page-sizes="[20,50,100]" :total="total" layout="total, sizes, prev, pager, next, jumper" @size-change="fetchData" @current-change="fetchData" />
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import * as problemApi from '@/api/problem'
import type { Problem } from '@/types'

const loading = ref(false)
const problems = ref<Problem[]>([])
const total = ref(0)
const currentPage = ref(1)
const pageSize = ref(20)
const selectedIds = ref<number[]>([])
const filterForm = reactive({ keyword: '', difficulty: '' })

function diffType(d: string) { return ({ EASY: 'success', MEDIUM: 'warning', HARD: 'danger' }[d] || 'info') as 'success' | 'warning' | 'danger' | 'info' }
function diffLabel(d: string) { return ({ EASY: '简单', MEDIUM: '中等', HARD: '困难' }[d] || d) }

function handleSelectionChange(rows: Problem[]) { selectedIds.value = rows.map(r => r.id) }

async function fetchData() {
  loading.value = true
  try {
    const res = await problemApi.getProblemList({ page: currentPage.value, pageSize: pageSize.value, keyword: filterForm.keyword || undefined, difficulty: (filterForm.difficulty as 'EASY'|'MEDIUM'|'HARD') || undefined })
    const data = res.data as unknown as { records: Problem[]; total: number }
    problems.value = data.records; total.value = data.total
  } finally { loading.value = false }
}

async function handleDelete(problem: Problem) {
  await ElMessageBox.confirm(`确定删除题目「${problem.title}」？`, '警告', { type: 'warning' })
  try { await problemApi.deleteProblem(problem.id); ElMessage.success('删除成功'); fetchData() } catch { ElMessage.error('删除失败') }
}

async function handleBatchDelete() {
  await ElMessageBox.confirm(`确定删除选中的 ${selectedIds.value.length} 道题目？`, '警告', { type: 'warning' })
  try { await problemApi.batchDeleteProblems(selectedIds.value); ElMessage.success('批量删除成功'); fetchData() } catch { ElMessage.error('删除失败') }
}

onMounted(fetchData)
</script>

<style scoped>
.filter-card { margin-bottom: 20px; border-radius: 12px; }
.table-card { border-radius: 12px; }
.tag-item { margin-right: 4px; }
.table-footer { display: flex; align-items: center; justify-content: space-between; margin-top: 16px; }
</style>
