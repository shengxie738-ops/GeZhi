import { get, post } from '@/utils/request'
import type { LoginForm, RegisterForm, LoginResult, UserInfo } from '@/types'

/** 用户登录 */
export function login(data: LoginForm) {
  return post<LoginResult>('/auth/login', data)
}

/** 用户注册 */
export function register(data: RegisterForm) {
  return post<UserInfo>('/auth/register', data)
}

/** 用户登出 */
export function logout() {
  return post<void>('/auth/logout')
}

/** 刷新 Token */
export function refreshToken(data: { refreshToken: string }) {
  return post<{ token: string; refreshToken: string }>('/auth/refresh', data)
}

/** 获取当前用户信息 */
export function getCurrentUser() {
  return get<UserInfo>('/auth/me')
}

/** 修改密码 */
export function changePassword(data: { oldPassword: string; newPassword: string }) {
  return post<void>('/auth/change-password', data)
}

/** 发送邮箱验证码 */
export function sendVerifyCode(email: string) {
  return post<void>('/auth/send-code', { email })
}

/** 重置密码 */
export function resetPassword(data: { email: string; code: string; newPassword: string }) {
  return post<void>('/auth/reset-password', data)
}

/** 更新用户头像 */
export function updateAvatar(file: File) {
  const formData = new FormData()
  formData.append('avatar', file)
  return post<{ avatar: string }>('/auth/avatar', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  })
}

/** 更新个人资料 */
export function updateProfile(data: Partial<UserInfo>) {
  return post<UserInfo>('/auth/profile', data)
}
