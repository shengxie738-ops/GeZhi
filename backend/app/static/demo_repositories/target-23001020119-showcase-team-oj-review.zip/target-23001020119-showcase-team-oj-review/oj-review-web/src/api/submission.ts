import { get, post } from '@/utils/request'
import type {
  Submission,
  SubmissionForm,
  SubmissionQuery,
  JudgeResult,
  PageResult
} from '@/types'

/** 提交代码 */
export function submitCode(data: SubmissionForm) {
  return post<Submission>('/submissions', data)
}

/** 获取提交列表（分页） */
export function getSubmissionList(params?: SubmissionQuery) {
  return get<PageResult<Submission>>('/submissions', params as Record<string, unknown>)
}

/** 获取提交详情 */
export function getSubmissionDetail(submissionId: number) {
  return get<Submission>(`/submissions/${submissionId}`)
}

/** 获取评测结果详情（含测试用例） */
export function getJudgeResult(submissionId: number) {
  return get<JudgeResult>(`/submissions/${submissionId}/judge-result`)
}

/** 重新评测 */
export function rejudgeSubmission(submissionId: number) {
  return post<void>(`/submissions/${submissionId}/rejudge`)
}

/** 批量重新评测 */
export function batchRejudge(submissionIds: number[]) {
  return post<void>('/submissions/batch-rejudge', { submissionIds })
}

/** 获取用户对指定题目的提交历史 */
export function getProblemSubmissionHistory(problemId: number, params?: Record<string, unknown>) {
  return get<PageResult<Submission>>(`/submissions/problem/${problemId}/history`, params)
}

/** 获取提交统计（语言分布、状态分布等） */
export function getSubmissionStats(params?: Record<string, unknown>) {
  return get<Record<string, unknown>>('/submissions/stats', params)
}

/** 获取最新的评测队列状态 */
export function getJudgeQueueStatus() {
  return get<{
    pending: number
    judging: number
    avgWaitTime: number
    avgJudgeTime: number
  }>('/submissions/judge-queue')
}

/** 获取支持的编程语言列表 */
export function getSupportedLanguages() {
  return get<{ id: string; name: string; version: string }[]>('/submissions/languages')
}

/** 下载提交代码 */
export function downloadSubmissionCode(submissionId: number) {
  return get<Blob>(`/submissions/${submissionId}/download`, undefined, {
    responseType: 'blob'
  })
}
