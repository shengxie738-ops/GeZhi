<template>
  <div class="page-container">
    <div class="page-header">
      <h2>教学复盘</h2>
      <el-select v-model="selectedCourseId" placeholder="选择课程" style="width:200px" @change="fetchReviewData">
        <el-option v-for="c in courses" :key="c.id" :label="c.name" :value="c.id" />
      </el-select>
    </div>

    <!-- 概览 -->
    <el-row :gutter="20" class="stat-cards" v-if="reviewData">
      <el-col :span="4" v-for="(stat, i) in overviewCards" :key="i">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value" :style="{ color: stat.color }">{{ stat.value }}</div>
          <div class="stat-label">{{ stat.label }}</div>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="20">
      <!-- 题目通过率 -->
      <el-col :span="14">
        <el-card shadow="never" class="section-card">
          <template #header><span>题目通过率</span></template>
          <v-chart v-if="reviewData" :option="problemChartOption" style="height:400px" autoresize />
          <el-empty v-else description="请选择课程" />
        </el-card>
      </el-col>

      <!-- 学生排名 -->
      <el-col :span="10">
        <el-card shadow="never" class="section-card">
          <template #header><span>学生成绩排名</span></template>
          <el-table v-if="reviewData" :data="reviewData.studentStats" stripe size="small" max-height="400">
            <el-table-column type="index" label="排名" width="60" />
            <el-table-column prop="realName" label="姓名" width="100" />
            <el-table-column prop="submitCount" label="提交" width="70" align="center" />
            <el-table-column prop="solvedCount" label="解题" width="70" align="center" />
            <el-table-column prop="score" label="分数" width="70" align="center">
              <template #default="{ row }"><span :style="{ color: row.score >= 60 ? '#67c23a' : '#f56c6c', fontWeight: 600 }">{{ row.score }}</span></template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
    </el-row>

    <!-- 提交趋势 -->
    <el-card shadow="never" class="section-card" style="margin-top:20px" v-if="reviewData">
      <template #header><span>班级提交趋势</span></template>
      <v-chart :option="trendOption" style="height:300px" autoresize />
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import * as courseApi from '@/api/course'
import { get } from '@/utils/request'
import type { Course, ReviewData } from '@/types'

const courses = ref<Course[]>([])
const selectedCourseId = ref<number>()
const reviewData = ref<ReviewData | null>(null)

const overviewCards = computed(() => {
  if (!reviewData.value) return []
  const o = reviewData.value.overview
  return [
    { label: '总提交数', value: o.totalSubmissions, color: '#409eff' },
    { label: '学生总数', value: o.totalStudents, color: '#67c23a' },
    { label: '活跃学生', value: o.activeStudents, color: '#e6a23c' },
    { label: '平均分', value: o.averageScore, color: '#f56c6c' },
    { label: '完成率', value: o.completionRate + '%', color: '#764ba2' },
    { label: '课程', value: reviewData.value.courseName, color: '#909399' }
  ]
})

const problemChartOption = computed(() => {
  if (!reviewData.value) return {}
  const stats = reviewData.value.problemStats
  return {
    tooltip: { trigger: 'axis' },
    grid: { left: 120, right: 30, top: 20, bottom: 30 },
    xAxis: { type: 'value', max: 100, axisLabel: { formatter: '{value}%' } },
    yAxis: { type: 'category', data: stats.map(p => p.problemTitle), inverse: true },
    series: [
      { type: 'bar', data: stats.map(p => p.acceptanceRate), itemStyle: { color: '#409eff', borderRadius: [0, 4, 4, 0] }, barWidth: 20,
        label: { show: true, position: 'right', formatter: '{c}%' } }
    ]
  }
})

const trendOption = computed(() => {
  if (!reviewData.value) return {}
  // 使用提交趋势的模拟数据
  const days = ['03-01', '03-02', '03-03', '03-04', '03-05', '03-06', '03-07']
  return {
    tooltip: { trigger: 'axis' },
    grid: { left: 50, right: 20, top: 20, bottom: 30 },
    xAxis: { type: 'category', data: days },
    yAxis: { type: 'value' },
    series: [{ type: 'line', smooth: true, data: [45, 62, 38, 78, 55, 90, 72], areaStyle: { opacity: 0.15 }, itemStyle: { color: '#667eea' } }]
  }
})

async function fetchReviewData() {
  if (!selectedCourseId.value) return
  try {
    const res = await get<ReviewData>(`/courses/${selectedCourseId.value}/review`)
    reviewData.value = res.data as unknown as ReviewData
  } catch { /* ignore */ }
}

onMounted(async () => {
  try {
    const res = await courseApi.getCourseList({ page: 1, pageSize: 100 })
    courses.value = (res.data as unknown as { records: Course[] }).records
    if (courses.value.length) { selectedCourseId.value = courses.value[0].id; fetchReviewData() }
  } catch { /* ignore */ }
})
</script>

<style scoped>
.stat-cards { margin-bottom: 20px; }
.stat-card { border-radius: 12px; text-align: center; padding: 10px 0; }
.stat-value { font-size: 24px; font-weight: 700; }
.stat-label { font-size: 13px; color: #909399; margin-top: 4px; }
.section-card { border-radius: 12px; }
</style>
