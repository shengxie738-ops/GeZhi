<template>
  <div class="page-container">
    <div class="page-header"><h2>课程管理</h2></div>

    <el-card shadow="never" class="filter-card">
      <el-form :inline="true" :model="filterForm">
        <el-form-item label="搜索"><el-input v-model="filterForm.keyword" placeholder="课程名称" clearable @keyup.enter="fetchData" /></el-form-item>
        <el-form-item label="状态">
          <el-select v-model="filterForm.status" placeholder="全部" clearable @change="fetchData">
            <el-option label="草稿" value="DRAFT" /><el-option label="已发布" value="PUBLISHED" /><el-option label="已归档" value="ARCHIVED" />
          </el-select>
        </el-form-item>
        <el-form-item><el-button type="primary" @click="fetchData">查询</el-button></el-form-item>
      </el-form>
    </el-card>

    <el-card shadow="never" class="table-card">
      <el-table :data="courses" v-loading="loading" stripe>
        <el-table-column prop="id" label="ID" width="60" />
        <el-table-column prop="code" label="课程代码" width="120" />
        <el-table-column prop="name" label="课程名称" min-width="200" />
        <el-table-column prop="teacherName" label="教师" width="120" />
        <el-table-column prop="semester" label="学期" width="120" />
        <el-table-column prop="studentCount" label="学生" width="80" align="center" />
        <el-table-column prop="problemCount" label="题目" width="80" align="center" />
        <el-table-column prop="status" label="状态" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="row.status === 'PUBLISHED' ? 'success' : row.status === 'DRAFT' ? 'warning' : 'info'" size="small">
              {{ row.status === 'PUBLISHED' ? '已发布' : row.status === 'DRAFT' ? '草稿' : '已归档' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="createdAt" label="创建时间" width="170">
          <template #default="{ row }">{{ formatDate(row.createdAt) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="120" align="center" fixed="right">
          <template #default="{ row }">
            <el-button text type="primary" size="small" @click="viewDetail(row)">详情</el-button>
            <el-button text type="danger" size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination-wrapper">
        <el-pagination v-model:current-page="currentPage" v-model:page-size="pageSize" :page-sizes="[20,50,100]" :total="total" layout="total, sizes, prev, pager, next, jumper" @size-change="fetchData" @current-change="fetchData" />
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import dayjs from 'dayjs'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useCourseStore } from '@/stores/course'
import type { Course } from '@/types'

const courseStore = useCourseStore()
const loading = ref(false)
const courses = ref<Course[]>([])
const total = ref(0)
const currentPage = ref(1)
const pageSize = ref(20)
const filterForm = reactive({ keyword: '', status: '' })

function formatDate(d: string) { return dayjs(d).format('YYYY-MM-DD HH:mm') }
function viewDetail(course: Course) { ElMessage.info(`课程详情：${course.name}`) }

async function fetchData() {
  loading.value = true
  try {
    await courseStore.fetchCourseList({ page: currentPage.value, pageSize: pageSize.value, keyword: filterForm.keyword || undefined, status: filterForm.status || undefined })
    courses.value = courseStore.courseList; total.value = courseStore.total
  } finally { loading.value = false }
}

async function handleDelete(course: Course) {
  await ElMessageBox.confirm(`确定删除课程「${course.name}」？`, '警告', { type: 'warning' })
  try { await courseStore.deleteCourse(course.id); ElMessage.success('删除成功') } catch { ElMessage.error('删除失败') }
}

onMounted(fetchData)
</script>

<style scoped>
.filter-card { margin-bottom: 20px; border-radius: 12px; }
.table-card { border-radius: 12px; }
.pagination-wrapper { display: flex; justify-content: flex-end; margin-top: 16px; }
</style>
