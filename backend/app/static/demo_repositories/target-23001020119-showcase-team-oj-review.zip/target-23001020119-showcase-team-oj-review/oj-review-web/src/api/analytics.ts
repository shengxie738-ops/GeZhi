import { get } from '@/utils/request'
import type {
  LearningOverview,
  DifficultyDistribution,
  TagStat,
  SubmissionTrend,
  CourseProgress,
  DailyActivity
} from '@/types'

/** 获取学习概览 */
export function getLearningOverview(courseId?: number) {
  return get<LearningOverview>('/analytics/overview', { courseId })
}

/** 获取难度分布 */
export function getDifficultyDistribution(courseId?: number) {
  return get<DifficultyDistribution>('/analytics/difficulty', { courseId })
}

/** 获取标签统计 */
export function getTagStats(courseId?: number) {
  return get<TagStat[]>('/analytics/tags', { courseId })
}

/** 获取提交趋势 */
export function getSubmissionTrend(params?: { days?: number; courseId?: number }) {
  return get<SubmissionTrend[]>('/analytics/submission-trend', params as Record<string, unknown>)
}

/** 获取课程进度 */
export function getCourseProgress() {
  return get<CourseProgress[]>('/analytics/course-progress')
}

/** 获取每日活跃热力图数据 */
export function getDailyActivity(year?: number) {
  return get<DailyActivity[]>('/analytics/daily-activity', { year })
}

/** 获取排名 */
export function getRanking(params?: { courseId?: number; page?: number; pageSize?: number }) {
  return get<{
    records: { userId: number; username: string; realName: string; score: number; solved: number; rank: number }[]
    total: number
    myRank: number
  }>('/analytics/ranking', params as Record<string, unknown>)
}

/** 获取弱项分析（哪些标签/难度做得差） */
export function getWeaknessAnalysis(courseId?: number) {
  return get<{
    weakTags: { tag: string; acceptanceRate: number; suggestedProblems: number[] }[]
    weakDifficulties: { difficulty: string; acceptanceRate: number }[]
    suggestions: string[]
  }>('/analytics/weakness', { courseId })
}

/** 获取学习时间分布 */
export function getTimeDistribution(courseId?: number) {
  return get<{ hour: number; count: number }[]>('/analytics/time-distribution', { courseId })
}
