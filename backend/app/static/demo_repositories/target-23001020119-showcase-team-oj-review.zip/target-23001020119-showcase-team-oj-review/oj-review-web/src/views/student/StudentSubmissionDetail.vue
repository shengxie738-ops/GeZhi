<template>
  <div class="page-container" v-loading="loading">
    <div class="page-header">
      <h2>提交详情 #{{ submission?.id }}</h2>
      <el-button @click="$router.back()">返回</el-button>
    </div>

    <template v-if="submission">
      <!-- 提交信息 -->
      <el-card shadow="never" class="info-card">
        <el-descriptions :column="4" border>
          <el-descriptions-item label="题目">
            <el-link type="primary" @click="$router.push(`/student/problems/${submission.problemId}`)">
              {{ submission.problemTitle }}
            </el-link>
          </el-descriptions-item>
          <el-descriptions-item label="状态">
            <el-tag :type="getStatusType(submission.status)" size="small">
              {{ getStatusLabel(submission.status) }}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="语言">{{ submission.language }}</el-descriptions-item>
          <el-descriptions-item label="分数">
            <span :style="{ color: submission.score >= 60 ? '#67c23a' : '#f56c6c', fontWeight: 700, fontSize: '16px' }">
              {{ submission.score }}
            </span>
          </el-descriptions-item>
          <el-descriptions-item label="耗时">{{ submission.timeUsed }}ms</el-descriptions-item>
          <el-descriptions-item label="内存">{{ formatMemory(submission.memoryUsed) }}</el-descriptions-item>
          <el-descriptions-item label="通过用例">{{ submission.testCasesPassed }} / {{ submission.testCasesTotal }}</el-descriptions-item>
          <el-descriptions-item label="提交时间">{{ formatDate(submission.createdAt) }}</el-descriptions-item>
        </el-descriptions>
      </el-card>

      <el-row :gutter="20">
        <!-- 代码展示 -->
        <el-col :span="14">
          <el-card shadow="never" class="section-card">
            <template #header>
              <div class="card-header">
                <span>提交代码</span>
                <el-button text type="primary" size="small" @click="copyCode">复制代码</el-button>
              </div>
            </template>
            <pre class="code-block"><code>{{ submission.code }}</code></pre>
          </el-card>
        </el-col>

        <!-- 测试点结果 -->
        <el-col :span="10">
          <el-card shadow="never" class="section-card">
            <template #header><span>测试点结果</span></template>
            <div v-if="judgeResult">
              <div v-for="(tc, index) in judgeResult.details" :key="index" class="testcase-item">
                <div class="testcase-header">
                  <span class="testcase-index">测试点 #{{ index + 1 }}</span>
                  <el-tag :type="getStatusType(tc.status)" size="small">{{ getStatusLabel(tc.status) }}</el-tag>
                </div>
                <div class="testcase-info">
                  <span>耗时：{{ tc.timeUsed }}ms</span>
                  <span>内存：{{ formatMemory(tc.memoryUsed) }}</span>
                </div>
              </div>
            </div>
            <div v-else class="empty-tip">暂无测试点信息</div>
          </el-card>

          <!-- 编译/运行输出 -->
          <el-card v-if="submission.errorMessage || submission.judgeInfo" shadow="never" class="section-card" style="margin-top: 20px">
            <template #header><span>输出信息</span></template>
            <div v-if="submission.errorMessage" class="error-output">
              <h4>错误信息</h4>
              <pre>{{ submission.errorMessage }}</pre>
            </div>
            <div v-if="submission.judgeInfo" class="judge-output">
              <h4>评测信息</h4>
              <pre>{{ submission.judgeInfo }}</pre>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </template>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import dayjs from 'dayjs'
import { ElMessage } from 'element-plus'
import * as submissionApi from '@/api/submission'
import type { Submission, JudgeResult } from '@/types'

const route = useRoute()
const submissionId = Number(route.params.submissionId)
const loading = ref(false)
const submission = ref<Submission | null>(null)
const judgeResult = ref<JudgeResult | null>(null)

function getStatusType(status: string) {
  const map: Record<string, string> = {
    ACCEPTED: 'success', WRONG_ANSWER: 'danger', PENDING: 'warning', JUDGING: '',
    TIME_LIMIT_EXCEEDED: 'danger', MEMORY_LIMIT_EXCEEDED: 'danger',
    RUNTIME_ERROR: 'danger', COMPILE_ERROR: 'danger', SYSTEM_ERROR: 'info'
  }
  return (map[status] || 'info') as 'success' | 'danger' | 'warning' | 'info' | ''
}

function getStatusLabel(status: string) {
  const map: Record<string, string> = {
    ACCEPTED: '通过', WRONG_ANSWER: '答案错误', PENDING: '等待中', JUDGING: '评测中',
    TIME_LIMIT_EXCEEDED: '超时', MEMORY_LIMIT_EXCEEDED: '内存超限',
    RUNTIME_ERROR: '运行错误', COMPILE_ERROR: '编译错误', SYSTEM_ERROR: '系统错误'
  }
  return map[status] || status
}

function formatMemory(bytes: number) {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`
}

function formatDate(date: string) {
  return dayjs(date).format('YYYY-MM-DD HH:mm:ss')
}

function copyCode() {
  if (submission.value?.code) {
    navigator.clipboard.writeText(submission.value.code)
    ElMessage.success('代码已复制到剪贴板')
  }
}

onMounted(async () => {
  loading.value = true
  try {
    const [subRes, judgeRes] = await Promise.allSettled([
      submissionApi.getSubmissionDetail(submissionId),
      submissionApi.getJudgeResult(submissionId)
    ])
    if (subRes.status === 'fulfilled') submission.value = subRes.value.data as unknown as Submission
    if (judgeRes.status === 'fulfilled') judgeResult.value = judgeRes.value.data as unknown as JudgeResult
  } finally {
    loading.value = false
  }
})
</script>

<style scoped>
.info-card {
  margin-bottom: 20px;
  border-radius: 12px;
}

.section-card {
  border-radius: 12px;
}

.card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.code-block {
  background: #1e1e1e;
  color: #d4d4d4;
  padding: 16px;
  border-radius: 8px;
  overflow-x: auto;
  font-family: 'Courier New', monospace;
  font-size: 13px;
  line-height: 1.6;
  max-height: 500px;
  overflow-y: auto;
}

.testcase-item {
  padding: 10px 0;
  border-bottom: 1px solid #f0f0f0;
}

.testcase-item:last-child {
  border-bottom: none;
}

.testcase-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 6px;
}

.testcase-index {
  font-weight: 600;
  font-size: 13px;
  color: #303133;
}

.testcase-info {
  display: flex;
  gap: 16px;
  font-size: 12px;
  color: #909399;
}

.error-output pre,
.judge-output pre {
  background: #f8f9fa;
  padding: 12px;
  border-radius: 6px;
  font-size: 13px;
  color: #f56c6c;
  overflow-x: auto;
  white-space: pre-wrap;
}

.judge-output pre {
  color: #303133;
}

.error-output h4,
.judge-output h4 {
  font-size: 13px;
  color: #606266;
  margin-bottom: 8px;
}

.empty-tip {
  text-align: center;
  color: #909399;
  padding: 20px 0;
}
</style>
