<template>
  <div class="page-container">
    <div class="page-header">
      <h2>系统设置</h2>
      <el-button type="primary" :loading="saving" @click="handleSave">保存设置</el-button>
    </div>

    <el-card shadow="never" class="form-card">
      <el-form ref="formRef" :model="settings" label-width="160px">
        <el-divider content-position="left">基本设置</el-divider>
        <el-form-item label="站点名称"><el-input v-model="settings.siteName" /></el-form-item>
        <el-form-item label="站点描述"><el-input v-model="settings.siteDescription" type="textarea" :rows="2" /></el-form-item>
        <el-form-item label="允许注册"><el-switch v-model="settings.allowRegister" /></el-form-item>
        <el-form-item label="默认角色">
          <el-select v-model="settings.defaultRole" style="width:200px">
            <el-option label="学生" value="STUDENT" /><el-option label="教师" value="TEACHER" />
          </el-select>
        </el-form-item>

        <el-divider content-position="left">上传与评测</el-divider>
        <el-form-item label="最大上传大小 (MB)"><el-input-number v-model="settings.maxUploadSize" :min="1" :max="100" /></el-form-item>
        <el-form-item label="提交频率限制 (秒)"><el-input-number v-model="settings.submissionRateLimit" :min="1" :max="60" /></el-form-item>
        <el-form-item label="评测超时 (秒)"><el-input-number v-model="settings.judgeTimeout" :min="5" :max="120" /></el-form-item>

        <el-divider content-position="left">邮件设置</el-divider>
        <el-row :gutter="16">
          <el-col :span="8"><el-form-item label="SMTP 主机"><el-input v-model="settings.smtpHost" /></el-form-item></el-col>
          <el-col :span="4"><el-form-item label="端口"><el-input-number v-model="settings.smtpPort" :min="1" :max="65535" style="width:100%" /></el-form-item></el-col>
          <el-col :span="6"><el-form-item label="用户名"><el-input v-model="settings.smtpUser" /></el-form-item></el-col>
          <el-col :span="6"><el-form-item label="发件人"><el-input v-model="settings.smtpFrom" /></el-form-item></el-col>
        </el-row>

        <el-divider content-position="left">维护模式</el-divider>
        <el-form-item label="维护模式"><el-switch v-model="settings.maintenanceMode" active-color="#f56c6c" /></el-form-item>
        <el-form-item label="维护提示"><el-input v-model="settings.maintenanceMessage" type="textarea" :rows="2" /></el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import type { FormInstance } from 'element-plus'
import { ElMessage } from 'element-plus'
import { get, put } from '@/utils/request'
import type { SystemSettings } from '@/types'

const formRef = ref<FormInstance>()
const saving = ref(false)

const settings = reactive<SystemSettings>({
  siteName: 'OJ Review', siteDescription: '在线评测与教学复盘平台', allowRegister: true,
  defaultRole: 'STUDENT', maxUploadSize: 10, submissionRateLimit: 5, judgeTimeout: 30,
  smtpHost: '', smtpPort: 465, smtpUser: '', smtpFrom: '',
  maintenanceMode: false, maintenanceMessage: '系统维护中，请稍后再试'
})

async function handleSave() {
  saving.value = true
  try {
    await put('/admin/settings', settings)
    ElMessage.success('设置已保存')
  } catch { ElMessage.error('保存失败') } finally { saving.value = false }
}

onMounted(async () => {
  try {
    const res = await get<SystemSettings>('/admin/settings')
    Object.assign(settings, res.data)
  } catch { /* ignore */ }
})
</script>

<style scoped>
.form-card { border-radius: 12px; max-width: 960px; }
</style>
