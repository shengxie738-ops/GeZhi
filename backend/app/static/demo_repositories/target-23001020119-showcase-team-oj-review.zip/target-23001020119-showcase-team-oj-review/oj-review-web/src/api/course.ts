import { get, post, put, del } from '@/utils/request'
import type { Course, CourseForm, CourseStudent, PageResult } from '@/types'

/** 获取课程列表（分页） */
export function getCourseList(params?: Record<string, unknown>) {
  return get<PageResult<Course>>('/courses', params)
}

/** 获取课程详情 */
export function getCourseDetail(courseId: number) {
  return get<Course>(`/courses/${courseId}`)
}

/** 创建课程 */
export function createCourse(data: CourseForm) {
  return post<Course>('/courses', data)
}

/** 更新课程 */
export function updateCourse(courseId: number, data: Partial<CourseForm>) {
  return put<Course>(`/courses/${courseId}`, data)
}

/** 删除课程 */
export function deleteCourse(courseId: number) {
  return del<void>(`/courses/${courseId}`)
}

/** 发布课程 */
export function publishCourse(courseId: number) {
  return post<void>(`/courses/${courseId}/publish`)
}

/** 归档课程 */
export function archiveCourse(courseId: number) {
  return post<void>(`/courses/${courseId}/archive`)
}

/** 获取课程学生列表 */
export function getCourseStudents(courseId: number, params?: Record<string, unknown>) {
  return get<PageResult<CourseStudent>>(`/courses/${courseId}/students`, params)
}

/** 移除课程学生 */
export function removeStudent(courseId: number, userId: number) {
  return del<void>(`/courses/${courseId}/students/${userId}`)
}

/** 学生加入课程 */
export function joinCourse(courseId: number, inviteCode?: string) {
  return post<void>(`/courses/${courseId}/join`, { inviteCode })
}

/** 获取学生已加入的课程列表 */
export function getEnrolledCourses() {
  return get<Course[]>('/courses/enrolled')
}

/** 获取课程邀请码 */
export function getInviteCode(courseId: number) {
  return get<{ inviteCode: string; expireAt: string }>(`/courses/${courseId}/invite-code`)
}

/** 重新生成课程邀请码 */
export function regenerateInviteCode(courseId: number) {
  return post<{ inviteCode: string; expireAt: string }>(`/courses/${courseId}/invite-code/regenerate`)
}

/** 批量导入学生 */
export function importStudents(courseId: number, file: File) {
  const formData = new FormData()
  formData.append('file', file)
  return post<{ success: number; failed: number; errors: string[] }>(
    `/courses/${courseId}/students/import`,
    formData,
    { headers: { 'Content-Type': 'multipart/form-data' } }
  )
}

/** 导出课程学生列表 */
export function exportStudents(courseId: number) {
  return get<Blob>(`/courses/${courseId}/students/export`, undefined, {
    responseType: 'blob'
  })
}

/** 获取课程统计概览 */
export function getCourseOverview(courseId: number) {
  return get<Record<string, unknown>>(`/courses/${courseId}/overview`)
}
