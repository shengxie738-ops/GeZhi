<template>
  <div class="page-container" v-loading="loading">
    <div class="page-header">
      <h2>学生详情</h2>
      <el-button @click="$router.back()">返回</el-button>
    </div>

    <template v-if="student">
      <el-row :gutter="20">
        <el-col :span="8">
          <el-card shadow="never" class="section-card">
            <template #header><span>基本信息</span></template>
            <div class="student-profile">
              <el-avatar :size="64">{{ student.realName?.charAt(0) }}</el-avatar>
              <h3>{{ student.realName }}</h3>
              <p class="student-no">{{ student.studentNo }}</p>
            </div>
            <el-descriptions :column="1" border size="small">
              <el-descriptions-item label="用户名">{{ student.username }}</el-descriptions-item>
              <el-descriptions-item label="进度"><el-progress :percentage="student.progress" :stroke-width="6" /></el-descriptions-item>
              <el-descriptions-item label="分数"><span :style="{ color: student.score >= 60 ? '#67c23a' : '#f56c6c', fontWeight: 700, fontSize: '18px' }">{{ student.score }}</span></el-descriptions-item>
              <el-descriptions-item label="加入时间">{{ formatDate(student.joinedAt) }}</el-descriptions-item>
            </el-descriptions>
          </el-card>
        </el-col>

        <el-col :span="16">
          <el-card shadow="never" class="section-card">
            <template #header><span>提交趋势</span></template>
            <v-chart :option="trendOption" style="height:260px" autoresize />
          </el-card>

          <el-card shadow="never" class="section-card" style="margin-top:20px">
            <template #header><span>最近提交</span></template>
            <el-table :data="submissions" stripe size="small">
              <el-table-column prop="problemTitle" label="题目" min-width="180" />
              <el-table-column prop="language" label="语言" width="100" />
              <el-table-column prop="status" label="状态" width="120">
                <template #default="{ row }"><el-tag :type="getStatusType(row.status)" size="small">{{ getStatusLabel(row.status) }}</el-tag></template>
              </el-table-column>
              <el-table-column prop="score" label="分数" width="70" align="center" />
              <el-table-column prop="createdAt" label="时间" width="160"><template #default="{ row }">{{ formatDate(row.createdAt) }}</template></el-table-column>
            </el-table>
          </el-card>
        </el-col>
      </el-row>
    </template>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import dayjs from 'dayjs'
import * as courseApi from '@/api/course'
import * as submissionApi from '@/api/submission'
import type { CourseStudent, Submission } from '@/types'

const route = useRoute()
const studentId = Number(route.params.studentId)
const loading = ref(false)
const student = ref<CourseStudent | null>(null)
const submissions = ref<Submission[]>([])

const trendOption = computed(() => ({
  tooltip: { trigger: 'axis' }, grid: { left: 50, right: 20, top: 20, bottom: 30 },
  xAxis: { type: 'category', data: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'] },
  yAxis: { type: 'value' },
  series: [
    { name: '提交数', type: 'line', smooth: true, data: [3, 5, 2, 8, 6, 4, 7], areaStyle: { opacity: 0.15 }, itemStyle: { color: '#409eff' } },
    { name: '通过数', type: 'line', smooth: true, data: [2, 4, 1, 6, 4, 3, 5], areaStyle: { opacity: 0.15 }, itemStyle: { color: '#67c23a' } }
  ]
}))

function getStatusType(s: string) { return ({ ACCEPTED: 'success', WRONG_ANSWER: 'danger', COMPILE_ERROR: 'danger' }[s] || 'info') as 'success'|'danger'|'warning'|'info'|'' }
function getStatusLabel(s: string) { return ({ ACCEPTED: '通过', WRONG_ANSWER: '答案错误', COMPILE_ERROR: '编译错误', RUNTIME_ERROR: '运行错误' }[s] || s) }
function formatDate(d: string) { return d ? dayjs(d).format('YYYY-MM-DD HH:mm') : '-' }

onMounted(async () => {
  loading.value = true
  try {
    const subRes = await submissionApi.getSubmissionList({ userId: studentId, page: 1, pageSize: 10 })
    submissions.value = (subRes.data as unknown as { records: Submission[] }).records
  } finally { loading.value = false }
})
</script>

<style scoped>
.section-card { border-radius: 12px; margin-bottom: 20px; }
.student-profile { text-align: center; padding: 20px 0; }
.student-profile h3 { margin: 12px 0 4px; font-size: 18px; color: #1d2129; }
.student-no { font-size: 13px; color: #909399; }
</style>
