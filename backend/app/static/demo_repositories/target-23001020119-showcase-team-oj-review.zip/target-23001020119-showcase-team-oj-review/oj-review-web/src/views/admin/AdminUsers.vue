<template>
  <div class="page-container">
    <div class="page-header">
      <h2>用户管理</h2>
      <el-button type="primary" @click="showCreateDialog = true"><el-icon><Plus /></el-icon> 添加用户</el-button>
    </div>

    <el-card shadow="never" class="filter-card">
      <el-form :inline="true" :model="filterForm">
        <el-form-item label="搜索"><el-input v-model="filterForm.keyword" placeholder="用户名/姓名" clearable @keyup.enter="fetchData" /></el-form-item>
        <el-form-item label="角色">
          <el-select v-model="filterForm.role" placeholder="全部" clearable @change="fetchData">
            <el-option label="学生" value="STUDENT" /><el-option label="教师" value="TEACHER" /><el-option label="管理员" value="ADMIN" />
          </el-select>
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="filterForm.status" placeholder="全部" clearable @change="fetchData">
            <el-option label="正常" :value="1" /><el-option label="禁用" :value="0" />
          </el-select>
        </el-form-item>
        <el-form-item><el-button type="primary" @click="fetchData">查询</el-button></el-form-item>
      </el-form>
    </el-card>

    <el-card shadow="never" class="table-card">
      <el-table :data="users" v-loading="loading" stripe>
        <el-table-column prop="id" label="ID" width="60" />
        <el-table-column prop="username" label="用户名" width="120" />
        <el-table-column prop="realName" label="姓名" width="100" />
        <el-table-column prop="email" label="邮箱" min-width="180" />
        <el-table-column prop="role" label="角色" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="row.role === 'ADMIN' ? 'danger' : row.role === 'TEACHER' ? 'warning' : ''" size="small">
              {{ row.role === 'ADMIN' ? '管理员' : row.role === 'TEACHER' ? '教师' : '学生' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="studentNo" label="学号/工号" width="120" />
        <el-table-column prop="status" label="状态" width="80" align="center">
          <template #default="{ row }"><el-tag :type="row.status === 1 ? 'success' : 'danger'" size="small">{{ row.status === 1 ? '正常' : '禁用' }}</el-tag></template>
        </el-table-column>
        <el-table-column prop="createdAt" label="注册时间" width="170">
          <template #default="{ row }">{{ formatDate(row.createdAt) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="200" align="center" fixed="right">
          <template #default="{ row }">
            <el-button text type="primary" size="small" @click="handleEdit(row)">编辑</el-button>
            <el-button text :type="row.status === 1 ? 'warning' : 'success'" size="small" @click="handleToggle(row)">{{ row.status === 1 ? '禁用' : '启用' }}</el-button>
            <el-button text type="danger" size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination-wrapper">
        <el-pagination v-model:current-page="currentPage" v-model:page-size="pageSize" :page-sizes="[20,50,100]" :total="total" layout="total, sizes, prev, pager, next, jumper" @size-change="fetchData" @current-change="fetchData" />
      </div>
    </el-card>

    <!-- 创建/编辑用户弹窗 -->
    <el-dialog v-model="showCreateDialog" :title="editingUser ? '编辑用户' : '添加用户'" width="600px" destroy-on-close>
      <el-form ref="formRef" :model="userForm" :rules="rules" label-width="100px">
        <el-row :gutter="16">
          <el-col :span="12"><el-form-item label="用户名" prop="username"><el-input v-model="userForm.username" :disabled="!!editingUser" /></el-form-item></el-col>
          <el-col :span="12"><el-form-item label="姓名" prop="realName"><el-input v-model="userForm.realName" /></el-form-item></el-col>
        </el-row>
        <el-row :gutter="16">
          <el-col :span="12"><el-form-item label="邮箱" prop="email"><el-input v-model="userForm.email" /></el-form-item></el-col>
          <el-col :span="12"><el-form-item label="手机号"><el-input v-model="userForm.phone" /></el-form-item></el-col>
        </el-row>
        <el-row :gutter="16">
          <el-col :span="12">
            <el-form-item label="角色" prop="role">
              <el-select v-model="userForm.role" style="width:100%">
                <el-option label="学生" value="STUDENT" /><el-option label="教师" value="TEACHER" /><el-option label="管理员" value="ADMIN" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12"><el-form-item label="学号/工号"><el-input v-model="userForm.studentNo" /></el-form-item></el-col>
        </el-row>
        <el-row :gutter="16">
          <el-col :span="12"><el-form-item label="学校"><el-input v-model="userForm.school" /></el-form-item></el-col>
          <el-col :span="12"><el-form-item label="院系"><el-input v-model="userForm.department" /></el-form-item></el-col>
        </el-row>
        <el-form-item v-if="!editingUser" label="密码" prop="password"><el-input v-model="userForm.password" type="password" show-password /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showCreateDialog = false">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="handleSubmit">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import type { FormInstance, FormRules } from 'element-plus'
import { ElMessage, ElMessageBox } from 'element-plus'
import dayjs from 'dayjs'
import { get, post, put, del } from '@/utils/request'
import type { UserInfo, UserForm, UserRole, PageResult } from '@/types'

const loading = ref(false)
const users = ref<UserInfo[]>([])
const total = ref(0)
const currentPage = ref(1)
const pageSize = ref(20)
const showCreateDialog = ref(false)
const submitting = ref(false)
const editingUser = ref<UserInfo | null>(null)
const formRef = ref<FormInstance>()
const filterForm = reactive({ keyword: '', role: '' as UserRole | '', status: undefined as number | undefined })

const userForm = reactive<UserForm & { password?: string }>({
  username: '', realName: '', email: '', phone: '', role: 'STUDENT',
  school: '', department: '', studentNo: '', password: ''
})

const rules: FormRules = {
  username: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
  realName: [{ required: true, message: '请输入姓名', trigger: 'blur' }],
  email: [{ required: true, message: '请输入邮箱', trigger: 'blur' }, { type: 'email', message: '邮箱格式不正确', trigger: 'blur' }],
  role: [{ required: true, message: '请选择角色', trigger: 'change' }],
  password: [{ required: true, message: '请输入密码', trigger: 'blur' }]
}

function formatDate(d: string) { return dayjs(d).format('YYYY-MM-DD HH:mm') }

function handleEdit(user: UserInfo) {
  editingUser.value = user
  Object.assign(userForm, { username: user.username, realName: user.realName, email: user.email, phone: user.phone, role: user.role, school: user.school, department: user.department, studentNo: user.studentNo })
  showCreateDialog.value = true
}

async function handleSubmit() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return
  submitting.value = true
  try {
    if (editingUser.value) {
      await put(`/admin/users/${editingUser.value.id}`, userForm)
      ElMessage.success('更新成功')
    } else {
      await post('/admin/users', userForm)
      ElMessage.success('创建成功')
    }
    showCreateDialog.value = false
    editingUser.value = null
    fetchData()
  } catch { ElMessage.error('操作失败') } finally { submitting.value = false }
}

async function handleToggle(user: UserInfo) {
  const action = user.status === 1 ? '禁用' : '启用'
  await ElMessageBox.confirm(`确定${action}用户「${user.realName}」？`, '确认')
  try {
    await put(`/admin/users/${user.id}/status`, { status: user.status === 1 ? 0 : 1 })
    ElMessage.success(`${action}成功`)
    fetchData()
  } catch { ElMessage.error('操作失败') }
}

async function handleDelete(user: UserInfo) {
  await ElMessageBox.confirm(`确定删除用户「${user.realName}」？`, '警告', { type: 'warning' })
  try { await del(`/admin/users/${user.id}`); ElMessage.success('删除成功'); fetchData() } catch { ElMessage.error('删除失败') }
}

async function fetchData() {
  loading.value = true
  try {
    const res = await get<PageResult<UserInfo>>('/admin/users', { page: currentPage.value, pageSize: pageSize.value, keyword: filterForm.keyword || undefined, role: filterForm.role || undefined, status: filterForm.status })
    const data = res.data as unknown as PageResult<UserInfo>
    users.value = data.records; total.value = data.total
  } finally { loading.value = false }
}

onMounted(fetchData)
</script>

<style scoped>
.filter-card { margin-bottom: 20px; border-radius: 12px; }
.table-card { border-radius: 12px; }
.pagination-wrapper { display: flex; justify-content: flex-end; margin-top: 16px; }
</style>
