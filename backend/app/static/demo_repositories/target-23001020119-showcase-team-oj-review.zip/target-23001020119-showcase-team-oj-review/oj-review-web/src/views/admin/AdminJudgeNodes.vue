<template>
  <div class="page-container">
    <div class="page-header">
      <h2>评测节点</h2>
      <el-button type="primary" @click="fetchData"><el-icon><Refresh /></el-icon> 刷新</el-button>
    </div>

    <el-row :gutter="20" class="stat-row">
      <el-col :span="8">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value" style="color:#67c23a">{{ onlineCount }}</div>
          <div class="stat-label">在线节点</div>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value" style="color:#e6a23c">{{ totalCurrentTask }}/{{ totalMaxTask }}</div>
          <div class="stat-label">当前任务/最大任务</div>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value" style="color:#409eff">{{ totalJudged }}</div>
          <div class="stat-label">总评测次数</div>
        </el-card>
      </el-col>
    </el-row>

    <el-card shadow="never" class="table-card">
      <el-table :data="nodes" v-loading="loading" stripe>
        <el-table-column prop="name" label="节点名称" width="150" />
        <el-table-column prop="host" label="地址" width="160"><template #default="{ row }">{{ row.host }}:{{ row.port }}</template></el-table-column>
        <el-table-column prop="status" label="状态" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="row.status === 'ONLINE' ? 'success' : row.status === 'BUSY' ? 'warning' : 'danger'" size="small">
              {{ row.status === 'ONLINE' ? '在线' : row.status === 'BUSY' ? '繁忙' : '离线' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="CPU" width="160">
          <template #default="{ row }"><el-progress :percentage="row.cpuUsage" :stroke-width="8" :color="row.cpuUsage > 80 ? '#f56c6c' : '#409eff'" /></template>
        </el-table-column>
        <el-table-column label="内存" width="160">
          <template #default="{ row }"><el-progress :percentage="row.memoryUsage" :stroke-width="8" :color="row.memoryUsage > 80 ? '#f56c6c' : '#67c23a'" /></template>
        </el-table-column>
        <el-table-column label="任务" width="120" align="center"><template #default="{ row }">{{ row.currentTask }}/{{ row.maxTask }}</template></el-table-column>
        <el-table-column prop="totalJudged" label="已评测" width="100" align="center" />
        <el-table-column prop="lastHeartbeat" label="最后心跳" width="170">
          <template #default="{ row }">{{ formatDate(row.lastHeartbeat) }}</template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import dayjs from 'dayjs'
import { get } from '@/utils/request'
import type { JudgeNode } from '@/types'

const loading = ref(false)
const nodes = ref<JudgeNode[]>([])

const onlineCount = computed(() => nodes.value.filter(n => n.status === 'ONLINE').length)
const totalCurrentTask = computed(() => nodes.value.reduce((s, n) => s + n.currentTask, 0))
const totalMaxTask = computed(() => nodes.value.reduce((s, n) => s + n.maxTask, 0))
const totalJudged = computed(() => nodes.value.reduce((s, n) => s + n.totalJudged, 0))

function formatDate(d: string) { return dayjs(d).format('YYYY-MM-DD HH:mm:ss') }

async function fetchData() {
  loading.value = true
  try {
    const res = await get<JudgeNode[]>('/admin/judge-nodes')
    nodes.value = res.data as unknown as JudgeNode[]
  } catch { /* ignore */ } finally { loading.value = false }
}

onMounted(fetchData)
</script>

<style scoped>
.stat-row { margin-bottom: 20px; }
.stat-card { border-radius: 12px; text-align: center; padding: 10px 0; }
.stat-value { font-size: 28px; font-weight: 700; }
.stat-label { font-size: 13px; color: #909399; margin-top: 4px; }
.table-card { border-radius: 12px; }
</style>
