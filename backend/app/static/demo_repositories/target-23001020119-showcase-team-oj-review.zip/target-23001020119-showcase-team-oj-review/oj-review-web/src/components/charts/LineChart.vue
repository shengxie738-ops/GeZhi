<template>
  <v-chart :option="chartOption" :style="{ height: height }" autoresize />
</template>

<script setup lang="ts">
import { computed } from 'vue'

const props = withDefaults(defineProps<{
  title?: string
  xData: string[]
  series: { name: string; data: number[]; color?: string }[]
  height?: string
  smooth?: boolean
}>(), {
  height: '320px',
  smooth: true
})

const chartOption = computed(() => ({
  title: props.title ? { text: props.title, left: 'center', textStyle: { fontSize: 14 } } : undefined,
  tooltip: { trigger: 'axis' },
  legend: props.series.length > 1 ? { data: props.series.map(s => s.name), bottom: 0 } : undefined,
  grid: { left: 50, right: 20, top: props.title ? 40 : 20, bottom: props.series.length > 1 ? 40 : 20 },
  xAxis: { type: 'category', data: props.xData, boundaryGap: false },
  yAxis: { type: 'value' },
  series: props.series.map(s => ({
    name: s.name,
    type: 'line',
    smooth: props.smooth,
    data: s.data,
    areaStyle: { opacity: 0.15 },
    itemStyle: s.color ? { color: s.color } : undefined
  }))
}))
</script>
