<template>
  <div class="page-container">
    <el-card class="welcome-card" shadow="never">
      <div class="welcome-content">
        <div>
          <h2>管理控制台</h2>
          <p>系统运行状态一览</p>
        </div>
      </div>
    </el-card>

    <el-row :gutter="20" class="stat-cards">
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-card-content">
            <div class="stat-icon" style="background:rgba(64,158,255,0.1);color:#409eff"><el-icon :size="28"><User /></el-icon></div>
            <div class="stat-info"><span class="stat-number">{{ stats.userCount }}</span><span class="stat-desc">用户总数</span></div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-card-content">
            <div class="stat-icon" style="background:rgba(103,194,58,0.1);color:#67c23a"><el-icon :size="28"><Reading /></el-icon></div>
            <div class="stat-info"><span class="stat-number">{{ stats.courseCount }}</span><span class="stat-desc">课程总数</span></div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-card-content">
            <div class="stat-icon" style="background:rgba(230,162,60,0.1);color:#e6a23c"><el-icon :size="28"><Document /></el-icon></div>
            <div class="stat-info"><span class="stat-number">{{ stats.submissionCount }}</span><span class="stat-desc">提交总数</span></div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-card-content">
            <div class="stat-icon" style="background:rgba(245,108,108,0.1);color:#f56c6c"><el-icon :size="28"><EditPen /></el-icon></div>
            <div class="stat-info"><span class="stat-number">{{ stats.problemCount }}</span><span class="stat-desc">题目总数</span></div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="20">
      <el-col :span="14">
        <el-card shadow="never" class="section-card">
          <template #header><span>用户增长趋势</span></template>
          <v-chart :option="userTrendOption" style="height:320px" autoresize />
        </el-card>
      </el-col>
      <el-col :span="10">
        <el-card shadow="never" class="section-card">
          <template #header><span>用户角色分布</span></template>
          <v-chart :option="rolePieOption" style="height:320px" autoresize />
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { get } from '@/utils/request'

const stats = ref({ userCount: 0, courseCount: 0, submissionCount: 0, problemCount: 0 })

const userTrendOption = computed(() => ({
  tooltip: { trigger: 'axis' },
  grid: { left: 50, right: 20, top: 20, bottom: 30 },
  xAxis: { type: 'category', data: ['1月', '2月', '3月', '4月', '5月', '6月'] },
  yAxis: { type: 'value' },
  series: [{ type: 'line', smooth: true, data: [120, 200, 350, 420, 580, 720], areaStyle: { opacity: 0.15 }, itemStyle: { color: '#409eff' } }]
}))

const rolePieOption = computed(() => ({
  tooltip: { trigger: 'item', formatter: '{b}: {c} ({d}%)' },
  legend: { bottom: 0 },
  series: [{
    type: 'pie', radius: ['35%', '65%'],
    itemStyle: { borderRadius: 6, borderColor: '#fff', borderWidth: 2 },
    data: [
      { value: 500, name: '学生', itemStyle: { color: '#409eff' } },
      { value: 50, name: '教师', itemStyle: { color: '#67c23a' } },
      { value: 5, name: '管理员', itemStyle: { color: '#f56c6c' } }
    ]
  }]
}))

onMounted(async () => {
  try {
    const res = await get<Record<string, number>>('/admin/stats')
    stats.value = res.data as unknown as typeof stats.value
  } catch { /* ignore */ }
})
</script>

<style scoped>
.welcome-card { margin-bottom: 20px; border-radius: 12px; background: linear-gradient(135deg, #1d1e2c 0%, #2d3748 100%); border: none; }
.welcome-card :deep(.el-card__body) { color: #fff; }
.welcome-content h2 { font-size: 22px; font-weight: 600; margin-bottom: 6px; }
.welcome-content p { font-size: 14px; opacity: 0.85; }
.stat-cards { margin-bottom: 20px; }
.stat-card { border-radius: 12px; }
.stat-card-content { display: flex; align-items: center; gap: 16px; }
.stat-icon { width: 56px; height: 56px; border-radius: 12px; display: flex; align-items: center; justify-content: center; }
.stat-number { display: block; font-size: 24px; font-weight: 700; color: #1d2129; }
.stat-desc { font-size: 13px; color: #909399; }
.section-card { border-radius: 12px; }
</style>
