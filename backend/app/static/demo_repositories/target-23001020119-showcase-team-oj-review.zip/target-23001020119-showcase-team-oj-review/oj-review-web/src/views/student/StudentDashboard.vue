<template>
  <div class="page-container">
    <!-- 欢迎卡片 -->
    <el-card class="welcome-card" shadow="never">
      <div class="welcome-content">
        <div class="welcome-text">
          <h2>你好，{{ authStore.userName }} 👋</h2>
          <p>今天又是充满挑战的一天，继续保持学习的热情吧！</p>
        </div>
        <div class="welcome-stats">
          <div class="stat-item">
            <span class="stat-value">{{ overview.streak }}</span>
            <span class="stat-label">连续天数</span>
          </div>
          <div class="stat-item">
            <span class="stat-value">{{ overview.todaySolved }}</span>
            <span class="stat-label">今日解题</span>
          </div>
          <div class="stat-item">
            <span class="stat-value">{{ overview.ranking }}</span>
            <span class="stat-label">当前排名</span>
          </div>
        </div>
      </div>
    </el-card>

    <!-- 数据概览 -->
    <el-row :gutter="20" class="stat-cards">
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-card-content">
            <div class="stat-icon" style="background: rgba(64, 158, 255, 0.1); color: #409eff">
              <el-icon :size="28"><Reading /></el-icon>
            </div>
            <div class="stat-info">
              <span class="stat-number">{{ enrolledCourses.length }}</span>
              <span class="stat-desc">已加入课程</span>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-card-content">
            <div class="stat-icon" style="background: rgba(230, 162, 60, 0.1); color: #e6a23c">
              <el-icon :size="28"><EditPen /></el-icon>
            </div>
            <div class="stat-info">
              <span class="stat-number">{{ overview.totalProblems - overview.solvedProblems }}</span>
              <span class="stat-desc">待完成题目</span>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-card-content">
            <div class="stat-icon" style="background: rgba(245, 108, 108, 0.1); color: #f56c6c">
              <el-icon :size="28"><Notebook /></el-icon>
            </div>
            <div class="stat-info">
              <span class="stat-number">{{ wrongCount }}</span>
              <span class="stat-desc">错题数量</span>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-card-content">
            <div class="stat-icon" style="background: rgba(103, 194, 58, 0.1); color: #67c23a">
              <el-icon :size="28"><TrendCharts /></el-icon>
            </div>
            <div class="stat-info">
              <span class="stat-number">{{ overview.acceptanceRate }}%</span>
              <span class="stat-desc">通过率</span>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="20">
      <!-- 最近提交 -->
      <el-col :span="16">
        <el-card shadow="never" class="section-card">
          <template #header>
            <div class="card-header">
              <span>最近提交</span>
              <el-button text type="primary" @click="$router.push('/student/submissions')">查看全部</el-button>
            </div>
          </template>
          <el-table :data="recentSubmissions" stripe style="width: 100%">
            <el-table-column prop="problemTitle" label="题目" min-width="200" show-overflow-tooltip>
              <template #default="{ row }">
                <el-link type="primary" @click="$router.push(`/student/problems/${row.problemId}`)">
                  {{ row.problemTitle }}
                </el-link>
              </template>
            </el-table-column>
            <el-table-column prop="language" label="语言" width="100" />
            <el-table-column prop="status" label="状态" width="140">
              <template #default="{ row }">
                <el-tag :type="getStatusType(row.status)" size="small">{{ getStatusLabel(row.status) }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="score" label="分数" width="80" align="center" />
            <el-table-column prop="createdAt" label="提交时间" width="170">
              <template #default="{ row }">{{ formatDate(row.createdAt) }}</template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>

      <!-- 右侧面板 -->
      <el-col :span="8">
        <!-- 学习进度 -->
        <el-card shadow="never" class="section-card">
          <template #header><span>学习进度</span></template>
          <div class="progress-chart">
            <v-chart :option="progressChartOption" style="height: 220px" autoresize />
          </div>
        </el-card>

        <!-- 错题提醒 -->
        <el-card shadow="never" class="section-card" style="margin-top: 20px">
          <template #header>
            <div class="card-header">
              <span>错题提醒</span>
              <el-button text type="primary" @click="$router.push('/student/wrong-book')">查看全部</el-button>
            </div>
          </template>
          <div v-if="wrongItems.length === 0" class="empty-tip">暂无错题，继续保持！</div>
          <div v-for="item in wrongItems" :key="item.id" class="wrong-item">
            <div class="wrong-info">
              <el-link type="primary" @click="$router.push(`/student/problems/${item.problemId}`)">
                {{ item.problemTitle }}
              </el-link>
              <el-tag :type="getDifficultyType(item.problemDifficulty)" size="small">
                {{ getDifficultyLabel(item.problemDifficulty) }}
              </el-tag>
            </div>
            <span class="wrong-count">错误 {{ item.wrongCount }} 次</span>
          </div>
        </el-card>

        <!-- 通知摘要 -->
        <el-card shadow="never" class="section-card" style="margin-top: 20px">
          <template #header>
            <div class="card-header">
              <span>最新通知</span>
              <el-button text type="primary" @click="$router.push('/student/notifications')">查看全部</el-button>
            </div>
          </template>
          <div v-if="notifications.length === 0" class="empty-tip">暂无通知</div>
          <div v-for="n in notifications" :key="n.id" class="notify-item" :class="{ unread: !n.isRead }">
            <el-icon :size="16" :color="n.isRead ? '#c0c4cc' : '#409eff'"><Bell /></el-icon>
            <div class="notify-content">
              <span class="notify-title">{{ n.title }}</span>
              <span class="notify-time">{{ formatDate(n.createdAt) }}</span>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import dayjs from 'dayjs'
import { useAuthStore } from '@/stores/auth'
import { useNotificationStore } from '@/stores/notification'
import * as analyticsApi from '@/api/analytics'
import * as wrongBookApi from '@/api/wrongBook'
import * as submissionApi from '@/api/submission'
import * as courseApi from '@/api/course'
import type { Submission, WrongBookItem, Course, LearningOverview, Notification } from '@/types'

const authStore = useAuthStore()
const notificationStore = useNotificationStore()

const overview = ref<LearningOverview>({
  totalProblems: 0, solvedProblems: 0, acceptanceRate: 0,
  totalSubmissions: 0, acceptedSubmissions: 0, averageScore: 0,
  ranking: 0, totalStudents: 0, streak: 0, todaySolved: 0, weeklySolved: 0
})
const enrolledCourses = ref<Course[]>([])
const recentSubmissions = ref<Submission[]>([])
const wrongItems = ref<WrongBookItem[]>([])
const wrongCount = ref(0)
const notifications = ref<Notification[]>([])

const progressChartOption = computed(() => ({
  tooltip: { trigger: 'item', formatter: '{b}: {c} ({d}%)' },
  legend: { bottom: 0, textStyle: { fontSize: 12 } },
  series: [{
    type: 'pie',
    radius: ['45%', '70%'],
    avoidLabelOverlap: false,
    itemStyle: { borderRadius: 8, borderColor: '#fff', borderWidth: 2 },
    label: { show: true, position: 'center', fontSize: 16, fontWeight: 'bold',
      formatter: () => `${overview.value.solvedProblems}/${overview.value.totalProblems}` },
    data: [
      { value: overview.value.solvedProblems, name: '已解决', itemStyle: { color: '#67c23a' } },
      { value: overview.value.totalProblems - overview.value.solvedProblems, name: '未解决', itemStyle: { color: '#e4e7ed' } }
    ]
  }]
}))

function getStatusType(status: string) {
  const map: Record<string, string> = {
    ACCEPTED: 'success', WRONG_ANSWER: 'danger', PENDING: 'warning', JUDGING: '',
    TIME_LIMIT_EXCEEDED: 'danger', MEMORY_LIMIT_EXCEEDED: 'danger',
    RUNTIME_ERROR: 'danger', COMPILE_ERROR: 'danger', SYSTEM_ERROR: 'info'
  }
  return (map[status] || 'info') as 'success' | 'danger' | 'warning' | 'info' | ''
}

function getStatusLabel(status: string) {
  const map: Record<string, string> = {
    ACCEPTED: '通过', WRONG_ANSWER: '答案错误', PENDING: '等待中', JUDGING: '评测中',
    TIME_LIMIT_EXCEEDED: '超时', MEMORY_LIMIT_EXCEEDED: '内存超限',
    RUNTIME_ERROR: '运行错误', COMPILE_ERROR: '编译错误', SYSTEM_ERROR: '系统错误'
  }
  return map[status] || status
}

function getDifficultyType(d: string) {
  const map: Record<string, string> = { EASY: 'success', MEDIUM: 'warning', HARD: 'danger' }
  return (map[d] || 'info') as 'success' | 'warning' | 'danger' | 'info'
}

function getDifficultyLabel(d: string) {
  const map: Record<string, string> = { EASY: '简单', MEDIUM: '中等', HARD: '困难' }
  return map[d] || d
}

function formatDate(date: string) {
  return dayjs(date).format('MM-DD HH:mm')
}

onMounted(async () => {
  try {
    const [overviewRes, coursesRes, submissionsRes, wrongRes, wrongCountRes] = await Promise.allSettled([
      analyticsApi.getLearningOverview(),
      courseApi.getEnrolledCourses(),
      submissionApi.getSubmissionList({ page: 1, pageSize: 5 }),
      wrongBookApi.getWrongBookList({ page: 1, pageSize: 3, isResolved: false }),
      wrongBookApi.getWrongBookStats()
    ])
    if (overviewRes.status === 'fulfilled') overview.value = overviewRes.value.data as unknown as LearningOverview
    if (coursesRes.status === 'fulfilled') enrolledCourses.value = coursesRes.value.data as unknown as Course[]
    if (submissionsRes.status === 'fulfilled') recentSubmissions.value = (submissionsRes.value.data as unknown as { records: Submission[] }).records
    if (wrongRes.status === 'fulfilled') wrongItems.value = (wrongRes.value.data as unknown as { records: WrongBookItem[] }).records
    if (wrongCountRes.status === 'fulfilled') wrongCount.value = (wrongCountRes.value.data as unknown as { unresolved: number }).unresolved
    await notificationStore.fetchNotifications({ page: 1, pageSize: 5 })
    notifications.value = notificationStore.notifications
  } catch { /* ignore */ }
})
</script>

<style scoped>
.welcome-card {
  margin-bottom: 20px;
  border-radius: 12px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border: none;
}

.welcome-card :deep(.el-card__body) {
  color: #fff;
}

.welcome-content {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.welcome-text h2 {
  font-size: 22px;
  font-weight: 600;
  margin-bottom: 6px;
}

.welcome-text p {
  font-size: 14px;
  opacity: 0.85;
}

.welcome-stats {
  display: flex;
  gap: 40px;
}

.stat-item {
  text-align: center;
}

.stat-value {
  display: block;
  font-size: 28px;
  font-weight: 700;
}

.stat-label {
  font-size: 12px;
  opacity: 0.8;
}

.stat-cards {
  margin-bottom: 20px;
}

.stat-card {
  border-radius: 12px;
}

.stat-card-content {
  display: flex;
  align-items: center;
  gap: 16px;
}

.stat-icon {
  width: 56px;
  height: 56px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.stat-number {
  display: block;
  font-size: 24px;
  font-weight: 700;
  color: #1d2129;
}

.stat-desc {
  font-size: 13px;
  color: #909399;
}

.section-card {
  border-radius: 12px;
  margin-bottom: 0;
}

.card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.wrong-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 0;
  border-bottom: 1px solid #f0f0f0;
}

.wrong-item:last-child {
  border-bottom: none;
}

.wrong-info {
  display: flex;
  align-items: center;
  gap: 8px;
}

.wrong-count {
  font-size: 12px;
  color: #f56c6c;
}

.notify-item {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  padding: 10px 0;
  border-bottom: 1px solid #f0f0f0;
}

.notify-item:last-child {
  border-bottom: none;
}

.notify-item.unread .notify-title {
  font-weight: 600;
  color: #1d2129;
}

.notify-content {
  flex: 1;
  min-width: 0;
}

.notify-title {
  display: block;
  font-size: 13px;
  color: #606266;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.notify-time {
  font-size: 12px;
  color: #c0c4cc;
}

.empty-tip {
  text-align: center;
  color: #909399;
  padding: 20px 0;
  font-size: 14px;
}
</style>
