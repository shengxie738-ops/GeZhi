<template>
  <div class="page-container">
    <div class="page-header">
      <h2>数据报表</h2>
      <el-select v-model="selectedCourseId" placeholder="选择课程" style="width:200px" @change="fetchReport">
        <el-option v-for="c in courses" :key="c.id" :label="c.name" :value="c.id" />
      </el-select>
    </div>

    <template v-if="report">
      <!-- 概览统计 -->
      <el-row :gutter="20" class="stat-row">
        <el-col :span="6" v-for="(s, i) in statCards" :key="i">
          <el-card shadow="hover" class="stat-card">
            <div class="stat-value" :style="{ color: s.color }">{{ s.value }}</div>
            <div class="stat-label">{{ s.label }}</div>
          </el-card>
        </el-col>
      </el-row>

      <el-row :gutter="20">
        <!-- 提交趋势 -->
        <el-col :span="14">
          <el-card shadow="never" class="chart-card">
            <template #header><span>提交趋势</span></template>
            <v-chart :option="trendOption" style="height:320px" autoresize />
          </el-card>
        </el-col>
        <!-- 难度分布 -->
        <el-col :span="10">
          <el-card shadow="never" class="chart-card">
            <template #header><span>难度分布</span></template>
            <v-chart :option="diffOption" style="height:320px" autoresize />
          </el-card>
        </el-col>
      </el-row>

      <el-row :gutter="20" style="margin-top:20px">
        <!-- 知识点统计 -->
        <el-col :span="12">
          <el-card shadow="never" class="chart-card">
            <template #header><span>知识点掌握</span></template>
            <v-chart :option="tagOption" style="height:360px" autoresize />
          </el-card>
        </el-col>
        <!-- 优秀学生 -->
        <el-col :span="12">
          <el-card shadow="never" class="chart-card">
            <template #header><span>优秀学生</span></template>
            <el-table :data="report.topStudents" stripe size="small">
              <el-table-column type="index" label="排名" width="60" />
              <el-table-column prop="realName" label="姓名" width="120" />
              <el-table-column prop="progress" label="进度" width="160">
                <template #default="{ row }"><el-progress :percentage="row.progress" :stroke-width="6" /></template>
              </el-table-column>
              <el-table-column prop="score" label="分数" width="80" align="center">
                <template #default="{ row }"><span style="color:#67c23a;font-weight:600">{{ row.score }}</span></template>
              </el-table-column>
            </el-table>
          </el-card>
        </el-col>
      </el-row>
    </template>

    <el-empty v-else description="请选择课程查看报表" />
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import * as courseApi from '@/api/course'
import { get } from '@/utils/request'
import type { Course, CourseReport } from '@/types'

const courses = ref<Course[]>([])
const selectedCourseId = ref<number>()
const report = ref<CourseReport | null>(null)

const statCards = computed(() => {
  if (!report.value) return []
  const r = report.value
  return [
    { label: '学生数', value: r.studentCount, color: '#409eff' },
    { label: '题目数', value: r.problemCount, color: '#67c23a' },
    { label: '提交数', value: r.submissionCount, color: '#e6a23c' },
    { label: '通过率', value: r.acceptanceRate + '%', color: '#f56c6c' }
  ]
})

const trendOption = computed(() => {
  if (!report.value) return {}
  const t = report.value.submissionTrend
  return {
    tooltip: { trigger: 'axis' }, legend: { data: ['提交数', '通过数'], bottom: 0 },
    grid: { left: 50, right: 20, top: 20, bottom: 40 },
    xAxis: { type: 'category', data: t.map(d => d.date) },
    yAxis: { type: 'value' },
    series: [
      { name: '提交数', type: 'line', smooth: true, data: t.map(d => d.submitCount), areaStyle: { opacity: 0.15 }, itemStyle: { color: '#409eff' } },
      { name: '通过数', type: 'line', smooth: true, data: t.map(d => d.acceptedCount), areaStyle: { opacity: 0.15 }, itemStyle: { color: '#67c23a' } }
    ]
  }
})

const diffOption = computed(() => {
  if (!report.value) return {}
  const d = report.value.difficultyStats
  return {
    tooltip: { trigger: 'item', formatter: '{b}: {c} ({d}%)' }, legend: { bottom: 0 },
    series: [{ type: 'pie', radius: ['35%', '65%'], itemStyle: { borderRadius: 6, borderColor: '#fff', borderWidth: 2 },
      data: [
        { value: d.easy.total, name: '简单', itemStyle: { color: '#67c23a' } },
        { value: d.medium.total, name: '中等', itemStyle: { color: '#e6a23c' } },
        { value: d.hard.total, name: '困难', itemStyle: { color: '#f56c6c' } }
      ] }]
  }
})

const tagOption = computed(() => {
  if (!report.value) return {}
  const tags = report.value.tagStats.slice(0, 10)
  return {
    tooltip: { trigger: 'axis' },
    grid: { left: 100, right: 30, top: 20, bottom: 30 },
    xAxis: { type: 'value', max: 100, axisLabel: { formatter: '{value}%' } },
    yAxis: { type: 'category', data: tags.map(t => t.tag), inverse: true },
    series: [{ type: 'bar', data: tags.map(t => t.acceptanceRate), itemStyle: { color: '#764ba2', borderRadius: [0, 4, 4, 0] }, barWidth: 18,
      label: { show: true, position: 'right', formatter: '{c}%' } }]
  }
})

async function fetchReport() {
  if (!selectedCourseId.value) return
  try {
    const res = await get<CourseReport>(`/courses/${selectedCourseId.value}/report`)
    report.value = res.data as unknown as CourseReport
  } catch { /* ignore */ }
}

onMounted(async () => {
  try {
    const res = await courseApi.getCourseList({ page: 1, pageSize: 100 })
    courses.value = (res.data as unknown as { records: Course[] }).records
    if (courses.value.length) { selectedCourseId.value = courses.value[0].id; fetchReport() }
  } catch { /* ignore */ }
})
</script>

<style scoped>
.stat-row { margin-bottom: 20px; }
.stat-card { border-radius: 12px; text-align: center; padding: 10px 0; }
.stat-value { font-size: 28px; font-weight: 700; }
.stat-label { font-size: 13px; color: #909399; margin-top: 4px; }
.chart-card { border-radius: 12px; }
</style>
