<template>
  <div class="code-editor-wrapper">
    <div ref="editorRef" class="editor-container" :style="{ height: height }"></div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onBeforeUnmount, watch, nextTick } from 'vue'

const props = withDefaults(defineProps<{
  modelValue: string
  language?: string
  theme?: string
  fontSize?: number
  readOnly?: boolean
  height?: string
}>(), {
  language: 'cpp',
  theme: 'vs-dark',
  fontSize: 14,
  readOnly: false,
  height: '400px'
})

const emit = defineEmits<{ 'update:modelValue': [value: string] }>()

const editorRef = ref<HTMLElement>()
let editor: {
  dispose: () => void
  getValue: () => string
  setValue: (v: string) => void
  updateOptions: (opts: Record<string, unknown>) => void
} | null = null

async function initEditor() {
  if (!editorRef.value) return
  try {
    const monaco = await import('@monaco-editor/loader')
    const loader = monaco.default || monaco
    const monacoEditor = await (loader as unknown as { init: () => Promise<unknown> }).init()
    const m = monacoEditor as {
      editor: {
        create: (el: HTMLElement, opts: Record<string, unknown>) => {
          dispose: () => void
          getValue: () => string
          setValue: (v: string) => void
          updateOptions: (opts: Record<string, unknown>) => void
          onDidChangeModelContent: (cb: () => void) => void
        }
      }
    }
    editor = m.editor.create(editorRef.value, {
      value: props.modelValue,
      language: props.language,
      theme: props.theme,
      fontSize: props.fontSize,
      readOnly: props.readOnly,
      minimap: { enabled: false },
      automaticLayout: true,
      scrollBeyondLastLine: false,
      lineNumbers: 'on',
      tabSize: 4,
      wordWrap: 'on'
    })
    editor.onDidChangeModelContent(() => {
      emit('update:modelValue', editor!.getValue())
    })
  } catch {
    // Monaco 加载失败时的后备方案
    if (editorRef.value) {
      editorRef.value.innerHTML = `<textarea style="width:100%;height:100%;font-family:monospace;font-size:${props.fontSize}px;padding:12px;border:none;resize:none;outline:none;background:#1e1e1e;color:#d4d4d4" ${props.readOnly ? 'readonly' : ''}>${props.modelValue}</textarea>`
    }
  }
}

watch(() => props.language, (val) => {
  // language change requires re-creating editor
})

watch(() => props.theme, (val) => {
  editor?.updateOptions({ theme: val })
})

watch(() => props.fontSize, (val) => {
  editor?.updateOptions({ fontSize: val })
})

onMounted(async () => {
  await nextTick()
  await initEditor()
})

onBeforeUnmount(() => {
  editor?.dispose()
})
</script>

<style scoped>
.code-editor-wrapper { width: 100%; }
.editor-container { width: 100%; border-radius: 8px; overflow: hidden; }
</style>
