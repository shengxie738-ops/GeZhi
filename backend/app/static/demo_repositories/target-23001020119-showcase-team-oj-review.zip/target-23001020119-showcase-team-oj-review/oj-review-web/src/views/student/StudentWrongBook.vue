<template>
  <div class="page-container">
    <div class="page-header">
      <h2>错题本</h2>
      <div class="header-actions">
        <el-button type="primary" plain @click="handleExport">
          <el-icon><Download /></el-icon> 导出
        </el-button>
      </div>
    </div>

    <!-- 筛选栏 -->
    <el-card shadow="never" class="filter-card">
      <el-form :inline="true" :model="filterForm">
        <el-form-item label="难度">
          <el-select v-model="filterForm.difficulty" placeholder="全部" clearable @change="fetchData">
            <el-option label="简单" value="EASY" />
            <el-option label="中等" value="MEDIUM" />
            <el-option label="困难" value="HARD" />
          </el-select>
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="filterForm.isResolved" placeholder="全部" clearable @change="fetchData">
            <el-option label="未掌握" :value="false" />
            <el-option label="已掌握" :value="true" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="fetchData">查询</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <!-- 统计卡片 -->
    <el-row :gutter="20" class="stat-row">
      <el-col :span="8">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value" style="color: #f56c6c">{{ stats.unresolved }}</div>
          <div class="stat-label">未掌握</div>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value" style="color: #67c23a">{{ stats.resolved }}</div>
          <div class="stat-label">已掌握</div>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value" style="color: #409eff">{{ stats.total }}</div>
          <div class="stat-label">总计</div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 错题列表 -->
    <el-card shadow="never" class="table-card">
      <el-table :data="wrongItems" v-loading="loading" stripe style="width: 100%">
        <el-table-column prop="problemTitle" label="题目" min-width="200">
          <template #default="{ row }">
            <el-link type="primary" @click="$router.push(`/student/problems/${row.problemId}`)">{{ row.problemTitle }}</el-link>
          </template>
        </el-table-column>
        <el-table-column prop="problemDifficulty" label="难度" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="getDifficultyType(row.problemDifficulty)" size="small">
              {{ getDifficultyLabel(row.problemDifficulty) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="知识点" min-width="160">
          <template #default="{ row }">
            <el-tag v-for="tag in row.tags?.slice(0, 3)" :key="tag" size="small" class="tag-item">{{ tag }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="wrongCount" label="错误次数" width="100" align="center">
          <template #default="{ row }">
            <span style="color: #f56c6c; font-weight: 600">{{ row.wrongCount }}</span>
          </template>
        </el-table-column>
        <el-table-column label="状态" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="row.isResolved ? 'success' : 'danger'" size="small">
              {{ row.isResolved ? '已掌握' : '未掌握' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="lastWrongAt" label="最近错误" width="170">
          <template #default="{ row }">{{ formatDate(row.lastWrongAt) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="200" align="center" fixed="right">
          <template #default="{ row }">
            <el-button text type="primary" size="small" @click="showDetail(row)">详情</el-button>
            <el-button
              v-if="!row.isResolved"
              text type="success" size="small"
              @click="handleMarkResolved(row)"
            >标记掌握</el-button>
            <el-button
              v-else
              text type="warning" size="small"
              @click="handleMarkUnresolved(row)"
            >取消掌握</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-wrapper">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :page-sizes="[20, 50, 100]"
          :total="total"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="fetchData"
          @current-change="fetchData"
        />
      </div>
    </el-card>

    <!-- 错题详情弹窗 -->
    <el-dialog v-model="detailVisible" title="错题详情" width="680px" destroy-on-close>
      <template v-if="currentItem">
        <el-descriptions :column="2" border>
          <el-descriptions-item label="题目">{{ currentItem.problemTitle }}</el-descriptions-item>
          <el-descriptions-item label="难度">
            <el-tag :type="getDifficultyType(currentItem.problemDifficulty)" size="small">
              {{ getDifficultyLabel(currentItem.problemDifficulty) }}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="错误次数">{{ currentItem.wrongCount }}</el-descriptions-item>
          <el-descriptions-item label="状态">
            <el-tag :type="currentItem.isResolved ? 'success' : 'danger'" size="small">
              {{ currentItem.isResolved ? '已掌握' : '未掌握' }}
            </el-tag>
          </el-descriptions-item>
        </el-descriptions>
        <div class="detail-section">
          <h4>错题备注</h4>
          <el-input
            v-model="editNote"
            type="textarea"
            :rows="4"
            placeholder="记录错误原因、解题思路等..."
          />
          <el-button type="primary" size="small" style="margin-top: 8px" @click="saveNote">保存备注</el-button>
        </div>
        <div class="detail-section">
          <h4>知识点</h4>
          <el-tag v-for="tag in currentItem.tags" :key="tag" class="tag-item">{{ tag }}</el-tag>
          <span v-if="!currentItem.tags?.length" style="color: #909399">暂无</span>
        </div>
      </template>
      <template #footer>
        <el-button @click="detailVisible = false">关闭</el-button>
        <el-button type="primary" @click="$router.push(`/student/problems/${currentItem?.problemId}`)">去练习</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import dayjs from 'dayjs'
import { ElMessage } from 'element-plus'
import * as wrongBookApi from '@/api/wrongBook'
import type { WrongBookItem, Difficulty } from '@/types'

const loading = ref(false)
const wrongItems = ref<WrongBookItem[]>([])
const total = ref(0)
const currentPage = ref(1)
const pageSize = ref(20)
const detailVisible = ref(false)
const currentItem = ref<WrongBookItem | null>(null)
const editNote = ref('')

const stats = reactive({ total: 0, unresolved: 0, resolved: 0 })

const filterForm = reactive({
  difficulty: '' as Difficulty | '',
  isResolved: undefined as boolean | undefined
})

function getDifficultyType(d: string) {
  const map: Record<string, string> = { EASY: 'success', MEDIUM: 'warning', HARD: 'danger' }
  return (map[d] || 'info') as 'success' | 'warning' | 'danger' | 'info'
}

function getDifficultyLabel(d: string) {
  const map: Record<string, string> = { EASY: '简单', MEDIUM: '中等', HARD: '困难' }
  return map[d] || d
}

function formatDate(date: string) {
  return dayjs(date).format('YYYY-MM-DD HH:mm')
}

function showDetail(item: WrongBookItem) {
  currentItem.value = item
  editNote.value = item.note || ''
  detailVisible.value = true
}

async function saveNote() {
  if (!currentItem.value) return
  try {
    await wrongBookApi.updateWrongBookNote(currentItem.value.id, editNote.value)
    currentItem.value.note = editNote.value
    ElMessage.success('备注已保存')
  } catch {
    ElMessage.error('保存失败')
  }
}

async function handleMarkResolved(item: WrongBookItem) {
  try {
    await wrongBookApi.markAsResolved(item.id)
    item.isResolved = true
    stats.unresolved = Math.max(0, stats.unresolved - 1)
    stats.resolved++
    ElMessage.success('已标记为掌握')
  } catch {
    ElMessage.error('操作失败')
  }
}

async function handleMarkUnresolved(item: WrongBookItem) {
  try {
    await wrongBookApi.markAsUnresolved(item.id)
    item.isResolved = false
    stats.resolved = Math.max(0, stats.resolved - 1)
    stats.unresolved++
    ElMessage.success('已取消掌握标记')
  } catch {
    ElMessage.error('操作失败')
  }
}

function handleExport() {
  ElMessage.info('正在导出...')
}

async function fetchData() {
  loading.value = true
  try {
    const res = await wrongBookApi.getWrongBookList({
      page: currentPage.value,
      pageSize: pageSize.value,
      difficulty: (filterForm.difficulty as Difficulty) || undefined,
      isResolved: filterForm.isResolved
    })
    const data = res.data as unknown as { records: WrongBookItem[]; total: number }
    wrongItems.value = data.records
    total.value = data.total
  } finally {
    loading.value = false
  }
}

async function fetchStats() {
  try {
    const res = await wrongBookApi.getWrongBookStats()
    const data = res.data as unknown as { total: number; unresolved: number; resolved: number }
    stats.total = data.total
    stats.unresolved = data.unresolved
    stats.resolved = data.resolved
  } catch { /* ignore */ }
}

onMounted(() => {
  fetchData()
  fetchStats()
})
</script>

<style scoped>
.filter-card {
  margin-bottom: 20px;
  border-radius: 12px;
}

.stat-row {
  margin-bottom: 20px;
}

.stat-card {
  border-radius: 12px;
  text-align: center;
  padding: 10px 0;
}

.stat-value {
  font-size: 32px;
  font-weight: 700;
}

.stat-label {
  font-size: 14px;
  color: #909399;
  margin-top: 4px;
}

.table-card {
  border-radius: 12px;
}

.tag-item {
  margin-right: 4px;
  margin-bottom: 2px;
}

.pagination-wrapper {
  display: flex;
  justify-content: flex-end;
  margin-top: 16px;
}

.detail-section {
  margin-top: 16px;
}

.detail-section h4 {
  font-size: 14px;
  font-weight: 600;
  color: #303133;
  margin-bottom: 8px;
}
</style>
