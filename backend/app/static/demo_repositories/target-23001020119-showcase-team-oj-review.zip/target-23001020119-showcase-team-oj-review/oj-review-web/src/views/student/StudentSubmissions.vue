<template>
  <div class="page-container">
    <div class="page-header">
      <h2>提交记录</h2>
    </div>

    <!-- 筛选栏 -->
    <el-card shadow="never" class="filter-card">
      <el-form :inline="true" :model="filterForm">
        <el-form-item label="语言">
          <el-select v-model="filterForm.language" placeholder="全部" clearable @change="fetchData">
            <el-option label="C++" value="cpp" />
            <el-option label="Java" value="java" />
            <el-option label="Python" value="python" />
            <el-option label="JavaScript" value="javascript" />
            <el-option label="Go" value="go" />
          </el-select>
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="filterForm.status" placeholder="全部" clearable @change="fetchData">
            <el-option label="通过" value="ACCEPTED" />
            <el-option label="答案错误" value="WRONG_ANSWER" />
            <el-option label="超时" value="TIME_LIMIT_EXCEEDED" />
            <el-option label="编译错误" value="COMPILE_ERROR" />
            <el-option label="运行错误" value="RUNTIME_ERROR" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="fetchData">查询</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <!-- 提交记录表格 -->
    <el-card shadow="never" class="table-card">
      <el-table :data="submissions" v-loading="loading" stripe style="width: 100%">
        <el-table-column prop="id" label="编号" width="80" align="center" />
        <el-table-column prop="problemTitle" label="题目" min-width="200">
          <template #default="{ row }">
            <el-link type="primary" @click="$router.push(`/student/problems/${row.problemId}`)">{{ row.problemTitle }}</el-link>
          </template>
        </el-table-column>
        <el-table-column prop="language" label="语言" width="100" />
        <el-table-column prop="status" label="状态" width="140">
          <template #default="{ row }">
            <el-tag :type="getStatusType(row.status)" size="small">{{ getStatusLabel(row.status) }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="score" label="分数" width="80" align="center">
          <template #default="{ row }">
            <span :style="{ color: row.score >= 60 ? '#67c23a' : '#f56c6c', fontWeight: 600 }">{{ row.score }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="timeUsed" label="耗时" width="100">
          <template #default="{ row }">{{ row.timeUsed }}ms</template>
        </el-table-column>
        <el-table-column prop="memoryUsed" label="内存" width="100">
          <template #default="{ row }">{{ formatMemory(row.memoryUsed) }}</template>
        </el-table-column>
        <el-table-column prop="createdAt" label="提交时间" width="170">
          <template #default="{ row }">{{ formatDate(row.createdAt) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="80" align="center" fixed="right">
          <template #default="{ row }">
            <el-button text type="primary" size="small" @click="$router.push(`/student/submissions/${row.id}`)">详情</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-wrapper">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :page-sizes="[20, 50, 100]"
          :total="total"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="fetchData"
          @current-change="fetchData"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import dayjs from 'dayjs'
import * as submissionApi from '@/api/submission'
import type { Submission, JudgeStatus } from '@/types'

const loading = ref(false)
const submissions = ref<Submission[]>([])
const total = ref(0)
const currentPage = ref(1)
const pageSize = ref(20)

const filterForm = reactive({
  language: '',
  status: '' as JudgeStatus | ''
})

function getStatusType(status: string) {
  const map: Record<string, string> = {
    ACCEPTED: 'success', WRONG_ANSWER: 'danger', PENDING: 'warning', JUDGING: '',
    TIME_LIMIT_EXCEEDED: 'danger', MEMORY_LIMIT_EXCEEDED: 'danger',
    RUNTIME_ERROR: 'danger', COMPILE_ERROR: 'danger', SYSTEM_ERROR: 'info'
  }
  return (map[status] || 'info') as 'success' | 'danger' | 'warning' | 'info' | ''
}

function getStatusLabel(status: string) {
  const map: Record<string, string> = {
    ACCEPTED: '通过', WRONG_ANSWER: '答案错误', PENDING: '等待中', JUDGING: '评测中',
    TIME_LIMIT_EXCEEDED: '超时', MEMORY_LIMIT_EXCEEDED: '内存超限',
    RUNTIME_ERROR: '运行错误', COMPILE_ERROR: '编译错误', SYSTEM_ERROR: '系统错误'
  }
  return map[status] || status
}

function formatMemory(bytes: number) {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`
}

function formatDate(date: string) {
  return dayjs(date).format('YYYY-MM-DD HH:mm:ss')
}

async function fetchData() {
  loading.value = true
  try {
    const res = await submissionApi.getSubmissionList({
      page: currentPage.value,
      pageSize: pageSize.value,
      language: filterForm.language || undefined,
      status: (filterForm.status as JudgeStatus) || undefined
    })
    const data = res.data as unknown as { records: Submission[]; total: number }
    submissions.value = data.records
    total.value = data.total
  } finally {
    loading.value = false
  }
}

onMounted(fetchData)
</script>

<style scoped>
.filter-card {
  margin-bottom: 20px;
  border-radius: 12px;
}

.table-card {
  border-radius: 12px;
}

.pagination-wrapper {
  display: flex;
  justify-content: flex-end;
  margin-top: 16px;
}
</style>
