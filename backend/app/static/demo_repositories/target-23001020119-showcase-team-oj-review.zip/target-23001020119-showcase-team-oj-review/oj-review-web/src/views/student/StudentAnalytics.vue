<template>
  <div class="page-container">
    <div class="page-header">
      <h2>学习分析</h2>
    </div>

    <el-row :gutter="20">
      <!-- 提交趋势折线图 -->
      <el-col :span="16">
        <el-card shadow="never" class="chart-card">
          <template #header><span>提交趋势（近30天）</span></template>
          <v-chart :option="trendOption" style="height: 320px" autoresize />
        </el-card>
      </el-col>
      <!-- 通过率变化 -->
      <el-col :span="8">
        <el-card shadow="never" class="chart-card">
          <template #header><span>通过率变化</span></template>
          <v-chart :option="acceptanceOption" style="height: 320px" autoresize />
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="20" style="margin-top: 20px">
      <!-- 知识点掌握度雷达图 -->
      <el-col :span="10">
        <el-card shadow="never" class="chart-card">
          <template #header><span>知识点掌握度</span></template>
          <v-chart :option="radarOption" style="height: 360px" autoresize />
        </el-card>
      </el-col>
      <!-- 错误类型分布饼图 -->
      <el-col :span="7">
        <el-card shadow="never" class="chart-card">
          <template #header><span>错误类型分布</span></template>
          <v-chart :option="pieOption" style="height: 360px" autoresize />
        </el-card>
      </el-col>
      <!-- 学习时间线 -->
      <el-col :span="7">
        <el-card shadow="never" class="chart-card">
          <template #header><span>学习时间分布</span></template>
          <v-chart :option="timeOption" style="height: 360px" autoresize />
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import * as analyticsApi from '@/api/analytics'
import type { SubmissionTrend, TagStat } from '@/types'

const trends = ref<SubmissionTrend[]>([])
const tagStats = ref<TagStat[]>([])

const trendOption = computed(() => ({
  tooltip: { trigger: 'axis' },
  legend: { data: ['提交数', '通过数'], bottom: 0 },
  grid: { left: 50, right: 20, top: 20, bottom: 40 },
  xAxis: { type: 'category', data: trends.value.map(t => t.date) },
  yAxis: { type: 'value' },
  series: [
    { name: '提交数', type: 'line', smooth: true, data: trends.value.map(t => t.submitCount), areaStyle: { opacity: 0.15 }, itemStyle: { color: '#409eff' } },
    { name: '通过数', type: 'line', smooth: true, data: trends.value.map(t => t.acceptedCount), areaStyle: { opacity: 0.15 }, itemStyle: { color: '#67c23a' } }
  ]
}))

const acceptanceOption = computed(() => ({
  tooltip: { trigger: 'axis', formatter: '{b}: {c}%' },
  grid: { left: 50, right: 20, top: 20, bottom: 40 },
  xAxis: { type: 'category', data: trends.value.slice(-14).map(t => t.date) },
  yAxis: { type: 'value', max: 100, axisLabel: { formatter: '{value}%' } },
  series: [{
    type: 'line', smooth: true,
    data: trends.value.slice(-14).map(t => t.submitCount > 0 ? Math.round(t.acceptedCount / t.submitCount * 100) : 0),
    itemStyle: { color: '#e6a23c' }, areaStyle: { opacity: 0.15, color: '#e6a23c' }
  }]
}))

const radarOption = computed(() => ({
  tooltip: {},
  radar: {
    indicator: tagStats.value.slice(0, 8).map(t => ({ name: t.tag, max: 100 })),
    shape: 'circle'
  },
  series: [{
    type: 'radar',
    data: [{
      value: tagStats.value.slice(0, 8).map(t => t.acceptanceRate),
      name: '掌握度',
      areaStyle: { opacity: 0.2 },
      lineStyle: { color: '#409eff' },
      itemStyle: { color: '#409eff' }
    }]
  }]
}))

const pieOption = computed(() => ({
  tooltip: { trigger: 'item', formatter: '{b}: {c} ({d}%)' },
  legend: { bottom: 0, textStyle: { fontSize: 11 } },
  series: [{
    type: 'pie', radius: ['35%', '65%'],
    itemStyle: { borderRadius: 6, borderColor: '#fff', borderWidth: 2 },
    data: [
      { value: 35, name: '答案错误', itemStyle: { color: '#f56c6c' } },
      { value: 20, name: '超时', itemStyle: { color: '#e6a23c' } },
      { value: 15, name: '编译错误', itemStyle: { color: '#909399' } },
      { value: 10, name: '运行错误', itemStyle: { color: '#409eff' } },
      { value: 5, name: '内存超限', itemStyle: { color: '#764ba2' } }
    ]
  }]
}))

const timeOption = computed(() => ({
  tooltip: { trigger: 'axis' },
  grid: { left: 50, right: 20, top: 20, bottom: 30 },
  xAxis: { type: 'category', data: Array.from({ length: 24 }, (_, i) => `${i}:00`) },
  yAxis: { type: 'value' },
  series: [{
    type: 'bar',
    data: [2, 1, 0, 0, 0, 1, 3, 8, 12, 15, 10, 8, 6, 10, 14, 12, 8, 6, 9, 13, 16, 14, 8, 4],
    itemStyle: {
      color: (params: { value: number }) => {
        const v = params.value
        return v > 12 ? '#409eff' : v > 6 ? '#67c23a' : '#e4e7ed'
      }
    }
  }]
}))

onMounted(async () => {
  try {
    const [trendRes, tagRes] = await Promise.allSettled([
      analyticsApi.getSubmissionTrend({ days: 30 }),
      analyticsApi.getTagStats()
    ])
    if (trendRes.status === 'fulfilled') trends.value = trendRes.value.data as unknown as SubmissionTrend[]
    if (tagRes.status === 'fulfilled') tagStats.value = tagRes.value.data as unknown as TagStat[]
  } catch { /* ignore */ }
})
</script>

<style scoped>
.chart-card {
  border-radius: 12px;
}
</style>
