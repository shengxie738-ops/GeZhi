import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import type { Course, CourseForm, CourseStudent, PageResult } from '@/types'
import * as courseApi from '@/api/course'

export const useCourseStore = defineStore('course', () => {
  // State
  const currentCourse = ref<Course | null>(null)
  const courseList = ref<Course[]>([])
  const total = ref(0)
  const loading = ref(false)
  const courseStudents = ref<CourseStudent[]>([])
  const enrolledCourseIds = ref<number[]>([])

  // Getters
  const publishedCourses = computed(() =>
    courseList.value.filter((c) => c.status === 'PUBLISHED')
  )

  // Actions
  async function fetchCourseList(params?: Record<string, unknown>) {
    loading.value = true
    try {
      const res = await courseApi.getCourseList(params)
      const data = res.data as unknown as PageResult<Course>
      courseList.value = data.records
      total.value = data.total
    } finally {
      loading.value = false
    }
  }

  async function fetchCourseDetail(courseId: number) {
    loading.value = true
    try {
      const res = await courseApi.getCourseDetail(courseId)
      currentCourse.value = res.data as unknown as Course
      return currentCourse.value
    } finally {
      loading.value = false
    }
  }

  async function createCourse(form: CourseForm) {
    const res = await courseApi.createCourse(form)
    return res.data
  }

  async function updateCourse(courseId: number, form: Partial<CourseForm>) {
    const res = await courseApi.updateCourse(courseId, form)
    return res.data
  }

  async function deleteCourse(courseId: number) {
    await courseApi.deleteCourse(courseId)
    courseList.value = courseList.value.filter((c) => c.id !== courseId)
  }

  async function fetchCourseStudents(courseId: number, params?: Record<string, unknown>) {
    const res = await courseApi.getCourseStudents(courseId, params)
    const data = res.data as unknown as PageResult<CourseStudent>
    courseStudents.value = data.records
    return data
  }

  async function joinCourse(courseId: number, inviteCode?: string) {
    await courseApi.joinCourse(courseId, inviteCode)
    enrolledCourseIds.value.push(courseId)
  }

  async function fetchEnrolledCourses() {
    const res = await courseApi.getEnrolledCourses()
    const data = res.data as unknown as Course[]
    enrolledCourseIds.value = data.map((c) => c.id)
    return data
  }

  function setCurrentCourse(course: Course | null) {
    currentCourse.value = course
  }

  return {
    // State
    currentCourse,
    courseList,
    total,
    loading,
    courseStudents,
    enrolledCourseIds,
    // Getters
    publishedCourses,
    // Actions
    fetchCourseList,
    fetchCourseDetail,
    createCourse,
    updateCourse,
    deleteCourse,
    fetchCourseStudents,
    joinCourse,
    fetchEnrolledCourses,
    setCurrentCourse
  }
}, {
  persist: {
    key: 'oj-course',
    pick: ['enrolledCourseIds']
  }
})
