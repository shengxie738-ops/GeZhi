<template>
  <div class="page-container">
    <div class="page-header">
      <h2>我的团队</h2>
      <div class="header-actions">
        <el-button type="primary" @click="showJoinDialog = true">
          <el-icon><Plus /></el-icon> 加入团队
        </el-button>
        <el-button type="success" @click="showCreateDialog = true">
          <el-icon><Plus /></el-icon> 创建团队
        </el-button>
      </div>
    </div>

    <div v-loading="loading" class="team-grid">
      <el-empty v-if="teams.length === 0" description="暂未加入任何团队" />
      <el-card v-for="team in teams" :key="team.id" shadow="hover" class="team-card" @click="$router.push(`/student/teams/${team.id}`)">
        <div class="team-header">
          <el-avatar :size="48" style="background: #409eff">{{ team.name.charAt(0) }}</el-avatar>
          <div class="team-info">
            <h3>{{ team.name }}</h3>
            <p>{{ team.courseName }}</p>
          </div>
        </div>
        <p class="team-desc">{{ team.description || '暂无描述' }}</p>
        <div class="team-meta">
          <span><el-icon><User /></el-icon> {{ team.leaderName }}</span>
          <span><el-icon><UserFilled /></el-icon> {{ team.memberCount }}/{{ team.maxMembers }}</span>
        </div>
      </el-card>
    </div>

    <!-- 加入团队弹窗 -->
    <el-dialog v-model="showJoinDialog" title="加入团队" width="420px" destroy-on-close>
      <el-form ref="joinFormRef" :model="joinForm" :rules="joinRules" label-width="80px">
        <el-form-item label="邀请码" prop="inviteCode">
          <el-input v-model="joinForm.inviteCode" placeholder="请输入团队邀请码" clearable />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showJoinDialog = false">取消</el-button>
        <el-button type="primary" :loading="joining" @click="handleJoin">加入</el-button>
      </template>
    </el-dialog>

    <!-- 创建团队弹窗 -->
    <el-dialog v-model="showCreateDialog" title="创建团队" width="520px" destroy-on-close>
      <el-form ref="createFormRef" :model="createForm" :rules="createRules" label-width="100px">
        <el-form-item label="团队名称" prop="name">
          <el-input v-model="createForm.name" placeholder="请输入团队名称" clearable />
        </el-form-item>
        <el-form-item label="团队描述" prop="description">
          <el-input v-model="createForm.description" type="textarea" :rows="3" placeholder="请输入团队描述" />
        </el-form-item>
        <el-form-item label="所属课程" prop="courseId">
          <el-select v-model="createForm.courseId" placeholder="选择课程" style="width: 100%">
            <el-option v-for="c in courses" :key="c.id" :label="c.name" :value="c.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="最大人数" prop="maxMembers">
          <el-input-number v-model="createForm.maxMembers" :min="2" :max="10" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showCreateDialog = false">取消</el-button>
        <el-button type="primary" :loading="creating" @click="handleCreate">创建</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import type { FormInstance, FormRules } from 'element-plus'
import { ElMessage } from 'element-plus'
import * as teamApi from '@/api/team'
import * as courseApi from '@/api/course'
import type { Team, Course } from '@/types'

const loading = ref(false)
const teams = ref<Team[]>([])
const courses = ref<Course[]>([])
const showJoinDialog = ref(false)
const showCreateDialog = ref(false)
const joining = ref(false)
const creating = ref(false)

const joinFormRef = ref<FormInstance>()
const createFormRef = ref<FormInstance>()
const joinForm = reactive({ inviteCode: '' })
const createForm = reactive({ name: '', description: '', courseId: undefined as number | undefined, maxMembers: 5 })
const joinRules: FormRules = { inviteCode: [{ required: true, message: '请输入邀请码', trigger: 'blur' }] }
const createRules: FormRules = {
  name: [{ required: true, message: '请输入团队名称', trigger: 'blur' }],
  courseId: [{ required: true, message: '请选择课程', trigger: 'change' }]
}

async function fetchData() {
  loading.value = true
  try {
    const res = await teamApi.getMyTeams()
    teams.value = res.data as unknown as Team[]
  } finally {
    loading.value = false
  }
}

async function handleJoin() {
  const valid = await joinFormRef.value?.validate().catch(() => false)
  if (!valid) return
  joining.value = true
  try {
    await teamApi.joinTeam(joinForm.inviteCode)
    ElMessage.success('加入团队成功')
    showJoinDialog.value = false
    joinForm.inviteCode = ''
    fetchData()
  } catch {
    ElMessage.error('加入失败，请检查邀请码')
  } finally {
    joining.value = false
  }
}

async function handleCreate() {
  const valid = await createFormRef.value?.validate().catch(() => false)
  if (!valid) return
  creating.value = true
  try {
    await teamApi.createTeam(createForm as { name: string; description: string; courseId: number; maxMembers: number })
    ElMessage.success('创建团队成功')
    showCreateDialog.value = false
    fetchData()
  } catch {
    ElMessage.error('创建失败')
  } finally {
    creating.value = false
  }
}

onMounted(async () => {
  fetchData()
  try {
    const res = await courseApi.getEnrolledCourses()
    courses.value = res.data as unknown as Course[]
  } catch { /* ignore */ }
})
</script>

<style scoped>
.team-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 20px;
}

.team-card {
  border-radius: 12px;
  cursor: pointer;
  transition: transform 0.2s;
}

.team-card:hover {
  transform: translateY(-4px);
}

.team-header {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 12px;
}

.team-info h3 {
  font-size: 16px;
  font-weight: 600;
  color: #1d2129;
}

.team-info p {
  font-size: 13px;
  color: #909399;
}

.team-desc {
  font-size: 13px;
  color: #606266;
  margin-bottom: 12px;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.team-meta {
  display: flex;
  gap: 16px;
  font-size: 13px;
  color: #909399;
}

.team-meta span {
  display: flex;
  align-items: center;
  gap: 4px;
}

.header-actions {
  display: flex;
  gap: 8px;
}
</style>
