<template>
  <aside class="app-sidebar" :class="{ collapsed }">
    <div class="sidebar-logo">
      <el-icon :size="28"><Monitor /></el-icon>
      <span v-show="!collapsed" class="logo-text">{{ title }}</span>
    </div>
    <el-menu
      :default-active="activeMenu"
      :collapse="collapsed"
      background-color="#1d1e2c"
      text-color="#a3a6b4"
      active-text-color="#409eff"
      router
      class="sidebar-menu"
    >
      <el-menu-item v-for="item in menuItems" :key="item.path" :index="item.path">
        <el-icon><component :is="item.icon" /></el-icon>
        <template #title>{{ item.label }}</template>
      </el-menu-item>
    </el-menu>
  </aside>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from 'vue-router'

interface MenuItem {
  path: string
  icon: string
  label: string
}

const props = defineProps<{
  collapsed?: boolean
  title?: string
  menuItems: MenuItem[]
}>()

const route = useRoute()
const activeMenu = computed(() => route.path)
</script>

<style scoped>
.app-sidebar {
  width: var(--oj-sidebar-width);
  height: 100vh;
  background: var(--oj-sidebar-bg);
  transition: width 0.3s;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.app-sidebar.collapsed { width: 64px; }
.sidebar-logo {
  height: var(--oj-header-height);
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  color: #fff;
  font-size: 18px;
  font-weight: 700;
  border-bottom: 1px solid rgba(255, 255, 255, 0.08);
  flex-shrink: 0;
}
.logo-text { white-space: nowrap; }
.sidebar-menu { flex: 1; border-right: none; overflow-y: auto; }
.sidebar-menu:not(.el-menu--collapse) { width: 100%; }
</style>
