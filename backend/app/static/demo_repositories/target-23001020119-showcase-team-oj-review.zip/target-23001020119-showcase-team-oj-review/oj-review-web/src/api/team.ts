import { get, post, put, del } from '@/utils/request'
import type { Team, TeamForm, TeamMember, PageResult } from '@/types'

/** 获取团队列表（分页） */
export function getTeamList(params?: Record<string, unknown>) {
  return get<PageResult<Team>>('/teams', params)
}

/** 获取团队详情 */
export function getTeamDetail(teamId: number) {
  return get<Team>(`/teams/${teamId}`)
}

/** 创建团队 */
export function createTeam(data: TeamForm) {
  return post<Team>('/teams', data)
}

/** 更新团队信息 */
export function updateTeam(teamId: number, data: Partial<TeamForm>) {
  return put<Team>(`/teams/${teamId}`, data)
}

/** 删除团队 */
export function deleteTeam(teamId: number) {
  return del<void>(`/teams/${teamId}`)
}

/** 通过邀请码加入团队 */
export function joinTeam(inviteCode: string) {
  return post<Team>('/teams/join', { inviteCode })
}

/** 离开团队 */
export function leaveTeam(teamId: number) {
  return post<void>(`/teams/${teamId}/leave`)
}

/** 移除团队成员 */
export function removeMember(teamId: number, userId: number) {
  return del<void>(`/teams/${teamId}/members/${userId}`)
}

/** 转让队长 */
export function transferLeader(teamId: number, newLeaderId: number) {
  return post<void>(`/teams/${teamId}/transfer`, { newLeaderId })
}

/** 获取团队成员列表 */
export function getTeamMembers(teamId: number) {
  return get<TeamMember[]>(`/teams/${teamId}/members`)
}

/** 获取我的团队列表 */
export function getMyTeams() {
  return get<Team[]>('/teams/my')
}

/** 重新生成团队邀请码 */
export function regenerateTeamInviteCode(teamId: number) {
  return post<{ inviteCode: string }>(`/teams/${teamId}/invite-code/regenerate`)
}

/** 教师端：获取课程下所有团队 */
export function getTeamsByCourse(courseId: number, params?: Record<string, unknown>) {
  return get<PageResult<Team>>(`/teams/course/${courseId}`, params)
}

/** 教师端：自动分组 */
export function autoAssignTeams(courseId: number, data: { teamSize: number; method: 'random' | 'balanced' }) {
  return post<{ teams: Team[] }>(`/teams/course/${courseId}/auto-assign`, data)
}
