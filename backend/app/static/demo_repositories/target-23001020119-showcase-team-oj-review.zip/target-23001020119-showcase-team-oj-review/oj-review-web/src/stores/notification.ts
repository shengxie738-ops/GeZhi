import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import type { Notification, NotificationQuery, NotificationType, PageResult } from '@/types'
import * as notificationApi from '@/api/notification'

export const useNotificationStore = defineStore('notification', () => {
  // State
  const notifications = ref<Notification[]>([])
  const total = ref(0)
  const unreadCount = ref(0)
  const loading = ref(false)

  // Getters
  const hasUnread = computed(() => unreadCount.value > 0)

  const unreadNotifications = computed(() =>
    notifications.value.filter((n) => !n.isRead)
  )

  // Actions
  async function fetchNotifications(params?: NotificationQuery) {
    loading.value = true
    try {
      const res = await notificationApi.getNotificationList(params)
      const data = res.data as unknown as PageResult<Notification>
      notifications.value = data.records
      total.value = data.total
    } finally {
      loading.value = false
    }
  }

  async function fetchUnreadCount() {
    const res = await notificationApi.getUnreadCount()
    unreadCount.value = (res.data as unknown as { count: number }).count
    return unreadCount.value
  }

  async function markAsRead(notificationId: number) {
    await notificationApi.markAsRead(notificationId)
    const target = notifications.value.find((n) => n.id === notificationId)
    if (target && !target.isRead) {
      target.isRead = true
      unreadCount.value = Math.max(0, unreadCount.value - 1)
    }
  }

  async function markAllAsRead() {
    await notificationApi.markAllAsRead()
    notifications.value.forEach((n) => {
      n.isRead = true
    })
    unreadCount.value = 0
  }

  async function deleteNotification(notificationId: number) {
    await notificationApi.deleteNotification(notificationId)
    const index = notifications.value.findIndex((n) => n.id === notificationId)
    if (index > -1) {
      const wasUnread = !notifications.value[index].isRead
      notifications.value.splice(index, 1)
      total.value--
      if (wasUnread) {
        unreadCount.value = Math.max(0, unreadCount.value - 1)
      }
    }
  }

  function addNotification(notification: Notification) {
    notifications.value.unshift(notification)
    total.value++
    if (!notification.isRead) {
      unreadCount.value++
    }
  }

  return {
    // State
    notifications,
    total,
    unreadCount,
    loading,
    // Getters
    hasUnread,
    unreadNotifications,
    // Actions
    fetchNotifications,
    fetchUnreadCount,
    markAsRead,
    markAllAsRead,
    deleteNotification,
    addNotification
  }
})
