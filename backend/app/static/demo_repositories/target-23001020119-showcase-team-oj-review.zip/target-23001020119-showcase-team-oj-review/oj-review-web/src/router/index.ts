import { createRouter, createWebHistory } from 'vue-router'
import type { RouteRecordRaw } from 'vue-router'

const routes: RouteRecordRaw[] = [
  // ─── Public routes ───────────────────────────────────
  {
    path: '/login',
    name: 'Login',
    component: () => import('@/views/auth/LoginView.vue'),
    meta: { title: '登录', public: true }
  },
  {
    path: '/register',
    name: 'Register',
    component: () => import('@/views/auth/RegisterView.vue'),
    meta: { title: '注册', public: true }
  },
  {
    path: '/403',
    name: 'Forbidden',
    component: () => import('@/views/error/ForbiddenView.vue'),
    meta: { title: '无权限', public: true }
  },
  {
    path: '/404',
    name: 'NotFound',
    component: () => import('@/views/error/NotFoundView.vue'),
    meta: { title: '页面不存在', public: true }
  },

  // ─── Student routes ──────────────────────────────────
  {
    path: '/student',
    component: () => import('@/layouts/StudentLayout.vue'),
    meta: { requiresAuth: true, role: 'STUDENT' },
    redirect: '/student/dashboard',
    children: [
      {
        path: 'dashboard',
        name: 'StudentDashboard',
        component: () => import('@/views/student/StudentDashboard.vue'),
        meta: { title: '学习概览' }
      },
      {
        path: 'courses',
        name: 'StudentCourses',
        component: () => import('@/views/student/StudentCourses.vue'),
        meta: { title: '我的课程' }
      },
      {
        path: 'courses/:courseId',
        name: 'StudentCourseDetail',
        component: () => import('@/views/student/StudentCourseDetail.vue'),
        meta: { title: '课程详情' }
      },
      {
        path: 'problems',
        name: 'StudentProblems',
        component: () => import('@/views/student/StudentProblems.vue'),
        meta: { title: '题目列表' }
      },
      {
        path: 'problems/:problemId',
        name: 'StudentProblemDetail',
        component: () => import('@/views/student/StudentProblemDetail.vue'),
        meta: { title: '题目详情' }
      },
      {
        path: 'submissions',
        name: 'StudentSubmissions',
        component: () => import('@/views/student/StudentSubmissions.vue'),
        meta: { title: '提交记录' }
      },
      {
        path: 'submissions/:submissionId',
        name: 'StudentSubmissionDetail',
        component: () => import('@/views/student/StudentSubmissionDetail.vue'),
        meta: { title: '提交详情' }
      },
      {
        path: 'wrong-book',
        name: 'StudentWrongBook',
        component: () => import('@/views/student/StudentWrongBook.vue'),
        meta: { title: '错题本' }
      },
      {
        path: 'analytics',
        name: 'StudentAnalytics',
        component: () => import('@/views/student/StudentAnalytics.vue'),
        meta: { title: '学习分析' }
      },
      {
        path: 'teams',
        name: 'StudentTeams',
        component: () => import('@/views/student/StudentTeams.vue'),
        meta: { title: '我的团队' }
      },
      {
        path: 'teams/:teamId',
        name: 'StudentTeamDetail',
        component: () => import('@/views/student/StudentTeamDetail.vue'),
        meta: { title: '团队详情' }
      },
      {
        path: 'notifications',
        name: 'StudentNotifications',
        component: () => import('@/views/student/StudentNotifications.vue'),
        meta: { title: '通知中心' }
      }
    ]
  },

  // ─── Teacher routes ──────────────────────────────────
  {
    path: '/teacher',
    component: () => import('@/layouts/TeacherLayout.vue'),
    meta: { requiresAuth: true, role: 'TEACHER' },
    redirect: '/teacher/dashboard',
    children: [
      {
        path: 'dashboard',
        name: 'TeacherDashboard',
        component: () => import('@/views/teacher/TeacherDashboard.vue'),
        meta: { title: '教师工作台' }
      },
      {
        path: 'courses',
        name: 'TeacherCourses',
        component: () => import('@/views/teacher/TeacherCourses.vue'),
        meta: { title: '课程管理' }
      },
      {
        path: 'courses/:courseId',
        name: 'TeacherCourseDetail',
        component: () => import('@/views/teacher/TeacherCourseDetail.vue'),
        meta: { title: '课程详情' }
      },
      {
        path: 'problems',
        name: 'TeacherProblems',
        component: () => import('@/views/teacher/TeacherProblems.vue'),
        meta: { title: '题库管理' }
      },
      {
        path: 'problems/create',
        name: 'TeacherProblemCreate',
        component: () => import('@/views/teacher/TeacherProblemCreate.vue'),
        meta: { title: '创建题目' }
      },
      {
        path: 'problems/:problemId/edit',
        name: 'TeacherProblemEdit',
        component: () => import('@/views/teacher/TeacherProblemEdit.vue'),
        meta: { title: '编辑题目' }
      },
      {
        path: 'submissions',
        name: 'TeacherSubmissions',
        component: () => import('@/views/teacher/TeacherSubmissions.vue'),
        meta: { title: '提交记录' }
      },
      {
        path: 'review',
        name: 'TeacherReview',
        component: () => import('@/views/teacher/TeacherReview.vue'),
        meta: { title: '教学复盘' }
      },
      {
        path: 'students',
        name: 'TeacherStudents',
        component: () => import('@/views/teacher/TeacherStudents.vue'),
        meta: { title: '学生管理' }
      },
      {
        path: 'students/:studentId',
        name: 'TeacherStudentDetail',
        component: () => import('@/views/teacher/TeacherStudentDetail.vue'),
        meta: { title: '学生详情' }
      },
      {
        path: 'teams',
        name: 'TeacherTeams',
        component: () => import('@/views/teacher/TeacherTeams.vue'),
        meta: { title: '团队管理' }
      },
      {
        path: 'reports',
        name: 'TeacherReports',
        component: () => import('@/views/teacher/TeacherReports.vue'),
        meta: { title: '数据报表' }
      },
      {
        path: 'judge-monitor',
        name: 'TeacherJudgeMonitor',
        component: () => import('@/views/teacher/TeacherJudgeMonitor.vue'),
        meta: { title: '评测监控' }
      }
    ]
  },

  // ─── Admin routes ────────────────────────────────────
  {
    path: '/admin',
    component: () => import('@/layouts/AdminLayout.vue'),
    meta: { requiresAuth: true, role: 'ADMIN' },
    redirect: '/admin/dashboard',
    children: [
      {
        path: 'dashboard',
        name: 'AdminDashboard',
        component: () => import('@/views/admin/AdminDashboard.vue'),
        meta: { title: '管理控制台' }
      },
      {
        path: 'users',
        name: 'AdminUsers',
        component: () => import('@/views/admin/AdminUsers.vue'),
        meta: { title: '用户管理' }
      },
      {
        path: 'courses',
        name: 'AdminCourses',
        component: () => import('@/views/admin/AdminCourses.vue'),
        meta: { title: '课程管理' }
      },
      {
        path: 'judge-nodes',
        name: 'AdminJudgeNodes',
        component: () => import('@/views/admin/AdminJudgeNodes.vue'),
        meta: { title: '评测节点' }
      },
      {
        path: 'logs',
        name: 'AdminLogs',
        component: () => import('@/views/admin/AdminLogs.vue'),
        meta: { title: '系统日志' }
      },
      {
        path: 'settings',
        name: 'AdminSettings',
        component: () => import('@/views/admin/AdminSettings.vue'),
        meta: { title: '系统设置' }
      }
    ]
  },

  // ─── Fallback ────────────────────────────────────────
  {
    path: '/',
    redirect: '/login'
  },
  {
    path: '/:pathMatch(.*)*',
    redirect: '/404'
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior(_to, _from, savedPosition) {
    return savedPosition || { top: 0 }
  }
})

export default router
