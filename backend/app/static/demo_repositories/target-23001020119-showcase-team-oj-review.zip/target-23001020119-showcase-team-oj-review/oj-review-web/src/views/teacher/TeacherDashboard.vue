<template>
  <div class="page-container">
    <!-- 欢迎 -->
    <el-card class="welcome-card" shadow="never">
      <div class="welcome-content">
        <div>
          <h2>你好，{{ authStore.userName }} 老师</h2>
          <p>欢迎回到教师工作台，今天有 {{ pendingReview }} 份提交待批改</p>
        </div>
      </div>
    </el-card>

    <!-- 统计卡片 -->
    <el-row :gutter="20" class="stat-cards">
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-card-content">
            <div class="stat-icon" style="background:rgba(64,158,255,0.1);color:#409eff"><el-icon :size="28"><Reading /></el-icon></div>
            <div class="stat-info"><span class="stat-number">{{ courseCount }}</span><span class="stat-desc">我的课程</span></div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-card-content">
            <div class="stat-icon" style="background:rgba(103,194,58,0.1);color:#67c23a"><el-icon :size="28"><User /></el-icon></div>
            <div class="stat-info"><span class="stat-number">{{ studentCount }}</span><span class="stat-desc">学生总数</span></div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-card-content">
            <div class="stat-icon" style="background:rgba(230,162,60,0.1);color:#e6a23c"><el-icon :size="28"><Document /></el-icon></div>
            <div class="stat-info"><span class="stat-number">{{ submissionCount }}</span><span class="stat-desc">提交总数</span></div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-card-content">
            <div class="stat-icon" style="background:rgba(245,108,108,0.1);color:#f56c6c"><el-icon :size="28"><EditPen /></el-icon></div>
            <div class="stat-info"><span class="stat-number">{{ problemCount }}</span><span class="stat-desc">题目总数</span></div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="20">
      <!-- 课程概览 -->
      <el-col :span="14">
        <el-card shadow="never" class="section-card">
          <template #header>
            <div class="card-header">
              <span>我的课程</span>
              <el-button text type="primary" @click="$router.push('/teacher/courses')">查看全部</el-button>
            </div>
          </template>
          <el-table :data="courses" stripe style="width:100%">
            <el-table-column prop="name" label="课程" min-width="180" />
            <el-table-column prop="studentCount" label="学生" width="80" align="center" />
            <el-table-column prop="problemCount" label="题目" width="80" align="center" />
            <el-table-column prop="status" label="状态" width="100" align="center">
              <template #default="{ row }">
                <el-tag :type="row.status === 'PUBLISHED' ? 'success' : row.status === 'DRAFT' ? 'warning' : 'info'" size="small">
                  {{ row.status === 'PUBLISHED' ? '已发布' : row.status === 'DRAFT' ? '草稿' : '已归档' }}
                </el-tag>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>

      <!-- 最近提交 -->
      <el-col :span="10">
        <el-card shadow="never" class="section-card">
          <template #header>
            <div class="card-header">
              <span>最近提交</span>
              <el-button text type="primary" @click="$router.push('/teacher/submissions')">查看全部</el-button>
            </div>
          </template>
          <div v-for="item in recentSubmissions" :key="item.id" class="recent-item">
            <div class="recent-info">
              <span class="recent-name">{{ item.realName }} - {{ item.problemTitle }}</span>
              <span class="recent-time">{{ formatDate(item.createdAt) }}</span>
            </div>
            <el-tag :type="getStatusType(item.status)" size="small">{{ getStatusLabel(item.status) }}</el-tag>
          </div>
          <el-empty v-if="recentSubmissions.length === 0" description="暂无提交" :image-size="80" />
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import dayjs from 'dayjs'
import { useAuthStore } from '@/stores/auth'
import * as courseApi from '@/api/course'
import * as submissionApi from '@/api/submission'
import * as problemApi from '@/api/problem'
import type { Course, Submission } from '@/types'

const authStore = useAuthStore()
const courseCount = ref(0)
const studentCount = ref(0)
const submissionCount = ref(0)
const problemCount = ref(0)
const pendingReview = ref(0)
const courses = ref<Course[]>([])
const recentSubmissions = ref<Submission[]>([])

function getStatusType(s: string) {
  const m: Record<string, string> = { ACCEPTED: 'success', WRONG_ANSWER: 'danger', PENDING: 'warning', JUDGING: '' }
  return (m[s] || 'info') as 'success' | 'danger' | 'warning' | 'info' | ''
}
function getStatusLabel(s: string) {
  const m: Record<string, string> = { ACCEPTED: '通过', WRONG_ANSWER: '错误', PENDING: '等待', JUDGING: '评测中', COMPILE_ERROR: '编译错误' }
  return m[s] || s
}
function formatDate(d: string) { return dayjs(d).format('MM-DD HH:mm') }

onMounted(async () => {
  try {
    const [courseRes, subRes] = await Promise.allSettled([
      courseApi.getCourseList({ page: 1, pageSize: 10 }),
      submissionApi.getSubmissionList({ page: 1, pageSize: 8 })
    ])
    if (courseRes.status === 'fulfilled') {
      const data = courseRes.value.data as unknown as { records: Course[]; total: number }
      courses.value = data.records
      courseCount.value = data.total
      studentCount.value = data.records.reduce((sum, c) => sum + c.studentCount, 0)
      problemCount.value = data.records.reduce((sum, c) => sum + c.problemCount, 0)
    }
    if (subRes.status === 'fulfilled') {
      const data = subRes.value.data as unknown as { records: Submission[]; total: number }
      recentSubmissions.value = data.records
      submissionCount.value = data.total
      pendingReview.value = data.records.filter(s => s.status === 'PENDING' || s.status === 'JUDGING').length
    }
  } catch { /* ignore */ }
})
</script>

<style scoped>
.welcome-card { margin-bottom: 20px; border-radius: 12px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border: none; }
.welcome-card :deep(.el-card__body) { color: #fff; }
.welcome-content h2 { font-size: 22px; font-weight: 600; margin-bottom: 6px; }
.welcome-content p { font-size: 14px; opacity: 0.85; }
.stat-cards { margin-bottom: 20px; }
.stat-card { border-radius: 12px; }
.stat-card-content { display: flex; align-items: center; gap: 16px; }
.stat-icon { width: 56px; height: 56px; border-radius: 12px; display: flex; align-items: center; justify-content: center; }
.stat-number { display: block; font-size: 24px; font-weight: 700; color: #1d2129; }
.stat-desc { font-size: 13px; color: #909399; }
.section-card { border-radius: 12px; }
.card-header { display: flex; align-items: center; justify-content: space-between; }
.recent-item { display: flex; align-items: center; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #f0f0f0; }
.recent-item:last-child { border-bottom: none; }
.recent-info { display: flex; flex-direction: column; }
.recent-name { font-size: 13px; color: #303133; }
.recent-time { font-size: 12px; color: #c0c4cc; }
</style>
