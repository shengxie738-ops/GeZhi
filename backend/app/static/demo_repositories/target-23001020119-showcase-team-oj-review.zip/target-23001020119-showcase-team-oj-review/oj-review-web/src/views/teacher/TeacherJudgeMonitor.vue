<template>
  <div class="page-container">
    <div class="page-header">
      <h2>评测监控</h2>
      <el-button type="primary" @click="fetchStatus"><el-icon><Refresh /></el-icon> 刷新</el-button>
    </div>

    <!-- 队列状态 -->
    <el-row :gutter="20" class="stat-row">
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value" style="color:#e6a23c">{{ queueStatus.pending }}</div>
          <div class="stat-label">等待中</div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value" style="color:#409eff">{{ queueStatus.judging }}</div>
          <div class="stat-label">评测中</div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value" style="color:#67c23a">{{ queueStatus.avgWaitTime }}ms</div>
          <div class="stat-label">平均等待</div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value" style="color:#764ba2">{{ queueStatus.avgJudgeTime }}ms</div>
          <div class="stat-label">平均评测</div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 提交统计 -->
    <el-row :gutter="20">
      <el-col :span="14">
        <el-card shadow="never" class="section-card">
          <template #header><span>状态分布</span></template>
          <v-chart :option="statusPieOption" style="height:300px" autoresize />
        </el-card>
      </el-col>
      <el-col :span="10">
        <el-card shadow="never" class="section-card">
          <template #header><span>语言分布</span></template>
          <v-chart :option="langPieOption" style="height:300px" autoresize />
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import * as submissionApi from '@/api/submission'

const queueStatus = ref({ pending: 0, judging: 0, avgWaitTime: 0, avgJudgeTime: 0 })

const statusPieOption = computed(() => ({
  tooltip: { trigger: 'item', formatter: '{b}: {c} ({d}%)' },
  legend: { bottom: 0 },
  series: [{
    type: 'pie', radius: ['35%', '65%'],
    itemStyle: { borderRadius: 6, borderColor: '#fff', borderWidth: 2 },
    data: [
      { value: 450, name: '通过', itemStyle: { color: '#67c23a' } },
      { value: 120, name: '答案错误', itemStyle: { color: '#f56c6c' } },
      { value: 30, name: '编译错误', itemStyle: { color: '#909399' } },
      { value: 25, name: '超时', itemStyle: { color: '#e6a23c' } },
      { value: 15, name: '运行错误', itemStyle: { color: '#409eff' } }
    ]
  }]
}))

const langPieOption = computed(() => ({
  tooltip: { trigger: 'item', formatter: '{b}: {c} ({d}%)' },
  legend: { bottom: 0 },
  series: [{
    type: 'pie', radius: ['35%', '65%'],
    itemStyle: { borderRadius: 6, borderColor: '#fff', borderWidth: 2 },
    data: [
      { value: 300, name: 'C++', itemStyle: { color: '#409eff' } },
      { value: 180, name: 'Java', itemStyle: { color: '#e6a23c' } },
      { value: 120, name: 'Python', itemStyle: { color: '#67c23a' } },
      { value: 50, name: 'JavaScript', itemStyle: { color: '#f56c6c' } }
    ]
  }]
}))

async function fetchStatus() {
  try {
    const res = await submissionApi.getJudgeQueueStatus()
    queueStatus.value = res.data as unknown as typeof queueStatus.value
  } catch { /* ignore */ }
}

onMounted(fetchStatus)
</script>

<style scoped>
.stat-row { margin-bottom: 20px; }
.stat-card { border-radius: 12px; text-align: center; padding: 10px 0; }
.stat-value { font-size: 28px; font-weight: 700; }
.stat-label { font-size: 13px; color: #909399; margin-top: 4px; }
.section-card { border-radius: 12px; }
</style>
