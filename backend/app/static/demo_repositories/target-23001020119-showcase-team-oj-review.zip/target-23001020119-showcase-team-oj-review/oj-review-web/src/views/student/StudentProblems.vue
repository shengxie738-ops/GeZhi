<template>
  <div class="page-container">
    <div class="page-header">
      <h2>题目列表</h2>
    </div>

    <!-- 筛选栏 -->
    <el-card shadow="never" class="filter-card">
      <el-form :inline="true" :model="filterForm">
        <el-form-item label="搜索">
          <el-input v-model="filterForm.keyword" placeholder="搜索题目" clearable prefix-icon="Search" @clear="fetchData" @keyup.enter="fetchData" />
        </el-form-item>
        <el-form-item label="难度">
          <el-select v-model="filterForm.difficulty" placeholder="全部" clearable @change="fetchData">
            <el-option label="简单" value="EASY" />
            <el-option label="中等" value="MEDIUM" />
            <el-option label="困难" value="HARD" />
          </el-select>
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="filterForm.status" placeholder="全部" clearable @change="fetchData">
            <el-option label="未尝试" value="NOT_TRIED" />
            <el-option label="已通过" value="ACCEPTED" />
            <el-option label="未通过" value="FAILED" />
          </el-select>
        </el-form-item>
        <el-form-item label="知识点">
          <el-select v-model="filterForm.tag" placeholder="全部" clearable filterable @change="fetchData">
            <el-option v-for="tag in tags" :key="tag" :label="tag" :value="tag" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="fetchData">查询</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <!-- 题目表格 -->
    <el-card shadow="never" class="table-card">
      <el-table :data="problems" v-loading="loading" stripe style="width: 100%">
        <el-table-column prop="id" label="编号" width="80" align="center" />
        <el-table-column prop="title" label="题目" min-width="240">
          <template #default="{ row }">
            <el-link type="primary" @click="$router.push(`/student/problems/${row.id}`)">{{ row.title }}</el-link>
          </template>
        </el-table-column>
        <el-table-column prop="difficulty" label="难度" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="getDifficultyType(row.difficulty)" size="small">
              {{ getDifficultyLabel(row.difficulty) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="知识点" min-width="180">
          <template #default="{ row }">
            <el-tag v-for="tag in row.tags?.slice(0, 3)" :key="tag" size="small" class="tag-item">{{ tag }}</el-tag>
            <el-tag v-if="row.tags?.length > 3" size="small" type="info">+{{ row.tags.length - 3 }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="状态" width="100" align="center">
          <template #default="{ row }">
            <el-icon v-if="row.solveStatus === 'ACCEPTED'" :size="20" color="#67c23a"><CircleCheckFilled /></el-icon>
            <el-icon v-else-if="row.solveStatus === 'FAILED'" :size="20" color="#f56c6c"><CircleCloseFilled /></el-icon>
            <el-icon v-else :size="20" color="#c0c4cc"><Minus /></el-icon>
          </template>
        </el-table-column>
        <el-table-column label="通过率" width="100" align="center">
          <template #default="{ row }">{{ row.acceptanceRate }}%</template>
        </el-table-column>
        <el-table-column label="操作" width="100" align="center" fixed="right">
          <template #default="{ row }">
            <el-button type="primary" text size="small" @click="$router.push(`/student/problems/${row.id}`)">做题</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-wrapper">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :page-sizes="[20, 50, 100]"
          :total="total"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="fetchData"
          @current-change="fetchData"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import * as problemApi from '@/api/problem'
import type { Problem } from '@/types'

const loading = ref(false)
const problems = ref<(Problem & { solveStatus?: string })[]>([])
const total = ref(0)
const currentPage = ref(1)
const pageSize = ref(20)
const tags = ref<string[]>(['数组', '字符串', '动态规划', '贪心', '二分查找', '树', '图论', '排序'])

const filterForm = reactive({
  keyword: '',
  difficulty: '',
  status: '',
  tag: ''
})

function getDifficultyType(d: string) {
  const map: Record<string, string> = { EASY: 'success', MEDIUM: 'warning', HARD: 'danger' }
  return (map[d] || 'info') as 'success' | 'warning' | 'danger' | 'info'
}

function getDifficultyLabel(d: string) {
  const map: Record<string, string> = { EASY: '简单', MEDIUM: '中等', HARD: '困难' }
  return map[d] || d
}

async function fetchData() {
  loading.value = true
  try {
    const res = await problemApi.getProblemList({
      page: currentPage.value,
      pageSize: pageSize.value,
      keyword: filterForm.keyword || undefined,
      difficulty: (filterForm.difficulty as 'EASY' | 'MEDIUM' | 'HARD') || undefined,
      tag: filterForm.tag || undefined,
      status: filterForm.status || undefined
    })
    const data = res.data as unknown as { records: Problem[]; total: number }
    problems.value = data.records
    total.value = data.total
  } finally {
    loading.value = false
  }
}

onMounted(fetchData)
</script>

<style scoped>
.filter-card {
  margin-bottom: 20px;
  border-radius: 12px;
}

.table-card {
  border-radius: 12px;
}

.tag-item {
  margin-right: 4px;
  margin-bottom: 2px;
}

.pagination-wrapper {
  display: flex;
  justify-content: flex-end;
  margin-top: 16px;
}
</style>
