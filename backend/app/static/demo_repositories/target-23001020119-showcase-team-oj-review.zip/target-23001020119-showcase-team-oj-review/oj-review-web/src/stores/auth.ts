import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import type { UserInfo, LoginForm, RegisterForm, LoginResult, UserRole } from '@/types'
import * as authApi from '@/api/auth'
import router from '@/router'

const roleHomeMap: Record<UserRole, string> = {
  STUDENT: '/student/dashboard',
  TEACHER: '/teacher/dashboard',
  ADMIN: '/admin/dashboard'
}

export const useAuthStore = defineStore('auth', () => {
  // State
  const token = ref<string>(localStorage.getItem('token') || '')
  const refreshToken = ref<string>(localStorage.getItem('refreshToken') || '')
  const userInfo = ref<UserInfo | null>(null)

  // Getters
  const isLoggedIn = computed(() => !!token.value)
  const userRole = computed(() => userInfo.value?.role)
  const userName = computed(() => userInfo.value?.realName || userInfo.value?.username || '')

  // Actions
  async function login(form: LoginForm) {
    const res = await authApi.login(form)
    const data = res.data as unknown as LoginResult
    setTokenData(data.token, data.refreshToken)
    userInfo.value = data.user
    return data
  }

  async function register(form: RegisterForm) {
    const res = await authApi.register(form)
    return res.data
  }

  async function fetchUserInfo() {
    const res = await authApi.getCurrentUser()
    userInfo.value = res.data as unknown as UserInfo
    return userInfo.value
  }

  async function logout() {
    try {
      await authApi.logout()
    } catch {
      // 即使请求失败也继续清理
    } finally {
      clearAuth()
      router.push('/login')
    }
  }

  async function refreshAccessToken() {
    const res = await authApi.refreshToken({ refreshToken: refreshToken.value })
    const data = res.data as unknown as { token: string; refreshToken: string }
    setTokenData(data.token, data.refreshToken)
    return data.token
  }

  function setTokenData(newToken: string, newRefreshToken: string) {
    token.value = newToken
    refreshToken.value = newRefreshToken
    localStorage.setItem('token', newToken)
    localStorage.setItem('refreshToken', newRefreshToken)
  }

  function clearAuth() {
    token.value = ''
    refreshToken.value = ''
    userInfo.value = null
    localStorage.removeItem('token')
    localStorage.removeItem('refreshToken')
  }

  function redirectByRole(role?: UserRole) {
    const target = role ? roleHomeMap[role] : '/login'
    router.push(target)
  }

  return {
    // State
    token,
    refreshToken,
    userInfo,
    // Getters
    isLoggedIn,
    userRole,
    userName,
    // Actions
    login,
    register,
    fetchUserInfo,
    logout,
    refreshAccessToken,
    setTokenData,
    clearAuth,
    redirectByRole
  }
}, {
  persist: {
    key: 'oj-auth',
    pick: ['token', 'refreshToken', 'userInfo']
  }
})
