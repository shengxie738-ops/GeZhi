# OJ Review API 文档

## 基础信息

- 基础路径: `/api/v1`
- 认证方式: JWT Bearer Token（通过 `Authorization` 请求头）
- 响应格式: JSON

### 通用响应结构

```json
{
  "code": 0,
  "message": "success",
  "data": {}
}
```

### 错误码

| 错误码 | 说明 |
|--------|------|
| 0 | 成功 |
| 400 | 请求参数错误 |
| 401 | 未认证 |
| 403 | 权限不足 |
| 404 | 资源不存在 |
| 500 | 服务器内部错误 |

---

## 一、认证模块 `/api/v1/auth`

| 方法 | 路径 | 说明 | 认证 |
|------|------|------|------|
| POST | `/auth/login` | 用户登录，返回 JWT Token | 否 |
| POST | `/auth/register` | 用户注册 | 否 |
| POST | `/auth/refresh` | 刷新 Token | 是 |

---

## 二、用户模块 `/api/v1/users`

| 方法 | 路径 | 说明 | 权限 |
|------|------|------|------|
| GET | `/users/me` | 获取当前用户信息 | 登录用户 |
| GET | `/users` | 用户列表（分页） | 教师/管理员 |
| GET | `/users/{id}` | 获取用户详情 | 教师/管理员 |
| PUT | `/users/{id}` | 更新用户信息 | 管理员 |
| DELETE | `/users/{id}` | 删除用户 | 管理员 |

---

## 三、课程模块 `/api/v1/courses`

| 方法 | 路径 | 说明 | 权限 |
|------|------|------|------|
| GET | `/courses` | 课程列表（分页） | 登录用户 |
| GET | `/courses/{id}` | 课程详情 | 登录用户 |
| POST | `/courses` | 创建课程 | 教师 |
| PUT | `/courses/{id}` | 更新课程 | 教师（课程拥有者） |
| DELETE | `/courses/{id}` | 删除课程 | 教师/管理员 |

### 课程成员

| 方法 | 路径 | 说明 | 权限 |
|------|------|------|------|
| GET | `/courses/{id}/members` | 课程成员列表 | 登录用户 |
| POST | `/courses/{id}/members` | 添加课程成员 | 教师 |
| DELETE | `/courses/{id}/members/{userId}` | 移除课程成员 | 教师 |

---

## 四、章节模块 `/api/v1/chapters`

| 方法 | 路径 | 说明 | 权限 |
|------|------|------|------|
| GET | `/courses/{courseId}/chapters` | 章节列表 | 登录用户 |
| GET | `/chapters/{id}` | 章节详情 | 登录用户 |
| POST | `/chapters` | 创建章节 | 教师 |
| PUT | `/chapters/{id}` | 更新章节 | 教师 |
| DELETE | `/chapters/{id}` | 删除章节 | 教师 |

---

## 五、题目模块 `/api/v1/problems`

| 方法 | 路径 | 说明 | 权限 |
|------|------|------|------|
| GET | `/problems` | 题目列表（分页、筛选） | 登录用户 |
| GET | `/problems/{id}` | 题目详情 | 登录用户 |
| POST | `/problems` | 创建题目 | 教师 |
| PUT | `/problems/{id}` | 更新题目 | 教师 |
| DELETE | `/problems/{id}` | 删除题目 | 教师/管理员 |

### 测试用例

| 方法 | 路径 | 说明 | 权限 |
|------|------|------|------|
| GET | `/problems/{id}/test-cases` | 测试用例列表 | 教师 |
| POST | `/problems/{id}/test-cases` | 添加测试用例 | 教师 |
| PUT | `/test-cases/{id}` | 更新测试用例 | 教师 |
| DELETE | `/test-cases/{id}` | 删除测试用例 | 教师 |

---

## 六、提交模块 `/api/v1/submissions`

| 方法 | 路径 | 说明 | 权限 |
|------|------|------|------|
| POST | `/submissions` | 提交代码（触发判题） | 登录用户 |
| GET | `/submissions` | 提交记录列表（分页） | 登录用户 |
| GET | `/submissions/{id}` | 提交详情（含测试点结果） | 登录用户 |
| POST | `/submissions/callback` | 判题结果回调（内部接口） | 内部 Token |

### 代码草稿

| 方法 | 路径 | 说明 | 权限 |
|------|------|------|------|
| GET | `/drafts?problemId={id}&language={lang}` | 获取代码草稿 | 登录用户 |
| PUT | `/drafts` | 保存代码草稿 | 登录用户 |

---

## 七、判题服务 `/judge-api`（内部服务）

判题服务通过 Nginx 代理暴露，端口 8090。

| 方法 | 路径 | 说明 | 认证 |
|------|------|------|------|
| POST | `/judge/submit` | 提交判题任务到队列 | X-Internal-Token |
| GET | `/judge/status/{id}` | 查询判题状态 | X-Internal-Token |
| POST | `/judge/callback` | 判题结果回调 | X-Internal-Token |
| GET | `/health` | 健康检查 | 否 |

---

## 八、错题本模块 `/api/v1/wrong-book`

| 方法 | 路径 | 说明 | 权限 |
|------|------|------|------|
| GET | `/wrong-book` | 错题本列表 | 登录用户 |
| PUT | `/wrong-book/{id}` | 更新错题笔记/掌握状态 | 登录用户 |
| DELETE | `/wrong-book/{id}` | 删除错题记录 | 登录用户 |

---

## 九、团队模块 `/api/v1/teams`

| 方法 | 路径 | 说明 | 权限 |
|------|------|------|------|
| GET | `/teams` | 团队列表 | 登录用户 |
| GET | `/teams/{id}` | 团队详情 | 登录用户 |
| POST | `/teams` | 创建团队 | 教师 |
| PUT | `/teams/{id}` | 更新团队 | 教师 |
| POST | `/teams/{id}/members` | 添加团队成员 | 教师 |
| DELETE | `/teams/{id}/members/{userId}` | 移除团队成员 | 教师 |

---

## 十、教师复盘模块 `/api/v1/reviews`

| 方法 | 路径 | 说明 | 权限 |
|------|------|------|------|
| GET | `/reviews` | 复盘列表 | 教师 |
| POST | `/reviews` | 创建复盘评语 | 教师 |
| PUT | `/reviews/{id}` | 更新复盘评语 | 教师 |
| DELETE | `/reviews/{id}` | 删除复盘评语 | 教师 |

---

## 十一、通知模块 `/api/v1/notifications`

| 方法 | 路径 | 说明 | 权限 |
|------|------|------|------|
| GET | `/notifications` | 通知列表 | 登录用户 |
| PUT | `/notifications/{id}/read` | 标记已读 | 登录用户 |
| PUT | `/notifications/read-all` | 全部标记已读 | 登录用户 |

---

## 十二、数据分析模块 `/api/v1/analytics`

| 方法 | 路径 | 说明 | 权限 |
|------|------|------|------|
| GET | `/analytics/course/{id}/overview` | 课程概览统计 | 教师 |
| GET | `/analytics/course/{id}/students` | 学生统计 | 教师 |
| GET | `/analytics/course/{id}/problems` | 题目统计 | 教师 |
| GET | `/analytics/student/{id}` | 学生个人统计 | 教师/本人 |
