# OJ Review 数据库文档

## 概述

- 数据库: MySQL 8.0
- 字符集: utf8mb4
- 排序规则: utf8mb4_unicode_ci
- 存储引擎: InnoDB

共 15 张表，涵盖用户管理、课程管理、题目管理、提交判题、团队协作、教师复盘等核心功能。

---

## 表结构总览

| 序号 | 表名 | 说明 |
|------|------|------|
| 1 | sys_user | 用户表 |
| 2 | course | 课程表 |
| 3 | course_member | 课程成员表 |
| 4 | course_chapter | 课程章节表 |
| 5 | problem | 题目表 |
| 6 | problem_test_case | 测试用例表 |
| 7 | code_draft | 代码草稿表 |
| 8 | submission | 提交表 |
| 9 | submission_case_result | 测试点结果表 |
| 10 | wrong_book | 错题本表 |
| 11 | team | 团队表 |
| 12 | team_member | 团队成员表 |
| 13 | teacher_review | 教师复盘表 |
| 14 | notification | 通知表 |
| 15 | audit_log | 审计日志表 |

---

## 1. sys_user 用户表

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 用户ID |
| username | VARCHAR(50) UNIQUE | 用户名 |
| password | VARCHAR(255) | BCrypt 加密密码 |
| real_name | VARCHAR(50) | 真实姓名 |
| student_no | VARCHAR(30) UNIQUE | 学号/工号 |
| email | VARCHAR(100) | 邮箱 |
| avatar | VARCHAR(500) | 头像URL |
| role | ENUM(STUDENT, TEACHER, ADMIN) | 角色 |
| status | TINYINT | 0-禁用 1-启用 |
| last_login_at | DATETIME | 最后登录时间 |
| created_at | DATETIME | 创建时间 |
| updated_at | DATETIME | 更新时间 |

---

## 2. course 课程表

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 课程ID |
| name | VARCHAR(100) | 课程名称 |
| code | VARCHAR(50) UNIQUE | 课程代码 |
| description | TEXT | 课程描述 |
| cover_image | VARCHAR(500) | 封面图URL |
| teacher_id | BIGINT FK→sys_user | 授课教师ID |
| status | ENUM(DRAFT, PUBLISHED, ARCHIVED) | 课程状态 |
| max_students | INT | 最大学生数 |
| start_date | DATE | 开始日期 |
| end_date | DATE | 结束日期 |
| created_at | DATETIME | 创建时间 |
| updated_at | DATETIME | 更新时间 |

---

## 3. course_member 课程成员表

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 记录ID |
| course_id | BIGINT FK→course | 课程ID |
| user_id | BIGINT FK→sys_user | 用户ID |
| role | ENUM(STUDENT, TEACHER, TA) | 课程角色 |
| joined_at | DATETIME | 加入时间 |

唯一约束: (course_id, user_id)

---

## 4. course_chapter 课程章节表

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 章节ID |
| course_id | BIGINT FK→course | 课程ID |
| title | VARCHAR(200) | 章节标题 |
| description | TEXT | 章节描述 |
| sort_order | INT | 排序序号 |
| status | ENUM(DRAFT, PUBLISHED) | 状态 |
| created_at | DATETIME | 创建时间 |
| updated_at | DATETIME | 更新时间 |

---

## 5. problem 题目表

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 题目ID |
| title | VARCHAR(200) | 题目标题 |
| description | TEXT | 题目描述（Markdown） |
| input_description | TEXT | 输入说明 |
| output_description | TEXT | 输出说明 |
| sample_input | TEXT | 样例输入 |
| sample_output | TEXT | 样例输出 |
| hint | TEXT | 提示 |
| difficulty | ENUM(EASY, MEDIUM, HARD) | 难度 |
| time_limit_ms | INT | 时间限制（毫秒） |
| memory_limit_mb | INT | 内存限制（MB） |
| chapter_id | BIGINT FK→course_chapter | 所属章节 |
| course_id | BIGINT FK→course | 所属课程 |
| author_id | BIGINT FK→sys_user | 出题人 |
| status | ENUM(DRAFT, PUBLISHED, ARCHIVED) | 状态 |
| accept_count | INT | 通过次数 |
| submit_count | INT | 提交次数 |
| created_at | DATETIME | 创建时间 |
| updated_at | DATETIME | 更新时间 |

---

## 6. problem_test_case 测试用例表

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 测试用例ID |
| problem_id | BIGINT FK→problem | 题目ID |
| input_data | TEXT | 输入数据 |
| expected_output | TEXT | 期望输出 |
| is_public | TINYINT | 是否公开（样例） |
| score | DECIMAL(5,1) | 分值 |
| sort_order | INT | 排序序号 |
| created_at | DATETIME | 创建时间 |

---

## 7. code_draft 代码草稿表

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 草稿ID |
| user_id | BIGINT FK→sys_user | 用户ID |
| problem_id | BIGINT FK→problem | 题目ID |
| language | VARCHAR(20) | 编程语言 |
| source_code | TEXT | 源代码 |
| created_at | DATETIME | 创建时间 |
| updated_at | DATETIME | 更新时间 |

唯一约束: (user_id, problem_id, language)

---

## 8. submission 提交表

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 提交ID |
| user_id | BIGINT FK→sys_user | 用户ID |
| problem_id | BIGINT FK→problem | 题目ID |
| course_id | BIGINT FK→course | 课程ID |
| language | VARCHAR(20) | 编程语言 |
| source_code | TEXT | 源代码 |
| status | ENUM | 判题状态 |
| score | DECIMAL(6,1) | 得分 |
| time_used_ms | INT | 运行时间（毫秒） |
| memory_used_kb | INT | 内存使用（KB） |
| compile_output | TEXT | 编译输出 |
| runtime_output | TEXT | 运行时输出 |
| passed_case_count | INT | 通过测试点数 |
| total_case_count | INT | 总测试点数 |
| ip_address | VARCHAR(45) | 提交IP |
| created_at | DATETIME | 提交时间 |
| judged_at | DATETIME | 判题完成时间 |

---

## 9. submission_case_result 测试点结果表

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 结果ID |
| submission_id | BIGINT FK→submission | 提交ID |
| test_case_id | BIGINT FK→problem_test_case | 测试用例ID |
| status | VARCHAR(30) | 状态 |
| time_used_ms | INT | 运行时间 |
| memory_used_kb | INT | 内存使用 |
| actual_output | TEXT | 实际输出 |
| error_message | TEXT | 错误信息 |
| created_at | DATETIME | 创建时间 |

---

## 10. wrong_book 错题本表

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 记录ID |
| user_id | BIGINT FK→sys_user | 用户ID |
| problem_id | BIGINT FK→problem | 题目ID |
| submission_id | BIGINT FK→submission | 最近错误提交ID |
| error_type | VARCHAR(30) | 错误类型 |
| note | TEXT | 用户笔记 |
| is_mastered | TINYINT | 是否已掌握 |
| created_at | DATETIME | 创建时间 |
| updated_at | DATETIME | 更新时间 |

唯一约束: (user_id, problem_id)

---

## 11. team 团队表

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 团队ID |
| name | VARCHAR(100) | 团队名称 |
| description | TEXT | 团队描述 |
| course_id | BIGINT FK→course | 所属课程 |
| leader_id | BIGINT FK→sys_user | 队长ID |
| max_members | INT | 最大成员数 |
| created_at | DATETIME | 创建时间 |
| updated_at | DATETIME | 更新时间 |

---

## 12. team_member 团队成员表

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 记录ID |
| team_id | BIGINT FK→team | 团队ID |
| user_id | BIGINT FK→sys_user | 用户ID |
| role | ENUM(MEMBER, LEADER) | 团队内角色 |
| joined_at | DATETIME | 加入时间 |

唯一约束: (team_id, user_id)

---

## 13. teacher_review 教师复盘表

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 复盘ID |
| teacher_id | BIGINT FK→sys_user | 教师ID |
| course_id | BIGINT FK→course | 课程ID |
| submission_id | BIGINT FK→submission | 关联提交 |
| problem_id | BIGINT | 关联题目 |
| team_id | BIGINT FK→team | 关联团队 |
| content | TEXT | 复盘内容（Markdown） |
| review_type | ENUM(SUBMISSION, TEAM, PROBLEM, GENERAL) | 复盘类型 |
| created_at | DATETIME | 创建时间 |
| updated_at | DATETIME | 更新时间 |

---

## 14. notification 通知表

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 通知ID |
| user_id | BIGINT FK→sys_user | 接收用户ID |
| title | VARCHAR(200) | 通知标题 |
| content | TEXT | 通知内容 |
| type | ENUM(SYSTEM, COURSE, JUDGE, TEAM, REVIEW) | 通知类型 |
| is_read | TINYINT | 是否已读 |
| related_id | BIGINT | 关联业务ID |
| related_type | VARCHAR(30) | 关联业务类型 |
| created_at | DATETIME | 创建时间 |

---

## 15. audit_log 审计日志表

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT PK | 日志ID |
| user_id | BIGINT FK→sys_user | 操作用户ID |
| action | VARCHAR(50) | 操作类型 |
| resource_type | VARCHAR(30) | 资源类型 |
| resource_id | BIGINT | 资源ID |
| detail | TEXT | 操作详情（JSON） |
| ip_address | VARCHAR(45) | IP地址 |
| user_agent | VARCHAR(500) | User-Agent |
| created_at | DATETIME | 创建时间 |

---

## ER 关系图（文本）

```
sys_user ─┬─< course (teacher_id)
          ├─< course_member (user_id)
          ├─< problem (author_id)
          ├─< code_draft (user_id)
          ├─< submission (user_id)
          ├─< wrong_book (user_id)
          ├─< team_member (user_id)
          ├─< team (leader_id)
          ├─< teacher_review (teacher_id)
          ├─< notification (user_id)
          └─< audit_log (user_id)

course ─┬─< course_member
        ├─< course_chapter
        ├─< problem
        ├─< submission
        ├─< team
        └─< teacher_review

course_chapter ─< problem

problem ─┬─< problem_test_case
         ├─< code_draft
         ├─< submission
         └─< wrong_book

submission ─┬─< submission_case_result
            ├─< wrong_book
            └─< teacher_review

team ─┬─< team_member
      └─< teacher_review
```
