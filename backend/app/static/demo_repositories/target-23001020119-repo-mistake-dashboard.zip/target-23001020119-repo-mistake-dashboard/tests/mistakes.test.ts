import { summarizeMistakes } from '../src/mistakes';

it('marks repeated mistakes as high risk', () => {
  expect(summarizeMistakes([{ tag: 'SQL', count: 3 }])[0].level).toBe('high');
});
