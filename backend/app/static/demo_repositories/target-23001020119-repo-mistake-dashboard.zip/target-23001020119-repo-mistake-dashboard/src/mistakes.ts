export type Mistake = { tag: string; count: number };

export function summarizeMistakes(items: Mistake[]) {
  return items.sort((a, b) => b.count - a.count).map(item => ({ ...item, level: item.count >= 3 ? 'high' : 'medium' }));
}
