import { summarizeMistakes } from './mistakes';

const rows = summarizeMistakes([
  { tag: 'B+树', count: 3 },
  { tag: '递归边界', count: 2 }
]);
console.log(rows);
